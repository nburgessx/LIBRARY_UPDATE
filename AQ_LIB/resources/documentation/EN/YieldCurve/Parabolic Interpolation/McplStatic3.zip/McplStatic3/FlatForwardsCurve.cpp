#include"FlatForwardsCurve.h"

#include "numrec/dnrutil.h"


namespace MCPL
{

	void FlatForwardsCurve::create( 
		const vector<double>&   Futures,	
		const vector<double>&   Adjustmnts,
		const vector<date>&     FuturesDates,
		const vector<date>      swapEffDates, 
		const vector<date>      swapDates, 
		const vector<double> &  swapRates, 
		const vector<double> &  swapTolerances, 
		const SwapType          sType,
		date &            today, 
		const map<date,double>& cashParams, 
		CURRENCY          ccy, 
		double            firstFixRate,
		Handle<RatesCurve>  swapDiscountCurve)
	{

		m_swapsDiscountCurve = swapDiscountCurve;
		if ( !m_swapsDiscountCurve )
			m_swapsDiscountCurve = Handle<RatesCurve>(this,null_deleter());

		if ( (m_today != today) 
			|| ( ccy != m_ccy )
			|| sType != m_swapType 
			|| !cmpvecs(swapEffDates, m_swapEffDates) 
			|| !cmpvecs(swapDates, m_swapMaturityDates) 
			|| !cmpmaps(cashParams, m_cashParams)
			|| !cmpvecs(FuturesDates, m_futuresEnds)
			|| !cmpvecs(Futures, m_futures)
			|| !cmpvecs(Adjustmnts, m_futuresAdj)
			|| firstFixRate != m_firstFixRate
			) 
		{
			set_currency_defaults(ccy, sType);
			m_today = today;
			m_spot = spot(today, ccy);

			m_swapType = sType;
			m_swapMaturityDates = swapDates;
			m_swapEffDates = swapEffDates;
			m_parRates = swapRates;
			m_swapTolerances = swapTolerances;
			m_cashParams = cashParams;

			m_firstFixRate = firstFixRate;

			m_futures.clear();
			if (Futures.size() > 0)
				for (unsigned int i=0; i<Futures.size(); i++)
				{
					m_futures.push_back(Futures[i]);
				}

			m_futuresAdj.clear();
			m_futuresAdj.resize(m_futures.size(), 0.0);
			if (Adjustmnts.size() > 0)
				for (unsigned int i=0; i<Adjustmnts.size(); i++)
				{
					m_futuresAdj[i] = Adjustmnts[i];
				}

			m_futuresStarts.clear();
			m_futuresStarts.resize(m_futures.size(), 0.0);
			if (FuturesDates.size() > 0)
				for (unsigned int i=0; i<Adjustmnts.size(); i++)
				{
					m_futuresStarts[i] = nthIMMDate(FuturesDates[i], 1, 3).roll(m_hols, 0, true);
				}

			clear();
			calculateDates();
			calculateCurve();
		} 
		else 
		{
			m_cashParams = cashParams;
			m_parRates = swapRates;
			m_swapTolerances = swapTolerances;

			m_futures.clear();
			if (Futures.size() > 0)
				for (unsigned int i=0; i<Futures.size(); i++)
				{
					m_futures.push_back(Futures[i]);
				}
			m_futuresAdj.clear();
			m_futuresAdj.resize(m_futures.size(), 0.0);
			if (Adjustmnts.size() > 0)
				for (unsigned int i=0; i<Adjustmnts.size(); i++)
				{
					m_futuresAdj[i] = Adjustmnts[i];
				}
			clear();
			calculateCurve();
		}
	}



	void FlatForwardsCurve::calculateDates()
	{
		unsigned int n_futures = m_futures.size();

		if (n_futures)
		{
			// Set up IMM start, end dates and day count fractions.
			m_futuresEnds.clear(); m_futuresEnds.resize(n_futures);
			m_futuresDCF.clear();  m_futuresDCF.resize( n_futures );

			for (unsigned int i = 0 ; i < n_futures ; ++i ) 
			{
				//TODO: fix for non-contiguous futures, i.e. do starts in IMM, maturities +3m. then deal with gaps/overlaps
				m_futuresEnds[i] = nthIMMDate(m_futuresStarts[i], 2, 3).roll(m_hols, 0, true);
				if (i>0 && m_futuresStarts[i] != m_futuresEnds[i-1])
					mcpl_error("futures dates do not form a contiguous strip");
				m_futuresDCF[i] = dayCountFrac(m_basis, m_futuresStarts[i] , m_futuresEnds[i] );
			}
		}

		unsigned int n_swaps = m_swapMaturityDates.size();
		if ( n_swaps > 0 )
		{
			// Set up swaps data
			m_swapCashflows.clear();
			m_swapLastDates.clear();

			for ( unsigned int j = 0 ; j < n_swaps ; ++j )
			{
				Swap tmpswap = Swap(PAY, m_swapType,  m_swapEffDates[j], m_swapMaturityDates[j], m_swapEffDates[j], 1, m_parRates[j], 0, m_swapHols, m_ccy);
				m_swapCashflows.push_back( tmpswap );
                if (n_futures > 0) // this is a proxy condition for 'we are building OIS curve'
				    m_swapLastDates.push_back( tmpswap.getLastDate() );
                else
				    m_swapLastDates.push_back( tmpswap.getLastDateFixed() );
			}
		}
	}


	void FlatForwardsCurve::calculateCurve()
	{
		discountCurve cashCurve;

		// bootstrap cash part of the curve
		cashCurve.set(m_today , 1.0 );  set(m_today , 1.0 );
        m_lastFittedDate = m_today;

        double spotDF = 0.0;
        if (m_cashParams.find(m_spot) != m_cashParams.end())
        {
		    double dcf = dayCountFrac(m_basis, m_today, m_spot);
		    spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );
		    cashCurve.set(m_spot , spotDF); set(m_spot , spotDF);
            m_lastFittedDate = m_spot;
        }
		date cashDateAfterIMM1(0); // date of the first cash rate after the first futures date
		map<date,double>::const_iterator it = m_cashParams.begin();
		++it;
		for (  ; it != m_cashParams.end() ; ++it ) 
		{
			double dcf = dayCountFrac( m_basis, m_spot, it->first );
			cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
			set(it->first, spotDF/(1+it->second*dcf ) );
			if ((long)cashDateAfterIMM1 == 0l)
                if (m_futuresStarts.size())
                {
                    if (it->first >= m_futuresStarts[0])
				        cashDateAfterIMM1 = it->first;
                }
                else
				    cashDateAfterIMM1 = it->first;
			m_lastFittedDate = it->first;
		}

		// set the stub discount factor by taking the DF at first cash maturity after IMM1 date and 
		//   interpolating back to IMM1 using the flat rate assumption and the first futures rate
		double immDF = 0.0;
		if (m_futures.size())
		{
			discountCurve::clear();
			discountCurve::set(m_today , 1.0 );
			discountCurve::set(m_spot , spotDF );

            if ((long)cashDateAfterIMM1 > 0l)
            {   // last cash date after first future
			    double cashDF = cashCurve.get(cashDateAfterIMM1);
			    double ffRate = (100.0-m_futures[0])/100.0 - m_futuresAdj[0]/10000.0;
			    discountCurve futCurve;
			    futCurve.set(m_futuresStarts[0], 1.0);
			    futCurve.set(m_futuresEnds[0], 1.0/(1+ffRate*m_futuresDCF[0]));
			    immDF = cashDF / futCurve.get(cashDateAfterIMM1);
            }
            else
            {   // last cash date before first future
			    double cashDF = cashCurve.get(m_lastFittedDate);

		        double DF1 = cashCurve.get(m_lastFittedDate-1);
		        double DF2 = cashCurve.get(m_lastFittedDate);
		        double dcf = dayCountFrac(act_365f, m_lastFittedDate-1, m_lastFittedDate);
		        double rate = dcf==0 ? 0 : zero(DF2/DF1, dcf);
			    immDF = cashDF / (1 + rate*dayCountFrac(act_365f, m_lastFittedDate, m_futuresStarts[0]));
            }

			discountCurve::set(m_futuresStarts[0], immDF );
		}
		else
		{
			// if no futures, just use the cash curve. do nothing as we extended both curves simultaneously up to now.
		}

		// bootstrap futures
		for (unsigned int i=0; i<m_futures.size(); i++)
		{
			double ffRate = (100.0-m_futures[i])/100.0 - m_futuresAdj[i]/10000.0;
			immDF /= (1.0 + ffRate * m_futuresDCF[i]); // the first immDF was set above!
			discountCurve::set(m_futuresEnds[i], immDF );
			m_lastFittedDate = m_futuresEnds[i];
		}
		// bootstrap swaps
		for ( unsigned int i=0 ; i < m_parRates.size() ; i++ )
		{
			if ( m_futures.size()==0 || (m_swapLastDates[i] > m_futuresEnds[m_futures.size()-1]) )
			{
				m_swapCashflows[i].setCoupon(m_parRates[i]);
				if (!fitParSwap(i) )
					break;
				else
					m_lastFittedDate = m_swapLastDates[i];
			}
		}
	}


	namespace FlatForwardsCurveFitFn
	{
		int index;
		Handle<FlatForwardsCurve> fitcurve;
	}

	bool FlatForwardsCurve::fitParSwap(int index)
	{
		FlatForwardsCurveFitFn::index = index;
		FlatForwardsCurveFitFn::fitcurve = Handle<FlatForwardsCurve>(this,null_deleter());

		double x1= -0.005;
		double x2=  0.03;

		double flatSegmentRate = linearFitter( FlatForwardsCurveFitFn::func_linear , x1, x2, max(1e-7 /*1/1000th of bp*/, m_swapTolerances[index]) );
		// nothing to do now as the curve should already be fitted for the specified instrument

		return true;
	}


	namespace FlatForwardsCurveFitFn
	{
		double func_linear(double flatSegmentRate)
		{
			// update the curve
			double dcf = dayCountFrac(fitcurve->m_basis, fitcurve->m_lastFittedDate, fitcurve->m_swapLastDates[index]);
			double dfLast = fitcurve->get(fitcurve->m_lastFittedDate);
			double dfFwd = exp(-flatSegmentRate*dcf); // assume the flatSegmentRate is continuously compounded rate
			fitcurve->set(fitcurve->m_swapLastDates[index], dfLast * dfFwd );
			// re-price the swap
			if ( fitcurve->m_swapsDiscountCurve ) // Discount using suppplied discount curve rather than the curve being built
			{
				fitcurve->m_swapCashflows[index].setCurves(fitcurve->m_swapsDiscountCurve, fitcurve);
			}
			else
			{
				fitcurve->m_swapCashflows[index].setCurves(fitcurve, fitcurve);
			}
			if (fitcurve->m_firstFixRate != 0.0)
				fitcurve->m_swapCashflows[index].fixFirst(fitcurve->m_firstFixRate);
			double swapRate = (fitcurve->m_swapCashflows[index]).Solve(0, solveFORCOUPON);
			double targetRate = fitcurve->m_parRates[index];

			return  ( swapRate - targetRate );
		}
	}





























	void FlatForwardsCurve::set_currency_defaults(CURRENCY ccy)
	{
		m_ccy = ccy;

		switch(m_ccy)
		{
		case USD:
			set_currency_defaults(ccy, SB3);
			break;
		case EUR:
			set_currency_defaults(ccy, AB6);
			break;
		case JPY:
			set_currency_defaults(ccy, SB6);
			break;
		case GBP:
			set_currency_defaults(ccy, SB6);
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}

	}

	void FlatForwardsCurve::set_currency_defaults(CURRENCY ccy, SwapType type)
	{

		vanillaSwapParams(ccy, type, m_fixedPmtsPerYear, m_fltPmtsPerYear, m_fixedBasis, m_basis) ;

		m_swapType = type;
		m_ccy = ccy;
		this->setCurrency(m_ccy);

		switch(ccy)
		{
		case USD:
			m_swapHols = HOLIDAYCAL(UK | USA);
			m_hols = UK;
			break;
		case EUR:
			m_swapHols = EUTARG;
			m_hols = EUTARG;
			break;
		case JPY:
			m_swapHols = JP;
			m_hols = UK;
			break;
		case GBP:
			m_swapHols = UK;
			m_hols = UK;
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}
	}


	bool FlatForwardsCurve::cmpvecs( const vector<double> & v1, const vector<double> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}
	//
	bool FlatForwardsCurve::cmpvecs( const vector<date> & v1, const vector<date> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}
	//
	bool FlatForwardsCurve::cmpmaps( const map<date,double> & v1, map<date,double> & v2)
	{
		if ( v1.size() != v2.size() ) return false;
		else 
		{
			bool test = true;
			map<date,double>::const_iterator it1 = v1.begin();
			map<date,double>::const_iterator it2 = v2.begin();
			while ( test && ( it1 != v1.end() ) && ( it2 != v2.end() ) )
			{
				if ( it1->first != it2->first ) 
					test = false;

				++it1;
				++it2;
			}		
			return test;
		}
		return false; // should not get here.
	}



	// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
	Handle<PPCurves> FlatForwardsCurve::create_PPCurves( double pp_val, bool CalculateGammaCurves)
	{
		Handle<PPCurves> pp_curves = Handle<PPCurves>(new PPCurves());

		int nHedges =  m_futures.size() + m_cashParams.size() + m_parRates.size(); 
		pp_curves->resize( nHedges ); 
		pp_curves->set_ppsize( pp_val/100.0 ); // set the perturb size in factor (i.e. 1 = 1%)

		pp_curves->base() = Handle<RatesCurve>(new FlatForwardsCurve(*this));

		unsigned int i=0;
		// up
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			clear();
			calculateCurve();
			pp_curves->label(i) = "cash " + (string) it->first;
			pp_curves->up(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] -= pp_val;
			clear();
			calculateCurve();
			pp_curves->label(i) = "Fut " + (string) m_futuresStarts[j];
			pp_curves->up(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
			m_futures[j] += pp_val;
		}
		for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
		{
			m_parRates[j] += pp_val/100.00;
			clear();
			calculateCurve();
			pp_curves->label(i) = "Swap " + (string) m_swapMaturityDates[j];
			pp_curves->up(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
			m_parRates[j] -= pp_val/100.00;
		}


		// dn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			clear();
			calculateCurve();
			pp_curves->dn(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			clear();
			calculateCurve();
			pp_curves->dn(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
			m_futures[j] -= pp_val;
		}
		for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
		{
			m_parRates[j] -= pp_val/100.00;
			clear();
			calculateCurve();
			pp_curves->dn(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
			m_parRates[j] += pp_val/100.00;
		}

		if (CalculateGammaCurves)
		{
			//upup
			for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
				m_futures[j] -= pp_val;
			for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
				it->second += pp_val/100.0;
			for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
				m_parRates[j] += pp_val/100.00;

			i=0;
			for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			{
				it->second += pp_val/100.0;
				partialClear();
				calculateCurve();
				pp_curves->upup(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				it->second -= pp_val/100.0;
			}
			for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			{
				m_futures[j] -= pp_val;
				partialClear();
				calculateCurve();
				pp_curves->upup(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				m_futures[j] += pp_val;
			}
			for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
			{
				m_parRates[j] += pp_val/100.00;
				partialClear();
				calculateCurve();
				pp_curves->upup(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				m_parRates[j] -= pp_val/100.00;
			}

			// updn
			i=0;
			for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			{
				it->second -= pp_val/100.0;
				partialClear();
				calculateCurve();
				pp_curves->updn(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				it->second += pp_val/100.0;
			}
			for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			{
				m_futures[j] += pp_val;
				partialClear();
				calculateCurve();
				pp_curves->updn(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				m_futures[j] -= pp_val;
			}
			for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
			{
				m_parRates[j] -= pp_val/100.00;
				partialClear();
				calculateCurve();
				pp_curves->updn(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				m_parRates[j] += pp_val/100.00;
			}


			//dnup
			for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
				m_futures[j] += 2.0*pp_val;
			for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
				it->second -= 2.0*pp_val/100.0;
			for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
				m_parRates[j] -= 2.0*pp_val/100.00;

			i=0;
			for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			{
				it->second += pp_val/100.0;
				partialClear();
				calculateCurve();
				pp_curves->dnup(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				it->second -= pp_val/100.0;
			}
			for ( unsigned int j=0 ; j < m_futures.size() ; ++j )
			{
				m_futures[j] -= pp_val;
				partialClear();
				calculateCurve();
				pp_curves->dnup(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				m_futures[j] += pp_val;
			}
			for ( unsigned int j=0 ; j < m_parRates.size() ; ++j )
			{
				m_parRates[j] += pp_val/100.00;
				partialClear();
				calculateCurve();
				pp_curves->dnup(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				m_parRates[j] -= pp_val/100.00;
			}

			// dndn
			i=0;
			for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			{
				it->second -= pp_val/100.0;
				partialClear();
				calculateCurve();
				pp_curves->dndn(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				it->second += pp_val/100.0;
			}
			for ( unsigned int j=0  ; j < m_futures.size() ; ++j ) 
			{
				m_futures[j] += pp_val;
				partialClear();
				calculateCurve();
				pp_curves->dndn(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				m_futures[j] -= pp_val;
			}
			for ( unsigned int j=0  ; j < m_parRates.size() ; ++j ) 
			{
				m_parRates[j] -= pp_val/100.00;
				partialClear();
				calculateCurve();
				pp_curves->dndn(i++)= Handle<RatesCurve>(new FlatForwardsCurve(*this));
				m_parRates[j] += pp_val/100.00;
			}


			for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
				m_futures[j] -= pp_val;
			for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
				it->second += pp_val/100.0;
			for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
				m_parRates[j] += pp_val/100.0;
		}

		partialClear();
		calculateCurve();

		return pp_curves;
	}





} // namespace MCPL