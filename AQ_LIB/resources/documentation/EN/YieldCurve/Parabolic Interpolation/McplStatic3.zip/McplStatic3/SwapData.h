#pragma once
#ifndef MCPLSWAPDATA_H
#define MCPLSWAPDATA_H
#include "MCPL.h"

#include<string>
#include<vector>

#include "mcpldefs.h"
#include "storageclasses.h"
#include "discountCurve.h"
#include "RatesCurve.h"
//#include "PPCurves.h"

using namespace std;

namespace MCPL
{


	typedef interpolatingStore<date,  double, linearInterpolator> BasisSpreadCurve;

	/********************************************************************
	a class which contains a zero curve (which can interpolate between 
	dates) and a simple string to double map
	********************************************************************/
	
	class swapData : public discountCurve, public RatesCurve
	{
	private:

		DayBasis m_basis;
		CURRENCY m_ccy;

		unsigned m_period_months;
		HOLIDAYCAL m_hols;


		//	ForecastCurveType m_type; // CMS or LIBOR

		virtual void dummy() {} // Make this a polymorphic object, so dynamic_cast works.

		void calculateCurve() {};
		void addDependent(Handle<RatesCurve> dependentCurve_) {};

	protected:

		BasisSpreadCurve m_basisSpread;

	public:

		swapData() : m_ccy(USD), m_period_months(3) 
		{ 
			m_basis = getLiborBasis(m_ccy); 
			m_hols = liborHolidays( m_ccy );
			m_basisSpread.setFlatVol(0);
		} // Default curve is 3m $LIBOR

		swapData(discountCurve & dc) : discountCurve(dc), m_ccy(USD), m_period_months(3)
		{ 
			m_basis = getLiborBasis(m_ccy);
			m_hols = liborHolidays( m_ccy );
			m_basisSpread.setFlatVol(0);
		}

		swapData(discountCurve & dc, CURRENCY ccy) : discountCurve(dc), m_ccy(ccy), m_period_months(3)
		{ 
			m_basis = getLiborBasis(m_ccy); 
			m_hols = liborHolidays( m_ccy );
			m_basisSpread.setFlatVol(0);
		}

		swapData(discountCurve & dc, CURRENCY ccy, unsigned period_months) : 
		discountCurve(dc), 
			m_ccy(ccy), 
			m_period_months(period_months)
		{ 
			m_basis = getLiborBasis( m_ccy ); 
			m_hols = liborHolidays( m_ccy );
			m_basisSpread.setFlatVol(0);
		}

		swapData(discountCurve & dc, CURRENCY ccy, unsigned period_months, std::map<date, double> & basisSpread) : 
		discountCurve(dc), 
			m_ccy(ccy), 
			m_period_months(period_months)
		{ 
			m_basis = getLiborBasis( m_ccy ); 
			m_hols = liborHolidays( m_ccy );
			if ( basisSpread.size() == 1 )
			{
				m_basisSpread.setFlatVol(basisSpread.begin()->second);
			}
			else
			{
				for ( std::map<date, double>::iterator it = basisSpread.begin() ; it != basisSpread.end() ; ++it )
				{
					m_basisSpread.set(it->first, it->second);
				}
			}
		}

		virtual Handle<RatesCurve> clone() { return Handle<swapData>(new swapData(*this)); }

		virtual void clear() 
		{ 
			m_basisSpread.clear();
			discountCurve::clear();
		}

		//void partialClear() { clear(); }

		//Doesn't clear basis spread data. Gets called from create_PP
		void partialClear()
		{ 
			discountCurve::clear();
		}

		double getZero(const date & d1, const date & d2, DayBasis basis); // forward rate from d1 to d2
		double getZero(const date & d1,const date & d2) { return getZero(d1, d2, m_basis); } // forward rate from d1 to d2

		// Get continuously compounded rate
		double getCCRate(date & d1, date & d2, DayBasis basis);

		double forecastFixing(date & reset_date ); 

		double getDiscountFactor(const date & d) { return get(d); }
		double getRatesDiscountFactor(const date & d) { return get(d); }
		DayBasis getDayBasis() { return m_basis; }
		CURRENCY getCurrency() { return m_ccy; }

		void setDiscountFactor(date & d, double value) { set(d, value); }
		void setDayBasis( DayBasis basis ) { m_basis=basis; }
		void setCurrency( CURRENCY ccy ) { m_ccy = ccy; }

		void setDefaults( CURRENCY ccy, unsigned p)
		{ 
			m_basis = getLiborBasis( ccy ); 
			m_hols = liborHolidays( ccy );
			m_period_months = p;
		}

		void setBasisCurve( std::map<date, double> & basisSpread )
		{
			m_basisSpread.clear();
			/*for ( std::map<date, double>::iterator it = basisSpread.begin() ; it != basisSpread.end() ; ++it )
			{
				m_basisSpread.set(it->first, it->second);
			}*/
			for (auto& bs : basisSpread)
				m_basisSpread.set(bs.first, bs.second);
		}

		BasisSpreadCurve getBasisCurve() { return m_basisSpread; }

		typedef discountCurve::labels labels;
		labels getZeroLabels() { return getLabels(); }
		labels getDiscountFactorLabels() { return getLabels(); }

		date firstDate() { return discountCurve::firstDate();}
		date lastDate() { return discountCurve::lastDate(); }
		void shiftCurve(double dR, DayBasis basis) { discountCurve::shiftCurve(dR, basis); }

		shared_ptr<vector<long>> getLabels() { return discountCurve::getLabels(); }
		//Handle<PPCurves>  create_PPCurves(double pp_val, bool CalculateGammaCurves = true) {};
	};

	//typedef RatesCurveWrapper<swapData> swapData2;

	/*
	class swapData
	{
	private:


	mutable discountCurve m_discountCurve;

	public:


	double getZero(date & d1, date & d2, DayBasis basis); // forward rate from d1 to d2


	double getDiscountFactor(date & d) { return m_discountCurve.get(d); }
	void setDiscountFactor(date & d, double value) { m_discountCurve.set(d, value); }

	typedef discountCurve::labels labels;
	labels getZeroLabels() { return m_discountCurve.getLabels(); }
	labels getDiscountFactorLabels() { return m_discountCurve.getLabels(); }

	void clear() { 	m_discountCurve.clear(); }

	};
	*/

} //namespace MCPL

#endif //MCPLSWAPDATA_H