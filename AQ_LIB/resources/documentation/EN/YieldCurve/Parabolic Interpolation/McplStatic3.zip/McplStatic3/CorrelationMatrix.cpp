#include "CorrelationMatrix.h"

//#define DEBUG

namespace MCPL
{


	CorrelationMatrix::CorrelationMatrix(const Matrix<int>& ndays, double CorrelationDecayCoeff )
		: Matrix<double>(ndays.size()-1 , ndays.size()-1)
	{
		f_correlationDecayCoeff = CorrelationDecayCoeff;
		f_correlationModel = GAUSSIAN;
		generateCorrMatrix(ndays);
	}

	void CorrelationMatrix::generateCorrMatrix(const Matrix<int>& ndays)
	{
		for (unsigned i = 0; i < Rows(); ++i)
		{
			(*this)(i,i) = 1.0;

			for (unsigned j = 0; j < i; ++j) (*this)(i,j) = (*this)(j,i);

			for (unsigned j = i+1; j < Cols(); ++j)
			{
				(*this)(i,j) = get_fwd_rate_correl(ndays(i), ndays(i + 1), ndays(j), ndays(j + 1));
			}
		}
	}


	double CorrelationMatrix::get_fwd_rate_correl(int start1, int end1, int start2, int end2)
	{
		switch (f_correlationModel)
		{
		case GAUSSIAN:
			return get_fwd_rate_correl_GAUSSIAN(start1, end1, start2, end2);
		case HISTORICAL:
			return get_fwd_rate_correl_HISTORICAL(start1, end1, start2, end2);
		case EXPONENTIAL:
			return get_fwd_rate_correl_EXPONENTIAL(start1, end1, start2, end2);
		case FLAT:
			return get_fwd_rate_correl_FLAT(start1, end1, start2, end2);
		default:
			return get_fwd_rate_correl_GAUSSIAN(start1, end1, start2, end2);
		}
	}

	double CorrelationMatrix::get_fwd_rate_correl_GAUSSIAN(int start1, int end1,
		int start2, int end2)
	{

		double m1 = (start1 + end1) / (2.0 * 365);
		double m2 = (start2 + end2) / (2.0 * 365);
		double rho, x;

		/* kludge to get the flat correlation term structure */
		if (f_correlationDecayCoeff < 0)
			return abs(f_correlationDecayCoeff);

		x = (m1 - m2) / (m1 + m2);
		rho = exp(-f_correlationDecayCoeff * x * x);

		return rho;
	}

	double CorrelationMatrix::get_fwd_rate_correl_EXPONENTIAL(int start1, int end1,
		int start2, int end2)
	{
		double sum = 0, RHO;
		double t1, t2, s1, s2;
		int i, j, count = 0;


		t1 = __min(start1, end1);
		t2 = __max(start1, end1);
		s1 = __min(start2, end2);
		s2 = __max(start2, end2);

		for (i = (int)ceil(s1); i < (int)ceil(s2); i++)
		{
			for (j = (int)ceil(t1); j < (int)ceil(t2); j++)
			{
				count++;
				sum += exp(-f_correlationDecayCoeff * abs(i - j) / 365.0);
			}
		}

		RHO = sum / count;

		return RHO;
	}

	double CorrelationMatrix::get_fwd_rate_correl_FLAT(int start1, int end1,
		int start2, int end2)
	{
		return f_correlationDecayCoeff;
	}

	double CorrelationMatrix::get_fwd_rate_correl_HISTORICAL(int start1, int end1,
		int start2, int end2)
	{
		return get_fwd_rate_correl_GAUSSIAN(start1, end1, start2, end2);
	}

}