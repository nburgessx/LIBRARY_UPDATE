#include "mcpldefs.h"

namespace MCPL
{

void mcpl_error( const MCPL_ERROR & message )
{
	MCPL_ERROR err = std::string("MCPL Error... ") + message;
	throw err;
}

} //namespace MCPL
