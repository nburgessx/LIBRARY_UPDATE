#pragma once
#ifndef MCPLTWOFACTOR_H
#define MCPLTWOFACTOR_H
#include "MCPL.h"

#include "mcpldefs.h"
#include "mcDataClasses/mcDataClasses.h"

namespace MCPL
{


class twoFactor
{
public:

	twoFactor();


	twoFactor(double* pforwardsa,double* pforwardsb,double* pstrikes,
		  double* pvolatilitiesa,double* pvolatilitiesb,double* pnumeraires,
		  double pstepsizea,double pstepsizeb,long int pnumberOfStepsa,int pnumberOfStepsb,long int ptrunca, long ptruncb,
		  long int pnumberOfDates,long int ppayerOrReceiver);


	~twoFactor();

	double priceStructure();

private:

	void setup(double* pforwardsa,double* pforwardsb,double* pstrikes,
		  double* pvolatilitiesa,double* pvolatilitiesb,double* pnumeraires,
		  double pstepsizea,double pstepsizeb,long int pnumberOfStepsa,int pnumberOfStepsb,long int ptrunca, long ptruncb,
		  long int pnumberOfDates,long int ppayerOrReceiver);


	double approxPV(int i,int j, int trunca,int truncb);
	void calculateProbabilities(double volatilitya,double volatilityb,double stepsizea,double stepsizeb,long numberOfStepsa,long numberOfStepsb,long trunca,long truncb);

	int numberOfDates;
	int numberOfStepsa;
	int numberOfStepsb;
	int trunca;
	int truncb;
	int payerOrReceiver;  // this is -1 or 1, depending on whether we have a put or a call.

	double stepsizea;
	double stepsizeb;

	double* numeraires;

	double* forwardsa;
	double* forwardsb;

	double* strikes;

	double* volatilitiesa;
	double* volatilitiesb;

	double* correlations;


	Matrix<double> futureValues;
	Matrix<double> presentValues;
	Matrix<double> transitionProbabilities;



};

}  // namespace MCPL

#endif // MCPLTWOFACTOR_H