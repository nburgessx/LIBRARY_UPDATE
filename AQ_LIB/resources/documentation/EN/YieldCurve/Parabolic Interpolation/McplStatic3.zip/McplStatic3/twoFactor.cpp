#include"twoFactor.h"
#include "mcpldefs.h"
#include<math.h>

namespace MCPL
{






  //default constructor

  twoFactor::twoFactor()
  {
  }

  //constructor


  // Constructor which can set up its own cashflows and work out forward rates etc...
  // Needs to be given the structure's dates etc.., a discount curve, a forecast curve and a swaption vol grid.
  /*oneFactor( DIRECTIONTYPE dir, date & start, date & first, date & mature, double notional1, double notional2, double coupon, 
  double couponStep, double spread, double spreadStep ,long int fixedPmtsPerYear, long int fltPmtsPerYear, 
  double strike, double strikeStep, long int noticeDays, long int lockout,	long int calls,
  DayBasis fixedBasis, DayBasis floatBasis, double stepsize, long int nsteps, long int trunc,
  swapData & discountCurve, swapData & forecastCurve, SwaptionVolGrid & volGrid, HOLIDAYCAL hol)
  {

  int nDates;

  // Set up the underlying swap cashflows.
  Swap underlyer(dir, first, mature, notional, coupon, spread, fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis,
  discountCurve, forecastCurve, hol);

  // Extract the underlying swap's start dates
  dateVec ULstartDates = (underlyer.getLeg(MC_FIXED)).getStartDates();

  dateVec exerciseDates ,startDates;

  for ( int i = ULstartDates.size()-1-lockout ; i > ULstartDates.size()-1-lockout-calls ; --i ) {

  cout << ULstartDates[i] << endl;

  exerciseDates.push_back( addBusinessDays( ULstartDates[i] ,  -noticeDays , hol) );
  startDates.push_back( addBusinessDays( ULstartDates[i] ,  -noticeDays , hol) );
  }


  // set up the arrays to construct the lattice.

  nDates = exerciseDates.size();
  double *pForwards = new double[nDates];
  double *pStrikes = new double[nDates];
  double *pForwardVols = new double[nDates];
  double *pNumeraires = new double[nDates];

  for ( i=0 ; i < nDates ; ++i ) {
  double vol1, vol2;

  cout << startDates[i] << " > " << mature << endl;

  // Set up a temp swap to calc forward rates
  Swap tempSwap(dir, startDates[i], mature, notional, coupon, spread, fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis,
  discountCurve, forecastCurve, hol);

  // Work out forward variamces
  if ( i==0 ) {
  pForwardVols[0] = volGrid.get(startDates[0] - start , mature - startDates[0] )/100;

  pForwardVols[0] *= pForwardVols[0] * dayCountFrac(fixedBasis, start ,startDates[0]) ;
  //cout << "Forward variance of underlyer is " << pForwardVols[0] << endl;
  } else {
  vol1 = volGrid.get(startDates[i-1] - start , mature - startDates[i-1] )/100;
  vol2 = volGrid.get(startDates[i]   - start , mature - startDates[i] )/100;

  pForwardVols[i] = vol2*vol2*dayCountFrac(fixedBasis , start , startDates[i] )  -
  vol1*vol1*dayCountFrac(fixedBasis , start , startDates[i-1]);  // Calc forward variance.
  }


  pForwards[i] = tempSwap.Solve(0, solveFORCOUPON);
  pNumeraires[i] = tempSwap.BPV() * notional;
  pStrikes[i] = strike + i*strikeStep;

  //		pForwards[i] = 1;
  //		pForwardVols[i] = .18267;
  //		pNumeraires[i] = 1;
  //		pStrikes[i] = 1;
  }

  // Set up the lattice
  setup( pForwards, pStrikes, pForwardVols, pNumeraires, stepsize, nsteps, trunc , nDates, dir == PAY ? -1:1 );

  //And free up the memory we allocated for arrays.
  delete [] pForwards;
  delete [] pStrikes;
  delete [] pForwardVols;
  delete [] pNumeraires;

  }

  */

  twoFactor::twoFactor(double* pforwardsa,double* pforwardsb,double* pstrikes,
    double* pvolatilitiesa,double* pvolatilitiesb,double* pnumeraires,
    double pstepsizea,double pstepsizeb,
    long int pnumberOfStepsa,int pnumberOfStepsb,long int ptrunca, long ptruncb,
    long int pnumberOfDates,long int ppayerOrReceiver)
  {
    setup( pforwardsa, pforwardsb, pstrikes, pvolatilitiesa, pvolatilitiesb, pnumeraires,
      pstepsizea, pstepsizeb, pnumberOfStepsa, pnumberOfStepsb, ptrunca, ptruncb,
      pnumberOfDates, ppayerOrReceiver);
  }


  void twoFactor::setup(double* pforwardsa,double* pforwardsb,double* pstrikes,
    double* pvolatilitiesa,double* pvolatilitiesb,double* pnumeraires,
    double pstepsizea,double pstepsizeb,long int pnumberOfStepsa,int pnumberOfStepsb,long int ptrunca, long ptruncb,
    long int pnumberOfDates,long int ppayerOrReceiver)
  {
    int i;	
    int j;
    double intrinsicValue;

    futureValues.redim(2*pnumberOfStepsa,2*pnumberOfStepsb); 
    presentValues.redim(2*pnumberOfStepsa,2*pnumberOfStepsb);
    transitionProbabilities.redim(2*ptrunca,2*ptruncb);

    // allocate memory and initialise the arrays we use to store values

    forwardsa= new double[2*pnumberOfDates+10];
    strikes= new double[2*pnumberOfDates+10];
    forwardsb= new double[2*pnumberOfDates+10];

    volatilitiesa=new double[2*pnumberOfDates+10];
    volatilitiesb=new double[2*pnumberOfDates+10];

    numeraires=new double[2*pnumberOfDates+10];

    //initialise

    for(i=0;i<pnumberOfDates;++i)
    {
      forwardsa[i]=pforwardsa[i];
      forwardsb[i]=pforwardsb[i];
      strikes[i]=pstrikes[i];
      volatilitiesa[i]=pvolatilitiesa[i];
      volatilitiesb[i]=pvolatilitiesb[i];
      numeraires[i] = pnumeraires[i];
    }

    numberOfDates=pnumberOfDates;
    numberOfStepsa=pnumberOfStepsa;
    numberOfStepsb=pnumberOfStepsb;

    trunca=ptrunca;
    truncb=ptruncb;
    stepsizea=pstepsizea;
    stepsizeb=pstepsizeb;

    payerOrReceiver=ppayerOrReceiver;

    if (payerOrReceiver==0)		payerOrReceiver=-1; //call
    else						payerOrReceiver=1; //put

    calculateProbabilities(volatilitiesa[numberOfDates-1],volatilitiesb[numberOfDates-1], stepsizea,stepsizeb, numberOfStepsa,numberOfStepsb,trunca,truncb);

    //initialise
    for(i = 0;i<2*numberOfStepsa;++i)
    {
      for(j = 0;j<2*numberOfStepsb;++j)
      {
        futureValues(i,j)=0;
        presentValues(i,j)=0;
      }
    }

    //initialise the values at the final date (s.b($)/b((Y)-f-k)*b(Y)
    for(i = -1*numberOfStepsa;i<numberOfStepsa;++i)
    {	
      for(j=-1*numberOfStepsb;j<numberOfStepsb;++j)
      {
        intrinsicValue=payerOrReceiver*(exp(stepsizea*i)*forwardsa[numberOfDates-1]-exp(stepsizeb*j)*forwardsb[numberOfDates-1]-strikes[numberOfDates-1])*numeraires[numberOfDates-1];
        if (intrinsicValue>0){
          futureValues(i+numberOfStepsa,j+numberOfStepsb)=intrinsicValue;}
        else
          futureValues(i+numberOfStepsa,j+numberOfStepsb)=0;
      }
    }
  }


  void twoFactor::calculateProbabilities(double volatilitya,double volatilityb,
    double stepsizea,double stepsizeb,long 
    numberOfStepsa,long numberOfStepsb,
    long trunca,long truncb)
  {

    double tempsum=0;
    //double pi=3.141592654;
    double pi=atan2(1.0,1.0)*4.0;
    int i=0,j=0;
    double temp;
    double rho=0;
    double u=0;
    double v=0;

    for(i = -1*trunca;i<trunca;++i)
    {
      for(j = -1*truncb;j<truncb;++j)
      {
        u=(-1*i*stepsizea-.5*volatilitya);
        v=(-1*j*stepsizeb-.5*volatilityb);
        temp=(u*u/volatilitya+v*v/volatilityb-2*rho*u*v/sqrt(volatilitya*volatilityb));		// the usual quadratic form.
        transitionProbabilities(i+trunca,j+truncb) = (1/(2*pi*sqrt(volatilitya*volatilityb*(1-rho*rho)))) * exp(-1*temp  / (2 *(1-rho*rho))) / (1 / (stepsizea*stepsizeb));
        tempsum = tempsum + transitionProbabilities(i+trunca,j+truncb);
      }
    }

    //normalise the probabilities, so that they sum to 1.
    for(i = -1*trunca;i<trunca;++i)
    {
      for(j = -1*truncb;j<truncb;++j)
      {
        transitionProbabilities(i+trunca,j+truncb)=transitionProbabilities(i+trunca,j+truncb)/tempsum;

      }
    }

  }


  double twoFactor::approxPV(int i,int j, int trunca,int truncb)
  {
    //the trunc parameter controls how many probabilities we will use.
    int k,l;
    int lowerCutOffa,lowerCutOffb;
    int upperCutOffa,upperCutOffb;

    double temp=0;

    lowerCutOffa=-1*trunca;
    lowerCutOffb=-1*truncb;
    upperCutOffa=trunca;
    upperCutOffb=truncb;

    if (i-trunca<0) 
    {
      lowerCutOffa=-1*i;
    }

    if (j-truncb<0) 
    {
      lowerCutOffb=-1*j;
    }

    if (i+trunca>2*numberOfStepsa )
    {
      upperCutOffa=(2*numberOfStepsa-i);
    }

    if (j+truncb>2*numberOfStepsb )
    {
      upperCutOffb=(2*numberOfStepsb-j);
    }

    for(k=lowerCutOffa;k<upperCutOffa;++k)
    {
      for(l=lowerCutOffb;l<upperCutOffb;++l)
      {
        temp = temp + transitionProbabilities(k+trunca,l+truncb) * futureValues(i+k,j+l);
      }
    }

    return temp;

  }

  // step backwards through the lattice

  double twoFactor::priceStructure()
  {
    int i,m,j;
    double value;
    double intrinsicValue;
    double bumpa,stepa;
    double bumpb,stepb;

    bumpa=exp(-1*stepsizea*numberOfStepsa);
    stepa=exp(stepsizea);
    bumpb=exp(-1*stepsizeb*numberOfStepsb);
    stepb=exp(stepsizeb);


    // backwards induction step.
    // if the PV at the node is less than the instrinsic value, then the PV becomes the intrinsic value.
    for(m=numberOfDates-1;m>0;--m)
    {
      for(i = -1*numberOfStepsa;i<numberOfStepsa;++i)
      {	
        for(j = -1*numberOfStepsb;j<numberOfStepsb;++j)
        {		
          intrinsicValue=payerOrReceiver*numeraires[m-1]*(exp(i*stepsizea)*forwardsa[m-1]-exp(j*stepsizeb)*forwardsb[m-1]-strikes[m-1]); //payers
          presentValues(i+numberOfStepsa,j+numberOfStepsb)=approxPV(i+numberOfStepsa,j+numberOfStepsb,trunca,truncb);	
          if (presentValues(i+numberOfStepsa,j+numberOfStepsb)<intrinsicValue)
          {	
            presentValues(i+numberOfStepsa,j+numberOfStepsb)=intrinsicValue; 
          }
          //bumpb=bumpb*stepb;
        }
        //bumpa=bumpa*stepa;
      }
      //after calculating all of the values at the current time, step back.
      for(i = -1*numberOfStepsa;i<numberOfStepsa;++i)
      {
        for(j = -1*numberOfStepsb;j<numberOfStepsb;++j)
        {
          futureValues(i+numberOfStepsa,j+numberOfStepsb)=presentValues(i+numberOfStepsa,j+numberOfStepsb);
        }
      }	
      calculateProbabilities(volatilitiesa[m-1],volatilitiesb[m-1], stepsizea,stepsizeb, numberOfStepsa,numberOfStepsb,trunca,truncb);
      value=futureValues(numberOfStepsa,numberOfStepsb);
    }

    // now get PV		
    value=approxPV(numberOfStepsa,numberOfStepsb,trunca,truncb);	
    return value;
  }

  //free up memory
  twoFactor::~twoFactor()
  {

    delete [] forwardsa;
    delete [] forwardsb;
    delete [] strikes;
    delete [] volatilitiesa;
    delete [] volatilitiesb;
    delete [] numeraires;
  }

  /* call with USD fixed on one side, JPY fixed on the other*/
  /* coupona, couponb, volatility, FXVolatility */






} // namespace MCPL