#include "blackmodel.h"
#include "mathmisc.h"
#include "VolatilityGrid.h"
#include "option.h"

#include "numrec/dnr.h"

using namespace NUMREC;

namespace MCPL
{



	double mixing_model::get_slope(double timeToExp, BlackVol vol) const
	{
		return m_t0_mixing_slope;
	}

	double mixing_model::get_mixing_from_slope(double d_strike, double d_forward, double slope) const
	{
		double mix = m_ATM_mixing + 100.0*(d_strike - d_forward) * slope;
		if (mix < m_minMixing)
		{
			mix = m_minMixing;
		}
		else if (mix > m_maxMixing)
		{
			mix = m_maxMixing;
		}

		return mix;
	}

	double mixing_model::get_mixing(double d_strike, double d_forward, double timeToExp, BlackVol vol) const
	{
		//	return m_ATM_mixing + 100.0*(d_strike - d_forward) * m_mixing_slope;
		return get_mixing_from_slope(d_strike, d_forward, get_slope(timeToExp, vol));
	}
	
	// mixing of 0 = lognormal price. mixing of 100 = normal price.
	double blackMixed(double strike, double forward, double T, BlackVol vol, double df, mixing_model m_mixing, OptionType type)
	{

		if (T <= 0)
			return df * intrinsicValue(strike, forward, type);

		BlackVol lognormal_vol = n2bATMvol(forward, T, vol);

		// mixing should be between 0 and 1 inclusive
		//	if ( (mixing > 1) || (mixing < 0) ) mcpl_error("bad mixing value to blackMixed");

		double mixing = m_mixing.get_mixing(strike, forward, T * 256, vol);

		double price = (mixing * blackNormal(strike, forward, T, vol, df, type) +
			(1.0 - mixing) * black(strike, forward, T, lognormal_vol, df, type));

		if (price < 0)
			price = 0;

		return price;
	}

	// Same as above, but returns the normal and lognormal prices.
	// mixing of 0 = lognormal price. mixing of 100 = normal price.
	double blackMixed(double strike, double forward, double T, BlackVol vol, double df, mixing_model m_mixing, OptionType type,
		double & normal_price, double & lognormal_price)
	{

		if (T <= 0)
			return df * intrinsicValue(strike, forward, type);

		BlackVol lognormal_vol = n2bATMvol(forward, T, vol);

		// mixing should be between 0 and 1 inclusive
		//	if ( (mixing > 1) || (mixing < 0) ) mcpl_error("bad mixing value to blackMixed");

		lognormal_price = black(strike, forward, T, lognormal_vol, df, type);
		normal_price = blackNormal(strike, forward, T, vol, df, type);

		double mixing = m_mixing.get_mixing(strike, forward, T * 256, vol);

		return(mixing * normal_price + (1.0 - mixing) * lognormal_price);
	}


	//double blackShifted(double strike, double forward, double T, double vol, double shift, double df, OptionType type)
	//{
	//	return black(strike + shift, forward + shift, T, vol, df, type);
	//}
	double blackProbabilityOfExercise(double strike, double forward, double T, BlackVol vol, OptionType type)
	{

		if ((T <= 0) || (vol.vol == 0))
			return inTheMoney(strike, forward, type) ? 1:0;

		strike += vol.rateShift;
		forward += vol.rateShift;

		double rootT = sqrt(T);

		double sigmaRootT = vol.vol*rootT;

		double d1 = (log(forward / strike) + (sigmaRootT*sigmaRootT*0.5)) / sigmaRootT;
		double d2 = d1 - sigmaRootT;

		double Nd2 = N(d2);

		double bsProb;

		if (type == Call)
		{
			bsProb = Nd2;
		}
		else if (type == Put)
		{
			bsProb = (1 - Nd2);
		}
		else if (type == Straddle)
		{
			bsProb = 1;
		}
		else
		{
			MCPL_ERROR errMsg = "Black76 cannot price this type of option";
			throw errMsg;
		}

		return bsProb;
	}

	double black(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{

		if ((T <= 0) || (vol.vol == 0))
			return df * intrinsicValue(strike, forward, type);

		strike += vol.rateShift;
		forward += vol.rateShift;

		double rootT = sqrt(T);

		double sigmaRootT = vol.vol*rootT;

		double d1 = (log(forward / strike) + (sigmaRootT*sigmaRootT*0.5)) / sigmaRootT;
		double d2 = d1 - sigmaRootT;

		double Nd1 = N(d1);
		double Nd2 = N(d2);

		double bsPrice;

		if (type == Call)
		{
			bsPrice = df * (forward*Nd1 - strike*Nd2);
		}
		else if (type == Put)
		{
			bsPrice = df * (strike*(1 - Nd2) - forward*(1 - Nd1));
		}
		else if (type == Straddle)
		{
			bsPrice = df * (2.0*forward*Nd1 - 2.0*strike*Nd2 + strike - forward);
		}
		else
		{
			MCPL_ERROR errMsg = "Black76 cannot price this type of option";
			throw errMsg;
		}

		return __max(bsPrice, 0.0);

	}

	double blackNormal(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{

		if ((T <= 0) || (vol.vol == 0))
			return df * intrinsicValue(strike, forward, type);

		//Not really needed for normal....
		strike += vol.rateShift;
		forward += vol.rateShift;

		double rootT = sqrt(T);

		double sigmaRootT = vol.vol*rootT;

		double d1 = (forward - strike) / sigmaRootT;
		double A = exp(-d1*d1 / 2.0) * sigmaRootT / root2Pi; // root2Pi defined in mathmisc.h

		double Nd1 = N(d1);

		double bsPrice;

		if (type == Call)
		{
			bsPrice = df * (A + (forward - strike) * Nd1);
		}
		else if (type == Put)
		{
			bsPrice = df * (A + (forward - strike) * (Nd1 - 1.0));
		}
		else if (type == Straddle) // Call + Put
		{
			bsPrice = df * (2.0*A + (forward - strike)*(2.0*Nd1 - 1.0));
		}
		else
		{
			MCPL_ERROR errMsg = "BlackNormal cannot price this type of option";
			throw errMsg;
		}

		return __max(bsPrice, 0.0);

	}

	double blackGeneric(double strike, double forward, double T, BlackVol vol, double df, mixing_model m_mixing,
		OptionType type, OptionModel model)
	{
		double PV;
		switch (model)
		{
		case BlackLogNormal:
			PV = black(strike, forward, T, vol, df, type);
			break;
		case BlackNormal:
			PV = blackNormal(strike, forward, T, vol, df, type);
			break;
		case BlackMixed:
			PV = blackMixed(strike, forward, T, vol, df, m_mixing, type);
			break;
		default:
			PV = 0;
		}
		return PV;
	}


	double blackDelta(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{

		// if T=0, return 0 or 100% delta
		if (T <= 0) {
			if (inTheMoney(strike, forward, type))
			if (type == Call)
				return df;
			else if (type == Put)
				return -df;
			else
				return (forward > strike) ? df : -df;
			else
				return(0);
		}

		/*if (vol.rateShift != 0)
			mcpl_error("Haven't implemented shifted lognormal delta yet.");*/

		strike += vol.rateShift;
		forward += vol.rateShift;

		double sigmaRootT = vol.vol*sqrt(T);


		double d1 = (log(forward / strike) + (sigmaRootT*sigmaRootT*0.5)) / sigmaRootT;

		double Nd1 = N(d1);

		double delta;

		if (type == Call)
		{
			delta = df * Nd1;
		}
		else if (type == Put)
		{
			delta = df * (Nd1 - 1);
		}
		else if (type == Straddle) // Call + Put
		{
			delta = df * (2.0*Nd1 - 1.0);
		}
		else
		{
			MCPL_ERROR errMsg = "BlackNormal cannot price this type of option";
			throw errMsg;
		}

		return delta;

	}


	double blackNormalDelta(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{
		// if T=0, return 0 or 100% delta
		if (T <= 0) {
			if (inTheMoney(strike, forward, type))
			if (type == Call)
				return df;
			else if (type == Put)
				return -df;
			else
				return (forward > strike) ? df : -df;
			else
				return(0);
		}

		strike += vol.rateShift;
		forward += vol.rateShift;

		double sigmaRootT = vol.vol*sqrt(T);

		double d1 = (forward - strike) / sigmaRootT;

		double Nd1 = N(d1);

		double delta;

		if (type == Call)
		{
			delta = df * Nd1;
		}
		else if (type == Put)
		{
			delta = df * (Nd1 - 1);
		}
		else if (type == Straddle) // Call + Put
		{
			delta = df * (2.0*Nd1 - 1.0);
		}
		else
		{
			MCPL_ERROR errMsg = "BlackNormal cannot price this type of option";
			throw errMsg;
		}

		return delta;

	}

	double blackMixedDelta(double strike, double forward, double T, BlackVol vol, double df, mixing_model m_mixing, OptionType type)
	{
		// if T=0, return 0 or 100% delta
		if (T <= 0) {
			if (inTheMoney(strike, forward, type))
			if (type == Call)
				return df;
			else if (type == Put)
				return -df;
			else
				return (forward > strike) ? df : -df;
			else
				return(0);
		}

		

		double mixing = m_mixing.get_mixing(strike, forward, T * 256, vol);


		BlackVol log_vol = n2bATMvol(forward, T, vol);
		double log_vega = blackVega(strike, forward, T, log_vol, df, type);
		double log_delta = blackDelta(strike, forward, T, log_vol, df, type);
		double normal_delta = blackNormalDelta(strike, forward, T, vol, df, type);

		if (vol.rateShift != 0)
		{
			strike += vol.rateShift;
			forward += vol.rateShift;
		}

		double delta = (1 - mixing) * (log_delta - log_vega*vol.vol*exp(log_vol.vol*log_vol.vol*T / 8.0) / forward / forward) +
			mixing*normal_delta;
		return delta;

	}

	double blackMixedGamma(double strike, double forward, double T, BlackVol vol, double df, mixing_model m_mixing,
		OptionType type)
	{

		if (T == 0) return 0;

		

		BlackVol log_vol = n2bATMvol(forward, T, vol);
		double log_vega = blackVega(strike, forward, T, log_vol, df, type);
		double log_delVega = blackDelVega(strike, forward, T, log_vol, df, type);
		double log_vegaVega = blackVegaVega(strike, forward, T, log_vol, df, type);
		double log_gamma = blackGamma(strike, forward, T, log_vol, df, type);
		double normal_gamma = blackNormalGamma(strike, forward, T, vol, df, type);

		double mixing = m_mixing.get_mixing(strike, forward, T * 256, vol);

		if (vol.rateShift != 0)
		{
			strike += vol.rateShift;
			forward += vol.rateShift;
		}

		double E = vol.vol / (forward*forward) * exp(log_vol.vol*log_vol.vol * T / 8.0);


		double gamma = (1 - mixing) * (log_gamma - E*(2.0*log_delVega - 2.0*log_vega / forward - vol.vol*log_vegaVega - log_vol.vol*T*log_vega*E / 4)) +
			mixing*normal_gamma;
		return gamma;

	}

	double blackGamma(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{
		if (T == 0) return 0;

		/*if (vol.rateShift != 0)
			mcpl_error("Haven't implemented shifted black gamma yet.");*/

		strike += vol.rateShift;
		forward += vol.rateShift;

		double sigmaRootT = vol.vol*sqrt(T);

		double d1 = (log(forward / strike) + (sigmaRootT*sigmaRootT*0.5)) / sigmaRootT;
		double dNd1 = exp(-d1*d1 / 2) / (root2Pi);

		double gamma;

		if (type == Call)
		{
			gamma = df * dNd1 / (sigmaRootT * forward);
		}
		else if (type == Put)
		{
			gamma = df * dNd1 / (sigmaRootT * forward);
		}
		else if (type == Straddle) // Call + Put
		{
			gamma = 2.0 * df * dNd1 / (sigmaRootT * forward);
		}
		else
		{
			MCPL_ERROR errMsg = "BlackNormal cannot price this type of option";
			throw errMsg;
		}

		return gamma;

	}

	double blackNormalGamma(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{

		if (T == 0) return 0;

		double sigmaRootT = vol.vol*sqrt(T);

		double d1 = (forward - strike) / sigmaRootT;

		double gamma;

		if (type == Call)
		{
			gamma = df * exp(-d1*d1 / 2) / (sigmaRootT * root2Pi);
		}
		else if (type == Put)
		{
			gamma = df * exp(-d1*d1 / 2) / (sigmaRootT * root2Pi);
		}
		else if (type == Straddle) // Call + Put
		{
			gamma = 2.0 * df * exp(-d1*d1 / 2) / (sigmaRootT * root2Pi);
		}
		else
		{
			MCPL_ERROR errMsg = "BlackNormal cannot price this type of option";
			throw errMsg;
		}

		return gamma;

	}

	double blackVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{

		if (T == 0) return 0;

		/*if (vol.rateShift != 0)
			mcpl_error("Haven't implemented shifted black vega yet.");*/
		
		strike += vol.rateShift;
		forward += vol.rateShift;

		double rootT = sqrt(T);
		double sigmaRootT = vol.vol*rootT;

		double d1 = (log(forward / strike) + (sigmaRootT*sigmaRootT*0.5)) / sigmaRootT;
		double dNd1 = exp(-d1*d1 / 2) / (root2Pi);

		double vega;

		if (type == Call)
		{
			vega = df * forward * dNd1 * rootT;
		}
		else if (type == Put)
		{
			vega = df * forward * dNd1 * rootT;
		}
		else if (type == Straddle) // Call + Put
		{
			vega = 2.0 * df * forward * dNd1 * rootT;
		}
		else
		{
			MCPL_ERROR errMsg = "BlackNormal cannot price this type of option";
			throw errMsg;
		}

		return vega;

	}

	double blackNormalVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{
		if (T == 0) return 0;

		double rootT = sqrt(T);
		double d1 = (forward - strike) / (vol.vol * rootT);

		double vega = df * rootT * exp(-(d1*d1) / 2) / root2Pi;
		return (type == Straddle) ? vega * 2.0 : vega;
	}


	double blackMixedVega(double strike, double forward, double T, BlackVol vol, double df, mixing_model m_mixing, OptionType type)
	{

		if (T == 0) return 0;


		/*if (vol.rateShift != 0)
			mcpl_error("Haven't implemented shifted black mixed vega yet.");*/

		BlackVol log_vol = n2bATMvol(forward, T, vol);

		double d1 = (log_vol.vol * sqrt(T)) / 2;

		double mixing = m_mixing.get_mixing(strike, forward, T * 256, vol);

		strike += vol.rateShift;
		forward += vol.rateShift;

		double vega = (1.0 - mixing)*blackVega(strike, forward, T, log_vol, df, type) * exp(d1*d1 / 2.0) / forward +
			mixing*blackNormalVega(strike, forward, T, vol, df, type);

		return vega;
	}

	//*****************************************************************************************************

	double blackTheta(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{

		if (T == 0) return 0;

		/*if (vol.rateShift != 0)
			mcpl_error("Haven't implemented shifted black theta yet.");*/

		strike += vol.rateShift;
		forward += vol.rateShift;

		double rootT = sqrt(T);
		double sigmaRootT = vol.vol*rootT;

		double d1 = (log(forward / strike) + (sigmaRootT*sigmaRootT*0.5)) / sigmaRootT;
		double d2 = d1 - sigmaRootT;

		double dNd1 = exp(-d1*d1 / 2.0) / (root2Pi);
		double dNd2 = exp(-d2*d2 / 2.0) / (root2Pi);

		double theta;

		if ((type == Call) || (type == Put))
		{
			theta = df * (strike * dNd2 * d1 - forward * dNd1 * d2) / (2.0*T);
		}
		else if (type == Straddle) // Call + Put
		{
			theta = df * (strike * dNd2 * d1 - forward * dNd1 * d2) / T;
		}
		else
		{
			MCPL_ERROR errMsg = "Black cannot price this type of option";
			throw errMsg;
		}

		return theta;

	}

	//*****************************************************************************************************

	double blackNormalTheta(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{

		if (T == 0) return 0;

		double rootT = sqrt(T);
		double sigmaRootT = vol.vol*rootT;

		double d1 = (forward - strike) / sigmaRootT;

		double dNd1 = exp(-d1*d1 / 2.0) / (root2Pi);

		double theta;

		if ((type == Call) || (type == Put))
		{
			theta = df * dNd1 * vol.vol / (2.0*rootT);
		}
		else if (type == Straddle) // Call + Put
		{
			theta = df * dNd1 * vol.vol / rootT;
		}
		else
		{
			MCPL_ERROR errMsg = "Black cannot price this type of option";
			throw errMsg;
		}

		return theta;

	}

	//*****************************************************************************************************

	double blackMixedTheta(double strike, double forward, double T, BlackVol vol, double df, mixing_model m_mixing,
		OptionType type)
	{

		if (T <= 0) return(0);

		/*if (vol.rateShift != 0)
			mcpl_error("Haven't implemented shifted black mixed theta yet.");*/

		double rootT = sqrt(T);

		BlackVol log_vol = n2bATMvol(forward, T, vol);
		double log_vega = blackVega(strike, forward, T, log_vol, df, type);
		double log_theta = blackTheta(strike, forward, T, log_vol, df, type);
		double normal_theta = blackNormalTheta(strike, forward, T, vol, df, type);

		double mixing = m_mixing.get_mixing(strike, forward, T * 256, vol);

		if (vol.rateShift != 0)
		{
			strike += vol.rateShift;
			forward += vol.rateShift;
		}

		double theta = (1.0 - mixing) * (log_theta + log_vega*(vol.vol*exp(log_vol.vol*log_vol.vol*T / 8.0) / forward - log_vol.vol) / (T*2.0)) +
			mixing*normal_theta;
		return theta;


	}

	//*****************************************************************************************************

	double blackDelVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{
		if (T == 0) return 0;

		/*if (vol.rateShift != 0)
			mcpl_error("Haven't implemented shifted black delvega yet.");*/

		strike += vol.rateShift;
		forward += vol.rateShift;

		double rootT = sqrt(T);
		double sigmaRootT = vol.vol*rootT;

		double d1 = (log(forward / strike) + (sigmaRootT*sigmaRootT*0.5)) / sigmaRootT;
		double dNd1 = exp(-d1*d1 / 2) / (root2Pi);

		double delVega;

		if (type == Call)
		{
			delVega = df * dNd1 * rootT * (1 - d1 / sigmaRootT);
		}
		else if (type == Put)
		{
			delVega = df * dNd1 * rootT * (1 - d1 / sigmaRootT);
		}
		else if (type == Straddle) // Call + Put
		{
			delVega = 2.0 * df * dNd1 * rootT * (1 - d1 / sigmaRootT);
		}
		else
		{
			MCPL_ERROR errMsg = "BlackNormal cannot price this type of option";
			throw errMsg;
		}

		return delVega;

	}

	double blackNormalDelVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{
		if (T == 0) return 0;

		double rootT = sqrt(T);
		double d1 = (forward - strike) / (vol.vol * rootT);

		double delVega = -df * d1 * exp(-(d1*d1) / 2) / (root2Pi*vol.vol);

		return (type == Straddle) ? delVega * 2.0 : delVega;
	}

	double blackVegaVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{

		if (T == 0) return 0;

		/*if (vol.rateShift != 0)
			mcpl_error("Haven't implemented shifted black vegavega yet.");*/

		strike += vol.rateShift;
		forward += vol.rateShift;

		double rootT = sqrt(T);
		double sigmaRootT = vol.vol*rootT;

		double d1 = (log(forward / strike) + (sigmaRootT*sigmaRootT*0.5)) / sigmaRootT;
		double dNd1 = exp(-d1*d1 / 2) / (root2Pi);

		double vegaVega;

		if (type == Call)
		{
			vegaVega = df * dNd1 * rootT * forward * d1 * (d1 / vol.vol + rootT);
		}
		else if (type == Put)
		{
			vegaVega = df * dNd1 * rootT * forward * d1 * (d1 / vol.vol + rootT);
		}
		else if (type == Straddle) // Call + Put
		{
			vegaVega = 2.0 * df * dNd1 * rootT * forward * d1 * (d1 / vol.vol + rootT);
		}
		else
		{
			MCPL_ERROR errMsg = "BlackNormal cannot price this type of option";
			throw errMsg;
		}

		return vegaVega;

	}

	double blackNormalVegaVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type)
	{
		if (T == 0) return 0;

		double rootT = sqrt(T);
		double d1 = (forward - strike) / (vol.vol * rootT);

		double vegaVega = df * rootT * exp(-(d1*d1) / 2) / root2Pi;
		vegaVega *= d1*d1 / vol.vol;

		return (type == Straddle) ? vegaVega * 2.0 : vegaVega;
	}


	//// globals for the NR routines
	//static double g_target, g_strike, g_forward, g_T, g_vol, g_df;
	//static OptionType g_type;
	//mixing_model g_mixing;

	//double blackImpVol_fn(double vol)
	//{
	//	return g_target - black(g_strike, g_forward, g_T, vol, g_df, g_type);
	//}

	//void blackImpVol_fitfn(double vol, double & price, double & vega)
	//{
	//	price = blackImpVol_fn(vol);
	//	vega = blackVega(g_strike, g_forward, g_T, vol, g_df, g_type);
	//}


	BlackVol blackImpVol(double targetPrice, double strike, double forward, double shift, double T, double df, OptionType type)
	{
		if (T == 0) return BlackVol(.0001, shift);
		if (timeValue(targetPrice, strike, forward, df, type) <= 0) return BlackVol(.0001, shift);

		const double TOL = 1e-8;

		auto fn = [&](double volval){return targetPrice - black(strike, forward, T, BlackVol(volval, shift), df, type); };
		auto fitfn = [&](double volval, double & price, double & vega){price = fn(volval); vega = blackVega(strike, forward, T, BlackVol(volval, shift), df, type); };

		double x1 = 0;
		double x2 = 1;
		NUMREC::zbrac(fn, &x1, &x2);
		double vol = dtsafe(fitfn, x1, x2, TOL);

		return BlackVol(vol,shift);
	}

	//double blackImpNormalVol_fn(double vol)
	//{
	//	return g_target - blackNormal(g_strike, g_forward, g_T, vol, g_df, g_type);
	//}

	//void blackImpNormalVol_fitfn(double vol, double & price, double & vega)
	//{
	//	price = blackImpNormalVol_fn(vol);
	//	vega = blackNormalVega(g_strike, g_forward, g_T, vol, g_df, g_type);
	//}

	BlackVol blackNormalImpVol(double targetPrice, double strike, double forward, double shift, double T, double df, OptionType type)
	{

		if (timeValue(targetPrice, strike, forward, df, type) <= 0) return BlackVol(0, shift);

		const double TOL = 1e-8;

		auto fn = [&](double volval){
			return targetPrice - blackNormal(strike, forward, T, BlackVol(volval, shift), df, type); 
		};
		
		auto fitfn = [&](double volval, double & price, double & vega){
			price = fn(volval); 
			vega = blackNormalVega(strike, forward, T, BlackVol(volval, shift), df, type); 
		};

		double x1 = 0.0;
		double x2 = (root2Pi * fabs(forward)) / (2.0*sqrt(T)); // Half of theoretical max for lognormal vol (normal vol has no max)
		if (x2 == x1)
			x2 += .01;

		NUMREC::zbrac(fn, &x1, &x2);
		return BlackVol(dtsafe(fitfn, x1, x2, TOL), shift);
	}

	/*double blackImpMixedVol_fn(double vol)
	{
		return g_target - blackMixed(g_strike, g_forward, g_T, vol, g_df, g_mixing, g_type);
	}

	void blackImpMixedVol_fitfn(double vol, double & price, double & vega)
	{
		price = blackImpMixedVol_fn(vol);
		vega = blackMixedVega(g_strike, g_forward, g_T, vol, g_df, g_mixing, g_type);
	}*/

	BlackVol blackMixedImpVol(double targetPrice, double strike, double forward, double shift, double T, double df, mixing_model mixing,
		OptionType type)
	{
		if (timeValue(targetPrice, strike, forward, df, type) <= 0) return BlackVol(0, shift);

		const double TOL = 1e-8;

		auto fn = [&](double volval){return targetPrice - blackMixed(strike, forward, T, BlackVol(volval, shift), df,  mixing, type); };
		auto fitfn = [&](double volval, double & price, double & vega){price = fn(volval); vega = blackMixedVega(strike, forward, T, BlackVol(volval, shift), df, mixing, type); };

		double vol;
		double x1 = 0.0;
		double x2 = (root2Pi * fabs(forward)) / (2.0*sqrt(T)); // Half of theoretical max.
		if (x2 == x1)
			x2 += .01;
		try
		{
			NUMREC::zbrac(fn, &x1, &x2);
		}
		catch (string err)
		{
			x1 = 0.0;
			x2 = 0.99 * (root2Pi * fabs(forward)) / sqrt(T); // Theoretical max.
			if (x2 == x1)
				x2 += .01;
			NUMREC::zbrac(fn, &x1, &x2);
		}
		vol = dtsafe(fitfn, x1, x2, TOL);

		return BlackVol(vol,shift);
	}

	double blackMixedImpMixing(double targetPrice, double strike, double forward, double T, double df, BlackVol vol, OptionType type)
	{
		double lognormal_price, normal_price;
		double mixedprice = blackMixed(strike, forward, T, vol, df, mixing_model(.5, 0, .5, .5), type, normal_price, lognormal_price);

		// can only work if normal and lognormal price differ
		if (fabs(normal_price - lognormal_price) > 1e-5)
		{
			return (targetPrice - lognormal_price) / (normal_price - lognormal_price);
		}
		else
		{
			return(.5);
		}
	}


	// Calculate the black normal vol which gives the same at the money straddle price using the blacknormal model
	// as the supplied lognormal vol gives using the black model.
	BlackVol b2nATMvol(double forward, double t, BlackVol vol)
	{

		if (vol.vol == 0) return BlackVol(0,vol.rateShift);
		
		forward += vol.rateShift;

		double sqrtt = sqrt(t);
		double d1 = vol.vol*sqrtt / 2.0;
		return BlackVol(root2Pi / sqrtt * forward * (2.0 * N(d1) - 1), vol.rateShift);
	}

	BlackVol n2bATMvol(double forward, double t, BlackVol nvol)
	{
		if (nvol.vol == 0) return BlackVol(0,nvol.rateShift);
		if ((forward + nvol.rateShift) <= 0)
			mcpl_error("cannot find a black vol for a negative effective forward rate in n2bATMvol");

		forward += nvol.rateShift;

		double sqrtt = sqrt(t);
		return BlackVol(ppnd((nvol.vol * sqrtt / (root2Pi * forward) + 1) / 2.0)*2.0 / sqrtt, nvol.rateShift);
	}


} // namespace MCPL