#include"FedFundBasisSwap.h"

namespace MCPL
{


	//FedFunds Basis swap no curves
	FedFundBasisSwap::FedFundBasisSwap(DIRECTIONTYPE dir, date & start, date & mature, double notional, double FedFundsSpread,
		const int rollDay, ROLLTYPE rolltype, long int FFPmtsPerYear, long int FloatPmtsPerYear, DayBasis FFBasis, DayBasis FloatBasis, 
		HOLIDAYCAL hol, CURRENCY ccy )
		: Swap( )
	{
		DIRECTIONTYPE dir2;

		m_notional  = notional;
		m_coupon    = 0;
		m_spread    = FedFundsSpread;
		m_direction = dir;

		p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = NULL;
		p_CMSvols = NULL;

		dir2 = dir == PAY ? RECEIVE : PAY;

		int pmtDateOffsetDays = 2;
		if ( ccy == EUR )
			pmtDateOffsetDays = 1;
		else if ( ccy == GBP )
			pmtDateOffsetDays = 0;

		addLeg( Handle<OISLeg>(new OISLeg( dir , start, mature, notional, FedFundsSpread, rollDay, rolltype, FFPmtsPerYear, FFBasis, hol, ccy, pmtDateOffsetDays, MCPL::ACCRUAL_AVERAGE ) ) );
		addLeg( Handle<Leg>( new Leg( dir2 , MC_FLOAT, start, mature, notional, 0, FloatPmtsPerYear, FloatBasis, hol, MCPL::ROLL_BACKWARD, ccy,  MCPL::ModelNone, mixing_model(), date(0), false, pmtDateOffsetDays ) ) );

	}


	// Solve for spread. legToSolveFor has to be either 0 or 1.
	double FedFundBasisSwap::Solve(double dPresentValue)
  {

	double dSwapBpv = 0.0;
    double dTarget = 0.0;

    Handle<Leg> leg = getLeg(0);
    double  dSwapValue = Price();
    dSwapBpv = leg->BasisPointValue() * leg->getNotional();
    dTarget = ( dPresentValue - dSwapValue  ) / dSwapBpv  + leg->getSpread();

	return dTarget;
  }


	//*************************************************************************************************

  void FedFundBasisSwap::fixFirst(double rate)
  {

		Handle<Leg> leg = getLeg(1);
		if ( ! leg->isFixed() )
		{
			leg->fixFirst(rate);
		}

	}


} //end namespace MCPL