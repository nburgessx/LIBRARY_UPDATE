#pragma once
#include <memory>
#include "mcpldefs.h"
#include "mcDateClass/Dates.h"

namespace MCPL
{
	class businessDates
	{
	private:
		static map<HOLIDAYCAL, shared_ptr< vector<date> > > _businessDates;
	public:

		static shared_ptr<vector<date>> genBusinessDates(const date& start_, const date& end_, HOLIDAYCAL hols_);
		static void initBusinessDates(const date&  start_, const date&  end_, HOLIDAYCAL hols_);
		static shared_ptr<vector<date>> businessDates::getBusinessDates(const date&  start_, const date&  end_, HOLIDAYCAL hols_);
		static shared_ptr<vector<date>> genDates(const date& startDate_, const DatePeriod& endPeriod_, const DatePeriod& freq_, HOLIDAYCAL hols_, NBDA conv_, NBDA endConv_, ROLLTYPE roll_);
		static shared_ptr<vector<date>> genDates(const date& startDate_, const date& endDate_, const DatePeriod& freq_, HOLIDAYCAL hols_, NBDA conv_, NBDA endConv_, ROLLTYPE roll_);
	};
}
