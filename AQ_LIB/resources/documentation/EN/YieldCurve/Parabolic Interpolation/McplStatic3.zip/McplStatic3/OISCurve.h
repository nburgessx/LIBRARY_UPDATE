#pragma once
#ifndef MCPLOISCURVE_H
#define MCPLOISCURVE_H

#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "discountcurve.h"
#include "PPCurves.h"
#include "OISSwap.h"
#include "OISFuture.h"
#include "handle.hpp"
#include "numrec/dnr.h"
#include "LinearCurvesHelpers.h"
#include "rateHelpers.h"

using namespace std;

// Similar to LinearForwardsCurve, but it uses linear forwards, not constrained to IMM dates, 
// and not required as inputs, so we just give it some 
namespace MCPL
{

	namespace OISCurveFitFn
	{
		double fitFunc(double OIrate);
	}

	namespace OISCurveFitFnMulti
	{
		void fitFuncMulti(const vector<double> &OIrates, vector<double> &errors);
	}

	class OISCurve : public swapData
	{
	public:
		// constructors
		OISCurve() {}

		virtual Handle<RatesCurve> clone() { return Handle<swapData>(new OISCurve(*this)); }

		void OISCurve::create( double OISRate, const vector<Handle<CurveRateHelper>> &Instruments , 
			date & today, CURRENCY ccy , const vector<date> &meetingDates);

		// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
		//void create_PPCurves( PPCurves & , double pp_val );

		dateVec getMeetingDates() { return m_meetingDates; }
		LinearCurve getInputRates() { return m_inputRates; }

		virtual Handle<PPCurves> create_PPCurves( double pp_val , bool CalculateGammaCurves = true);

	private:



		date m_today;
		date m_spot;

		//void set_currency_defaults(CURRENCY);
		//void set_currency_defaults(CURRENCY, SwapType);

		DayBasis m_basis;
		CURRENCY m_ccy;

		long int m_fixedPmtsPerYear;
		long int m_fltPmtsPerYear;
		DayBasis m_fixedBasis;

		vector<Handle<CurveRateHelper>>	m_instruments;
		/*vector<Handle<OISFuture>> m_futures;
		vector<Handle<OISSwap>>		m_swaps;*/
		double										m_ONRate;
		dateVec										m_meetingDates;

		map<long int, Handle<CurveRateHelper>>		m_rateHelperMap;
		vector<long>												m_rateHelperKeys;
		LinearCurve													m_inputRates;			// Rates at the maturity of each instrument
		//map<long int, double>								m_meetingRates;		// The rate set at each meeting date. Set by interpolating m_inputRates. ** Do we need this?

		HOLIDAYCAL				m_hols;								// holiday cal for the futures
		HOLIDAYCAL				m_swapHols;						// holiday cal for the swaps



		void set_currency_defaults(CURRENCY ccy);
		void calculateDates();
		void calculateCurve();
		void calculateCurveFast();

		void buildDiscountCurveFromOIRates();

		void fitInstrument(const unsigned int index);

		long findClosestInstrumentKey(date date_);

		friend double OISCurveFitFn::fitFunc(double OIrate);
		friend void   OISCurveFitFnMulti::fitFuncMulti(const vector<double> &OIrates, vector<double> &errors);

	};

} // namespace MCPL

#endif // MCPLOISCURVE_H