#include "Swap.h"
#include "LinearCurvesHelpers.h"

#include <iostream>
#include <iomanip>

namespace MCPL
{

	shared_ptr<Swap> Swap::CloneCashflows()
	{
		//First make a shallow copy.
		shared_ptr<Swap> copy = shared_ptr<Swap>(new Swap(*this));

		//Now deep clone the cashflows.
		copy->v_Leg.clear();
		for (auto leg : v_Leg)
		{
			copy->v_Leg.push_back(leg->CloneCashflows());
		}

		return copy;
	}

//*******************************************************************/
  void Swap::addLeg (Handle<Leg> leg)
  {
    v_Leg.push_back( leg );
    v_Leg.back()->setCurves(p_DiscountCurve, p_ForecastCurve) ;
  }	


//*******************************************************************/
  Handle<Leg> Swap::getLastLeg()
  {
    return v_Leg.back();
  }

  void Swap::popLeg()
  {
    v_Leg.pop_back();
  }

//*******************************************************************/
  Handle<Leg> Swap::getLeg(PAYTYPE type)
  {
    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      if ( (*it)->getType() == type ) return *it;
    }
    return *v_Leg.end();
  }


	//*******************************************************************/
  void Swap::setNotional(double notional)
  {
    m_notional = notional;

    // Set coupons in all legs.
    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
       (*it)->setNotional(notional);
    }
  }

	//*******************************************************************/
  void Swap::setNotional(const vector<double>& notional)
  {
    m_notional = notional[0];

    // Set coupons in all legs.
    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
       (*it)->setNotional(notional);
    }
  }


//*******************************************************************/
  void Swap::setCoupon(double coupon)
  {
    m_coupon = coupon;

    // Set coupons in all legs.
    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      if (  (*it)->isFixed() )  (*it)->setCoupon(coupon);
    }
  }

//*******************************************************************/
  void Swap::setCoupon(const vector<double>& coupon)
  {
    m_coupon = coupon[0];

    // Set coupons in all legs.
    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      if (  (*it)->isFixed() )  (*it)->setCoupon(coupon);
    }
  }

  //*******************************************************************/
  shared_ptr<vector<double>> Swap::getCoupons() const
  {
	  for (vLeg::const_iterator it = v_Leg.begin(); it != v_Leg.end(); ++it)
	  {
		  if ((*it)->getType() == PAYTYPE::MC_FIXED) return (*it)->getCoupons();
	  }
	  return shared_ptr<vector<double>>();
  }
//*************************************************************************************************

  void Swap::setSpread(double spread)
  {
    m_spread = spread;

    // Set spreads in all legs.
    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      if ( ! (*it)->isFixed() ) (*it)->setSpread(spread);
    }
  }


//*************************************************************************************************
  
	void Swap::setSpread(const vector<double>& spread)
  {
    m_spread = spread[0];

    // Set coupons in all legs.
    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
       if ( !(*it)->isFixed() )  (*it)->setSpread(spread);
    }
  }

	//*******************************************************************/

    date Swap::getLastDate()
  {
    date last(0);

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      if (  (*it)->getLastDate() > last ) 
        last =  (*it)->getLastDate();
    }

    return last;
  }

  date Swap::getLastDateFixed()
  {
    date last(0);

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      if (  (*it)->isFixed() &&  (*it)->getLastDate() > last ) 
        last =  (*it)->getLastDate();
    }

    return last;
  }

//*************************************************************************************************

  void Swap::fixFirst(double rate)
  {

    // Fix first payment period in all floating legs to rate.
    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      if ( !(*it)->isFixed() ) (*it)->fixFirst(rate);
    }
  }

//*************************************************************************************************

  void Swap::unfixFirst()
  {

    // Unfix first payment period in all floating legs
    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      if ( !(*it)->isFixed() ) (*it)->unfixFirst();
    }
  }


  //*************************************************************************************************


  vector<PAYTYPE> & Swap::getLegTypes( vector<PAYTYPE> & typeVec )
  {
    typeVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
      typeVec.push_back( (*it)->getType() );

    return typeVec;
  }

  //*************************************************************************************************

  vector<dateVec> & Swap::getStartDates( vector<dateVec> & vecVec )
  {
    vecVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      dateVec tmpVec;
      vecVec.push_back( (*it)->getStartDates( tmpVec ) );
    }
    return vecVec;
  }

  //*************************************************************************************************

  vector<dateVec> & Swap::getAdjStartDates( vector<dateVec> & vecVec )
  {
    vecVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      dateVec tmpVec;
      vecVec.push_back( (*it)->getAdjStartDates( tmpVec ) );
    }
    return vecVec;
  }

	  //*************************************************************************************************

  vector<dateVec> & Swap::getEndDates( vector<dateVec> & vecVec )
  {
    vecVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      dateVec tmpVec;
      vecVec.push_back( (*it)->getEndDates( tmpVec ) );
    }
    return vecVec;
  }

  //*************************************************************************************************

  vector<dateVec> & Swap::getAdjEndDates( vector<dateVec> & vecVec )
  {
    vecVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      dateVec tmpVec;
      vecVec.push_back( (*it)->getAdjEndDates( tmpVec ) );
    }
    return vecVec;
  }
  //*************************************************************************************************

  vector<dateVec> & Swap::getPaymentDates( vector<dateVec> & vecVec )
  {
    vecVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      dateVec tmpVec;
      vecVec.push_back( (*it)->getPaymentDates( tmpVec ) );
    }
    return vecVec;
  }

//*******************************************************************/

  vector< vector<double> > & Swap::getNotionals( vector< vector<double> > & vecVec )
  {
    vecVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      vector<double> tmpVec;
      vecVec.push_back( (*it)->getNotionals( tmpVec ) );
    }
    return vecVec;
  }

	//*******************************************************************/

  vector< vector<double> > & Swap::getDCFs( vector< vector<double> > & vecVec )
  {
    vecVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      vector<double> tmpVec;
      vecVec.push_back( (*it)->getDCFs( tmpVec ) );
    }
    return vecVec;
  }

	//*******************************************************************/

  vector< vector<double> > & Swap::getDiscountFactors( vector< vector<double> > & vecVec )
  {
    vecVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      vector<double> tmpVec;
      vecVec.push_back( (*it)->getDiscountFactors( tmpVec ) );
    }
    return vecVec;
  }

//*******************************************************************/

  vector< vector<double> > & Swap::getPayments( vector< vector<double> > & vecVec )
  {
    vecVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      vector<double> tmpVec;
      vecVec.push_back( (*it)->getPayments( tmpVec ) );
    }
    return vecVec;
  }

//*******************************************************************/

  vector< vector<double> > & Swap::getRates( vector< vector<double> > & vecVec )
  {
    vecVec.clear();

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      vector<double> tmpVec;
      vecVec.push_back( (*it)->getRates( tmpVec ) );
    }
    return vecVec;
  }

 //*************************************************************************************************


  double Swap::Price() 
  {
    double dValueOfSwap = 0.0;

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      dValueOfSwap += (*it)->Price();
    }
    return dValueOfSwap;
  }

//*************************************************************************************************

// Prices a swap using the given coupon.
  double Swap::Price( double coupon ) 
  {
    double dValueOfSwap = 0.0;

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      dValueOfSwap += (*it)->Price( coupon );
    }
    return dValueOfSwap;
  }

//*******************************************************************/
  // Prices the swap to a payment date.

  double Swap::Price(date & priceDate)
  {
    double dValueOfSwap = 0.0;

    //double tmp = p_DiscountCurve->getDiscountFactor(priceDate);


    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      dValueOfSwap += (*it)->Price(priceDate);
    }
    return dValueOfSwap;

  }

  //*******************************************************************/
  // Prices the swap using only periods which fall entirely between the first and last dates

  double Swap::Price(date & firstDate, date& lastDate)
  {
	  double dValueOfSwap = 0.0;

	  //double tmp = p_DiscountCurve->getDiscountFactor(priceDate);


	  for (vLeg::iterator it = v_Leg.begin(); it != v_Leg.end(); ++it)
	  {
		  dValueOfSwap += (*it)->Price(firstDate, lastDate);
	  }
	  return dValueOfSwap;

  }

//*******************************************************************/
  double Swap::Price(date & priceDate, double rate)
  {
    auto oldRates = getCoupons();
    setCoupon(rate);
    double price = Price(priceDate);
    setCoupon(*oldRates);
    return price;
  }

  //*******************************************************************/
  double Swap::Price(date & firstDate, date& lastDate, double rate)
  {
	  auto oldRates = getCoupons();
	  setCoupon(rate);
	  double price = Price(firstDate, lastDate);
	  setCoupon(*oldRates);
	  return price;
  }


//*******************************************************************/
  //Price only legs of given type. PVs to today of DF curve
  double Swap::PriceLeg( PAYTYPE type, date & priceDate)
  {
    double dValue = 0;

    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      if ( (*it)->getType() == type ) 
      {
        dValue += (*it)->Price(priceDate);
      }
    }
    return dValue;
  }

	//*******************************************************************/

  double Swap::Solve(double dPresentValue, SOLVETYPE stSolveType)
  {
    //	solves to find the coupon, given PV OR solves to find the spread, given PV.
    //  can be further extended.

    //  iLegNumber is the Leg on which we are to solve

    /*	if ( m_sps ) {
    return getLeg(MC_FIXED).getBeginPP()->getFloatingRate();
    }
    */
    double dSwapBpv = 0.0;
    double dTarget = 0.0;

    // find the value of the swap

    if ( stSolveType == solveFORCOUPON )
    {
      Handle<Leg> leg = getLeg(MC_FIXED);
      double  dSwapValue = Price( leg->getCoupon() );
      dSwapBpv = leg->notionalBasisPointValue();
      dTarget = ( dPresentValue - dSwapValue ) / dSwapBpv + leg->getCoupon();
    }
    else if(stSolveType==solveFORSPREAD)
    {
      Handle<Leg> leg = getLeg(MC_FLOAT);
      double  dSwapValue = Price();
      dSwapBpv = leg->notionalBasisPointValue();
      dTarget = ( dPresentValue - dSwapValue  ) / dSwapBpv  + leg->getSpread();
    }
    return dTarget;
  }

  //*******************************************************************/

  double Swap::SolveRateNumeric(double dPresentValue_, date priceFrom_)
  {
	  auto fn = [&](double rate){ return dPresentValue_ - Price(priceFrom_, rate); };
	  return linearFitter(fn, 0, .05, 1e-4);
  }

  //*******************************************************************/

  double Swap::SolveRateNumeric(double dPresentValue_, date priceFrom_, date priceTo_)
  {
	  auto fn = [&](double rate){ return dPresentValue_ - Price(priceFrom_, priceTo_, rate); };
	  return linearFitter(fn, 0, .05, 1e-4);
  }

	//*******************************************************************/

  void Swap::PrintLegPrices(void)
  {
    for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
    {
      (*it)->printRates();
      cout << "Leg type " << (*it)->getType() << " PV = " << (*it)->Price() << endl;
    }
  }

//*******************************************************************/
  // Sets the swap data, and resyncs the legs to the new data
  void Swap::setCurves(Handle<RatesCurve> discCurve, Handle<RatesCurve> fcastCurve, shared_ptr<VolatilityGrid> pCMSvols)
  {
    p_DiscountCurve = discCurve;
    p_ForecastCurve = fcastCurve;
    p_Leg2ForecastCurve = fcastCurve;
    p_CMSvols = pCMSvols;
	this->updatePaymentsFromCurves();
  }

	//*******************************************************************/
  // Sets the swap data using different forecast curves, as for a basis swap, and resyncs the legs to the new data
  void Swap::setCurves(Handle<RatesCurve> discCurve, Handle<RatesCurve> leg1fcastCurve, Handle<RatesCurve> leg2fcastCurve, shared_ptr<VolatilityGrid> pCMSvols)
  {
    p_DiscountCurve = discCurve;
    p_ForecastCurve = leg1fcastCurve;
    p_Leg2ForecastCurve = leg2fcastCurve;
    p_CMSvols = pCMSvols;
	this->updatePaymentsFromCurves();
  }

//*******************************************************************/
  // resyncs the legs to the data (needed on its own as we pass out pointers to the data, so people can
  // change it without passing it back in.
  void Swap::updatePaymentsFromCurves()
	{
		if ( ( p_DiscountCurve ) && ( p_ForecastCurve ) ) //Test for nullness
		{
			int legCounter = 1;

			for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) 
			{
				if ( legCounter == 1 )
				{
					(*it)->setCurves(p_DiscountCurve, p_ForecastCurve , p_CMSvols);
				}
				else
				{
					(*it)->setCurves(p_DiscountCurve, p_Leg2ForecastCurve , p_CMSvols);
				}
				(*it)->updatePaymentsFromCurves();
				legCounter++;
			}
		}
	}

 //*******************************************************************/
 // Returns the BPV of the swap suitable for pricing a swaption
  double Swap::BPV()
  {
    return getLeg(MC_FIXED)->BasisPointValue();
  }

	//*******************************************************************/
 // Returns the BPV of the swap suitable for pricing a swaption
  double Swap::notionalBPV()
  {
    return abs( getLeg(MC_FIXED)->notionalBasisPointValue() );
  }

//*******************************************************************/
  // Returns the BPV of the swap by paralell shifting the curves by 1bp.
  double Swap::numericalBPV()
  {
    double pv1, pv2;
    pv1 = Price();

    if ( p_ForecastCurve == p_DiscountCurve ) 
    {
      //swapData forecastCurve = *p_ForecastCurve;
      p_DiscountCurve->shiftCurve(.0001, act_360);
	  updatePaymentsFromCurves();
      pv2 = Price();
      p_DiscountCurve->shiftCurve(-.0001, act_360);
	  updatePaymentsFromCurves();
    } 
    else if ( p_ForecastCurve == p_Leg2ForecastCurve )
    {
      //swapData forecastCurve = *p_ForecastCurve;
      //swapData discountCurve = *p_DiscountCurve;
      p_DiscountCurve->shiftCurve(.0001, act_360);
      p_ForecastCurve->shiftCurve(.0001, act_360);
	  updatePaymentsFromCurves();
      pv2 = Price();
      p_DiscountCurve->shiftCurve(-.0001, act_360);
      p_ForecastCurve->shiftCurve(-.0001, act_360);
	  updatePaymentsFromCurves();
    }
		else //Basis swap
		{
      p_DiscountCurve->shiftCurve(.0001, act_360);
      p_ForecastCurve->shiftCurve(.0001, act_360);
      p_Leg2ForecastCurve->shiftCurve(.0001, act_360);
	  updatePaymentsFromCurves();
      pv2 = Price();
      p_DiscountCurve->shiftCurve(-.0001, act_360);
      p_ForecastCurve->shiftCurve(-.0001, act_360);
      p_Leg2ForecastCurve->shiftCurve(-.0001, act_360);
	  updatePaymentsFromCurves();
		}
		double pv3 = Price();
    return (pv2-pv1)/m_notional*10000.0;

  }
  // Copy constructor. We need this as otherwise the pointers in the legs which point back to members of Swap become stale.
  /* Swap::Swap( Swap & rhs)
  {
  v_Leg = rhs.v_Leg;
  eDealType = rhs.eDealType;
  m_iNumberOfLegs = rhs.m_iNumberOfLegs;
  m_swapData = rhs.m_swapData;
  for ( vLeg::iterator it = v_Leg.begin() ; it != v_Leg.end(); ++it ) {
  it->setDataPointer(p_swapData);
  }

  } */

//*******************************************************************/
  // Given the currency and swap type, returns the default day bases, and frequencies.
  void vanillaSwapParams(CURRENCY ccy, SwapType type,
    long int & fixedPmtsPerYear, long int & fltPmtsPerYear, 
    DayBasis & fixedBasis, DayBasis & floatBasis) 
  {
    bool isMoney;
    switch ( type )
    {
    case QB6:
      isMoney = false;
      fixedPmtsPerYear = 4;
      fltPmtsPerYear = 2;
      break;

    case SB6:
      isMoney = false;
      fixedPmtsPerYear = 2;
      fltPmtsPerYear = 2;
      break;

    case AB6:
      isMoney = false;
      fixedPmtsPerYear = 1;
      fltPmtsPerYear = 2;
      break;

    case QB3:
      isMoney = false;
      fixedPmtsPerYear = 4;
      fltPmtsPerYear = 4;
      break;

    case SB3:
      isMoney = false;
      fixedPmtsPerYear = 2;
      fltPmtsPerYear = 4;
      break;

    case AB3:
      isMoney = false;
      fixedPmtsPerYear = 1;
      fltPmtsPerYear = 4;
      break;

    case QM6:
      isMoney = true;
      fixedPmtsPerYear = 4;
      fltPmtsPerYear = 2;
      break;

    case SM6:
      isMoney = true;
      fixedPmtsPerYear = 2;
      fltPmtsPerYear = 2;
      break;

    case AM6:
      isMoney = true;
      fixedPmtsPerYear = 1;
      fltPmtsPerYear = 2;
      break;

    case QM3:
      isMoney = true;
      fixedPmtsPerYear = 4;
      fltPmtsPerYear = 4;
      break;

    case SM3:
      isMoney = true;
      fixedPmtsPerYear = 2;
      fltPmtsPerYear = 4;
      break;

    case AM3:
      isMoney = true;
      fixedPmtsPerYear = 1;
      fltPmtsPerYear = 4;
      break;

			//SB12, SM12, AB12, AM12, QB12, QM12, SB1, SM1, AB1, AM1, QB1, QM1
     case QB12:
      isMoney = false;
      fixedPmtsPerYear = 4;
      fltPmtsPerYear = 1;
      break;
    case QM12:
      isMoney = true;
      fixedPmtsPerYear = 4;
      fltPmtsPerYear = 1;
      break;
		case SB12:
      isMoney = false;
      fixedPmtsPerYear = 2;
      fltPmtsPerYear = 1;
      break;
    case SM12:
      isMoney = true;
      fixedPmtsPerYear = 2;
      fltPmtsPerYear = 1;
      break;
    case AB12:
      isMoney = false;
      fixedPmtsPerYear = 1;
      fltPmtsPerYear = 1;
      break;
    case AM12:
      isMoney = true;
      fixedPmtsPerYear = 1;
      fltPmtsPerYear = 1;
      break;
		case QB1:
      isMoney = false;
      fixedPmtsPerYear = 4;
      fltPmtsPerYear = 1;
      break;
    case QM1:
      isMoney = true;
      fixedPmtsPerYear = 4;
      fltPmtsPerYear = 12;
      break;
		case SB1:
      isMoney = false;
      fixedPmtsPerYear = 2;
      fltPmtsPerYear = 12;
      break;
    case SM1:
      isMoney = true;
      fixedPmtsPerYear = 2;
      fltPmtsPerYear = 12;
      break;
    case AB1:
      isMoney = false;
      fixedPmtsPerYear = 1;
      fltPmtsPerYear = 12;
      break;
    case AM1:
      isMoney = true;
      fixedPmtsPerYear = 1;
      fltPmtsPerYear = 12;
      break;
		case MB1:
      isMoney = false;
      fixedPmtsPerYear = 12;
      fltPmtsPerYear = 12;
      break;
    case MM1:
      isMoney = true;
      fixedPmtsPerYear = 12;
      fltPmtsPerYear = 12;
      break;

	default:
      mcpl_error(std::string("swap type not implemented in Swap.cpp."));
    }

    switch ( ccy )
    {
    case USD: case EUR: case CHF:
      fixedBasis = isMoney ? act_360 : _30_360;
      floatBasis = act_360;
      break;
    case GBP:
      fixedBasis = act_365f;
      floatBasis = act_365f;
      break;
    case JPY:
      fixedBasis = isMoney ? act_360 : act_365f;
      floatBasis = act_360;
      break;
    default:
      mcpl_error(std::string("currency does not have a vanilla swap type.") );
    }
  }

  // Given the currency, returns the default day bases, and frequencies.
  void vanillaSwapParams(CURRENCY ccy,
    long int & fixedPmtsPerYear, long int & fltPmtsPerYear, 
    DayBasis & fixedBasis, DayBasis & floatBasis) 
  {
    switch ( ccy )
    {
    case USD:
      vanillaSwapParams(ccy, AM3, fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis);
      break;
    case EUR:
      vanillaSwapParams(ccy, AB6, fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis);
      break;
    case GBP: case JPY:
      vanillaSwapParams(ccy, SB6, fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis);
      break;
    case CHF:
      vanillaSwapParams(ccy, AB3, fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis);
      break;
    }
  }

  // Intelligent swap constructor!!

  Swap::Swap (DIRECTIONTYPE dir, date & start, date & mature, double notional, 
    double coupon, double spread, long int fixedPmtsPerYear, long int fltPmtsPerYear, 
    DayBasis fixedBasis, DayBasis floatBasis, HOLIDAYCAL hol, bool IsFRA) 
  {
    DIRECTIONTYPE dir2;

    m_notional  = notional;
    m_coupon    = coupon;
    m_spread    = spread;
    m_direction = dir;
	m_hols = hol;
	m_effectiveDate = start;
	m_matureDate = mature;
	m_adjMatureDate = m_matureDate;
	m_adjMatureDate.rollFwd(hol, true);
	m_roll = mature.day();
	m_longCoupon = false;

    m_IsFRA = IsFRA;

	p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
	p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);
    
	dir2 = dir == PAY ? RECEIVE : PAY;

    addLeg( Handle<Leg>(new Leg( dir , MC_FIXED, start, mature, notional, coupon, fixedPmtsPerYear, fixedBasis, 
      hol, ROLL_BACKWARD, UNDEF/*ccy*/, ModelNone/*option model*/, mixing_model(), date(0)/*today*/, IsFRA) ) );
    addLeg( Handle<Leg>(new Leg( dir2 , MC_FLOAT, start, mature, notional, spread, fltPmtsPerYear, floatBasis, 
      hol, ROLL_BACKWARD, UNDEF/*ccy*/, ModelNone/*option model*/, mixing_model(), date(0)/*today*/, IsFRA) ) );
  }

	//With roll.
	Swap::Swap (DIRECTIONTYPE dir, date & start, date & mature, date & roll, double notional, 
    double coupon, double spread, long int fixedPmtsPerYear, long int fltPmtsPerYear, 
    DayBasis fixedBasis, DayBasis floatBasis, HOLIDAYCAL hol) 
  {
    DIRECTIONTYPE dir2;

    m_notional  = notional;
    m_coupon    = coupon;
    m_spread    = spread;
    m_direction = dir;
		m_hols = hol;
		m_effectiveDate = start;
		m_matureDate = mature;
		m_adjMatureDate = m_matureDate;
		m_adjMatureDate.rollFwd(hol, true);
		m_roll = roll.day();
		m_longCoupon = false;


		p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);

    dir2 = dir == PAY ? RECEIVE : PAY;

    addLeg( Handle<Leg>(new Leg( dir , MC_FIXED, start, mature, notional, coupon, fixedPmtsPerYear, fixedBasis, hol) ) );
    addLeg( Handle<Leg>(new Leg( dir2 , MC_FLOAT, start, mature, notional, spread, fltPmtsPerYear, floatBasis, hol) ) );
  }

  // Vanilla swap constructor.
  Swap::Swap( DIRECTIONTYPE dir, date & start, date & mature, double notional, double coupon, double spread, 
    HOLIDAYCAL hol, CURRENCY ccy)
  {
    DIRECTIONTYPE dir2;

    m_notional  = notional;
    m_coupon    = coupon;
    m_spread    = spread;
    m_direction = dir;
    DayBasis fixedBasis, floatBasis;
    long int fixedPmtsPerYear, fltPmtsPerYear;
		m_hols = hol;
		m_effectiveDate = start;
		m_matureDate = mature;
		m_adjMatureDate = m_matureDate;
		m_adjMatureDate.rollFwd(hol, true);
		m_roll = mature.day();
		m_longCoupon = false;


		p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);

		// Get the params for the vanilla swap in this currency.
    vanillaSwapParams(ccy, fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis);

    dir2 = dir == PAY ? RECEIVE : PAY;

    addLeg( Handle<Leg>(new Leg( dir , MC_FIXED, start, mature, notional, coupon, fixedPmtsPerYear, fixedBasis, hol) ) );
    addLeg( Handle<Leg>(new Leg( dir2 , MC_FLOAT, start, mature, notional, spread, fltPmtsPerYear, floatBasis, hol) ) );
  }

	// SwapType swap constructor with roll date
  Swap::Swap( DIRECTIONTYPE dir, SwapType sType, date & start, date & mature, date & roll,
    double notional, double coupon, double spread, HOLIDAYCAL hol, CURRENCY ccy, bool IsOIS)
  {
    DIRECTIONTYPE dir2;

    m_notional  = notional;
    m_coupon    = coupon;
    m_spread    = spread;
    m_direction = dir;
    DayBasis fixedBasis, floatBasis;
    long int fixedPmtsPerYear, fltPmtsPerYear;
		m_hols = hol;
		m_effectiveDate = start;
		m_matureDate = mature;
		m_adjMatureDate = m_matureDate;
		m_adjMatureDate.rollFwd(hol, true);
		m_roll = roll.day();
		m_longCoupon = false;


		p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);

    if ( start > mature ) MCPL_ERROR("start date must precede end date in swap generation.");

    // Get the params for the vanilla swap in this currency.
    vanillaSwapParams(ccy, sType, fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis);

    dir2 = dir == PAY ? RECEIVE : PAY;

    addLeg( Handle<Leg>(new Leg( dir , MC_FIXED, start, mature, roll, notional, coupon, fixedPmtsPerYear, fixedBasis, hol, UNDEF/*ccy*/, ModelNone/*option model*/, mixing_model(), date(0) /*today*/, false/*isfra*/, 0/*payDateOffset*/, IsOIS) ) );
    addLeg( Handle<Leg>(new Leg( dir2 , MC_FLOAT, start, mature, roll, notional, spread, fltPmtsPerYear, floatBasis, hol, UNDEF/*ccy*/, ModelNone/*option model*/, mixing_model(), date(0) /*today*/, false/*isfra*/, 0/*payDateOffset*/, IsOIS) ) );
  }

  // SwapType swap constructor.
  Swap::Swap( DIRECTIONTYPE dir, SwapType sType, date & start, date & mature, 
    double notional, double coupon, double spread, HOLIDAYCAL hol, CURRENCY ccy, ROLLTYPE rolltype, bool IsFRA)
  {
    DIRECTIONTYPE dir2;

    m_notional  = notional;
    m_coupon    = coupon;
    m_spread    = spread;
    m_direction = dir;
    m_IsFRA     = IsFRA;
    DayBasis fixedBasis, floatBasis;
    long int fixedPmtsPerYear, fltPmtsPerYear;
		m_hols = hol;
		m_effectiveDate = start;
		m_matureDate = mature;
		m_adjMatureDate = m_matureDate;
		m_adjMatureDate.rollFwd(hol, true);
		m_roll = mature.day();
		m_longCoupon = false;


		p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);

    if ( start > mature ) MCPL_ERROR("start date must precede end date in swap generation.");

    // Get the params for the vanilla swap in this currency.
    vanillaSwapParams(ccy, sType, fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis);

    dir2 = dir == PAY ? RECEIVE : PAY;

    addLeg( Handle<Leg>(new Leg( dir , MC_FIXED, start, mature, notional, coupon, fixedPmtsPerYear, fixedBasis, hol, rolltype, ccy, ModelNone/*option model*/, mixing_model(), date(0)/*today*/, IsFRA) ) );
    addLeg( Handle<Leg>(new Leg( dir2 , MC_FLOAT, start, mature, notional, spread, fltPmtsPerYear, floatBasis, hol, rolltype, ccy, ModelNone/*option model*/, mixing_model(), date(0)/*today*/, IsFRA) ) );
  }

  // Same as above, but also sets the curves
  Swap::Swap( DIRECTIONTYPE dir, date & start, date & mature, double notional, 
    double coupon, double spread, long int fixedPmtsPerYear, long int fltPmtsPerYear, 
    DayBasis fixedBasis, DayBasis floatBasis, Handle<RatesCurve> discountCurve, 
	Handle<RatesCurve> forecastCurve, HOLIDAYCAL hol, shared_ptr<VolatilityGrid> pCMSvols)
  {
    DIRECTIONTYPE dir2;

    m_notional  = notional;
    m_coupon    = coupon;
    m_spread    = spread;
    m_direction = dir;
		m_hols = hol;
		m_effectiveDate = start;
		m_matureDate = mature;
		m_adjMatureDate = m_matureDate;
		m_adjMatureDate.rollFwd(hol, true);
		m_roll = mature.day();
		m_longCoupon = false;


    dir2 = dir == PAY ? RECEIVE : PAY;

    addLeg( Handle<Leg>(new Leg( dir , MC_FIXED, start, mature, notional, coupon, fixedPmtsPerYear, fixedBasis, hol) ) );
    addLeg( Handle<Leg>(new Leg( dir2 , MC_FLOAT, start, mature, notional, spread, fltPmtsPerYear, floatBasis, hol) ) );

    p_DiscountCurve = discountCurve;
    p_Leg2ForecastCurve = p_ForecastCurve = forecastCurve;
    p_CMSvols = pCMSvols;
	this->updatePaymentsFromCurves();
  }

  // allows us to set up asset swaps
  Swap::Swap( PAYTYPE sideOneType, PAYTYPE sideTwoType, date & start, 
    date & firstFixedCoupon, date & mature, double notional, double coupon, 
    double spread, long int fixedPmtsPerYear, long int fltPmtsPerYear, 
    DayBasis fixedBasis, DayBasis floatBasis, Handle<RatesCurve> discountCurve, 
	Handle<RatesCurve> forecastCurve, HOLIDAYCAL hol, shared_ptr<VolatilityGrid> pCMSvols)
  {

		m_notional  = notional;
    m_coupon    = coupon;
    m_spread    = spread;
    m_direction = PAY;
	m_hols = hol;
	m_effectiveDate = start;
	m_matureDate = mature;
	m_adjMatureDate = m_matureDate;
	m_adjMatureDate.rollFwd(hol, true);
	m_roll = mature.day();
	m_longCoupon = false;


    //careful, this looks generic but is specific to asset swaps. BEWARE.
    firstFixedCoupon = addBusinessMonths(firstFixedCoupon, (-12/fixedPmtsPerYear) , hol, true);
    addLeg( Handle<Leg>(new Leg( PAY , sideOneType, firstFixedCoupon, mature, notional, coupon, fixedPmtsPerYear, fixedBasis, hol) ) );
    addLeg( Handle<Leg>(new Leg( RECEIVE , sideTwoType, start, mature, notional, spread, fltPmtsPerYear, floatBasis, hol) ) );

    p_DiscountCurve = discountCurve;
    p_Leg2ForecastCurve = p_ForecastCurve = forecastCurve;
    p_CMSvols = pCMSvols;
	this->updatePaymentsFromCurves();
  }


	
	//Basis swap. 
	Swap::Swap( date & start, date & mature, double notional, double leg1Spread, double leg2Spread, 
		  long int leg1PmtsPerYear, long int leg2PmtsPerYear, DayBasis leg1Basis, DayBasis leg2Basis, 
		  Handle<RatesCurve> discountCurve, Handle<RatesCurve> leg1forecastCurve, Handle<RatesCurve> leg2forecastCurve, HOLIDAYCAL hol )
  {
    m_notional  = notional;
    m_coupon    = leg1Spread;
    m_spread    = leg2Spread;
    m_direction = PAY;
	m_hols = hol;
	m_effectiveDate = start;
	m_matureDate = mature;
	m_adjMatureDate = m_matureDate;
	m_adjMatureDate.rollFwd(hol, true);
	m_roll = mature.day();
	m_longCoupon = false;


    addLeg( Handle<Leg>(new Leg( PAY , MC_FLOAT, start, mature, notional, leg1Spread, leg1PmtsPerYear, leg1Basis, hol) ) );
    addLeg( Handle<Leg>(new Leg( RECEIVE , MC_FLOAT, start, mature, notional, leg2Spread, leg2PmtsPerYear, leg2Basis, hol) ) );

    p_DiscountCurve = discountCurve;
    p_ForecastCurve = leg1forecastCurve;
    p_Leg2ForecastCurve = leg2forecastCurve;
	p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);
	this->updatePaymentsFromCurves();
  }

	//Basis swap no curves
	Swap::Swap( date & start, date & mature, double notional, double leg1Spread, double leg2Spread, 
		  long int leg1PmtsPerYear, long int leg2PmtsPerYear, DayBasis leg1Basis, DayBasis leg2Basis, HOLIDAYCAL hol )
  {
    m_notional  = notional;
    m_coupon    = leg1Spread;
    m_spread    = leg2Spread;
    m_direction = PAY;
	m_hols = hol;
	m_effectiveDate = start;
	m_matureDate = mature;
	m_adjMatureDate = m_matureDate;
	m_adjMatureDate.rollFwd(hol, true);
	m_roll = mature.day();
	m_longCoupon = false;


    addLeg( Handle<Leg>(new Leg( PAY , MC_FLOAT, start, mature, notional, leg1Spread, leg1PmtsPerYear, leg1Basis, hol) ) );
    addLeg( Handle<Leg>(new Leg( RECEIVE , MC_FLOAT, start, mature, notional, leg2Spread, leg2PmtsPerYear, leg2Basis, hol) ) );

 		p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);

  }


 // // As above (i.e. lets you specify the two leg types ) and also alows for index tenors 
 // // which differ from 12/pmtsperyear
 // // i.e. for CMS swaps.
 // Swap::Swap( PAYTYPE sideOneType, PAYTYPE sideTwoType, date & start, date & mature, 
 //   double notional, double spread1, double spread2, 
 //   long int fixedPmtsPerYear, long int fltPmtsPerYear, long int sideOneTenorMnths, 
 //   long int sideTwoTenorMnths, SwapType CMStype1, SwapType CMStype2, 
 //   DayBasis fixedBasis, DayBasis floatBasis, Handle<RatesCurve> discountCurve, 
 //   Handle<RatesCurve> forecastCurve, HOLIDAYCAL hol, CURRENCY ccy, 
 //   VolatilityGrid * pCMSvols, OptionModel CMSmodel)
 // {

 //   m_notional  = notional;
 //   m_coupon    = spread1;
 //   m_spread    = spread2;
 //   m_direction = PAY;
	//m_hols = hol;
	//m_effectiveDate = start;
	//m_matureDate = mature;
	//m_adjMatureDate = m_matureDate;
	//m_adjMatureDate.rollFwd(hol, true);
	//m_roll = mature.day();
	//m_longCoupon = false;


 //   addLeg( Handle<Leg>(new Leg( PAY , sideOneType, start, mature, notional, spread1, fixedPmtsPerYear, sideOneTenorMnths, 
 //     CMStype1, fixedBasis, hol, ccy, CMSmodel) ) );
 //   addLeg( Handle<Leg>(new Leg( RECEIVE , sideTwoType, start, mature, notional, spread2, fltPmtsPerYear, sideTwoTenorMnths, 
 //     CMStype2, floatBasis, hol, ccy, CMSmodel) ) );

 //   p_DiscountCurve = discountCurve;
 //   p_Leg2ForecastCurve = p_ForecastCurve = forecastCurve;
 //   p_CMSvols = pCMSvols;
 //   this->setCurves();
 // }


  // allows us to set up a SPS, i.e for a cap
  Swap::Swap (DIRECTIONTYPE dir, date & start, date & mature, double notional, double coupon, double spread, 
    DayBasis fixedBasis, DayBasis floatBasis, long floatMonths, HOLIDAYCAL hol) 
  {
    DIRECTIONTYPE dir2;

    m_notional  = notional;
    m_coupon    = coupon;
    m_spread    = spread;
    m_direction = dir;
    m_sps = true;
	m_hols = hol;
	m_effectiveDate = start;
	m_matureDate = mature;
	m_adjMatureDate = m_matureDate;
	m_adjMatureDate.rollFwd(hol, true);
	m_roll = mature.day();
	m_longCoupon = false;


	p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
	p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);

    dir2 = dir == PAY ? RECEIVE : PAY;

    addLeg( Handle<Leg>(new Leg( dir , MC_FIXED, start, mature, notional, coupon, fixedBasis, floatMonths, hol) ) );
    addLeg( Handle<Leg>(new Leg( dir2 , MC_FLOAT, start, mature, notional, spread, floatBasis, floatMonths, hol) ) );
  }

  // Has a roll date, long last/first coupon, roll fwd/back and spread/coupon steps
  Swap::Swap( DIRECTIONTYPE dir, date & start, date & first, date & mature, date & roll, 
    ROLLTYPE rolltype, bool longCoupon, double notional, double coupon, double couponStep, 
    double spread, double spreadStep, long int fixedPmtsPerYear, long int fltPmtsPerYear, 
    DayBasis fixedBasis, DayBasis floatBasis, Handle<RatesCurve> discountCurve, 
	Handle<RatesCurve> forecastCurve, HOLIDAYCAL hol, shared_ptr<VolatilityGrid> pCMSvols)
  {
    m_notional  = notional;
    m_coupon    = coupon;
    m_spread    = spread;
    m_direction = PAY;
	m_hols = hol;
	m_effectiveDate = start;
	m_matureDate = mature;
	m_adjMatureDate = m_matureDate;
	m_adjMatureDate.rollFwd(hol, true);
	m_roll = roll.day();
	m_longCoupon = longCoupon;

    DIRECTIONTYPE dir2 = dir == PAY ? RECEIVE : PAY;

    addLeg(	Handle<Leg>(new Leg(dir, MC_FIXED , start , first, mature, roll, rolltype, longCoupon, 
      notional, coupon, couponStep, fixedPmtsPerYear, fixedBasis, hol) ) );
    addLeg( Handle<Leg>(new Leg(dir2, MC_FLOAT , start , first, mature, roll, rolltype, longCoupon, 
      notional, spread, spreadStep, fltPmtsPerYear, floatBasis, hol) ) );

    p_DiscountCurve = discountCurve;
    p_Leg2ForecastCurve = p_ForecastCurve = forecastCurve;
    p_CMSvols = pCMSvols;
	this->updatePaymentsFromCurves();
  }

  // In this constructor, can specify Fixed leg notional, coupon and spread as vectors, one element per
  // payment.
	// Auto generates float leg notionals.
  // Has a roll date, roll fwd/back.
  Swap::Swap( DIRECTIONTYPE dir, date & start, date & first, date & mature, date & roll, 
    ROLLTYPE rolltype, bool longCoupon, const vector<double> & vFixedNotional, const vector<double> & vcoupon, 
    const vector<double> & vspread, long int fixedPmtsPerYear, long int fltPmtsPerYear, 
    DayBasis fixedBasis, DayBasis floatBasis, Handle<RatesCurve> discountCurve, 
	Handle<RatesCurve> forecastCurve, HOLIDAYCAL hol, shared_ptr<VolatilityGrid> pCMSvols)
  {
    m_notional  = vFixedNotional[0];
    m_coupon    = vcoupon[0];
    m_spread    = vspread[0];
    m_direction = PAY;
	m_hols = hol;
	m_effectiveDate = start;
	m_matureDate = mature;
	m_adjMatureDate = m_matureDate;
	m_adjMatureDate.rollFwd(hol, true);
	m_roll = roll.day();
	m_longCoupon = longCoupon;

	double legRatio = (double)fltPmtsPerYear / (double)fixedPmtsPerYear;
	unsigned floatNSize = (unsigned) (vFixedNotional.size() * legRatio);
	vector<double> vFloatNotionals;
	vFloatNotionals.reserve( floatNSize );

	for ( unsigned ifl = 0 ; ifl < floatNSize ; ++ifl )
	{
		unsigned ifxd = (unsigned)( (double)ifl / legRatio );
		vFloatNotionals.push_back( vFixedNotional[ifxd] );
	}

    DIRECTIONTYPE dir2 = dir == PAY ? RECEIVE : PAY;

    addLeg(	Handle<Leg>(new Leg(dir, MC_FIXED , start , first, mature, roll, rolltype, longCoupon, 
      vFixedNotional, vcoupon, fixedPmtsPerYear, fixedBasis, hol) ) );
    addLeg(	Handle<Leg>(new Leg(dir2, MC_FLOAT , start , first, mature, roll, rolltype, longCoupon, 
      vFloatNotionals, vspread, fltPmtsPerYear, floatBasis, hol) ) );

	p_DiscountCurve = discountCurve;
    p_Leg2ForecastCurve = p_ForecastCurve = forecastCurve;
    p_CMSvols = pCMSvols;
	this->updatePaymentsFromCurves();
  }

  //this is a simple solve routine
  // currently it solves for spread or coupon given PV.
  // in future it should solve for volatility and step up.





} //end scope
// End.
