#pragma once

#ifndef MCPLRERERENCEINDEX_H
#define MCPLRERERENCEINDEX_H
#include "MCPL.h"
#include "McDateClass/dates.h"
#include "mcpldefs.h"

namespace MCPL
{

typedef enum {
  LIBOR, CMS
} ReferenceIndexType;

class ReferenceIndex
{
public:
	ReferenceIndex() : m_period_months(3), m_ccy(USD) , m_type(LIBOR)
		{m_basis = getLiborBasis(m_ccy); }

	ReferenceIndex(CURRENCY ccy) : m_period_months(3), m_ccy(ccy) , m_type(LIBOR)
		{m_basis = getLiborBasis(m_ccy); }

	ReferenceIndex(CURRENCY ccy, unsigned period_months) : m_period_months(period_months), m_ccy(ccy) , m_type(LIBOR)
		{m_basis = getLiborBasis(m_ccy); }

private:
	unsigned m_period_months;
	HOLIDAYCAL m_hols;
	CURRENCY m_ccy;
	DayBasis m_basis;
	ReferenceIndexType m_type; // CMS or LIBOR
};

} // namespace

#endif
