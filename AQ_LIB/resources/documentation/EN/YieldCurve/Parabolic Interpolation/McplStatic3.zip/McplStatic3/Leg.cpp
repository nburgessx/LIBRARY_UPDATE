#pragma warning ( disable : 4251 4786 ) 

#include "Leg.h"
#include "Swap.h"
#include "cms.h"
#include "Globals.h"
#include <iostream>
#include <iomanip>

namespace MCPL
{

	bool sortPredicate( Handle<PaymentPeriod> pp1, Handle<PaymentPeriod> pp2) 
	{ 
		return pp1->getAdjustedStart() < pp2->getAdjustedStart(); 
	}

	void Leg::sortPayments() 
	{ 
		sort( v_paymentPeriod.begin() ,  v_paymentPeriod.end(), sortPredicate ); 
	}


	//Add a payment period to a Leg
	void Leg::addPayment(Handle<PaymentPeriod> pp)
	{
		v_paymentPeriod.push_back( pp );
		date lastDate =  m_payType != MC_FIXED && pp->getFloatingPeriodEnd() > pp->getAdjustedEnd() ? 
			pp->getFloatingPeriodEnd() : pp->getAdjustedEnd();
		if ( lastDate > m_lastDate )
			m_lastDate = lastDate;
	}

	//***********************************************************************************************************

	Leg::pp_iterator Leg::firstFixablePeriod()
	{
		if ( !p_DiscountCurve )
		{
			return v_paymentPeriod.begin();
		}
		else
		{
			date curveDate = p_DiscountCurve->firstDate();
			pp_iterator it = v_paymentPeriod.begin();

			while ( ( it != v_paymentPeriod.end() ) && ((*it)->getReset() <= curveDate) )
				it++;

			if ( it != v_paymentPeriod.begin() )
				it--;

			return it;
		}
	}

	Leg::pp_iterator Leg::prevFixablePeriod()
	{
		// returns the period preceding the fistFixable one, if there is any
		pp_iterator it = firstFixablePeriod();
		if ( it != v_paymentPeriod.begin() )
			it--;
		return it;
	}
	//***********************************************************************************************************

	void Leg::setSpread(double spread)
	{
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			(*it)->setSpread(spread);
		}
	}
	//***********************************************************************************************************

	void Leg::setSpread(const vector<double> & spread)
	{
		if ( spread.size() < v_paymentPeriod.size() ) 
		{
			ostringstream errStr;
			errStr << "Spread vector shorter (" << spread.size() << ") than number of periods in leg ("
				<< v_paymentPeriod.size() <<").";

			mcpl_error( errStr.str() );
		}

		int i=0;
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			(*it)->setSpread(spread[i++]);
		}
	}


	//***********************************************************************************************************

	shared_ptr<vector<double>> Leg::getCoupons() const
	{
		auto coupons = shared_ptr<vector<double>>(new vector<double>);
		for (vPaymentPeriod::const_iterator it = v_paymentPeriod.begin(); it != v_paymentPeriod.end(); ++it)
			coupons->push_back((*it)->getCoupon());

		return coupons;
	}

	//***********************************************************************************************************

	dateVec & Leg::getStartDates( dateVec & dVec)
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getTargetStart() );

		return dVec;
	}


	//***********************************************************************************************************


	dateVec & Leg::getAdjStartDates( dateVec & dVec)
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getAdjustedStart() );

		return dVec;
	}



	//***********************************************************************************************************


	dateVec & Leg::getEndDates( dateVec & dVec)
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getTargetEnd() );

		return dVec;
	}

	//***********************************************************************************************************

	dateVec & Leg::getAdjEndDates( dateVec & dVec)
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getAdjustedEnd() );

		return dVec;
	}

	//***********************************************************************************************************


	dateVec & Leg::getPaymentDates( dateVec & dVec)
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getPaymentDate() );

		return dVec;
	}


	//***********************************************************************************************************

	vector<double> & Leg::getNotionals( vector<double>  & dVec )
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getNotional() );

		return dVec;
	}

	//***********************************************************************************************************

	vector<double> & Leg::getDCFs( vector<double>  & dVec )
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getDayCountFraction() );

		return dVec;
	}

	//***********************************************************************************************************

	vector<double> & Leg::getDiscountFactors( vector<double>  & dVec )
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getDiscountFactor() );

		return dVec;
	}

	//***********************************************************************************************************

	vector<double> & Leg::getPayments( vector<double>  & dVec )
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getPaymentAmount() );

		return dVec;
	}

	//***********************************************************************************************************

	vector<double> & Leg::getPVs( vector<double>  & dVec )
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->Price() );

		return dVec;
	}

	//***********************************************************************************************************

	vector<double> & Leg::getVegas( vector<double>  & dVec )
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getVega() );

		return dVec;
	}

	//***********************************************************************************************************

	vector<double> & Leg::getRates( vector<double>  & dVec )
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getFloatingRate() );

		return dVec;
	}

	//***********************************************************************************************************

	vector<double> & Leg::getSpreads( vector<double>  & dVec )
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getSpread() );

		return dVec;
	}

	//***********************************************************************************************************

	vector<BlackVol> & Leg::getVols(vector<BlackVol>  & dVec)
	{
		dVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			dVec.push_back( (*it)->getVolatility() );

		return dVec;
	}

	//***********************************************************************************************************

	vector<PaymentPeriod> & Leg::getAllPeriods( vector<PaymentPeriod> & ppVec )
	{
		ppVec.clear();
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			ppVec.push_back( **it );

		return ppVec;
	}

	//***********************************************************************************************************

	void Leg::setCoupon(double  coupon)
	{
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			(*it)->setCoupon(coupon);
		}
	}
	//***********************************************************************************************************

	void Leg::setCoupon(const vector<double> & coupon)
	{
		if ( coupon.size() < v_paymentPeriod.size() ) 
		{
			ostringstream errStr;
			errStr << "Coupon vector shorter (" << coupon.size() << ") than number of periods in leg ("
				<< v_paymentPeriod.size() <<").";

			mcpl_error( errStr.str() );
		}
		int i=0;
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			(*it)->setCoupon(coupon[i++]);
		}
	}

	//***********************************************************************************************************

	void Leg::setNotional(double  notional)
	{
		notional = abs(notional) * (m_paymentDirection == PAY) ? -1 : 1; // -ve notional for paying.

		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			(*it)->setNotional(notional);
		}
	}

	//***********************************************************************************************************

	void Leg::setNotional(const vector<double> & vNotional)
	{
		vector<double> notionals(v_paymentPeriod.size());

		if ( vNotional.size() != v_paymentPeriod.size() ) 
		{
			unsigned notPeriods = vNotional.size();
			unsigned legPeriods = v_paymentPeriod.size();

			double legRatio = (double) legPeriods / (double) notPeriods;
			if ( legPeriods < notPeriods )
				legRatio = 1/legRatio;

			if ( ( legRatio != 2 ) && (legRatio != 3) && ( legRatio != 4 ) && ( legRatio != 6 ) && ( legRatio != 12 ) )
			{
				ostringstream errStr;
				errStr << "Weird ratio of notionals supplied (" << vNotional.size() << ") to periods in leg ("
					<< v_paymentPeriod.size() <<").";

				mcpl_error( errStr.str() );
			}
			else
			{
				if ( legPeriods < notPeriods )
					legRatio = 1/legRatio;

				// Create correct length vector of notionals
				for ( unsigned i=0 ; i < legPeriods ; ++i )
				{
					notionals[i] = vNotional[(unsigned)(i / legRatio)];
				}
			}
		}
		else
		{
			notionals = vNotional;
		}

		int i=0;
		int dir = (m_paymentDirection == PAY) ? -1 : 1;
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			(*it)->setNotional( abs(notionals[i++]) * dir ); // -ve notional for paying.
		}
	}


	//***********************************************************************************************************


	double Leg::Price() 
	{
		double dValueOfLeg = 0.0;

		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			dValueOfLeg += (*it)->Price();
		}
		return dValueOfLeg;
	}

	//***********************************************************************************************************

	// prices leg given a coupon rate.
	double Leg::Price( double coupon ) 
	{
		double dValueOfLeg = 0.0;

		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			dValueOfLeg += (*it)->Price( coupon );
		}
		return dValueOfLeg;
	}

	//***********************************************************************************************************


	double Leg::Vega() 
	{
		double dVegaOfLeg = 0.0;

		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			dVegaOfLeg += (*it)->getVega();
		}
		return dVegaOfLeg;
	}

	//***********************************************************************************************************


	void Leg::printDates()
	{
		int i=0;
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			cout << ++i << "  " << (*it)->getAdjustedStart() << " ( " << (*it)->getTargetStart() << " ) ->"
				<< (*it)->getAdjustedEnd() << " ( " << (*it)->getTargetEnd() << " ) ->"
				<< (*it)->getAdjustedEnd() - (*it)->getAdjustedStart() << " days  :  dcf=" 
				<< (*it)->getDayCountFraction() << endl ;
		}
	}


	//***********************************************************************************************************

	void Leg::printRates()
	{
		double rate;
		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			rate = (*it)->getPaymentType() == MC_FLOAT ? (*it)->getFloatingRate() :(*it)->getCoupon();
			cout << (*it)->getAdjustedStart() << "  :  " 
				<< (*it)->getAdjustedEnd() << "  :  " 
				<< (*it)->getAdjustedEnd() - (*it)->getAdjustedStart() << "  :  " 
				<< rate << "  :  " 
				<< (*it)->getDiscountFactor() << "  :  " 
				<< (*it)->getDayCountFraction() * (*it)->getNotional() * rate  << "  :  " 
				<< p_ForecastCurve->getZero((*it)->getAdjustedStart() , (*it)->getAdjustedEnd() ) << endl;
		}
	}


	//***********************************************************************************************************

	/*********************************************
	*  Values a Leg and PVs it to today (from DF curve)     *
	*********************************************/
	double Leg::Price(date valueDate)
	{
		return Price(valueDate, (*(v_paymentPeriod.rbegin()))->getAdjustedEnd());
	}

	//***********************************************************************************************************

	/*********************************************
	*  Only price the leg using pp which fall entirely between the first nad last dates   *
	*********************************************/
	double Leg::Price(date firstDate, date lastDate)
	{
		double dValueOfLeg = 0.0;
		PaymentPeriod tmpPeriod;


		for (vPaymentPeriod::iterator it = v_paymentPeriod.begin(); it != v_paymentPeriod.end(); ++it)
		{
			// Value periods which are entirely after the firstDate and before the lastDate
			if ((*it)->getAdjustedStart() >= firstDate && (*it)->getAdjustedEnd() <= lastDate)
			{
				dValueOfLeg += (*it)->Price();
			}
			//else 
			//{
			//	// Value periods which are only partially after the payment date.
			//	if ( ((*it)->getAdjustedStart() < valueDate ) && 
			//		( (*it)->getAdjustedEnd() > valueDate ) ) 
			//	{

			//		MCPL_ERROR err;
			//		err = "You are trying to value a leg to a date " + string(valueDate) + " in the middle of a payment period ( " + string((*it)->getAdjustedStart()) + " -> " + string((*it)->getAdjustedEnd()) + " ). ";
			//		err += "This code has not been implemented yet, so you have probably made a mistake";
			//		throw err;
			//	}
			//}

		}
		// Return the value PVd to the value Date.
		//	updatePaymentsFromData(*p_swapData);
		return dValueOfLeg;
	}


	//***********************************************************************************************************


	// *****************************************************
	//
	// Returns the payment period which contains paymentDate
	//
	// *****************************************************
	Handle<PaymentPeriod> Leg::getPayment(date &paymentDate)
	{
		bool found = false;
		vPaymentPeriod::iterator it;

		for ( it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
			if ( (*it)->getPaymentDate() == paymentDate ) 
			{
				found = true;
				break;
			}

			// If paymentDate doesn't exist in this leg, throw a wobbly.
			if ( ! found ) 
			{
				MCPL_ERROR err("Non existant payment date in Leg::getPayment");
				throw err;
			}
			return *it; 
	}


	//***********************************************************************************************************


	double Leg::BasisPointValue() 
	{
		double dSwapBpv = 0.0;


		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			dSwapBpv += (*it)->getDayCountFraction() * (*it)->getDiscountFactor();
		}
		return dSwapBpv;
	}

	//***********************************************************************************************************


	double Leg::notionalBasisPointValue() 
	{
		double dSwapBpv = 0.0;


		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			dSwapBpv += (*it)->getDayCountFraction() * (*it)->getDiscountFactor() * (*it)->getNotional();
		}
		return dSwapBpv;
	}


	//***********************************************************************************************************


	void Leg::updatePaymentsFromCurves()
	{

		date firstDCurveDate = p_DiscountCurve->firstDate();
		date lastFCurveDate = p_ForecastCurve->lastDate();

		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			// changed by Alexey to exclude today's payments from legPV. used to be >=
			if ( (*it)->getPaymentDate() > firstDCurveDate )
			{
				if (!m_IsFRA)
					(*it)->setDiscountFactor( p_DiscountCurve->getDiscountFactor( (*it)->getPaymentDate() ) );
				else
					(*it)->setDiscountFactor( p_DiscountCurve->getDiscountFactor( (*it)->getAdjustedStart() ) );
			}
			else
				(*it)->setDiscountFactor(0);


			//typedef enum {MC_FIXED,MC_BOND,MC_PAYMENT, MC_FLOAT, MC_CAP, MC_FLOOR, MC_CMS} PAYTYPE;

			// Now update the floating payments
			if ( (*it)->getAdjustedStart() >= firstDCurveDate )
			{
				switch ( m_payType )
				{
				case MC_FLOAT:
				case MC_FIXED:
					if ((m_payType == MC_FIXED) && !m_IsFRA) // only set float rate on fixed leg of a FRA. required for correct calculation of the payment
						break;
					//  Floating rate as defined by Apollo. This is WRONG!
					//  Use it anyway in case of interpolating front stub.
					if ( (*it)->interpolateRate() && Globals::GetAdjustDates() /*MCPL*/ )  
					{
						(*it)->setFloatingRate( p_ForecastCurve->getZero( (*it)->getAdjustedStart() , (*it)->getAdjustedEnd() , m_basis) );
					} 
					else 
					{
						// Correct floating rate
						if ( (*it)->getFloatingPeriodEnd() <= lastFCurveDate )
						{
							(*it)->setFloatingRate( p_ForecastCurve->getZero( (*it)->getAdjustedStart() , (*it)->getFloatingPeriodEnd(), m_basis ) );
						}
						else
						{
							(*it)->setFloatingRate( p_ForecastCurve->getZero( (*it)->getAdjustedStart() , (*it)->getAdjustedEnd() , m_basis) );
						}

						//Apollo Floating Rate
						//it->setFloatingRate( p_ForecastCurve->getZero( it->getAdjustedStart() , it->getAdjustedEnd() , m_basis) );
					}
					break;

				case MC_CMS:
					{
						//				date end = addBusinessMonths( it->getAdjustedStart() , m_CMStenor*12.0 , m_hols);
						date end = addMonths( (*it)->getAdjustedStart() , (long)(m_CMStenor*12.0) );
						Swap cms(PAY, m_CMStype, (*it)->getAdjustedStart(), end, 1, 0, 0, m_hols, m_currency);
						cms.setCurves( p_DiscountCurve , p_ForecastCurve );
						double rate = cms.Solve(0, solveFORCOUPON);

						if ( p_CMSvols ) 
						{
							// Calculate CMS adjustment if we are a CMS leg with a pointer to a vol grid
							date spot = firstDCurveDate;
							BlackVol vol = p_CMSvols->get( (*it)->getAdjustedStart() , (tenor) m_CMStenor );
							if (vol.rateShift != 0.0)
								mcpl_error("cms swaps not implemented with shifted vols yet");
							double unused_var=0;

							double cms_adjust = (*it)->getOptionModel() == BlackLogNormal ? 
								cms_swap_adj(unused_var, rate, vol.vol, dayCountFrac(act_365, spot,(*it)->getAdjustedStart()) ,
								(int)m_CMStenor, 12.0/m_paymentMonths ) :
							cms_swap_normal_adj(unused_var, rate, vol.vol, dayCountFrac(act_365, spot,(*it)->getAdjustedStart()) ,
								(int)m_CMStenor, 12.0/m_paymentMonths) ;

							(*it)->setCMSAdjustment(cms_adjust);
						} 
						else 
						{
							(*it)->setCMSAdjustment(0);
						}
						(*it)->setFloatingRate( cms.Solve(0, solveFORCOUPON) );
					}
					break;

				case MC_CAP:
				case MC_FLOOR:
				case MC_STRADDLE:
					//  Floating rate as defined by Apollo. This is WRONG!
					//			it->setFloatingRate( p_ForecastCurve->getZero( it->getAdjustedStart() , it->getAdjustedEnd() , m_basis) );

					// correct floating rate (unless FloatPeriodEnd goes past end of DC)
					if ( (*it)->getFloatingPeriodEnd() <= lastFCurveDate )
					{
						(*it)->setFloatingRate( p_ForecastCurve->getZero( (*it)->getAdjustedStart() , (*it)->getFloatingPeriodEnd(), getLiborBasis(m_currency)) );
					}
					else
					{
						(*it)->setFloatingRate( p_ForecastCurve->getZero( (*it)->getAdjustedStart() , (*it)->getAdjustedEnd() , m_basis) );
					}

					(*it)->setVolatilityGrid( m_pCapVols );
					switch( (*it)->getOptionModel() )
					{
					case BlackLogNormal:
					case BlackNormal:
					case BlackMixed:
					case QModel:
						(*it)->setVolatility( m_pCapVols->get( **it ) );
						//it->setMixing( m_pCapVols->get_mixing() );
						break;
					}
				}
			}
		}
	}


	//***********************************************************************************************************

	// Intelligent leg constructors.
	// For MC_FLOAT, place the spread in coupon.

	Leg::Leg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, const date & target,
		double notional, double coupon, long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, 
		ROLLTYPE rolltype, CURRENCY ccy, OptionModel model, mixing_model &mixing, date & today, bool IsFRA, int payDateOffsetDays_)
	{
		int m = 12 / pmtPerYear;
		m_IsFRA = IsFRA;
		GenerateLeg( dir , type , start , start , target , target , rolltype, false, notional, coupon, 0,
			pmtPerYear, m, basis, hol, model, mixing, ccy, today, payDateOffsetDays_);
	}

	// Leg constructor with roll day.
	Leg::Leg (DIRECTIONTYPE dir, PAYTYPE type, date & start, date & target, date & roll,
		double notional, double coupon, long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, CURRENCY ccy,
		OptionModel model, mixing_model &mixing, date & today, bool IsFRA, int payDateOffsetDays_, bool IsOIS )
	{
		int m = 12 / pmtPerYear;
		m_IsFRA = IsFRA;
		GenerateLeg( dir , type , start , start , target , roll , ROLL_BACKWARD, false, notional, coupon, 0,
			pmtPerYear, m, basis, hol, model, mixing, ccy, today, payDateOffsetDays_, IsOIS);
	}


	// For legs where 12 / pmt per year != float index tenor (i.e. CMS)
	Leg::Leg (DIRECTIONTYPE dir, PAYTYPE type, date & start, date & target,
		double notional, double coupon, long int pmtPerYear, long int floatMonths, SwapType CMStype, 
		DayBasis basis, HOLIDAYCAL hol, ROLLTYPE rolltype, CURRENCY ccy, OptionModel model, mixing_model &mixing, date & today, bool IsFRA, int payDateOffsetDays_)
	{
		m_IsFRA = IsFRA;
		GenerateLeg(dir, type, start, start, target, target, rolltype, false, notional, coupon, 0,
			pmtPerYear, floatMonths, basis, hol, model, mixing, ccy, today, payDateOffsetDays_);
		m_CMStype = CMStype;
	}

	Leg::Leg (DIRECTIONTYPE dir, PAYTYPE type, 
		const date & start, const date & first, const date & target, const date & roll, ROLLTYPE rolltype,
		bool longCoupon, double notional, double coupon, long int pmtPerYear, DayBasis basis,
		HOLIDAYCAL hol, CURRENCY ccy, OptionModel model, mixing_model &mixing, date & today, bool IsFRA, int payDateOffsetDays_)
	{
		int m = 12 / pmtPerYear;
		m_IsFRA = IsFRA;
		GenerateLeg( dir , type , start , first , target , roll , rolltype, longCoupon, 
			notional, coupon, 0, pmtPerYear, m, basis, hol, model, mixing, ccy, today, payDateOffsetDays_);
	}

	// as above, but also has a coupon (spread) step
	Leg::Leg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, const date & first, const date & target, const date & roll, 
		ROLLTYPE rolltype, bool longCoupon, double notional, double coupon, double couponStep, 
		long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, CURRENCY ccy, OptionModel model, mixing_model &mixing, date & today, bool IsFRA, int payDateOffsetDays_)
	{
		int m = 12 / pmtPerYear;
		m_IsFRA = IsFRA;
		GenerateLeg( dir , type , start , first , target , 
			roll , rolltype, longCoupon, notional, coupon, couponStep, pmtPerYear, m, basis, hol, model, mixing, ccy, today, payDateOffsetDays_);
	}

	// as above, but also has a coupon (spread) vector
	Leg::Leg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, const date & first, 
		const date & target, const date & roll, ROLLTYPE rolltype, bool longCoupon,
		const vector<double> & vNotional, const vector<double> & vcoupon, long int pmtPerYear, 
		DayBasis basis, HOLIDAYCAL hol, CURRENCY ccy, OptionModel model, 
		mixing_model &mixing, date & today, bool IsFRA, int payDateOffsetDays_)
	{
		int m = 12 / pmtPerYear;
		m_IsFRA = IsFRA;
		GenerateLeg( dir , type , start , first , target , 
			roll , rolltype, longCoupon, vNotional[0], vcoupon[0], 0, pmtPerYear, m, basis, 
			hol, model, mixing, ccy, today, payDateOffsetDays_);

		if ( vNotional.size() > 0 )
			setNotional(vNotional);

		if (type == MC_FIXED )
		{
			setCoupon( vcoupon );
		} 
		else 
		{
			setSpread( vcoupon );
		}
	}

	// for SPS
	Leg::Leg (DIRECTIONTYPE dir, PAYTYPE type, date & start, date & target,
		double notional, double coupon, DayBasis basis, long int floatMonths, HOLIDAYCAL hol, 
		CURRENCY ccy, OptionModel model, mixing_model &mixing, date & today, bool IsFRA, int payDateOffsetDays_)
	{
		m_IsFRA = IsFRA;
		m_paymentDirection = dir;
		m_currency = ccy;
		m_hols = hol;
		m_payType = type;
		p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		//	m_pCapVols = m_pCapNormalVols = NULL;
		m_pCapVols = shared_ptr<VolatilityGrid>(nullptr);
		p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);
		m_basis = basis;
		m_floatMonths = floatMonths;
		m_pmtsPerYear = 1;

		if ( type == MC_CMS )
			m_CMStenor = floatMonths/12.0;

		notional *= (dir == PAY) ? -1 : 1; // -ve notional for paying.

		double dcf , spread=0;
		date floatingPeriodEnd;
		date adjTarget = target;
		date adjStart = start;

		date workingDayLimitDate = addMonths(today, 3);



		adjTarget.rollFwd(hol, true);
		adjStart.rollFwd(hol, true);
		date pmtDate = adjTarget + payDateOffsetDays_;
		pmtDate.rollFwd(hol, false);
		date adjExercise = ( ccy != UNDEF ) ? fixing( adjStart , ccy) : addBusinessDays( adjStart , -2 , hol);
		date & exercise = adjExercise;
		date & reset = exercise;

		dcf = (type == MC_BOND) ? (1.0) : dayCountFrac(basis, adjStart, adjTarget);
		m_paymentMonths = (int) (dcf*12.0);

		double timeToExp;
		if (model == BlackLogNormal || adjExercise >= workingDayLimitDate)
		{
			timeToExp = dayCountFrac(act_365f , today , adjExercise );
		} 
		else
		{
			timeToExp = workingDayCountFrac(today, adjExercise, ccy, hol);
		}

		if (type == MC_FLOAT || type == MC_CMS)
		{
			spread = coupon;
			coupon = 0;
		}

		if ( type == MC_FLOAT || type == MC_CAP || type ==  MC_FLOOR || type == MC_STRADDLE ) 
			floatingPeriodEnd = addBusinessMonths(adjStart, m_floatMonths, m_hols, false);

		addPayment( Handle<PaymentPeriod>( new PaymentPeriod( type, notional , 0.0 , dcf, 0.0 , start, adjStart, target, adjTarget,
			reset, pmtDate, floatingPeriodEnd, exercise, adjExercise, coupon, spread, 0.0, (unsigned)0.0, model, timeToExp, mixing) ) );

		m_lastDate = adjTarget > floatingPeriodEnd ? adjTarget : floatingPeriodEnd;

	}



	/*
	*   Generates the cashflows.
	*  Set first=start for no long first coupon
	*/

	void Leg::GenerateLeg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, 
		const date & first, const date & target, const date & roll, ROLLTYPE rolltype, 
		bool longCoupon, double notional, double coupon, double couponStep, long int pmtPerYear,
		long int floatMonths, DayBasis basis, HOLIDAYCAL hol, OptionModel model, 
		mixing_model &mixing, CURRENCY ccy, date & today, int payDateOffsetDays_, bool IsOIS)
	{
		switch ( rolltype)
		{
		case ROLL_IMM1: case ROLL_IMM3:
			GenerateIMMLeg ( dir, type, start, first, target, longCoupon, rolltype, notional, 
				coupon, couponStep, pmtPerYear, floatMonths, basis, hol, model, mixing, ccy, today, payDateOffsetDays_, IsOIS);
			break;
		default:
			GenerateGeneralLeg( dir, type, start, first, target, roll, rolltype, longCoupon, 
				notional, coupon, couponStep, pmtPerYear, floatMonths, basis, hol, model, 
				mixing, ccy, today, payDateOffsetDays_, IsOIS);
		}
	}


	void Leg::GenerateIMMLeg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, 
		const date & first, const date & target,  bool longCoupon, ROLLTYPE rolltype, 
		double notional, double coupon, double couponStep, long int pmtPerYear, 
		long int floatMonths, DayBasis basis, HOLIDAYCAL hol, OptionModel model, 
		mixing_model &mixing, CURRENCY ccy, date & today, int payDateOffsetDays_, bool IsOIS)
	{
		m_paymentDirection = dir;
		m_currency = ccy;
		m_hols = hol;
		m_payType = type;
		p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		//	m_pCapVols = m_pCapNormalVols = NULL;
		m_pCapVols = shared_ptr<VolatilityGrid>(nullptr);
		p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);
		m_basis = basis;
		double timeToExp;
		m_pmtsPerYear = pmtPerYear;

		notional *= (dir == PAY) ? -1 : 1; // -ve notional for paying.

		double dcf , spread=0;
		date pStart, pAdjStart, pEnd, pAdjEnd, pmtDate, floatEnd, exercise, adjExercise;
		date adjTarget = target;
		date adjFirst = first;
		date adjStart = start;
		int IMMmonths = (rolltype == ROLL_IMM3) ? 3 : 1; // 3m or 1m IMMs

		date workingDayLimitDate = addMonths(today, 3);

		adjTarget.rollFwd(hol, true);
		adjFirst.rollFwd(hol, true);
		adjStart.rollFwd(hol, true);

		if ( adjStart >= adjTarget )
			mcpl_error("The adjusted start date muxt be earlier than the adjusted end date in Leg::GenerateIMMLeg");

		int m = 12 / pmtPerYear; // Number of months in payment period
		m_paymentMonths = m; 
		m_floatMonths = floatMonths; 

		if ( type == MC_CMS )
			m_CMStenor = floatMonths/12.0;

		if (type == MC_FLOAT || type == MC_CMS)
		{
			spread = coupon;
			coupon = 0;
		}

		//We roll backwards for IMM swaps.
		pStart = target;
		pAdjStart = adjTarget;

		do 
		{
			// beginning of pp = end of previous pp, but we're rolling backwards
			pEnd = pStart;
			pAdjEnd = pAdjStart;

			pAdjStart = pStart = nthIMMDate(pEnd, 1-m/IMMmonths, IMMmonths);
			pAdjStart.rollFwd(hol, true); // FRN = true for swaps - affects end of month rolls

			if ( type == MC_FLOAT || type == MC_CAP || type ==  MC_FLOOR || type == MC_STRADDLE ) 
		    	floatEnd = addBusinessMonths(pAdjStart, m_floatMonths, m_hols, false);
//                if (Globals::GetAdjustDates()) // MCPL
//                {
                    if (pAdjStart == pAdjStart.lastWDayInMonth(m_hols))
                        floatEnd = floatEnd.lastWDayInMonth(m_hols);
//                }
//                else // Apollo
//		    		;

			pmtDate = pAdjEnd + payDateOffsetDays_;
			pmtDate.rollFwd(hol, false);

			if ( pStart >= start ) 
			{
				date & reset = exercise = adjExercise = ( ccy != UNDEF ) ? fixing( pAdjStart , ccy) : addBusinessDays( pAdjStart , -2 , hol);
				dcf = (type == MC_BOND) ? (1.0/pmtPerYear) : dayCountFrac(basis, pAdjStart, pAdjEnd);

				if (model == BlackLogNormal || adjExercise >= workingDayLimitDate)
				{
					timeToExp = dayCountFrac(act_365f , today , adjExercise );
				} 
				else
				{
					timeToExp = workingDayCountFrac(today, adjExercise, ccy, hol);
				}
				addPayment(  Handle<PaymentPeriod>( new PaymentPeriod( type, notional , 0.0 , dcf, 0.0 , pStart, pAdjStart, pEnd, pAdjEnd,
					reset, pmtDate, floatEnd, exercise, adjExercise, coupon, spread, 0.0, m_paymentMonths, model, 
					timeToExp, mixing, BlackVol(0,0), m_IsFRA) ) );
			}
			else 
			{
				date & reset = exercise = adjExercise = ( ccy != UNDEF ) ? fixing( adjStart , ccy) : addBusinessDays( adjStart , -2 , hol);
				dcf = (type == MC_BOND) ? (1.0/pmtPerYear) : dayCountFrac(basis, start, pAdjEnd);

				if (model == BlackLogNormal || adjExercise >= workingDayLimitDate)
				{
					timeToExp = dayCountFrac(act_365f , today , adjExercise );
				} 
				else
				{
					timeToExp = workingDayCountFrac(today, adjExercise, ccy, hol);
				}
				addPayment(  Handle<PaymentPeriod>( new PaymentPeriod( type, notional , 0.0 , dcf, 0.0 , start, adjStart, pEnd, pAdjEnd,
					reset, pmtDate, floatEnd, exercise, adjExercise, coupon, spread, 0.0, m_paymentMonths, model,
					timeToExp, mixing, BlackVol(0, 0), m_IsFRA)));
			}

		} while (pStart > start);



		// Sort the paymen tperiods
		sortPayments();

		// Step up the coupon if needed.
		if ( couponStep != 0 ) 
		{
			int i=0;
			for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin(); it != v_paymentPeriod.end() ; ++i , ++it )
			{
				if ( type == MC_FIXED )
				{
					(*it)->setCoupon(coupon + int(i/pmtPerYear) * couponStep);
				}
				else
				{
					(*it)->setSpread(spread + int(i/pmtPerYear) * couponStep);
				}
			}
		}

		// set up last date
		Handle<PaymentPeriod> period_ref = v_paymentPeriod.back();
		m_lastDate = m_payType != MC_FIXED && period_ref->getFloatingPeriodEnd() > period_ref->getAdjustedEnd() ? 
			period_ref->getFloatingPeriodEnd() : period_ref->getAdjustedEnd();

		m_lastDate = m_lastDate < period_ref->getPaymentDate() ? period_ref->getPaymentDate() : m_lastDate;
		//	printDates();	

	}

	void Leg::GenerateGeneralLeg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, const date & first, 
		const date & target, const date & roll, ROLLTYPE rolltype, bool longCoupon, double notional, 
		double coupon, double couponStep, long int pmtPerYear, long int floatMonths, DayBasis basis, 
		HOLIDAYCAL hol, OptionModel model, mixing_model &mixing, CURRENCY ccy, date & today, int payDateOffsetDays_, bool IsOIS)
	{


		/*	cout << "Start  " << start << endl;
		cout << "First  " << first << endl;
		cout << "Target " << target << endl;
		cout << "Roll   " << roll << endl;
		*/

		m_paymentDirection = dir;
		m_currency = ccy;
		m_hols = hol;
		m_payType = type;
		p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		//	m_pCapVols = m_pCapNormalVols = NULL;
		m_pCapVols = shared_ptr<VolatilityGrid>(nullptr);
		p_CMSvols = shared_ptr<VolatilityGrid>(nullptr);
		m_basis = basis;
		m_pmtsPerYear = pmtPerYear;

		double timeToExp;

		notional *= (dir == PAY) ? -1 : 1; // -ve notional for paying.

		double dcf , spread=0;
		date pStart, pAdjStart, pEnd, pAdjEnd, pmtDate, floatEnd, exercise, adjExercise;
		date & reset = exercise;
		date adjTarget = target;
		date adjFirst = first;
		date adjStart = start;

		date workingDayLimitDate = addMonths(today, 3);

		adjTarget.rollFwd(hol, true);
        if (Globals::GetAdjustDates())
        {
		    adjFirst.rollFwd(hol, true);
		    adjStart.rollFwd(hol, true);
        }

		if ( adjStart >= adjTarget )
			mcpl_error("The adjusted start date muxt be earlier than the adjusted end date in Leg::GenerateGeneralLeg");

		int m = 12 / pmtPerYear;
		m_paymentMonths = m; 
		m_floatMonths = floatMonths; 

		if ( type == MC_CMS )
			m_CMStenor = floatMonths/12.0;

		if (type == MC_FLOAT || type == MC_CMS)
		{
			spread = coupon;
			coupon = 0;
		}


		int rollDay = rolltype == ROLL_MONTHEND ? 32 : roll.day();


		// Calculate first and last dates in the `core'
		//	double dtemp = dayCountFrac(_30_360, first, target) ;
		int nCorePeriods = (int)(	dayCountFrac(_30_360, first, target) * pmtPerYear ); // number of payments in core


		date coreStart , adjCoreStart;
		if ( rolltype == ROLL_BACKWARD || rolltype == ROLL_MONTHEND ) 
		{
			while ( addMonths( target , -(m * (nCorePeriods)) )  < first ) --nCorePeriods; 
			coreStart = addMonths( target , -(m * nCorePeriods) );
            if (nCorePeriods>0) // added by Alexey. fixes bug where for example 2W swap is transformed into 1M swap by this code.
			    coreStart.setDay( rollDay );
			if ( countWD(first, coreStart, hol) <= 2 )
				coreStart = first;
		} 
		else 
		{
			coreStart = first;
			while ( addMonths( coreStart , (m * nCorePeriods) )  > target ) --nCorePeriods;
		}

		pEnd = coreStart;
		pAdjEnd = coreStart;
        if (Globals::GetAdjustDates() || (nCorePeriods>0 && pAdjEnd!=start) || coreStart==target)
        {
       		adjCoreStart = pAdjEnd.rollFwd(hol, true);
        }
        else
        {
       		adjCoreStart = pAdjEnd;
        }

		date temp =  addMonths(first , m * nCorePeriods);
		if ( longCoupon && ( target >  addMonths(first , pmtPerYear * nCorePeriods) ) ) --nCorePeriods; // Decrease the number of periods by one if there is a short period.

		// calc the core periods

		for ( int i=0 ; i < nCorePeriods ; ++i ) 
		{		
			pStart = pEnd; // End of previous PP = start of next PP
			pAdjStart = pAdjEnd;

			if ( longCoupon && (i == nCorePeriods) ) pEnd = target;
			else
			{
				pEnd = addMonths(coreStart, m*(i + 1));
				if ((i == nCorePeriods-1) && countWD(pEnd, target, hol) <= 2) // Fix for a problem where target is in different month from pEnd (i.e. target is 1st Dec, pEnd is 31st Nov, roll day is 1st...)
					pEnd = target;
				else
					pEnd.setDay(rollDay);
			}
			//else pEnd = addMonths(coreStart , m*(i+1) ).setDay( rollDay );
			if ( pEnd > target ) pEnd = target;

			pAdjEnd = pEnd;
			pAdjEnd.rollFwd(hol, true); // FRN = true for swaps - affects end of month rolls

			// A bit of a cludge to get rid of situation with month end rolls from feb leaving an end stub af a couple of days
			if ( (adjTarget - pAdjEnd) <= 2 && Globals::GetAdjustDates() ) 
			{
				pAdjEnd = adjTarget;
			}

			pmtDate = pAdjEnd + payDateOffsetDays_;
			pmtDate.rollFwd(hol, false);
			exercise = adjExercise = ( ccy != UNDEF ) ? fixing( pAdjStart , ccy) : addBusinessDays( pAdjStart , -2 , hol);


			//		exercise = adjExercise = addBusinessDays( pAdjStart , -2 , hol);
			if (model == BlackLogNormal || adjExercise >= workingDayLimitDate)
			{
				timeToExp = dayCountFrac(act_365f , today , adjExercise );
			} 
			else
			{
				timeToExp = workingDayCountFrac(today, adjExercise, ccy, hol);
			}

			dcf = (type == MC_BOND) ? (1.0/pmtPerYear) : dayCountFrac(basis, pAdjStart, pAdjEnd);



			if ( type == MC_FLOAT || type == MC_CAP || type ==  MC_FLOOR || type == MC_STRADDLE || type == MC_FIXED) 
	    		floatEnd = addBusinessMonths(pAdjStart, m_floatMonths, m_hols, false);
                if (!IsOIS)
                {
                    if (pAdjStart == pAdjStart.lastWDayInMonth(m_hols))
                        floatEnd = floatEnd.lastWDayInMonth(m_hols);
                }
                else
	    			floatEnd = pAdjEnd;

			addPayment( Handle<PaymentPeriod>(new  PaymentPeriod( type, notional , 0.0 , dcf, 0.0 , pStart, pAdjStart, pEnd, pAdjEnd,
				reset, pmtDate, floatEnd, exercise, adjExercise, coupon, spread, 0.0, m_paymentMonths,
				model, timeToExp, mixing, BlackVol(0, 0), m_IsFRA)));
		}


		// Add the end stub if needed
		if ( pAdjEnd < adjTarget && !(rolltype == ROLL_BACKWARD || rolltype == ROLL_MONTHEND) )
		{
			pStart = pEnd; // End of previous PP = start of next PP
			pAdjStart = pAdjEnd;

			pEnd = target;
			pAdjEnd = pEnd;
			pAdjEnd.rollFwd(hol, true); // FRN = true for swaps - affects end of month rolls

			pmtDate = pAdjEnd + payDateOffsetDays_;
			pmtDate.rollFwd(hol, false);

			exercise = adjExercise = ( ccy != UNDEF ) ? fixing( pAdjStart , ccy) : addBusinessDays( pAdjStart , -2 , hol);
			//		exercise = adjExercise = addBusinessDays( pAdjStart , -2 , hol);
			if (model == BlackLogNormal || adjExercise >= workingDayLimitDate)
			{
				timeToExp = dayCountFrac(act_365f , today , adjExercise );
			} 
			else
			{
				timeToExp = workingDayCountFrac(today, adjExercise, ccy, hol);
			}

			dcf = (type == MC_BOND) ? (1.0/pmtPerYear) : dayCountFrac(basis, pAdjStart, pAdjEnd);


			if ( type == MC_FLOAT || type == MC_CAP || type ==  MC_FLOOR || type == MC_STRADDLE || type == MC_FIXED) 
            {
				floatEnd = addBusinessMonths(pAdjStart, m_floatMonths, m_hols, false);
                if (!IsOIS ) 
                {
                    if (pAdjStart == pAdjStart.lastWDayInMonth(m_hols))
                        floatEnd = floatEnd.lastWDayInMonth(m_hols);
                }
                else 
	    			floatEnd = pAdjEnd;
            }

			addPayment( Handle<PaymentPeriod>(new PaymentPeriod( type, notional , 0.0 , dcf, 0.0 , pStart, pAdjStart, pEnd, pAdjEnd,
				reset, pmtDate, floatEnd, exercise, adjExercise, coupon, spread, 0.0, m_paymentMonths,
				model, timeToExp, mixing, BlackVol(0, 0), m_IsFRA)));
		}

		// and the front core stub if needed
		if ( adjCoreStart > adjFirst )
		{
			pStart = first; // End of previous PP = start of next PP
			pAdjStart = pStart;
            if (Globals::GetAdjustDates())
	    		pAdjStart.rollFwd(hol, true);

			pEnd = coreStart;
			pAdjEnd = pEnd;
      		pAdjEnd.rollFwd(hol, true); // FRN = true for swaps - affects end of month rolls

			floatEnd = pAdjEnd;

			pmtDate = pAdjEnd + payDateOffsetDays_;
    		pmtDate.rollFwd(hol, false);

			exercise = adjExercise = ( ccy != UNDEF ) ? fixing( pAdjStart , ccy) : addBusinessDays( pAdjStart , -2 , hol);
			//		exercise = adjExercise = addBusinessDays( pAdjStart , -2 , hol);
			if (model == BlackLogNormal || adjExercise >= workingDayLimitDate)
			{
				timeToExp = dayCountFrac(act_365f , today , adjExercise );
			} 
			else
			{
				timeToExp = workingDayCountFrac(today, adjExercise, ccy, hol);
			}

			dcf = (type == MC_BOND) ? (1.0/pmtPerYear) : dayCountFrac(basis, pAdjStart, pAdjEnd);


			if ( type == MC_FLOAT || type == MC_CAP || type ==  MC_FLOOR || type == MC_STRADDLE  || type == MC_FIXED ) 
				floatEnd = addBusinessMonths(pAdjStart, m_floatMonths, m_hols, false);
                if ( !IsOIS )
                {
                    if (pAdjStart == pAdjStart.lastWDayInMonth(m_hols))
                        floatEnd = floatEnd.lastWDayInMonth(m_hols);
                }
                else 
	    			floatEnd = pAdjEnd;

			addPayment( Handle<PaymentPeriod>(new PaymentPeriod( type, notional , 0.0 , dcf, 0.0 , pStart, pAdjStart, pEnd, pAdjEnd,
				reset, pmtDate, floatEnd, exercise, adjExercise, coupon, spread, 0.0, m_paymentMonths,
				model, timeToExp, mixing, BlackVol(0, 0), m_IsFRA)));


		}


		// and the first period if needed.
		if ( adjFirst > adjStart ) 
		{
			pStart = start; // End of previous PP = start of next PP
			pAdjStart = pStart;
            if (Globals::GetAdjustDates())
	    		pAdjStart.rollFwd(hol, true);

			pEnd = first;
			pAdjEnd = pEnd;
    		pAdjEnd.rollFwd(hol, true); // FRN = true for swaps - affects end of month rolls

			pmtDate = pAdjEnd + payDateOffsetDays_;
    		pmtDate.rollFwd(hol, false);
			exercise = adjExercise = ( ccy != UNDEF ) ? fixing( pAdjStart , ccy) : addBusinessDays( pAdjStart , -2 , hol);
			//		exercise = adjExercise = addBusinessDays( pAdjStart , -2 , hol);
			if (model == BlackLogNormal || adjExercise >= workingDayLimitDate)
			{
				timeToExp = dayCountFrac(act_365f , today , adjExercise );
			} 
			else
			{
				timeToExp = workingDayCountFrac(today, adjExercise, ccy, hol);
			}

			dcf = (type == MC_BOND) ? (1.0/pmtPerYear) : dayCountFrac(basis, pAdjStart, pAdjEnd);


			if ( type == MC_FLOAT || type == MC_CAP || type ==  MC_FLOOR || type == MC_STRADDLE  || type == MC_FIXED) 
				floatEnd = addBusinessMonths(pAdjStart, m_floatMonths, m_hols, false);
                if ( !IsOIS )
                {
                    if (pAdjStart == pAdjStart.lastWDayInMonth(m_hols))
                        floatEnd = floatEnd.lastWDayInMonth(m_hols);
                }
                else
	    			floatEnd = pAdjEnd;

			addPayment( Handle<PaymentPeriod>(new PaymentPeriod( type, notional , 0.0 , dcf, 0.0 , pStart, pAdjStart, pEnd, pAdjEnd,
				reset, pmtDate, floatEnd, exercise, adjExercise, coupon, spread, 0.0, m_paymentMonths,
				model, timeToExp, mixing, BlackVol(0, 0), m_IsFRA)));

		}

		// Sort the paymen tperiods
		sortPayments();
		if ( couponStep != 0 ) 
		{
			int i=0;
			for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin(); it != v_paymentPeriod.end() ; ++i , ++it )
				if ( type == MC_FIXED )
				{
					(*it)->setCoupon(coupon + int(i/pmtPerYear) * couponStep);
				}
				else
				{
					(*it)->setSpread(spread + int(i/pmtPerYear) * couponStep);
				}
		}

        if (!v_paymentPeriod.size())
		{
			ostringstream errStr;
			errStr << "No payment periods in leg";
			mcpl_error( errStr.str() );
		}
            
		Handle<PaymentPeriod> period_ref = v_paymentPeriod.back();
		m_lastDate = m_payType != MC_FIXED && period_ref->getFloatingPeriodEnd() > period_ref->getAdjustedEnd() ? 
			period_ref->getFloatingPeriodEnd() : period_ref->getAdjustedEnd();

		m_lastDate = m_lastDate < period_ref->getPaymentDate() ? period_ref->getPaymentDate() : m_lastDate;


		if ( type == MC_FLOAT ) v_paymentPeriod[0]->setInterpolateRate( true );

		//	printDates();	
	}

	// Clone function which creates a deep clone of cashflows
	shared_ptr<Leg> Leg::CloneCashflows()
	{
		//First make a shallow copy.
		shared_ptr<Leg> copy = shared_ptr<Leg>(new Leg(*this));

		//Now deep clone the cashflows.
		copy->v_paymentPeriod.clear();
		for (auto pp : v_paymentPeriod)
		{
			copy->v_paymentPeriod.push_back(shared_ptr<PaymentPeriod>(new PaymentPeriod(*pp)));
		}

		return copy;
	}
} //namespace MCPL
