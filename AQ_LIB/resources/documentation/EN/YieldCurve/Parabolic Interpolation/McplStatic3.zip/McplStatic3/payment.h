#pragma once
#ifndef MCPLPAYMENT_H
#define MCPLPAYMENT_H
#include "MCPL.h"

#include<string>
#include<vector>

#include "mcpldefs.h"
#include "option.h"
#include "blackmodel.h"
#include "VolatilityGrid.h"

using namespace std;

namespace MCPL
{

class PaymentPeriod  : public VolatilityDeal
{
private:
// Compulsory fields 	
	PAYTYPE m_ePaymentType; 
	bool		m_isAccrualPeriod;  // Is this a compounding period. If it is, it's FV includes the previous period's FV.

	double m_dNotional;		// the notional of the period, the sign determines whether we are long or short.
	double m_dDiscountFactor;	// the discount factor from the valuation date to the payment day of the period
	double m_dDayCountFraction; // the tenor of the period, weighted by Day Basis.
	double m_dForecastRate;	// the forecast rate for the period, on a money basis (ACT/360 except GBP, AUD, HKD)
	double m_dCMSAdjustment;	// the CMS convexity adjustment.

// date info

	date m_dtTargetStart;     // always set
	date m_dtAdjustedStart;   // always set
	date m_dtTargetEnd;	   // always set
	date m_dtAdjustedEnd;		// always set
	date m_dtReset;			// the reset date for the period, used when the payment type is "FLOAT" or "CMS"
	date m_dtPaymentDate;      // always set
	date m_dtFloatingPeriodEnd; // set when the payment type is "FLOAT".
	date m_dtTargetExercise;	// the exercise date for the period (if we have a BERMUDAN)
	date m_dtAdjustedExercise; 

// optional fields, only defined where required. e.g, if sPaymentType is "FLOAT"
// then dCoupon is irrelevant
	double m_dFee;		// used when the payment is a PAYMENT.
//	double m_dStrike;   // the strike when the payment is a CAP or FLOOR
	double m_dCoupon;	  // the coupon when the payment is a FIXED.
	double m_dSpread;   // the spread when the payment is a FLOAT
	BlackVol m_dVolatility; // the forward vol when the payment is a CAP, FLOOR or CMS
//	double m_NormalVolatility; // the forward vol when the payment is a CAP, FLOOR or CMS in bp per year.
	double m_timeToExpiry;  // time to expiry of CAP or FLOOR in years, ( money basis - ACT/360 )
	OptionModel m_optionModel; // what sort of model are we using to price CAPs and FLOORs
	mixing_model m_mixing;		// Mixing parameter for mixed option model.
	shared_ptr<VolatilityGrid> m_pVolGrid; // Pointer to volatility grid, from which we can get vols and option params.
	double m_dFloatingRate; // the floating rate when the payment is a FLOAT or CMS, this is on the period Day Basis (not necessarily money)
	unsigned long int m_iTenor; // the tenor of the underlying payment in months

	bool m_hasFixed; // if a PP has fixed, don't allow changes to the forecast rate
	bool m_interpolateRate; // Do we interpolate the floating rate? Needed if we are a front or back stub.

	int m_sequenceNumber; // Sequence number in leg. Used for accrual.
	ACCRUAL_TYPE m_accrualType; // accrual type for an accrual period. i.e. flat compounding, averaging etc...
	std::tr1::weak_ptr<PaymentPeriod> m_prevPayment; // weak ptr to previous payment in sequence.

    bool m_IsFRA;
public:
	//Constructors
	PaymentPeriod(PAYTYPE pType = MC_FIXED, 
			      double notional=1, 
				  double discountFactor = 1, 
				  double DCF = 1,
				  double coupon=0, 
				  double spread=0, 
				  double floatRate = 1,
                  bool IsFRA = false) :
		m_ePaymentType(pType),
		m_isAccrualPeriod(false),
		m_accrualType(ACCRUAL_FLAT_COMPOUNDING),
		m_sequenceNumber(0),
		m_dNotional(notional),
		m_dDiscountFactor(discountFactor),
		m_dDayCountFraction (DCF),
		m_dCoupon (coupon),
		m_dSpread (spread),
		m_dFloatingRate (floatRate),
		//m_pVolGrid(NULL),
		m_hasFixed (false),
		m_interpolateRate(false),
        m_IsFRA(IsFRA)
		{}
	
	//simple constructor for the case when we have a cash payment	
	PaymentPeriod(double Fee,
				  date   PaymentDate):
		m_ePaymentType(MC_PAYMENT),
		m_isAccrualPeriod(false),
		m_accrualType(ACCRUAL_FLAT_COMPOUNDING),
		m_sequenceNumber(0),
		m_dFee(Fee),
		m_dtPaymentDate(PaymentDate),
		//m_pVolGrid(NULL),
		m_hasFixed (false),
		m_interpolateRate(false),
        m_IsFRA(false)
		{}

/*	PaymentPeriod(PAYTYPE pType, 
			      double notional, 
				  double DiscountFactor, 
				  double DCF,
				  double forecastRate,
				  date TargetStart,
				  date AdjustedStart,   // always set
				  date TargetEnd,	   // always set
				  date AdjustedEnd,		// always set
				  date Reset,			// the reset date for the period, used when the payment type is "FLOAT" or "CMS"
				  date PaymentDate,      // always set
				  date FloatingPeriodEnd, // set when the payment type is "FLOAT".
				  date TargetExercise,	// the exercise date for the period (if we have a BERMUDAN)
				  date AdjustedExercise, 
				  double Strike,
				  double Coupon, 
				  double Spread, 
				  double Volatility,
				  double FloatingRate,
				  int CMSTenor ) :
		m_ePaymentType(pType),
		m_dNotional(notional),
		m_dDiscountFactor(DiscountFactor),
		m_dDayCountFraction (DCF),
		m_dForecastRate (forecastRate),
		m_dtTargetStart (TargetStart),
		m_dtAdjustedStart (AdjustedStart),
		m_dtTargetEnd (TargetEnd),
		m_dtAdjustedEnd (AdjustedEnd),		
		m_dtReset (Reset),
		m_dtPaymentDate (PaymentDate),
		m_dtFloatingPeriodEnd (FloatingPeriodEnd),
		m_dtTargetExercise (TargetExercise),
		m_dtAdjustedExercise (AdjustedExercise), 
		m_dCoupon (Coupon),
		m_dSpread (Spread),
		m_dStrike (Strike),
		m_dVolatility (Volatility),
		m_dFloatingRate (FloatingRate),
		m_iCMSTenor (CMSTenor),
		m_optionModel(ModelNone),
		m_hasFixed(false)
		{}
*/
		// used for Caps & Floors
		PaymentPeriod(PAYTYPE pType, 
			      double notional, 
				  double DiscountFactor, 
				  double DCF,
				  double forecastRate,
				  date TargetStart,
				  date AdjustedStart,   // always set
				  date TargetEnd,	   // always set
				  date AdjustedEnd,		// always set
				  date Reset,			// the reset date for the period, used when the payment type is "FLOAT" or "CMS"
				  date PaymentDate,      // always set
				  date FloatingPeriodEnd, // set when the payment type is "FLOAT".
				  date TargetExercise,	// the exercise date for the period (if we have a BERMUDAN)
				  date AdjustedExercise, 
				  double Coupon, 
				  double Spread, 
				  double FloatingRate,
				  unsigned int Tenor,
				  OptionModel otype = ModelNone,
				  double timeToExpiry = 0,
				  mixing_model mixing = mixing_model(),
//  				  double NormalVolatility = 0,
				  BlackVol Volatility = BlackVol(0,0),
                  bool IsFRA = false) :
		m_ePaymentType(pType),
		m_isAccrualPeriod(false),
		m_accrualType(ACCRUAL_FLAT_COMPOUNDING),
		m_sequenceNumber(0),
		m_dNotional(notional),
		m_dDiscountFactor(DiscountFactor),
		m_dDayCountFraction (DCF),
		m_dForecastRate (forecastRate),
		m_dtTargetStart (TargetStart),
		m_dtAdjustedStart (AdjustedStart),
		m_dtTargetEnd (TargetEnd),
		m_dtAdjustedEnd (AdjustedEnd),		
		m_dtReset (Reset),
		m_dtPaymentDate (PaymentDate),
		m_dtFloatingPeriodEnd (FloatingPeriodEnd),
		m_dtTargetExercise (TargetExercise),
		m_dtAdjustedExercise (AdjustedExercise), 
		m_dCoupon (Coupon),
		m_dSpread (Spread),
		m_dVolatility (Volatility),
//		m_NormalVolatility (NormalVolatility),
		m_timeToExpiry (timeToExpiry),
		m_mixing (mixing),
		m_dFloatingRate (FloatingRate),
		m_iTenor (Tenor),
		m_optionModel(otype),
		m_hasFixed(false),
		//m_pVolGrid(NULL),
		m_interpolateRate(false),
        m_IsFRA(IsFRA)
		{}
	//members
	double Price();
	double Price( double coupon );
	double getPaymentAmount(); // Undiscounted price().
	double getAccruedAmount(); // Value to be added by this period. If this is not an accruall period, this is same as PaymentAmount
	double getPaymentAmount( double coupon ); // Undiscounted price().
	double getAccruedAmount( double coupon ); // Value to be added by this period. If this is not an accruall period, this is same as PaymentAmount
	double getVega();
	double sumOfDCFInSequence(); // Gets the sum of DCFs of payments in the current accrual sequence. Needed for average accrual. 

	// comparison operator, so that we can sort PaymentPeriods
	bool operator< (const PaymentPeriod &pp) const { return m_dtAdjustedStart < pp.m_dtAdjustedStart; }

	// Gets
	PAYTYPE getType() { return m_ePaymentType; }
	double getNotional() { return m_dNotional; }
	double getDiscountFactor() { return m_dDiscountFactor; }
	double getDayCountFraction() { return m_dDayCountFraction; }

	date getTargetStart() { return m_dtTargetStart; }
	date getAdjustedStart() { return  m_dtAdjustedStart; }
	date getTargetEnd() { return m_dtTargetEnd;}
	date getAdjustedEnd() { return m_dtAdjustedEnd; }
	date getReset() { return m_dtReset; }
	date getPaymentDate() { return m_dtPaymentDate; }
	date getFloatingPeriodEnd() { return m_dtFloatingPeriodEnd; }
	date getTargetExercise() { return m_dtTargetExercise; }
	date getAdjustedExercise() { return m_dtAdjustedExercise; } 

	double getFee()	   { return m_dFee;	   } const
//	double getStrike() { return m_dCoupon; } const
	double getCoupon() { return m_dCoupon; } const
	double getSpread() { return m_dSpread; } const
	BlackVol getVolatility() { if (!m_pVolGrid) return BlackVol(0,0); else return m_pVolGrid->get(*this); } const
//	double getNormalVolatility() { return m_NormalVolatility; } const
	double getFloatingRate()  { return m_dFloatingRate; } const 
	double getCMSAdjustment() { return m_dCMSAdjustment;} const
	unsigned long getTenor()  { return m_iTenor; } const
	double getTimeToExpiry() { return m_timeToExpiry; } const
	PAYTYPE getPaymentType()  { return m_ePaymentType; } const
	OptionModel getOptionModel() { return m_optionModel; } const
	mixing_model getMixing() { return m_mixing; }
	bool hasFixed() { return m_hasFixed; } const
	bool interpolateRate() { return m_interpolateRate; } const
	bool getIsAccrualPeriod() { return m_isAccrualPeriod; } const
	int getSequenceNumber() { m_sequenceNumber; }
	ACCRUAL_TYPE	getAccrualType() { return m_accrualType; }

	// Sets
	void setNotional( double notional) { m_dNotional = notional; }
	void setPaymentType(  PAYTYPE PaymentType) { m_ePaymentType = PaymentType; }
	void setDiscountFactor( double DiscountFactor) { m_dDiscountFactor = DiscountFactor; }
	void setDayCountFraction( double DayCountFraction) { m_dDayCountFraction = DayCountFraction; } 
	void setForecastRate( double ForecastRate) { m_dForecastRate = ForecastRate;}
	void setCMSAdjustment( double CMSAdjustment) { m_dCMSAdjustment = CMSAdjustment;}

	void setTargetStart( date TargetStart) { m_dtTargetStart = TargetStart; }
	void setAdjustedStart( date AdjustedStart) { m_dtAdjustedStart = AdjustedStart; } 
	void setTargetEnd(  date TargetEnd) { m_dtTargetEnd = TargetEnd; }	
	void setAdjustedEnd(  date AdjustedEnd ) { m_dtAdjustedEnd = AdjustedEnd; }
	void setReset(  date Reset ) { m_dtReset = Reset; }	
	void setPaymentDate(  date PaymentDate ) { m_dtPaymentDate = PaymentDate; } 
	void setFloatingPeriodEnd(  date FloatingPeriodEnd ) { m_dtFloatingPeriodEnd = FloatingPeriodEnd; }
	void setTargetExercise( date TargetExercise) { m_dtTargetExercise = TargetExercise; }
	void setAdjustedExercise( date AdjustedExercise) { m_dtAdjustedExercise = AdjustedExercise; } 

	void setFee   ( double Fee)    { m_dFee	   = Fee;}
//	void setStrike( double Strike) { m_dStrike = Strike; }
	void setCoupon( double coupon) { m_dCoupon = coupon; }
	void setSpread( double spread) { m_dSpread = spread; }
	void setVolatility(BlackVol Volatility) { m_dVolatility = Volatility; }
	void setVolatilityGrid(shared_ptr<VolatilityGrid> vol) { m_pVolGrid = vol; };
//	void setNormalVolatility( double Volatility) { m_NormalVolatility = Volatility; }
	void setFloatingRate( double FloatingRate) 
	{ 
		if ( ! m_hasFixed ) 
			m_dFloatingRate = FloatingRate; 
	}
	void setOptionModel( OptionModel model) { m_optionModel = model; }
	void setMixing(mixing_model & mixing) { m_mixing = mixing; }
	void setCMSTenor( int Tenor) { m_iTenor = Tenor; }
	void fixFloatingRate( double rate) { m_dFloatingRate = rate; m_hasFixed = true; }
	void unfixFloatingRate() { m_hasFixed = false; }
	void setInterpolateRate(bool doInter) { m_interpolateRate = doInter; }
	void setIsAccrualPeriod(bool isAccrual) { m_isAccrualPeriod = isAccrual; } 
	void setSequenceNumber(int i) { m_sequenceNumber = i; }
	void setAccrualType(ACCRUAL_TYPE	type) { m_accrualType = type; }
	void setPreviousPaymentInSequence(Handle<PaymentPeriod> pp) { m_prevPayment = pp; }
	std::tr1::weak_ptr<PaymentPeriod> getPreviousPaymentInSequence() { return m_prevPayment; }

	// define virtual volatilityDeal members

	tenor get_tenor()  {return tenor(getTenor()/12.0); } 
	date get_expiry() { return getAdjustedExercise(); }
	strike get_strike() { return getCoupon(); }
	double get_forward() { return getFloatingRate(); }
	BlackVol get_vol() { return getVolatility(); }

};


} // Namespace MCPL

#endif
