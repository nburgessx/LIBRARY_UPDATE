#pragma once

#ifndef GENERICBERMUDAN_H
#define GENERICBERMUDAN_H

#pragma warning ( disable : 4251 4786 ) 
#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "swap.h"
#include "option.h"
#include "onefactor.h"
#include "onefactornormal.h"
#include "onefactormixed.h"
#include "OneFactorGeneric.h"
#include "oneFactorGenericNormal.h"
#include "oneFactorGenericBlack.h"

#include<vector>


using namespace std;

namespace MCPL
{

	class GenericBermudan : public Swap
	{
	public:
		GenericBermudan() {}


		GenericBermudan(const date & priceto, const shared_ptr<Swap>&  underlyer,
			const vector<double> & vStrikes, long int noticeDays, const vector<bool>& toExercise,
			double stepsize, long int nsteps, long int trunc, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve,
			shared_ptr<VolatilityGrid> volGrid, bool includeSwapPV, bool useAmortisingVolCorrection, OptionModel optModel, double Beta = 0.0, bool useLinear=true);


		shared_ptr<dateVec> getExerciseDates() { return m_exerciseDates; }
		shared_ptr<dateVec> getStartDates() { return m_ULstartDates; }
		shared_ptr<vector<bool>> getExercise() { return m_exercise; }

		shared_ptr<vector<double>>  getNumeraires() const { return m_numeraires; }
		shared_ptr<vector<double>>  getStrikes() const { return m_strikes; }
		shared_ptr<vector<double>>  getForwards() const { return m_forwards; }
		shared_ptr<vector<double>>  getAdjStrikes() const { return m_adjustedstrikes; }
		shared_ptr<vector<double>>  getVolStrikes() const { return m_volStrikes; }
		shared_ptr<vector<double>>  getAdjForwards() const { return m_zeroOffsetForwards; }
		shared_ptr<vector<double>>  getVariances() const { return m_forwardVols; }
		shared_ptr<vector<double>>  getVols() const { return m_vols; }
		shared_ptr<vector<double>>  getAmmrtVols() const { return m_ammrtVols; }
		shared_ptr<vector<double>>  getNotionals() { return getLeg(MCPL::MC_FIXED)->getNotionals(); }

		double getUnderlyerPV() const { return m_ULPV; }


		void updatePaymentsFromCurves(Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr));
		double Price();

		shared_ptr<oneFactorGeneric> getGenericLattice() { return m_Glattice; }
		shared_ptr<oneFactorNormal> getNormalLattice() { return m_normalLattice; }


	private:

		bool _useGenericLattice;
		bool _useLinear;

		void   setupCurves();
		void   setupAmmortisingCurves();

		shared_ptr<oneFactorGeneric> m_Glattice;
		oneFactor	m_lattice;
		shared_ptr<oneFactorNormal> m_normalLattice;

		shared_ptr<vector<double>> m_numeraires;
		shared_ptr<vector<double>> m_forwards;
		shared_ptr<vector<double>> m_zeroOffsetForwards;
		shared_ptr<vector<double>> m_strikes;
		shared_ptr<vector<double>> m_volStrikes;
		shared_ptr<vector<double>> m_adjustedstrikes;
		shared_ptr<vector<double>> m_inputEffectiveStrikes;
		shared_ptr<vector<double>> m_forwardVols;
		shared_ptr<vector<double>> m_vols;
		shared_ptr<vector<double>> m_ammrtVols;

		shared_ptr<dateVec> m_exerciseDates, m_startDates, m_ULstartDates;
		shared_ptr<vector<bool>> m_exercise;
		shared_ptr<vector<bool>> m_inputExercises;

		bool _buy = true;

		date m_priceto;
		vector<double> m_inputStrikes;
		unsigned int m_noticeDays, m_lockout, m_calls;
		unsigned int m_nsteps, m_trunc;
		double m_stepsize;
		double m_beta;
		double m_ULPV;
		bool m_includeSwapPV;
		OptionModel m_optModel;

	};


} // Namespace MCPL

#endif // GENERICBERMUDAN_H