#include"oneFactor.h"
#include "mathmisc.h"
#include<math.h>

#include <fstream>

//#define DEBUG

namespace MCPL
{



	// Constructor which can set up its own cashflows and work out forward rates etc...
	// Needs to be given the structure's dates etc.., a discount curve, a forecast curve 
	// and a swaption vol grid. 
	//    This differs from the previous version in that it takes vectors of strikes and
	// spreads.


	oneFactor::oneFactor( DIRECTIONTYPE dir, date & priceto, date & start, 
		date & first, date & mature, date & roll, bool longCoupon, const vector<double> & vNotionals, 
		vector<double> &vSpreads, long int fixedPmtsPerYear, long int fltPmtsPerYear, 
		vector<double> &vStrikes, long int noticeDays, long int lockout,	
		long int calls, DayBasis fixedBasis, DayBasis floatBasis, double stepsize, 
		long int nsteps, long int trunc, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, 
		VolatilityGrid & volGrid, HOLIDAYCAL hol)
	{

		int nDates;

		// Set up the cashflows.
		Swap ULswap( dir, start, first, mature, roll, ROLL_FORWARD, longCoupon, vNotionals, 
			vStrikes, vSpreads, fixedPmtsPerYear, fltPmtsPerYear, 
			fixedBasis, floatBasis, discountCurve, forecastCurve, hol);

		m_ULPV = ULswap.Price();
		//	m_ULPV = ULswap.Solve(0,solveFORCOUPON);

		//	Leg underlyer(dir, MC_FIXED , start , first, mature, roll, false, longCoupon, notional, 0, 
		//				fixedPmtsPerYear, fixedBasis, hol);

		Handle<Leg> underlyer = ULswap.getLeg(MC_FIXED);

		// Extract the underlying swap's start dates
		//dateVec exerciseDates ,startDates , ULstartDates;

		underlyer->getStartDates( ULstartDates );
		int nStartDates = ULstartDates.size();

		for ( int i = 0 ; i < nStartDates ; ++i)  exercise.push_back(false);

		for ( i = lockout ; i < lockout+calls ; ++i ) 
		{

			if ( i >= nStartDates ) mcpl_error("oneFactorNormal: too many calls or lockouts");

			exercise[i] = true;
			exerciseDates.push_back( addBusinessDays( ULstartDates[i] ,  -noticeDays , hol) );
			startDates.push_back( ULstartDates[i].rollFwd(hol,true) );
		}


		// set up the arrays to construct the lattice.

		nDates = exerciseDates.size();
		vector<double> pForwards(nDates);
		vector<double> pStrikes(nDates);
		vector<double> pForwardVols(nDates);
		vector<double> pNumeraires(nDates);

		vector<double> adjStrikes, adjFwds;

		for ( i=0 ; i < nDates ; ++i ) 
		{
			double vol1, vol2;
			unsigned j = (unsigned)((i+lockout) * (double(fltPmtsPerYear)/double(fixedPmtsPerYear)));
			pStrikes[i] = vStrikes[i+lockout];

			vector<double> tmpStrikes, tmpSpreads, tmpzeroSpreads, tmpNotionals;

			for ( unsigned k=i+lockout ; k <= vStrikes.size() ; ++k ) tmpStrikes.push_back(vStrikes[k]);
			for ( unsigned k=j ; k <= vSpreads.size() ; ++k ) tmpSpreads.push_back(vSpreads[k]);
			for ( unsigned int k=j ; k < vSpreads.size() ; ++k ) tmpzeroSpreads.push_back(0);
			for ( unsigned k=j ; k <= vNotionals.size() ; ++k ) tmpNotionals.push_back(vNotionals[k]);

			// Set up a temp swap to calc forward rates
			//		Swap tempSwap(dir, startDates[i], mature, notional, 0, spreads[i], fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis,
			//					discountCurve, forecastCurve, hol);

			Swap tempSwap( dir, startDates[i], startDates[i], mature, roll, ROLL_FORWARD, longCoupon, tmpNotionals, 
				tmpStrikes, tmpSpreads, fixedPmtsPerYear, fltPmtsPerYear, 
				fixedBasis, floatBasis, discountCurve, forecastCurve, hol);

			Swap tempSwapNoSpread( dir, startDates[i], startDates[i], mature, roll, ROLL_FORWARD, longCoupon, tmpNotionals, 
				tmpStrikes, tmpzeroSpreads, fixedPmtsPerYear, fltPmtsPerYear, 
				fixedBasis, floatBasis, discountCurve, forecastCurve, hol);

			pForwards[i] = tempSwap.Solve(0, solveFORCOUPON);
			adjFwds.push_back( tempSwapNoSpread.Solve(0, solveFORCOUPON) );

			pNumeraires[i] = tempSwap.notionalBPV();

			// Work out forward variamces
			if (volGrid.getShift() != 0.0)
				mcpl_error("oneFactor doesn't work with shifted rate models yet.");

			vol2 = volGrid.get((expiry) (startDates[i]   - priceto) , (tenor) dayCountFrac(act_365, startDates[i], mature),
				(strike) pStrikes[i], pForwards[i] ).vol;
			if ( i==0 ) 
			{
				pForwardVols[0] = vol2*vol2 * dayCountFrac(act_365, priceto ,exerciseDates[0]) ;
			} 
			else 
			{
				vol1 = volGrid.get(expiry(startDates[i-1] - priceto), (tenor) dayCountFrac(act_365, startDates[i-1], mature) ,
													(strike) pStrikes[i-1], pForwards[i-1]).vol;
				// debug << "vol1= " << vol1 << "  vol2= " << vol2 << endl;
				pForwardVols[i] = vol2*vol2*dayCountFrac(act_365 , priceto , exerciseDates[i] )  -
					vol1*vol1*dayCountFrac(act_365 , priceto , exerciseDates[i-1]);  // Calc forward variance.
			}

			if ( pForwardVols[i] <= 0 ) pForwardVols[i] = 0;

			double offset =  pForwards[i] - adjFwds[i];
			adjStrikes.push_back( pStrikes[i] - offset );

		}

		// Set up the lattice
		setup( adjFwds, adjStrikes, pForwardVols, pNumeraires, stepsize, trunc , nsteps, dir == PAY ? 1:0 );

	}

	oneFactor::oneFactor(const vector<double> & pforwards, const vector<double> & pstrikes, const vector<double> & pvolatilities,
		const vector<double> & pnumeraires, const double pstepsize, const long int ptrunc,
		const long int pnumberOfSteps,const long int ppayerOrReceiver)
	{
		setup(pforwards, pstrikes, pvolatilities, pnumeraires, pstepsize, ptrunc, pnumberOfSteps, ppayerOrReceiver);
	}


	void oneFactor::setup(const vector<double> & pforwards, const vector<double> & pstrikes, const vector<double> & pvolatilities,
		const vector<double> & pnumeraires, const double pstepsize, const long int ptrunc, const long int pnumberOfSteps, const long int ppayerOrReceiver)
	{
		int i, pnumberOfDates;
		double intrinsicValue;

		pnumberOfDates = pforwards.size();

		if ( pnumberOfDates > 0 )
		{

			// allocate memory and initialise the arrays we use to store values
			presentValues.resize(2*pnumberOfSteps+1);
			futureValues.resize(2*pnumberOfSteps+1);
			transitionProbabilities.resize(2*ptrunc+1);


			forwards = pforwards;
			strikes = pstrikes;
			volatilities = pvolatilities;
			numeraires = pnumeraires;

			// Check inputs are same sized.
			if ( (pnumberOfDates != strikes.size()) && 
				(pnumberOfDates != volatilities.size() ) &&
				(pnumberOfDates != numeraires.size() ) )
				mcpl_error("input arrays not all same size for OneFactor.");

			numberOfDates=pnumberOfDates;
			numberOfSteps=pnumberOfSteps;
			trunc=ptrunc;
			stepsize=pstepsize;
			payerOrReceiver=ppayerOrReceiver;

			for(i = 0;i<2*numberOfSteps+1;++i)
			{
				futureValues[i]=0;
				presentValues[i]=0;
			}


			//determine whether we are pricing a call or a put.

			if (payerOrReceiver==0)
			{
				payerOrReceiver=-1;		//call
			}
			else
				payerOrReceiver=1;		//put

			//calculate the probabilities for moving from the penultimate to the last time.
			calculateProbabilities(volatilities[numberOfDates-1], stepsize, numberOfSteps,trunc);

			//initialise the values at the final date.
			for(i = -1*numberOfSteps ; i<=numberOfSteps ; ++i)
			{
				intrinsicValue = payerOrReceiver*((exp(stepsize*i)*forwards[numberOfDates - 1] - strikes[numberOfDates - 1])*numeraires[numberOfDates - 1] );
				if (intrinsicValue>0){
					futureValues[i+numberOfSteps] =intrinsicValue;}
				else
					futureValues[i+numberOfSteps]=0;
			}
		}
	}

	void oneFactor::calculateProbabilities(double volatility,double stepsize,long numberOfSteps,long trunc)
	{
		double tempsum=0;
		const double pi = Pi;
		double temp;
		int i;

		for(i = -1*trunc ; i<=trunc ; ++i)
		{
			temp=(i*stepsize+.5*volatility)*(i*stepsize+.5*volatility);
			//		transitionProbabilities[i+trunc] = (1/sqrt(2 * pi * volatility)) * exp(-1*temp  / (2 * volatility)) / (1 / (stepsize));
			transitionProbabilities[i+trunc] = exp(-1*temp  / (2 * volatility));
			tempsum = tempsum + transitionProbabilities[i+trunc];
		}

		//normalise the probabilities, so that they sum to 1.
		// this seems to make the results more stable as a function of trunc.

		for(i = -1*trunc ; i<=trunc ; ++i)
		{
			transitionProbabilities[i+trunc]=transitionProbabilities[i+trunc]/tempsum;
		}
	}


	double oneFactor::approxPV(int i, int trunc)
	{
		//the trunc parameter controls how many probabilities we will use.

		int k;
		int lowerCutOff;
		int upperCutOff;
		double temp=0;

		lowerCutOff=-1*trunc;
		upperCutOff=trunc;

		// now check to see if we get taken over the edge by going trunc steps from i.
		if (i-trunc<0) 
		{
			lowerCutOff=-1*i;
		}

		if (i+trunc>2*numberOfSteps )
		{
			upperCutOff=(2*numberOfSteps-i);
		}

		//perform the multiplication
		for(k = lowerCutOff ; k<=upperCutOff ; ++k)
		{
			temp = temp + transitionProbabilities[k+trunc] * futureValues[i + k];
		}

		return temp;
	}

	// step backwards through the lattice

	double oneFactor::priceStructure()
	{
		int i,m;
		double value;
		double intrinsicValue;

		// backwards induction step.
		// if the PV at the node is less than the instrinsic value, then the PV becomes the intrinsic value.

		for(m=numberOfDates-1;m>0;--m)
		{
			for(i = -1*numberOfSteps ; i <= numberOfSteps;++i)
			{		
				intrinsicValue = payerOrReceiver*(numeraires[m - 1] * (exp(stepsize*i)*forwards[m - 1] - strikes[m - 1]) ); //payers
				presentValues[i+numberOfSteps]=approxPV(i+numberOfSteps,trunc);	
				if (presentValues[i+numberOfSteps]<intrinsicValue)
				{	
					presentValues[i+numberOfSteps]=intrinsicValue; 
				}
			}		

			//after calculating all of the values at the current time, step back.
			for(i = -1*numberOfSteps ; i<=numberOfSteps ; ++i)
			{
				futureValues[i+numberOfSteps]=presentValues[i+numberOfSteps];
			}
			calculateProbabilities(volatilities[m-1], stepsize, numberOfSteps,trunc);
			value=futureValues[numberOfSteps];
		}

		// now get PV		
		value=approxPV(numberOfSteps,trunc);	

		return value;
	}

	// destructor
	// We need this to free up the memory we grab in the constructor.
	/*oneFactor::~oneFactor()
	{
	delete [] presentValues;
	delete [] futureValues;
	delete [] transitionProbabilities;
	delete [] forwards;
	delete [] strikes;
	delete [] volatilities;
	delete [] numeraires;
	}*/


} // namespace MCPL
