// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__847304FB_C239_11D5_B218_00B0D022B2E4__INCLUDED_)
#define AFX_STDAFX_H__847304FB_C239_11D5_B218_00B0D022B2E4__INCLUDED_

#ifndef WINVER
	#define WINVER 0x0501
#endif

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#include <windows.h>
#include <string>
#include <vector>
#ifdef UNICODE
	typedef std::wstring TSTRING;
#else
	typedef std::string TSTRING;
#endif

// TODO: reference additional headers your program requires here



//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__847304FB_C239_11D5_B218_00B0D022B2E4__INCLUDED_)
