#pragma once

#ifndef BermudanSwap_H
#define BermudanSwap_H

#pragma warning ( disable : 4251 4786 ) 
#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "swap.h"
#include "option.h"
#include "onefactor.h"
#include "onefactornormal.h"
#include "onefactormixed.h"

#include<vector>


using namespace std;

namespace MCPL
{

  class BermudanSwap : public Swap
  {
  public:
    BermudanSwap() {}

		
    BermudanSwap( const date & priceto, const Swap&  underlyer,  
      const vector<double> & vStrikes, long int noticeDays, const vector<bool>& toExercise,  
      double stepsize, long int nsteps, long int trunc, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, 
	  shared_ptr<VolatilityGrid> volGrid, bool includeSwapPV, bool useAmortisingVolCorrection, OptionModel optModel, double Beta = 0.0);

    BermudanSwap( DIRECTIONTYPE type, date & priceto, date & start, 
      date & first, date & mature, date & roll, bool longCoupon, const vector<double> & vNotionals,  
      const vector<double> & spreads, unsigned int fixedPmtsPerYear, unsigned int fltPmtsPerYear, 
      const vector<double> & strikes, long int noticeDays, long int lockout, long int calls, 
      DayBasis fixedBasis, DayBasis floatBasis, double stepsize, long int nsteps, 
      long int trunc, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, 
	  shared_ptr<VolatilityGrid> volGrid, HOLIDAYCAL hol, bool includeSwapPV, OptionModel optModel, double Beta = 0.0);

  BermudanSwap::BermudanSwap( DIRECTIONTYPE dir, date & priceto, date & start, 
    date & first, date & mature, date & roll, bool longCoupon, const vector<double> & vNotionals, 
    const vector<double> &vSpreads, unsigned int fixedPmtsPerYear, unsigned int fltPmtsPerYear, 
    const vector<double> &vStrikes, long int noticeDays, const vector<bool> toExercise, 
		DayBasis fixedBasis, DayBasis floatBasis, double stepsize, 
    long int nsteps, long int trunc, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, 
	shared_ptr<VolatilityGrid> volGrid, HOLIDAYCAL hol, bool includeSwapPV, OptionModel optModel, double Beta = 0.0);

    dateVec & getExerciseDates() { return m_exerciseDates; }
    dateVec & getStartDates() { return m_ULstartDates; }
    vector<bool> & getExercise() { return m_exercise; }

    vector<double>  getNumeraires() const { return m_numeraires; }
    vector<double>  getStrikes() const { return m_strikes; }
    vector<double>  getForwards() const { return m_forwards; }
    vector<double>  getAdjStrikes() const { return m_adjustedstrikes; }
    vector<double>  getAdjForwards() const { return m_zeroOffsetForwards; }
    vector<double>  getVariances() const { return m_forwardVols; }
    vector<double>  getVols() const { return m_vols; }
    vector<double>  getAmmrtVols() const { return m_ammrtVols; }
	vector<double>  getNotionals() { vector<double> v; return getLeg(MCPL::MC_FIXED)->getNotionals(v); }

    double getUnderlyerPV() const { return m_ULPV; }


	void updatePaymentsFromCurves(Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr));
    double Price();


  private:

    void   BermudanSwap::setupCurves();
		void   BermudanSwap::setupAmmortisingCurves();

    oneFactor m_lattice; 
    oneFactorNormal m_normalLattice;

    vector<double> m_numeraires;
    vector<double> m_forwards;
    vector<double> m_zeroOffsetForwards;
    vector<double> m_strikes;
    vector<double> m_adjustedstrikes;
    vector<double> m_forwardVols;
    vector<double> m_vols;
    vector<double> m_ammrtVols;

    dateVec m_exerciseDates ,m_startDates , m_ULstartDates;
    vector<bool> m_exercise;
		vector<bool> m_inputExercises;

	date m_priceto;
    vector<double> m_inputStrikes;
    unsigned int m_noticeDays, m_lockout, m_calls;
    unsigned int m_nsteps, m_trunc;
    double m_stepsize;
	double m_beta;
    double m_ULPV;
    bool m_includeSwapPV;
    OptionModel m_optModel;

  };


} // Namespace MCPL

#endif // BermudanSwap_H