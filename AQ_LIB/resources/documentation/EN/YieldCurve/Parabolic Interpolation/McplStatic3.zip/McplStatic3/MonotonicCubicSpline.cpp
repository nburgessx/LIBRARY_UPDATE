
#include "MonotonicCubicSpline.h"
#include "qgaus.h"
#include <algorithm>

using namespace std;
namespace MCPL
{

	MonotonicCubicSpline::MonotonicCubicSpline(const vector<double>& xs_, const vector<double>& ys_)
	{
		for (unsigned int i = 0; i < xs_.size(); i++)
		{
			_points.push_back(MCSPoint(xs_[i], ys_[i]));
		}

		_curveGood = false;
	}

	void MonotonicCubicSpline::calculate()
	{

		// Get consecutive differences and slopes
		for (unsigned int i = 0; i < _points.size() - 1; i++)
		{
			double dx = _points[i + 1].x - _points[i].x, dy = _points[i + 1].y - _points[i].y;
			_points[i].dx = dx; _points[i].dy = dy; _points[i].m = dy / dx;
		}

		// Get degree-1 coefficients
		_points[0].c1 = _points[0].m;
		for (unsigned int i = 0; i < _points.size() - 2; i++)
		{
			double m = _points[i].m, mNext = _points[i+1].m;
			if (m * mNext <= 0)
			{
				_points[i+1].c1 = 0;
			}
			else
			{
				double dx = _points[i].dx, dxNext = _points[i+1].dx, common = dx + dxNext;
				_points[i + 1].c1 = (3 * common / ((common + dxNext) / m + (common + dx) / mNext));
			}
		}
		_points.rbegin()->c1 = (_points.rbegin()+1)->m;

		// Get degree-2 and degree-3 coefficients
		for (unsigned int i = 0; i < _points.size() - 1; i++)
		{
			double c1 = _points[i].c1, m = _points[i].m, invDx = 1 / _points[i].dx, common = c1 + _points[i+1].c1 - 2.0*m;
			_points[i].c2 = ((m - c1 - common) * invDx); _points[i].c3 = (common * invDx * invDx);
		}

		_curveGood = true;
	}

	void MonotonicCubicSpline::calculate(unsigned int badIndex_)
	{
		unsigned int c1min = max(badIndex_ - 1, 0);
		unsigned int c2min = max(badIndex_ - 2, 0);
		unsigned int c1max = min(_points.size() - 1, badIndex_ + 1);
		unsigned int c2max = min(_points.size() - 2, badIndex_ + 1);

		// Get consecutive differences and slopes
		for (unsigned int i = c1min; i < c1max; i++)
		{
			double dx = _points[i + 1].x - _points[i].x, dy = _points[i + 1].y - _points[i].y;
			_points[i].dx = dx; _points[i].dy = dy; _points[i].m = dy / dx;
		}

		// Get degree-1 coefficients
		if ( c1min == 0 )
			_points[0].c1 = _points[0].m;
		if (c1max == _points.size() - 1)
			_points.rbegin()->c1 = (_points.rbegin()+1)->m;
		for (unsigned int i = max(c1min, 1); i <= min(c1max, _points.size() - 2); i++)
		{
			double m = _points[i-1].m, mNext = _points[i].m;
			if (m * mNext <= 0)
			{
				_points[i].c1=0;
			}
			else
			{
				double dx = _points[i - 1].dx, dxNext = _points[i].dx, common = dx + dxNext;
				_points[i].c1 = (3 * common / ((common + dxNext) / m + (common + dx) / mNext));
			}
		}

		// Get degree-2 and degree-3 coefficients
		for (unsigned int i = c2min; i <= c2max; i++)
		{
			double c1 = _points[i].c1, m = _points[i].m, invDx = 1 / _points[i].dx, common = c1 + _points[i + 1].c1 - 2.0*m;
			_points[i].c2 = ((m - c1 - common) * invDx); _points[i].c3 = (common * invDx * invDx);
		}

		_curveGood = true;
	}


	shared_ptr<vector<double>> MonotonicCubicSpline::interpolate(const vector<double>& interpPts_)
	{
		auto result = shared_ptr<vector<double>>(new vector<double>());
		for (unsigned int i = 0; i < interpPts_.size(); i++)
			result->push_back(interpolate(interpPts_[i]));

		return result;
	}


	double MonotonicCubicSpline::interpolate(double x)
	{
		if (!_curveGood)
			calculate();

		// The rightmost point in the dataset should give an exact result
		unsigned int i = _points.size() - 1;
		if (x == _points[i].x)
			return _points[i].y;

		// Search for the interval x is in, returning the corresponding y if x is one of the original xs
		auto it = lower_bound(_points.begin(), _points.end(), x, [](const MCSPoint& pt, double x){ return pt.x < x; });
		i = it - _points.begin();

		if (it == _points.end() || i > _points.size()-1 || i < 0)
			mcpl_error("Bounds violation");

		if (it->x == x)
			return it->y;
		else
			--i; //We want the point before x

		

		// Interpolate
		double diff = x - _points[i].x, diffSq = diff * diff;
		return _points[i].y + _points[i].c1 * diff + _points[i].c2 * diffSq + _points[i].c3 * diff * diffSq;
	}

	//The definite integral.
	double MonotonicCubicSpline::integrate(double x1_, double x2_)
	{
		//Checks
		if (x1_ == x2_)
			return 0;

		if ((min(x1_, x2_) < _points[0].x) || (max(x1_, x2_) > _points.rbegin()->x) )
			mcpl_error("Cannot extrapolate in MonotonicCubicSpline::integrate");

		if (x2_ < x1_)
			mcpl_error("x1 must be <= x2 in MonotonicCubicSpline::integrate");

		if (!_curveGood)
			calculate();


		// Search for the interval x1_ is in.
		auto it1 = lower_bound(_points.begin(), _points.end(), x1_, [](const MCSPoint& pt, double x){ return pt.x < x; }); //first element that is >= x1_
		if (it1->x != x1_)
			it1--;

		// Search for the interval x2_ is in.
		auto it2 = lower_bound(_points.begin(), _points.end(), x2_, [](const MCSPoint& pt, double x){ return pt.x < x; })-1; //last element that is < x2_

		unsigned int i1 = it1 - _points.begin();
		unsigned int i2 = it2 - _points.begin();

		if (i1 == i2)
			return integrate(i1, x2_) - integrate(i1, x1_);
		
		double ends = integrate(i1, _points[i1 + 1].x) - integrate(i1, x1_) + integrate(i2, x2_) - integrate(i2, _points[i2].x);
		double middle = 0;
		for (unsigned int i = i1 + 1; i < i2; i++)
			middle += integrate(i, _points[i + 1].x) - integrate(i, _points[i].x);

		return ends + middle;
	}

	//The indefinite integral of spline segment i at point x_
	double MonotonicCubicSpline::integrate(unsigned int i, double x_)
	{
		double diff = x_ - _points[i].x, diffSq = diff * diff;
		return _points[i].y * diff + _points[i].c1 * diffSq / 2.0 + _points[i].c2 * diffSq*diff / 3.0 + _points[i].c3 * diffSq * diffSq / 4.0;
	}

	//The arc length from x1_ to x2_.
	double MonotonicCubicSpline::arcLength(double x1_, double x2_)
	{
		//Checks
		if (x1_ == x2_)
			return 0;

		if ((min(x1_, x2_) < _points[0].x) || (max(x1_, x2_) > _points.rbegin()->x))
			mcpl_error("Cannot extrapolate in MonotonicCubicSpline::arcLength");

		if (x2_ < x1_)
			mcpl_error("x1 must be <= x2 in MonotonicCubicSpline::arcLength");

		if (!_curveGood)
			calculate();


		// Search for the interval x1_ is in.
		auto it1 = lower_bound(_points.begin(), _points.end(), x1_, [](const MCSPoint& pt, double x){ return pt.x < x; }); //first element that is >= x1_
		if (it1->x != x1_)
			it1--;

		// Search for the interval x2_ is in.
		auto it2 = lower_bound(_points.begin(), _points.end(), x2_, [](const MCSPoint& pt, double x){ return pt.x < x; }) - 1; //last element that is < x2_

		unsigned int i1 = it1 - _points.begin();
		unsigned int i2 = it2 - _points.begin();

		if (i1 == i2)
			return arcLength(i1, x1_, x2_);

		double ends = arcLength(i1, x1_, _points[i1 + 1].x) + arcLength(i2, it2->x , x2_);
		double middle = 0;
		for (unsigned int i = i1 + 1; i < i2; i++)
			middle += arcLength(i, _points[i].x, _points[i + 1].x);

		return ends + middle;
	
}
	//The arc length from x1_ to x2_ of spline segment i.
	double MonotonicCubicSpline::arcLength(unsigned int i, double x1_, double x2_)
	{
		double arcLen = qgaus([&](double x){
			double diff = x - _points[i].x;
			double dydx = _points[i].c1 + 2.0*_points[i].c2 * diff + 3.0*_points[i].c3 * diff*diff;
			return sqrt(1.0 + dydx*dydx);
		}, x1_, x2_);
		
		return arcLen - (x2_-x1_);
	}

	// Can improve this to use locality of curve around insertion point.
	void MonotonicCubicSpline::add(double x_, double y_)
	{
		if ((_points.size() == 0) || (x_ > _points.rbegin()->x))
		{
			_points.push_back(MCSPoint(x_, y_));
			_curveGood = false;
		}
		else
		{
			// Search for the interval x is in, returning the corresponding y if x is one of the original xs
			auto it = lower_bound(_points.begin(), _points.end(), x_, [](const MCSPoint& pt, double x){ return pt.x < x; });
			int i = it - _points.begin();

			if (it->x == x_)
			{
				it->y = y_;
				if (_curveGood)
					calculate(i);
			}
			else
			{
				_points.insert(it, MCSPoint(x_, y_));
				if (_curveGood)
				{
					calculate(i);
				}
			}
		}
	}

	unsigned int MonotonicCubicSpline::getFirstAffectedIndex(double x_)
	{
		// Search for the interval x_ is in.
		auto it = lower_bound(_points.begin(), _points.end(), x_, [](const MCSPoint& pt, double x){ return pt.x < x; }); //first element that is >= x1_
		if (it->x != x_ && it != _points.begin() )
			it--;

		int index = it - _points.begin();

		return(max(0, index - 2));
	}

	double MonotonicCubicSpline::getLabelAtIndex(unsigned int index)
	{
		return _points[index].x;
	}

	void MonotonicCubicSpline::erase(unsigned int index_)
	{
		_points.erase(_points.begin() + index_);
		if ( _curveGood )
			calculate(index_);
	}

} //Namespace MCPL
