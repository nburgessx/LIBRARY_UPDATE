#pragma once
#ifndef MCPLSHORTENDCURVE_H
#define MCPLSHORTENDCURVE_H

#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "discountcurve.h"
#include "PPCurves.h"
#include "Swap.h"
#include "numrec/dnr.h"

using namespace std;

namespace MCPL
{

	namespace ShortEndCurveFitFn
	{
		double func_linear(double drop);
	}
		
	class ShortEndCurve : public swapData
	{
	public:
		// constructors
		ShortEndCurve() : m_curveGood(false) {}


		void create( const vector<double> & futures, const vector<double> & adjustments, 
			const map<date,double> & swaps, const SwapType sType,
			date & today, date & firstFuture, const map<date,double> & serials, const vector<date> stubDates,
			CURRENCY ccy);

		// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
		void create_PPCurves( PPCurves & , double pp_val );

	private:

		void set_currency_defaults(CURRENCY);
		void set_currency_defaults(CURRENCY, SwapType);

		DayBasis m_basis;
		CURRENCY m_ccy;

		long int m_fixedPmtsPerYear;
		long int m_fltPmtsPerYear;
		DayBasis m_fixedBasis;
		DayBasis m_fltBasis;

		date m_today;
		date m_spot;

		date m_1stFut;

		bool							m_curveGood;					// Is the curve in a good state?

		HOLIDAYCAL				m_hols;								// holiday cal for the futures
		HOLIDAYCAL				m_swapHols;						// holiday cal for the swaps

		SwapType					m_swapType;
		dateVec						m_starts;							// start of IMM period
		dateVec						m_ends;								// ends of IMM periods
		LinearCurve				m_synthAdjustments;		// A linearly interpolable curve for conv adjustments.
		vector<double>		m_adjustments;				// convexity adjustments in bp
		vector<double>		m_futures;						// future prices
		int								m_nInputFutures;			// Number of input futures
		vector<double>		m_PDCF;								// IMM period day count fraction

		long							m_firstUsedSwapIndex;	//The index in m_parRates of the first swap to be used (this first swap is priced using futs though!)
		vector<double>		m_parRates;						// swap par points
		vector<double>		m_swapTenors;					// swap tenors
		map<date, double>	m_swapParams;					// Swap maturity - rate pairs.
		vector<date>			m_swapLastDates;			// swap last dates
		vector<date>			m_swapDFDates;				// dates on which we set the discount factor.
		vector<Swap>			m_swapCashflows;			// the swaps we actually use, one per fixed pmt period
		vector<double>		m_linFutsPriceDrops;	// Drops between the futures prices. One for each swap par rate. This is what we solve for. 
		vector<int>				m_linFutsSwapIndex;		// Index of first fut with mat date > swap[-1]'s mat date

		map<date, double>	m_serials;						// Start date, rate for serials.
		double						m_3mCashRate;					// 3m Cash rate.
		vector<date>			m_stubDates;					// Dates on which to calc DFs in `stub'

		vector<date>			m_shortEndStarts;			// Dates on which short end curve futures + serials start, in order.
		vector<date>			m_shortEndEnds;				// Dates on which short end curve futures + serials end, in order.
		vector<double>		m_shortEndPDCFs;			// Period day count fraction
		vector<double>		m_shortEndRates;			// Rate of future.
		vector<bool>			m_shortEndIsFut;			// Is this input a future? If not is a serial future.

		void calculateCurve();
		void calculateCurveFromFutures();
		void calculateDates();

		bool cmpvecs( const vector<date> & v1, const vector<date> & v2);
		bool cmpvecs( const vector<double> & v1, const vector<double> & v2);
		bool cmpmaps( const map<date,double> & v1, map<date,double> & v2);

		void fitFuturesDrops(int index);

		void generateSwapVectors();
		void generateSwapRateVector();

		friend double ShortEndCurveFitFn::func_linear(double);

	};

} // namespace MCPL

#endif // MCPLLINEARFUTURESCURVE_H