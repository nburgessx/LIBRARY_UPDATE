#include"OISCurve.h"

#include "numrec/dnrutil.h"


namespace MCPL
{
	void OISCurve::create( double ONRate, const vector<Handle<CurveRateHelper>> & Instruments, 
		date & today, CURRENCY ccy , const vector<date> &meetingDates)
	{

		if ( Instruments.size() == 0 )
			mcpl_error("OISCurve needs some instruments to build a curve");

		set_currency_defaults(ccy);
		m_today = today;
		m_spot = spot(today, ccy);

		m_instruments = Instruments;
		m_ONRate = ONRate;
		m_meetingDates = meetingDates;

		calculateDates();
		calculateCurve();
//		calculateCurveFast();
	}

//======================================================================================================================
//======================================================================================================================
	long OISCurve::findClosestInstrumentKey(date date_)
	{
		int daysToFind = date_ - m_today;
		map<long int, Handle<CurveRateHelper>>::const_iterator lower = m_rateHelperMap.lower_bound( daysToFind );

		int lowerBoundKey = lower->first;
		
		if ( daysToFind == lowerBoundKey ||  lower == m_rateHelperMap.end() )
			return daysToFind;

		int prevKey = (--lower)->first;

		if ( (daysToFind - prevKey ) <= (lowerBoundKey - daysToFind) )
			return prevKey;
		else
			return lowerBoundKey;
	}

	void OISCurve::calculateDates()
	{
		clear();
		//
		//Setup the map of rateHelpers
		//
		m_rateHelperMap.clear();
		for ( vector<Handle<CurveRateHelper>>::const_iterator it = m_instruments.begin() ; 
			it != m_instruments.end(); it++ )
		{
			Handle<CurveRateHelper> helper = *it;
			long int daysToEnd = helper->getLastDate() - m_today;

			// Add the rateHelper if we don't already have one with the same end date
			if ( m_rateHelperMap.find(daysToEnd) == m_rateHelperMap.end() ) 
				m_rateHelperMap[daysToEnd] = helper;

		}

		//
		// Setup the vector of meeting dates, creating monthly synthetic meetings beyond the end of the supplied dates.
		//
		date lastDate = m_today + m_rateHelperMap.rbegin()->first;

		// Do we need to add some more dates to end of meetingDates?
		if ( (m_meetingDates.size() == 0 ) || ( lastDate > *(m_meetingDates.rbegin()) ) )
		{
			date lastMeetingDate;
			if (m_meetingDates.size() == 0 )
				lastMeetingDate = m_today;
			else
				lastMeetingDate = *(m_meetingDates.rbegin());

			date mtgDate, prevMtgDate = lastMeetingDate;
			int monthadd = 1;
			do 
			{
				mtgDate = addBusinessMonths(lastMeetingDate, monthadd, m_hols, false);
				
				long closestInstrumentKey = findClosestInstrumentKey(mtgDate); // Align the meeting dates with nearby instrument sensitivity max dates.

				if ( abs((mtgDate - m_today) - closestInstrumentKey) <= 15 )
					mtgDate = m_today + closestInstrumentKey;

				if ( ((mtgDate - prevMtgDate ) > 15) )// Ensure first synthetic meeting date is at last 15 days after last supplied meeting date.
				{
						m_meetingDates.push_back(mtgDate);
						monthadd = 1;
						prevMtgDate = mtgDate;
				}
				else
				{
					if ( (mtgDate - lastMeetingDate) > 15 )
						monthadd++;
				}

			} while ( mtgDate < lastDate);

		}

		// Set inputRates. The key is the days to the last meeting date which is < last date of rateHelper.
		m_inputRates.clear();
		m_rateHelperKeys.clear();
		m_inputRates.set(0,m_ONRate);
		unsigned int inputIndex = 1; //Index 0 is the ON rate

		int previousMeetingIndex = -1;
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			m_rateHelperKeys.push_back(it->first);
			date lastInstDate = m_today + it->first;
			date firstInstDate = it->second->getStartDate();

			for ( int meetingIndex = previousMeetingIndex+1 ; meetingIndex < (int) m_meetingDates.size() ; meetingIndex++ )
			{
				if ( m_meetingDates[meetingIndex] >= lastInstDate )
				{
					if ( ( meetingIndex == 0 ) )
					{
						it->second->UseInCurve = false;
					} 
					else if ( meetingIndex == previousMeetingIndex+1 ) // No meeting between the end of last instrument and the end of this one
					{
						if ( m_meetingDates[meetingIndex-1] < firstInstDate ) // No meeting during life of instrument
						{
							it->second->UseInCurve = true;
							it->second->ContainsAMeeting = false;
							//Take the meeting from the previous instrument.
							map<long, Handle<CurveRateHelper>>::iterator it2 = it;
							it2--;
							it2->second->UseInCurve = false;
							it->second->InputsIndex = it2->second->InputsIndex;
						}
						else
						{
							it->second->UseInCurve = false;
						}
					}
					else
					{
						previousMeetingIndex = meetingIndex-1;
						m_inputRates.set(m_meetingDates[previousMeetingIndex] - m_today, it->second->getTargetRate());

						it->second->UseInCurve = true;
						it->second->ContainsAMeeting = true;
						it->second->InputsIndex = inputIndex++;
					}
					break;
				}

			}
		}

	}

	void OISCurve::calculateCurve()
	{
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			if ( it->second->UseInCurve )
			{
				fitInstrument(it->first);
			}
		}
	}

//======================================================================================================================
//======================================================================================================================

	// Forward flat fwds from meeting dates.
	void OISCurve::buildDiscountCurveFromOIRates()
	{
		this->clear();

		this->set(m_today,1);
					
		double oneDayDCF = dayCountFrac(m_basis, m_today, m_today+1 );

		double rate = m_inputRates.get(0) * oneDayDCF;
		double PDF = 1.0 / pow(1.0+rate , m_meetingDates[0] - m_today);
		this->set(m_meetingDates[0],  PDF);
		
		for ( unsigned int i=1 ; i < m_meetingDates.size() ; i++  )
		{
			double rate;
			if ( (m_meetingDates[i] - m_today) <= m_inputRates.lastLabel() )
			{
				rate = m_inputRates.get(m_meetingDates[i-1] - m_today) * oneDayDCF;
			}
			else
			{
				rate = m_inputRates.get( m_inputRates.lastLabel() ) * oneDayDCF;
			}
			double PDF = 1.0 / pow(1.0+rate , m_meetingDates[i] - m_meetingDates[i-1]);
			this->set(m_meetingDates[i], this->get(m_meetingDates[i-1]) * PDF);
		}
	}

	// Backward flat fwds from meeting dates.
	//void OISCurve::buildDiscountCurveFromOIRates()
	//{
	//	this->clear();

	//	this->set(m_today,1);
	//				
	//	double oneDayDCF = dayCountFrac(m_basis, m_today, m_today+1 );

	//	double rate = m_inputRates.get(m_meetingDates[0] - m_today) * oneDayDCF;
	//	double PDF = 1.0 / pow(1.0+rate , m_meetingDates[0] - m_today);
	//	this->set(m_meetingDates[0],  PDF);
	//	
	//	for ( unsigned int i=1 ; i < m_meetingDates.size() ; i++  )
	//	{
	//		double rate;
	//		if ( (m_meetingDates[i] - m_today) <= m_inputRates.lastLabel() )
	//		{
	//			rate = m_inputRates.get(m_meetingDates[i] - m_today) * oneDayDCF;
	//		}
	//		else
	//		{
	//			rate = m_inputRates.get( m_inputRates.lastLabel() ) * oneDayDCF;
	//		}
	//		double PDF = 1.0 / pow(1.0+rate , m_meetingDates[i] - m_meetingDates[i-1]);
	//		this->set(m_meetingDates[i], this->get(m_meetingDates[i-1]) * PDF);
	//	}
	//}

//======================================================================================================================
//======================================================================================================================

	namespace OISCurveFitFn
	{
		unsigned int key;
		Handle<OISCurve> fitcurve;

		double fitFunc(double OIrate)
		{
			Handle<OISCurve> curve = fitcurve;
			curve->m_inputRates.setAtIndex(curve->m_rateHelperMap[key]->InputsIndex , OIrate);
			curve->buildDiscountCurveFromOIRates();
			curve->m_rateHelperMap[key]->SetCurves(curve,curve);
			double calcRate = curve->m_rateHelperMap[key]->getRate();
			return calcRate - curve->m_rateHelperMap[key]->getTargetRate();
		}
	}

	namespace OISCurveFitFnMulti
	{
		Handle<OISCurve> fitcurve;

		void fitFuncMulti(const vector<double> &OIrates, vector<double> &errors)
		{
			Handle<OISCurve> curve = fitcurve;

			// adjust the levels of OI rates in the curve
			unsigned int key = 0;
			for ( map<long, Handle<CurveRateHelper>>::iterator it = curve->m_rateHelperMap.begin() ;     key < OIrates.size() && it != curve->m_rateHelperMap.end() ;      it++ )
			{
				if ( it->second->UseInCurve )
				{
					curve->m_inputRates.setAtIndex( curve->m_rateHelperMap[it->first]->InputsIndex , OIrates[key]);
				}
				key++;
			}

			// rebuild the curve
			curve->buildDiscountCurveFromOIRates();
			
			// calculate mispricing errors
			key = 0;
			for ( map<long, Handle<CurveRateHelper>>::iterator it = curve->m_rateHelperMap.begin() ;     key < OIrates.size() && it != curve->m_rateHelperMap.end() ;      it++ )
			{
				if ( it->second->UseInCurve )
				{
					curve->m_rateHelperMap[it->first]->SetCurves(curve,curve);
					errors[key] = curve->m_rateHelperMap[it->first]->getRate() - curve->m_rateHelperMap[it->first]->getTargetRate();
				}
				key++;
			}
		}
	}


//======================================================================================================================
//======================================================================================================================

	void OISCurve::fitInstrument(const unsigned int key)
	{
		OISCurveFitFn::fitcurve = Handle<OISCurve>(this,null_deleter());
		OISCurveFitFn::key = key;

		double x1=-.001;
		double x2=.001;

		double OIrate = linearFitter( OISCurveFitFn::fitFunc , x1, x2, .0000001 );

		m_inputRates.setAtIndex( m_rateHelperMap[key]->InputsIndex , OIrate);
		//buildDiscountCurveFromOIRates(); // after successfull iteration we already have the curve built
	}


	void OISCurve::calculateCurveFast()
	{
		OISCurveFitFnMulti::fitcurve = Handle<OISCurve>(this,null_deleter()); // not cool if we build curves in multiple threads

		double x1 = -.001;
		double x2 = +.001;
		double tolerance = 1e-8; // 0.0001 of a B.P.

		int result = multiDummyFitter( OISCurveFitFnMulti::fitFuncMulti, m_rateHelperMap.size(), x1, x2, tolerance );

		//buildDiscountCurveFromOIRates(); // after successfull iteration we already have the curve built. no need to rebuild it here

		if (result!=0)
			mcpl_error("dummy multi-dimensional NR did not converge. may be Jacobian is far from diagonal matrix?");
	}


//======================================================================================================================
//======================================================================================================================


	void OISCurve::set_currency_defaults(CURRENCY ccy)
	{

		m_ccy = ccy;
		this->setCurrency(m_ccy);

		switch(ccy)
		{
		case USD:
			m_hols = USA;
			m_basis = act_360;
			break;
		case EUR:
			m_hols = EUTARG;
			m_basis = act_360;
			break;
		case JPY:
			m_hols = JP;
			m_basis = act_365;
			break;
		case GBP:
			m_hols = UK;
			m_basis = act_365f;
			break;
		default:
			mcpl_error("Currency not yet supported in OISCurve");
		}
	}


//======================================================================================================================
//======================================================================================================================

	Handle<PPCurves> OISCurve::create_PPCurves( double pp_val, bool CalculateGammaCurves )
	{


		Handle<PPCurves> pp_curves = Handle<PPCurves>(new PPCurves());

		int nHedges = 1+ m_rateHelperMap.size() ; // Add 1 for cash rate.
		pp_curves->resize( nHedges ); 
		pp_curves->set_ppsize( pp_val/100.0 ); // set the perturb size in factor (i.e. 1 = 1%)

		pp_curves->base() = Handle<swapData>(new OISCurve(*this));

		unsigned int i=0;
		//
		// up
		//

		//Cash
		partialClear();
		m_ONRate += pp_val/100.0;
		pp_curves->label(i) = "cash O/N";
		calculateCurve();
		pp_curves->up(i++)= Handle<swapData>(new OISCurve(*this));
		m_ONRate -= pp_val/100.0;

		//Everything else
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			it->second->setTargetRate( it->second->getTargetRate() + pp_val/100.0 );
			pp_curves->label(i) = it->second->getLabel();
			partialClear();
			calculateCurve();
			pp_curves->up(i++)= Handle<swapData>(new OISCurve(*this));
			it->second->setTargetRate( it->second->getTargetRate() - pp_val/100.0 );
		}

		//
		// dn
		//

		i=0;
		//Cash
		partialClear();
		m_ONRate -= pp_val/100.0;
		calculateCurve();
		pp_curves->dn(i++)= Handle<swapData>(new OISCurve(*this));
		m_ONRate += pp_val/100.0;

		//Everything else
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			it->second->setTargetRate( it->second->getTargetRate() - pp_val/100.0 );
			partialClear();
			calculateCurve();
			pp_curves->dn(i++)= Handle<swapData>(new OISCurve(*this));
			it->second->setTargetRate( it->second->getTargetRate() + pp_val/100.0 );
		}

		//
		//upup
		//
		m_ONRate += pp_val/100.0;
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			it->second->setTargetRate( it->second->getTargetRate() + pp_val/100.0 );
		}
		i=0;

		//Cash
		partialClear();
		m_ONRate += pp_val/100.0;
		calculateCurve();
		pp_curves->upup(i++)= Handle<swapData>(new OISCurve(*this));
		m_ONRate -= pp_val/100.0;

		//Everything else
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			it->second->setTargetRate( it->second->getTargetRate() + pp_val/100.0 );
			partialClear();
			calculateCurve();
			pp_curves->upup(i++)= Handle<swapData>(new OISCurve(*this));
			it->second->setTargetRate( it->second->getTargetRate() - pp_val/100.0 );
		}

		//
		// updn
		//

		i=0;
		//Cash
		partialClear();
		m_ONRate -= pp_val/100.0;
		calculateCurve();
		pp_curves->updn(i++)= Handle<swapData>(new OISCurve(*this));
		m_ONRate += pp_val/100.0;

		//Everything else
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			it->second->setTargetRate( it->second->getTargetRate() - pp_val/100.0 );
			partialClear();
			calculateCurve();
			pp_curves->updn(i++)= Handle<swapData>(new OISCurve(*this));
			it->second->setTargetRate( it->second->getTargetRate() + pp_val/100.0 );
		}


		//
		//dnup
		//
		m_ONRate -= 2.0 * pp_val/100.0;
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			it->second->setTargetRate( it->second->getTargetRate() - 2.0*pp_val/100.0 );
		}
		i=0;

		//Cash
		partialClear();
		m_ONRate += pp_val/100.0;
		calculateCurve();
		pp_curves->dnup(i++)= Handle<swapData>(new OISCurve(*this));
		m_ONRate -= pp_val/100.0;

		//Everything else
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			it->second->setTargetRate( it->second->getTargetRate() + pp_val/100.0 );
			partialClear();
			calculateCurve();
			pp_curves->dnup(i++)= Handle<swapData>(new OISCurve(*this));
			it->second->setTargetRate( it->second->getTargetRate() - pp_val/100.0 );
		}

		//
		// dndn
		//

		i=0;
		//Cash
		partialClear();
		m_ONRate -= pp_val/100.0;
		calculateCurve();
		pp_curves->dndn(i++)= Handle<swapData>(new OISCurve(*this));
		m_ONRate += pp_val/100.0;

		//Everything else
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			it->second->setTargetRate( it->second->getTargetRate() - pp_val/100.0 );
			partialClear();
			calculateCurve();
			pp_curves->dndn(i++)= Handle<swapData>(new OISCurve(*this));
			it->second->setTargetRate( it->second->getTargetRate() + pp_val/100.0 );
		}

		//
		//Take all inputs back to original state.
		//
		m_ONRate += pp_val/100.0;
		for ( map<long, Handle<CurveRateHelper>>::iterator it = m_rateHelperMap.begin() ; it != m_rateHelperMap.end() ; it++ )
		{
			it->second->setTargetRate( it->second->getTargetRate() + pp_val/100.0 );
		}

		partialClear();
		calculateCurve();

		return pp_curves;
	}






} // namespace MCPL