#include "mcpldefs.h"

namespace MCPL
{

	CURRENCY str2Currency(const char * strType)
	{
		CURRENCY retVal = UNDEF;

		if      ( ! _stricmp(strType , "USD")) retVal = USD;
		else if ( ! _stricmp(strType , "GBP")) retVal = GBP;
		else if ( ! _stricmp(strType , "JPY")) retVal = JPY;
		else if ( ! _stricmp(strType , "EUR")) retVal = EUR;

		else if ( ! _stricmp(strType , "DEM")) retVal = DEM;
		else if ( ! _stricmp(strType , "CHF")) retVal = CHF;
		else if ( ! _stricmp(strType , "FRF")) retVal = FRF;
		else if ( ! _stricmp(strType , "ITL")) retVal = ITL;
		else if ( ! _stricmp(strType , "XEU")) retVal = XEU;
		else if ( ! _stricmp(strType , "ESP")) retVal = ESP;
		else if ( ! _stricmp(strType , "CAD")) retVal = CAD;
		else if ( ! _stricmp(strType , "AUD")) retVal = AUD;
		else if ( ! _stricmp(strType , "HKD")) retVal = HKD;
		else if ( ! _stricmp(strType , "NZD")) retVal = NZD;
		else if ( ! _stricmp(strType , "FIM")) retVal = FIM;
		else if ( ! _stricmp(strType , "SEK")) retVal = SEK;
		else if ( ! _stricmp(strType , "DKK")) retVal = DKK;
		else if ( ! _stricmp(strType , "NKR")) retVal = NKR;
		else if ( ! _stricmp(strType , "NLG")) retVal = NLG;
		else if ( ! _stricmp(strType , "MYR")) retVal = MYR;
		else if ( ! _stricmp(strType , "BEF")) retVal = BEF;
		else if ( ! _stricmp(strType , "THB")) retVal = THB;
		else if ( ! _stricmp(strType , "IDR")) retVal = IDR;
		else if ( ! _stricmp(strType , "ATS")) retVal = ATS;
		else if ( ! _stricmp(strType , "TWD")) retVal = TWD;

		else
			mcpl_error( MCPL_ERROR(std::string("unknown currency : ") + std::string(strType)) );

		return retVal;
	}

	const char* ApolloEnums::FinancialIndex2str(ApolloEnums::FinancialIndex index_)
	{
		switch(index_)
		{
		case LIBOR:
			return "LIBOR";
		case TIBOR:
			return "TIBOR";
		case EURIBOR:
			return "EURIBOR";
		case HIBOR:
			return "HIBOR";
		case BA:
			return "BA";
		case CHIBOR:
			return "CHIBOR";
		case SOR:
			return "SOR";
		case MEXIBOR:
			return "MEXIBOR";
		case NIBOR:
			return "NIBOR";
		case CIBOR:
			return "CIBOR";
		case STIBOR:
			return "STIBOR";
		case OIS:
			return "OIS";
		case FEDFUNDS:
			return "FEDFUNDS";
		case EONIA:
			return "EONIA";
		case SONIA:
			return "SONIA";
		case TONAR:
			return "TONAR";
		case CMS:
			return "CMS";
		case MODIFIED:
			return "MODIFIED";
		case DEFAULT:
			return "DEFAULT";
		default:
			mcpl_error("Can't cnvert FinancialIndex " + stringify(index_) + " to string");
		}
	}
		const char* currency2str( CURRENCY ccy)
	{
		switch(ccy)
		{
			case USD:
				return "USD";
			case GBP:
				return "GBP";
			case JPY:
				return "JPY";
			case EUR:
				return "EUR";
			default:
				mcpl_error("Can't cnvert CURRENCY to string");
		}
	}

	SwapType str2SwapType( const char* strSwapType)
	{
		SwapType retVal;

		if ( ! _stricmp(strSwapType , "AM6")) retVal = AM6;
		else if ( ! _stricmp(strSwapType , "AM6s") ) retVal = AM6;
		else if ( ! _stricmp(strSwapType , "AM 6s") ) retVal = AM6;
		else if ( ! _stricmp(strSwapType , "AM 6's") ) retVal = AM6;

		else if ( ! _stricmp(strSwapType , "AM3") ) retVal =  AM3;
		else if ( ! _stricmp(strSwapType , "AM3s") ) retVal = AM3;
		else if ( ! _stricmp(strSwapType , "AM 3") ) retVal =  AM3;
		else if ( ! _stricmp(strSwapType , "AM 3's") ) retVal = AM3;

		else if ( ! _stricmp(strSwapType , "AB6") ) retVal =  AB6;
		else if ( ! _stricmp(strSwapType , "AB6s") ) retVal = AB6;
		else if ( ! _stricmp(strSwapType , "AB 6") ) retVal =  AB6;
		else if ( ! _stricmp(strSwapType , "AB 6's") ) retVal = AB6;

		else if ( ! _stricmp(strSwapType , "AB3") ) retVal =  AB3;
		else if ( ! _stricmp(strSwapType , "AB3s") ) retVal = AB3;
		else if ( ! _stricmp(strSwapType , "AB 3") ) retVal =  AB3;
		else if ( ! _stricmp(strSwapType , "AB 3's") ) retVal = AB3;

		else if ( ! _stricmp(strSwapType , "SM6") ) retVal =  SM6;
		else if ( ! _stricmp(strSwapType , "SM6s") ) retVal = SM6;
		else if ( ! _stricmp(strSwapType , "SM 6") ) retVal =  SM6;
		else if ( ! _stricmp(strSwapType , "SM 6's") ) retVal = SM6;

		else if ( ! _stricmp(strSwapType , "SM3") ) retVal =  SM3;
		else if ( ! _stricmp(strSwapType , "SM3s") ) retVal = SM3;
		else if ( ! _stricmp(strSwapType , "SM 3") ) retVal =  SM3;
		else if ( ! _stricmp(strSwapType , "SM 3's") ) retVal = SM3;

		else if ( ! _stricmp(strSwapType , "SB6") ) retVal =  SB6;
		else if ( ! _stricmp(strSwapType , "SB6s") ) retVal = SB6;
		else if ( ! _stricmp(strSwapType , "SB 6") ) retVal =  SB6;
		else if ( ! _stricmp(strSwapType , "SB 6's") ) retVal = SB6;

		else if ( ! _stricmp(strSwapType , "SB3") ) retVal =  SB3;
		else if ( ! _stricmp(strSwapType , "SB3s") ) retVal = SB3;
		else if ( ! _stricmp(strSwapType , "SB 3") ) retVal =  SB3;
		else if ( ! _stricmp(strSwapType , "SB 3's") ) retVal = SB3;

		else if ( ! _stricmp(strSwapType , "QM6") ) retVal =  QM6;
		else if ( ! _stricmp(strSwapType , "QM6s") ) retVal = QM6;
		else if ( ! _stricmp(strSwapType , "QM 6") ) retVal =  QM6;
		else if ( ! _stricmp(strSwapType , "QM 6's") ) retVal = QM6;

		else if ( ! _stricmp(strSwapType , "QM3") ) retVal =  QM3;
		else if ( ! _stricmp(strSwapType , "QM3s") ) retVal = QM3;
		else if ( ! _stricmp(strSwapType , "QM 3") ) retVal =  QM3;
		else if ( ! _stricmp(strSwapType , "QM 3's") ) retVal = QM3;

		else if ( ! _stricmp(strSwapType , "QB6") ) retVal =  QB6;
		else if ( ! _stricmp(strSwapType , "QB6s") ) retVal = QB6;
		else if ( ! _stricmp(strSwapType , "QB 6") ) retVal =  QB6;
		else if ( ! _stricmp(strSwapType , "QB 6's") ) retVal = QB6;

		else if ( ! _stricmp(strSwapType , "QB3") ) retVal =  QB3;
		else if ( ! _stricmp(strSwapType , "QB3s") ) retVal = QB3;
		else if ( ! _stricmp(strSwapType , "QB 3") ) retVal =  QB3;
		else if ( ! _stricmp(strSwapType , "QB 3's") ) retVal = QB3;
		//
		else if ( ! _stricmp(strSwapType , "AM12")) retVal = AM12;
		else if ( ! _stricmp(strSwapType , "AM12s") ) retVal = AM12;
		else if ( ! _stricmp(strSwapType , "AM 12s") ) retVal = AM12;
		else if ( ! _stricmp(strSwapType , "AM 12's") ) retVal = AM12;

		else if ( ! _stricmp(strSwapType , "AB12") ) retVal =  AB12;
		else if ( ! _stricmp(strSwapType , "AB12s") ) retVal = AB12;
		else if ( ! _stricmp(strSwapType , "AB 12") ) retVal =  AB12;
		else if ( ! _stricmp(strSwapType , "AB 12's") ) retVal = AB12;

		else if ( ! _stricmp(strSwapType , "SM12") ) retVal =  SM12;
		else if ( ! _stricmp(strSwapType , "SM12s") ) retVal = SM12;
		else if ( ! _stricmp(strSwapType , "SM 12") ) retVal =  SM12;
		else if ( ! _stricmp(strSwapType , "SM 12's") ) retVal = SM12;

		else if ( ! _stricmp(strSwapType , "SB12") ) retVal =  SB12;
		else if ( ! _stricmp(strSwapType , "SB12s") ) retVal = SB12;
		else if ( ! _stricmp(strSwapType , "SB 12") ) retVal =  SB12;
		else if ( ! _stricmp(strSwapType , "SB 12's") ) retVal = SB12;

		else if ( ! _stricmp(strSwapType , "QM12") ) retVal =  QM12;
		else if ( ! _stricmp(strSwapType , "QM12s") ) retVal = QM12;
		else if ( ! _stricmp(strSwapType , "QM 12") ) retVal =  QM12;
		else if ( ! _stricmp(strSwapType , "QM 12's") ) retVal = QM12;

		else if ( ! _stricmp(strSwapType , "QB12") ) retVal =  QB12;
		else if ( ! _stricmp(strSwapType , "QB12s") ) retVal = QB12;
		else if ( ! _stricmp(strSwapType , "QB 12") ) retVal =  QB12;
		else if ( ! _stricmp(strSwapType , "QB 12's") ) retVal = QB12;
		//
		else if ( ! _stricmp(strSwapType , "AM1")) retVal = AM1;
		else if ( ! _stricmp(strSwapType , "AM1s") ) retVal = AM1;
		else if ( ! _stricmp(strSwapType , "AM 1s") ) retVal = AM1;
		else if ( ! _stricmp(strSwapType , "AM 1's") ) retVal = AM1;

		else if ( ! _stricmp(strSwapType , "AB1") ) retVal =  AB1;
		else if ( ! _stricmp(strSwapType , "AB1s") ) retVal = AB1;
		else if ( ! _stricmp(strSwapType , "AB 1") ) retVal =  AB1;
		else if ( ! _stricmp(strSwapType , "AB 1's") ) retVal = AB1;

		else if ( ! _stricmp(strSwapType , "SM1") ) retVal =  SM1;
		else if ( ! _stricmp(strSwapType , "SM1s") ) retVal = SM1;
		else if ( ! _stricmp(strSwapType , "SM 1") ) retVal =  SM1;
		else if ( ! _stricmp(strSwapType , "SM 1's") ) retVal = SM1;

		else if ( ! _stricmp(strSwapType , "SB1") ) retVal =  SB1;
		else if ( ! _stricmp(strSwapType , "SB1s") ) retVal = SB1;
		else if ( ! _stricmp(strSwapType , "SB 1") ) retVal =  SB1;
		else if ( ! _stricmp(strSwapType , "SB 1's") ) retVal = SB1;

		else if ( ! _stricmp(strSwapType , "QM1") ) retVal =  QM1;
		else if ( ! _stricmp(strSwapType , "QM1s") ) retVal = QM1;
		else if ( ! _stricmp(strSwapType , "QM 1") ) retVal =  QM1;
		else if ( ! _stricmp(strSwapType , "QM 1's") ) retVal = QM1;

		else if ( ! _stricmp(strSwapType , "QB1") ) retVal =  QB1;
		else if ( ! _stricmp(strSwapType , "QB1s") ) retVal = QB1;
		else if ( ! _stricmp(strSwapType , "QB 1") ) retVal =  QB1;
		else if ( ! _stricmp(strSwapType , "QB 1's") ) retVal = QB1;

		else if ( ! _stricmp(strSwapType , "MM1") ) retVal =  MM1;
		else if ( ! _stricmp(strSwapType , "MM1s") ) retVal =  MM1;

		else if ( ! _stricmp(strSwapType , "MB1") ) retVal = MB1;
		else if ( ! _stricmp(strSwapType , "MB1s") ) retVal = MB1;

		//
		else mcpl_error("bad swap type " + string(strSwapType));

		return retVal;
	}

	ROLLTYPE str2RollType( const char * strRollType)
	{
		ROLLTYPE retVal;

		if ( ! _stricmp(strRollType , "forward")) retVal = ROLL_FORWARD;
		else if ( ! _stricmp(strRollType , "backward") ) retVal = ROLL_BACKWARD;
		else if ( ! _stricmp(strRollType , "imm1") ) retVal = ROLL_IMM1;
		else if ( ! _stricmp(strRollType , "imm3") ) retVal = ROLL_IMM3;
		else if ( ! _stricmp(strRollType , "eom") ) retVal = ROLL_MONTHEND;

		else mcpl_error("bad roll type " + string(strRollType));

		return retVal;
	}


	// the possible types of payment
	PAYTYPE str2PayType( const char * strPayType )
	{
		PAYTYPE retVal;

		if ( ! _stricmp(strPayType , "fixed")) retVal = MC_FIXED;
		else if ( ! _stricmp(strPayType , "bond") ) retVal = MC_BOND;
		else if ( ! _stricmp(strPayType , "payment") ) retVal = MC_PAYMENT;
		else if ( ! _stricmp(strPayType , "float") ) retVal = MC_FLOAT;
		else if ( ! _stricmp(strPayType , "cap") ) retVal = MC_CAP;
		else if ( ! _stricmp(strPayType , "floor") ) retVal = MC_FLOOR;
		else if ( ! _stricmp(strPayType , "straddle") ) retVal = MC_STRADDLE;
		else if ( ! _stricmp(strPayType , "cms") ) retVal = MC_CMS;

		else mcpl_error("bad payment type " + string(strPayType));

		return retVal;
	}

	BONDTYPE str2BondType(const char *strBondType)
	{
		BONDTYPE retVal;
		if ( ! _stricmp(strBondType , "jgb")) retVal = JGB;
		else if ( ! _stricmp(strBondType , "bund") ) retVal = BUND;
		else if ( ! _stricmp(strBondType , "treasury") ) retVal = TREASURY;
		else if ( ! _stricmp(strBondType , "gilt") ) retVal = GILT;

		else mcpl_error("bad bond type " + string(strBondType));

		return retVal;
	}


	// the possible types of payment
	DIRECTIONTYPE str2DirectionType( const char * strDir)
	{
		DIRECTIONTYPE retVal;

		if ( ! _stricmp(strDir , "Pay")) retVal = PAY;
		else if ( ! _stricmp(strDir , "Rec") ) retVal = RECEIVE;
		else if ( ! _stricmp(strDir , "Receive") ) retVal = RECEIVE;

		else mcpl_error("bad swap direction type " + string(strDir));

		return retVal;
	}


	unsigned workingDaysPerYear(const CURRENCY ccy)
	{
		switch (ccy) {
	case USD:
		return 252;
		break;
	case EUR:
		return 256;
		break;
	case GBP:
		return 253;
		break;
	default:
		return 365;
		}
	}

	double workingDayCountFrac(const date & d1,const date & d2, const CURRENCY ccy, const HOLIDAYCAL hol)
	{
		double dcf;
		switch (ccy) {
	case USD:
		dcf = (double) countWD( d1, d2, USA) / (double) workingDaysPerYear(ccy);
		break;
	case EUR:
		dcf = (double) countWD( d1, d2, EUTARG) / (double) workingDaysPerYear(ccy);
		break;
	case GBP:
		dcf = (double) countWD( d1, d2, UK) / (double) workingDaysPerYear(ccy);
		break;
	default:
		dcf = dayCountFrac(act_365f , d1 , d2 );
		}

		return dcf;
	}

	DayBasis getLiborBasis(const CURRENCY ccy)
	{
		DayBasis basis;

		switch (ccy) 
		{
		case USD:
		case EUR:
			basis = act_360;
			break;
		case GBP:
			basis = act_365f;
			break;
		default:
			basis = act_360;
		}
		return basis;
	}

	date spot(date &today, CURRENCY ccy)
	{
		date spot = today;
		switch (ccy) 
		{
		case USD:
			spot = addBusinessDays(spot, 1, UK);
			spot = addBusinessDays(spot, 1, HOLIDAYCAL(USA+UK) );
			break;
		case EUR:
			spot = addBusinessDays(spot, 2, EUTARG);
			break;
		case GBP:
			break;
		case JPY:
			spot = addBusinessDays(spot, 2, HOLIDAYCAL(JP+UK));
			break;
		default:
			spot = addBusinessDays(spot, 2, NONE);
		}
		return spot;
	}

	// finds the date that makes today spot
	date fixing(date &today, CURRENCY ccy)
	{
		date fix = today;
		switch (ccy) 
		{
		case USD:
			fix = addBusinessDays(fix, -1, HOLIDAYCAL(USA+UK) );
			fix = addBusinessDays(fix, -1, UK);
			break;
		case EUR:
			fix = addBusinessDays(fix, -2, EUTARG);
			break;
		case GBP:
			break;
		case JPY:
			fix = addBusinessDays(fix, -2, HOLIDAYCAL(JP+UK));
			break;
		default:
			fix = addBusinessDays(fix, -2, NONE);
		}
		return fix;
	}

	HOLIDAYCAL liborHolidays(CURRENCY ccy)
	{
		HOLIDAYCAL hols;
		switch (ccy) 
		{
		case USD:
			hols = HOLIDAYCAL(USA+UK);
			break;
		case EUR:
			hols = EUTARG;
			break;
		case GBP:
			hols = UK;
			break;
		case JPY:
			hols = HOLIDAYCAL(JP+UK);
			break;
		default:
			hols =  NONE;
		}
		return hols;
	}

	HOLIDAYCAL Holidays(CURRENCY ccy)
	{
		HOLIDAYCAL hols;
		switch (ccy) 
		{
		case USD:
			hols = HOLIDAYCAL(USA);
			break;
		case EUR:
			hols = EUTARG;
			break;
		case GBP:
			hols = UK;
			break;
		case JPY:
			hols = HOLIDAYCAL(JP);
			break;
		default:
			hols =  NONE;
		}
		return hols;
	}

} //namespace MCPL
