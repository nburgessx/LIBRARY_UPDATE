#pragma once
#ifndef MCPLCUBICFORWARDSCURVE_H
#define MCPLCUBICFORWARDSCURVE_H

#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "discountcurve.h"
#include "PPCurves.h"
#include "Swap.h"
//#include "numrec/dnr.h"
#include "numrec3/nr3.h"
#include "numrec3/interp_1d.h"

#include "LinearCurvesHelpers.h"

using namespace std;

// Similar to LinearForwardsCurve, but it uses linear forwards, not constrained to IMM dates, 
// and not required as inputs, so we just give it some 
namespace MCPL
{

	namespace CubicForwardsCurveFitFn
	{
		double func_linear(double drop);
	}
		
	namespace CubicForwardsCurveNDimMinFn
	{
		double func_minimise(double adjustment[]);
	}

	namespace CubicForwardsCurveNDimMinFn2
	{
		double func_minimise(double adjustment[]);
	}

	class CubicForwardsCurve : public swapData
	{
	public:
		// constructors
		CubicForwardsCurve() : m_curveGood(false) {}


	void CubicForwardsCurve::create( const vector<date> swapEffDates , const vector<date> swapDates, 
			const vector<double> & swapRates, const vector<double> & swapTolerances, const SwapType sType,
		date & today, const map<date,double> & cashParams, CURRENCY ccy, double fitfactor, int testval,  Handle<RatesCurve> swapDiscountCurve = Handle<RatesCurve>());

		// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
		Handle<PPCurves> create_PPCurves(  double pp_val );

	private:

		void set_currency_defaults(CURRENCY);
		void set_currency_defaults(CURRENCY, SwapType);

		DayBasis m_basis;
		CURRENCY m_ccy;

		long int m_fixedPmtsPerYear;
		long int m_fltPmtsPerYear;
		DayBasis m_fixedBasis;

		date m_today;
		date m_spot;

		Handle<RatesCurve> 	m_swapsDiscountCurve;	// If swaps are vs 6s, can still discount them vs 3s.

		bool							m_curveGood;					// Is the curve in a good state?

		HOLIDAYCAL				m_hols;								// holiday cal for the futures
		HOLIDAYCAL				m_swapHols;						// holiday cal for the swaps

		SwapType					m_swapType;
		dateVec						m_starts;							// start of IMM period
		dateVec						m_ends;								// ends of IMM periods
		vector<double>		m_forwards;						// forward rates
		int								m_nInputFutures;			// Number of input futures
		vector<double>		m_PDCF;								// IMM period day count fraction

		double						m_fitfactor;
		vector<double>		m_parRates;						// swap par points
		//vector<double>		m_swapTenors;					// swap tenors
		vector<double>		m_swapTolerances;			// Tolerance for fit of swap rate.
		//map<date, double>	m_swapParams;					// Swap maturity - rate pairs.
		vector<date>			m_swapLastDates;			// swap last dates (last date on which swap depends on the curve)
		vector<date>			m_swapMaturityDates;	// swap maturity dates
		vector<date>			m_swapEffDates;				// The effective dates for the swaps. Allows us to use fwd swaps!
		vector<date>			m_swapDFDates;				// dates on which we set the discount factor.
		vector<Swap>			m_swapCashflows;			// the swaps we actually use, one per fixed pmt period
		long							m_lastUsedSwapIndex;  // The index of the last used swap in m_swapCashflows
		vector<Leg>				m_cashflows;					// the cashflows we actually use, one per fixed pmt period
		vector<double>		m_swapAdjustments;		// swap tenors
		vector<double>		m_linFutsPriceDrops;	// Drops between the futures prices. One for each swap par rate. This is what we solve for. 
		vector<int>				m_linFutsSwapIndex;		// Index of first fut with mat date > swap[-1]'s mat date

		vector<double>		m_segmentLengths;			// Length of each segment in curve. Need to minimise sum of this to make tension.
		double						m_curveLength;				// Total length of curve

		map<date, double>	m_cashParams;					// cash maturity - rate pairs.

		// Cubic spline stuff
		vector<double>		m_xvals;							// x values for spline. Number of days from pvdate to fixing date.
		vector<double>		m_yvals;							// y(x) values for spline. Forward rate fixing at x
		double						m_yp1;								// dydx at x=0
		double						m_ypn;								// dydx at x=nx

		int m_testval;

		void calculateCurve();
		void calculateCurveFromFutures();
		void calculateDates();
		void calcFuturesFromSwaps(int index);

		void calcFwdsFromSpline();

		bool cmpvecs( const vector<double> & v1, const vector<double> & v2);
		bool cmpvecs( const vector<date> & v1, const vector<date> & v2);
		bool cmpmaps( const map<date,double> & v1, map<date,double> & v2);

		bool fitFuturesDrops(int index);
		bool fitNDimSwapAdjs();
		void fitNDimSwapAdjs2();

		void generateSwapVectors();
		void generateSwapRateVector();

		friend double CubicForwardsCurveFitFn::func_linear(double);
		friend double CubicForwardsCurveNDimMinFn::func_minimise(double[]);
		friend double CubicForwardsCurveNDimMinFn2::func_minimise(double[]);

	};

} // namespace MCPL

#endif // MCPLCUBICFORWARDSCURVE_H