#pragma once

#ifndef MCPLBASISSWAP_H
#define MCPLBASISSWAP_H
#pragma warning ( disable : 4251 4786 ) 

#include "mcpldefs.h"
#include "mathmisc.h"
#include "option.h"
#include "Swap.h"
#include "mcDateClass/dates.h"

using namespace std;
#include<string>
#include<vector>


namespace MCPL
{
	/* the asset swap class is a child of the swap class */
	class BasisSwap : public Swap
	{	
	public :
		//constructors
		BasisSwap() {}


		//Basis swap
		BasisSwap( date & start, date & mature, double notional, double leg1Spread, double leg2Spread, 
			long int leg1PmtsPerYear, long int leg2PmtsPerYear, DayBasis leg1Basis, DayBasis leg2Basis, 
			Handle<RatesCurve> discountCurve, Handle<RatesCurve> leg1forecastCurve, Handle<RatesCurve> leg2forecastCurve, HOLIDAYCAL hol );


		//Basis swap no curves
		BasisSwap( date & start, date & mature, double notional, double leg1Spread, double leg2Spread, 
			long int leg1PmtsPerYear, long int leg2PmtsPerYear, DayBasis leg1Basis, DayBasis leg2Basis, HOLIDAYCAL hol );


		// Solve for spread. legToSolveFor has to be either 0 or 1.
		double BasisSwap::Solve(double dPresentValue, int legToSolveFor);
		virtual double Solve() { return Solve( 0.0 , p_defaultLeg ); }

		//
		virtual void fixFirst(unsigned int LegNumber, double fixedRate);

		void setDefaultLeg(int i) 
		{ 
			MCPL_REQUIRE((i>=0 && i <= 1),"Default leg must be 0 or 1"); 
			p_defaultLeg = i; 
		}

		int	getDefaultLeg() { return p_defaultLeg; }

	private:

		int p_defaultLeg;	// The default leg to apply the spread to when solving.

	};

}

#endif // MCPLBASISSWAP_H
