#pragma once
#ifndef MCPLAPOLLOCURVE_H
#define MCPLAPOLLOCURVE_H

#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "discountcurve.h"
#include "PPCurves.h"
#include "Swap.h"
#include "BasisSwap.h"

using namespace std;

namespace MCPL
{

	class ApolloCurve : public swapData
	{
	public:
		// constructors
		ApolloCurve() : 
				m_curveGood(false),
				m_useMinRateFirstStub(false)	
			{}


		//ApolloCurve(const vector<double> & futures, const vector<double> & adjustments, 
		//						const vector<double> & par_rates, const vector<double> & tenors, const SwapType sType,
		//						date & spot, date & firstFuture, discountCurve & stub, CURRENCY ccy) :
		//	m_spot(spot),
		//	m_1stFut(firstFuture),
		//	m_futures(futures),
		//	m_adjustments(adjustments),
		//	m_parRates(par_rates),
		//	m_swapTenors(tenors),
		//	m_stub_curve(stub)
		//{
		//	set_currency_defaults(ccy, sType);
		//	clear();
		//	calculateDates();
		//	calculateCurve();
		//}

		//ApolloCurve(const vector<double> & futures, const vector<double> & adjustments, 
		//						const vector<double> & par_rates, const vector<double> & tenors,
		//						date & spot, date & firstFuture, discountCurve & stub, CURRENCY ccy) :
		//	m_spot(spot),
		//	m_1stFut(firstFuture),
		//	m_futures(futures),
		//	m_adjustments(adjustments),
		//	m_parRates(par_rates),
		//	m_swapTenors(tenors),
		//	m_stub_curve(stub)
		//{
		//	set_currency_defaults(ccy);
		//	clear();
		//	calculateDates();
		//	calculateCurve();
		//}

		void create( const vector<double> & futures, const vector<double> & adjustments, 
			const map<date,double> & swaps, const SwapType sType,	date & today, date & firstFuture, 
			const map<date,double> & cash, CURRENCY ccy, bool useMinRateFirstStub);

		// Generate a spread curve off a base curve and a set of spreads.
		void createSpreadCurve( Handle<ApolloCurve> baseCurve, const map<date,double> & cashSpreads, const vector<double> & futuresSpreads,
									const map<date,double> & swapsSpreads, const DayBasis spreadBasis, 
									const DatePeriod & spreadTenor, const DatePeriod & spreadCashTenor	);

		//void setStubCurve(discountCurve & d) { m_stub_curve = d; }

		// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
		Handle<PPCurves> ApolloCurve::create_PPCurves( double pp_val );

		void addDependent(Handle<ApolloCurve> dependentCurve);

		void setCurrency( CURRENCY ccy ) 
		{ 
			m_ccy = ccy; 
			swapData::setCurrency(ccy);
		}

		CURRENCY getCurrency() 
		{
			return m_ccy;
		}

		date getToday()	{	return m_today;	}

		date getSpot()	{ return m_spot; }

	private:

		void set_currency_defaults(CURRENCY);
		void set_currency_defaults(CURRENCY, SwapType);

		DayBasis m_basis;
		CURRENCY m_ccy;

		bool		 m_useMinRateFirstStub;

		long int m_fixedPmtsPerYear;
		long int m_fltPmtsPerYear;
		DayBasis m_fixedBasis;
		DayBasis m_fltBasis;

		DayBasis m_spreadBasis;
		DatePeriod m_spreadTenor;
		DatePeriod m_spreadCashTenor; // Tenor of the cash rate to use in the spread curve stub calc.

		date m_today;
		date m_spot;

		bool m_extrapolateLastFutRate; // Are we extrapolating the last future rate to avoid using the first swap?
		date m_extraStart;
		date m_extraEnd;
		double m_extraPDCF;  // globals for extrapolation.

		date m_3mDate;
		date m_cashDate; // Maturity date of cash we are going to match when calculating stub rate.
		int		m_cashDateFuture; // Index number of last future whose start date comes before m_cashDate
		double m_t1;
		double m_t3m;
		double m_3mDCF;
		double m_cashDCF;
		double m_ffDCF;
		vector<double>	m_fut_t;
		vector<double>	m_fut_DCF;

		date m_1stFut;

		bool					m_curveGood;			// Is the curve in a good state?

		HOLIDAYCAL				m_hols;					// holiday cal for the futures
		HOLIDAYCAL				m_swapHols;				// holiday cal for the swaps

		SwapType				m_swapType;
		dateVec					m_starts;				// start of IMM period
		dateVec					m_ends;					// ends of IMM periods
		vector<double>			m_adjustments;			// convexity adjustments in bp
		vector<double>			m_futures;				// future prices
		vector<double>			m_PDCF;					// IMM period day count fraction

		long					m_firstUsedSwapIndex;	//The index in m_parRates of the first swap to be used (this first swap is priced using futs though!)
		vector<double>			m_parRates;				// swap par points
		vector<double>			m_swapTenors;			// swap tenors
		map<date, double>		m_swapParams;			// Swap maturity - rate pairs.
		//vector<date>			m_swapEndDates;			// swap end dates
		vector<date>			m_swapLastDates;		// swap last dates
		vector<date>			m_swapDFDates;			// dates on which we set the discount factor.
		//vector<Swap>			m_swaps;				// the swaps, so that we don't have to keep calcing the dates.
		vector<Swap>			m_usedSwaps;			// the swaps we actually use, one per fixed pmt period
		vector<bool>			m_useSwapInCurve;		// Is this swap to be used in the curve?

		// Stuff used in spread curve calc
		Handle<ApolloCurve>	m_baseCurve;
		vector<Handle<ApolloCurve>>	m_dependentCurves;
		Leg								m_spreadLeg;

		LinearCurve				m_TenorSpreads;
		BasisSwap					m_firstBasisSwap;	// The longest basis swap which can be solved entirely using the futures. I.e. 3y if using 12 futs.

		// vector of indeces from base flost leg and spread leg. The index of each index is the same of the index from the corresponding
		// swap in m_swapLastDates. i.e. spread pp with same end date as 4th swap is m_spreadPpIndexWithEndDateSameAsSwap[4]
		vector<unsigned int> m_spreadPpIndexWithEndDateSameAsSwap;
		vector<unsigned int> m_basePpIndexWithEndDateSameAsSwap;
		
		map<unsigned int,unsigned int> m_basePpIndexWithEndDateSameAsSpreadPp; // Map of spread pp index to base pp index
		map<unsigned int,unsigned int> m_spreadPpIndexWithEndDateSameAsBasePp; // Map of base pp index to spread pp index

		vector<long>				m_spreadPpTenorMonths;
		vector<long>				m_basePpTenorMonths;

		//discountCurve			m_stub_curve;			// discount curve from LIBOR rates to get DF to first IMM start date.
		map<date, double>		m_cashParams;			// cash maturity - rate pairs.
        vector<long>            m_SpreadTenorDCFs;

		void calculateCurve();
		void calculateDates();
		void calculateSpreadDates();
		void calculateSpreadCurve();

		bool cmpvecs( const vector<double> & v1, const vector<double> & v2);
		bool cmpmaps( const map<date,double> & v1, map<date,double> & v2);

		void generateSwapVectors();
		void generateSwapRateVector();
		void generateSpreadVectors(map<date,double> spreads);

	};

} // namespace MCPL

#endif // MCPLAPOLLOCURVE_H