#include"oneFactorGenericBlack.h"
#include "mathmisc.h"
#include<math.h>

#include <fstream>
#include "LatticeCurve.h"

//#define DEBUG

namespace MCPL
{

	
	void oneFactorGenericBlack::calcInstrinsic()
	{
		auto oldFcrv = _ULdeal->getForecastPtr();
		shared_ptr<LatticeCurve> curve(new LatticeCurve(oldFcrv, _exDates[0], [](double f) {return f; }));

		_ULdeal->setCurves(_ULdeal->getDiscountPtr(), curve);

		for (int iEx = _exDates.size() - 1; iEx >= 0; iEx--)
		{
			//vector<double> test;
			date deltaDate = _exDates[iEx];
			curve->setChangeFwdFromDate(deltaDate);
			for (int k = 0; k < _nSteps + 1; k++)
			{
				//Because we are using a factor, rather than an additive shift for the fwds, we don't need to worry about different day basis on fixed and float legs. (See OneFactorGenericNormal)
				double fwdFac = exp(_dFwd * (k - _nSteps / 2));
				curve->setFwdDeltaFn([&](double f) { return f * fwdFac; });
				_ULdeal->updatePaymentsFromCurves(_ULdeal->getDiscountPtr(), curve);
				_intrinsicValues(iEx, k) = (_priceToCancelCashflows ? -1.0 : 1.0) * _ULdeal->Price(deltaDate);
				//test.push_back(_intrinsicValues(iEx, k));
			}
		}

		_ULdeal->setCurves(_ULdeal->getDiscountPtr(), oldFcrv);
	}

	//If UL value is linear with fwd rate, then we can use this fast instrinsic value calculator.
	void oneFactorGenericBlack::calcInstrinsicFast()
	{
		auto ulSwap = dynamic_pointer_cast<Swap>(_ULdeal); // Linear only works for swaps.
		auto oldFcrv = ulSwap->getForecastPtr();
		shared_ptr<LatticeCurve> curve(new LatticeCurve(oldFcrv, _exDates[0], [](double f) {return f; }));

		ulSwap->setCurves(ulSwap->getDiscountPtr(), curve);

		auto dealNoSpread = dynamic_pointer_cast<Swap>(ulSwap->CloneDealCashflows());
		dealNoSpread->setSpread(0);

		for (int iEx = _exDates.size() - 1; iEx >= 0; iEx--)
		{
			//vector<double> test;
			//vector<double> fwds;

			date deltaDate = _exDates[iEx];
			curve->setChangeFwdFromDate(deltaDate);

			double fwdNoSpread = dealNoSpread->SolveRateNumeric(0, deltaDate);

			double ival1 = (_priceToCancelCashflows ? -1.0 : 1.0) * ulSwap->Price(deltaDate);
			double fwd1 = ulSwap->SolveRateNumeric(0, deltaDate);

			curve->setFwdDeltaFn([&](double f) { return f + _dFwd; });
			ulSwap->updatePaymentsFromCurves(ulSwap->getDiscountPtr(), curve);

			double ival2 = (_priceToCancelCashflows ? -1.0 : 1.0) * ulSwap->Price(deltaDate);
			double fwd2 = ulSwap->SolveRateNumeric(0, deltaDate);

			double numeraire = (ival2 - ival1) / (fwd2 - fwd1);

			curve->setFwdDeltaFn([](double f) { return f; });
			ulSwap->updatePaymentsFromCurves(ulSwap->getDiscountPtr(), curve);

			
			for (int k = 0; k < _nSteps + 1; k++)
			{
				_intrinsicValues(iEx, k) = ival1 + numeraire * fwdNoSpread * (exp(_dFwd * (k - _nSteps / 2)) - 1);
				//test.push_back(_intrinsicValues(iEx, k));
			}
			
		}

		ulSwap->setCurves(ulSwap->getDiscountPtr(), oldFcrv);
	}

	void oneFactorGenericBlack::calcProbabilities()
	{
		for (unsigned int ex = 0; ex < _exDates.size(); ex++)
		{
			double volatility = _fwdVols[ex];
			double tempSum = 0;
			//vector<double> test;
			for (int k = 0; k < _nSteps * 2 + 1; k++)
			{
				int i = k - _nSteps;
				double temp = (i * _dFwd + .5 * volatility) * (i * _dFwd + .5 * volatility);
				double prob = exp(-1 * temp / (2 * volatility));
				_Probabilities(ex, k) = prob;
				//test.push_back(_Probabilities(ex, k));
				tempSum += prob;
			}

			//Normalise
			for (int k = 0; k < _nSteps * 2 + 1; k++)
			{
				_Probabilities(ex, k) = _Probabilities(ex, k) / tempSum;
			}
		}
	}
}