#include"FuturesCurve.h"



namespace MCPL
{

void FuturesCurve::calculateDates()
{
	m_today = addBusinessDays(m_spot,-2, m_hols);
	m_1wk = addBusinessPeriod(m_spot , DatePeriod(7) , m_hols );
	m_1month = addBusinessMonths(m_spot , 1 , m_hols);
	m_2month = addBusinessMonths(m_spot , 2 , m_hols);

	int n_futures = m_futures.size();

	// Set up IMM start, end dates and day count fractions.
	m_starts.clear(); m_starts.resize(n_futures);
	m_ends.clear(); m_ends.resize(n_futures);
	m_PDCF.clear(); m_PDCF.resize( n_futures );
	m_gap_DCF.clear(); m_gap_DCF.resize( n_futures );
	for ( int i = 0 ; i < n_futures ; ++i ) 
  {
		m_starts[i] = nthIMMDate(m_1stFut, i+1, 3).roll(m_hols, 0, true);
		m_ends[i] = addBusinessMonths( m_starts[i] , 3 , m_hols , false );
		m_PDCF[i] = dayCountFrac(m_basis, m_starts[i] , m_ends[i] );
	}
	for ( i = 0 ; i < n_futures-1 ; ++i ) 
  {
		if ( m_starts[i+1] >= m_ends[i] )
			m_gap_DCF[i] =  dayCountFrac(m_basis, m_ends[i] , m_starts[i+1] );
		else 
			m_gap_DCF[i] =  -1.0*dayCountFrac(m_basis , m_starts[i+1], m_ends[i] );
	}
	m_1stFut = m_starts[0];
}


void FuturesCurve::calculateCurve()
{
	double next_rate, rate, PDF;
	double unadj_next_rate, unadj_rate;
	int n_futures = m_futures.size();
	double gap_DF;

	discountCurve::set(m_today , 1.0 );
	discountCurve::set(m_spot , m_stub_curve.get(m_spot) );
	if ( m_1wk < m_1stFut ) discountCurve::set(m_1wk , m_stub_curve.get(m_1wk) );
	if ( m_1month < m_1stFut ) discountCurve::set(m_1month , m_stub_curve.get(m_1month) );
	if ( m_2month < m_1stFut ) discountCurve::set(m_2month , m_stub_curve.get(m_2month) );

	discountCurve::set(m_1stFut , m_stub_curve.get(m_1stFut) ); // set first discount from LIBOR

	// Calculate DF from first IMM 

	next_rate = (100.0-m_futures[0])/100.0 - m_adjustments[0]/10000.0;
	unadj_next_rate = (100.0-m_futures[0])/100.0;

	for ( int i = 0 ; i < n_futures-1 ; ++i ) 
  {
		date start = m_starts[i];
		date end = m_ends[i];

		rate = next_rate;
		unadj_rate = unadj_next_rate;
		next_rate = (100.0-m_futures[i+1])/100.0 - m_adjustments[i+1]/10000.0;
		unadj_next_rate = (100.0-m_futures[i+1])/100.0;

//		gap_DF = 1.0/(1.0 + ((rate + next_rate)/2.0) * m_gap_DCF[i] );

		if ( m_gap_DCF[i] >= 0 ) 
			gap_DF = 1.0/(1.0 + rate * m_gap_DCF[i] );
		else
			gap_DF = 1.0/(1.0 + next_rate * m_gap_DCF[i] );

		PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
		discountCurve::set(m_starts[i+1] , get(m_starts[i]) * PDF * gap_DF );
	}

	// now do the last period.
	 // no gap for last period. And set DF to end of period, rather than beginning of next.
	i = n_futures-1;
	rate = next_rate;
	PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
	discountCurve::set(m_ends[i] , get(m_starts[i]) * PDF );
		

}

void FuturesCurve::set_currency_defaults(CURRENCY ccy)
{
	m_ccy = ccy;

	switch(m_ccy)
	{
	case USD:
		m_basis = act_360;
		m_hols = UK;
		break;
	case EUR:
		m_basis = act_360;
		m_hols = EUTARG;
		break;
	case JPY:
		m_basis = act_360;
		m_hols = JP;
		break;
	case GBP:
		m_basis = act_365f;
		m_hols = UK;
		break;
	default:
		mcpl_error("No such currency in futures curve");
	}

}

void FuturesCurve::create( const vector<double> & futures, const vector<double> & adjustments, 
						  date & spot, date & firstFut, discountCurve & stub, CURRENCY ccy)
{
	if ( (m_spot != spot) || (m_1stFut != firstFut) || futures.size() != m_futures.size() ) 
  {
		set_currency_defaults(ccy);
		m_spot = spot;
		m_1stFut = firstFut;
		m_futures = futures;
		m_adjustments = adjustments;
		m_stub_curve = stub;
		clear();
		calculateDates();
		calculateCurve();
	} 
  else 
  {
		m_futures = futures;
		m_adjustments = adjustments;
		m_stub_curve = stub;
		clear();
		calculateCurve();
	}
}


// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
Handle<PPCurves> FuturesCurve::create_PPCurves( double pp_val )
{
	Handle<PPCurves> pp_curves = Handle<PPCurves>(new PPCurves());

	pp_curves->resize(m_futures.size()+1); // one for each futures plus the stub;
	pp_curves->set_ppsize( pp_val/100.0 ); // set the perturb size in factor (i.e. 1 = 1%)

	pp_curves->base() = Handle<swapData>(new FuturesCurve(*this));

	// up
	m_stub_curve.shiftCurve(pp_val/100.0 , m_basis);
	partialClear();
	calculateCurve();
	pp_curves->up(0)= Handle<swapData>(new FuturesCurve(*this));
	m_stub_curve.shiftCurve(-pp_val/100.0 , m_basis);
	for ( unsigned int i=0 ; i < m_futures.size() ; ++i ) 
    {
		m_futures[i] -= pp_val;
		partialClear();
		calculateCurve();
		pp_curves->up(i+1)= Handle<swapData>(new FuturesCurve(*this));
		m_futures[i] += pp_val;
	}

	// dn
	m_stub_curve.shiftCurve(-1.*pp_val/100.0 , m_basis);
	partialClear();
	calculateCurve();
	pp_curves->dn(0)= Handle<swapData>(new FuturesCurve(*this));
	m_stub_curve.shiftCurve(pp_val/100.0 , m_basis);
	for ( i=0 ; i < m_futures.size() ; ++i ) 
    {
		m_futures[i] += pp_val;
		partialClear();
		calculateCurve();
		pp_curves->dn(i+1)= Handle<swapData>(new FuturesCurve(*this));
		m_futures[i] -= pp_val;
	}

	//upup
	for ( i=0 ; i < m_futures.size() ; ++i ) 
    m_futures[i] -= pp_val;
	m_stub_curve.shiftCurve(2.*pp_val/100.0 , m_basis); //up2
	partialClear();
	calculateCurve();
	pp_curves->upup(0)= Handle<swapData>(new FuturesCurve(*this));
	m_stub_curve.shiftCurve(-1.*pp_val/100.0 , m_basis); //up1
	for ( i=0 ; i < m_futures.size() ; ++i ) 
    {
		m_futures[i] -= pp_val;
		partialClear();
		calculateCurve();
		pp_curves->upup(i+1)= Handle<swapData>(new FuturesCurve(*this));
		m_futures[i] += pp_val;
	}

	// updn
	m_stub_curve.shiftCurve(-1.*pp_val/100.0 , m_basis); //up0
	partialClear();
	calculateCurve();
	pp_curves->updn(0)= Handle<swapData>(new FuturesCurve(*this));
	m_stub_curve.shiftCurve(pp_val/100.0 , m_basis); //up 1
	for ( i=0 ; i < m_futures.size() ; ++i ) 
    {
		m_futures[i] += pp_val;
		partialClear();
		calculateCurve();
		pp_curves->updn(i+1)= Handle<swapData>(new FuturesCurve(*this));
		m_futures[i] -= pp_val;
	}

	//dnup
	for ( i=0 ; i < m_futures.size() ; ++i ) 
    m_futures[i] += 2.0*pp_val;
	m_stub_curve.shiftCurve(-1.*pp_val/100.0 , m_basis); //up 0
	partialClear();
	calculateCurve();
	pp_curves->dnup(0)= Handle<swapData>(new FuturesCurve(*this));
	m_stub_curve.shiftCurve(-1.*pp_val/100.0 , m_basis); // dn 1
	for ( i=0 ; i < m_futures.size() ; ++i )
    {
		m_futures[i] -= pp_val;
		partialClear();
		calculateCurve();
		pp_curves->dnup(i+1)= Handle<swapData>(new FuturesCurve(*this));
		m_futures[i] += pp_val;
	}

	// dndn
	m_stub_curve.shiftCurve(-1.*pp_val/100.0 , m_basis); //dn 2
	partialClear();
	calculateCurve();
	pp_curves->dndn(0)= Handle<swapData>(new FuturesCurve(*this));
	m_stub_curve.shiftCurve(pp_val/100.0 , m_basis); // dn 1
	for ( i=0 ; i < m_futures.size() ; ++i ) 
    {
		m_futures[i] += pp_val;
		partialClear();
		calculateCurve();
		pp_curves->dndn(i+1)= Handle<swapData>(new FuturesCurve(*this));
		m_futures[i] -= pp_val;
	}
	for ( i=0 ; i < m_futures.size() ; ++i ) 
    m_futures[i] -= pp_val;

	m_stub_curve.shiftCurve(pp_val/100.0 , m_basis); // dn 0

	partialClear();
	calculateCurve();

	return pp_curves;
}


} // namespace MCPL