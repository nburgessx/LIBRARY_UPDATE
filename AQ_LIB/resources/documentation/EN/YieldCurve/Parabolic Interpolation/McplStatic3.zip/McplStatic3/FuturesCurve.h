#pragma once
#ifndef MCPLFUTURESCURVE_H
#define MCPLFUTURESCURVE_H

#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "discountcurve.h"
#include "PPCurves.h"

using namespace std;

namespace MCPL
{

class FuturesCurve : public swapData
{
public:
	// constructors
	FuturesCurve() : m_curveGood(false) {}

/*	FuturesCurve(date & spot, discountCurve & stub, HOLIDAYCAL hols) : 
		m_curveGood(false),
		m_spot(spot),
		m_hols(hols),
		m_stub_curve(stub)
		{}
*/
	
	FuturesCurve(vector<double> & futures, vector<double> & adjustments, date & spot, date & firstFuture, 
					discountCurve & stub, CURRENCY ccy) :
		m_spot(spot),
		m_1stFut(firstFuture),
		m_futures(futures),
		m_adjustments(adjustments),
		m_stub_curve(stub)
		{
			set_currency_defaults(ccy);
			clear();
			calculateDates();
			calculateCurve();
		}

	void create( const vector<double> & futures, const vector<double> & adjustments, date & spot, date & firstFuture, discountCurve & stub, CURRENCY hols);

	void setStubCurve(discountCurve & d) { m_stub_curve = d; }

	// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
	Handle<PPCurves> create_PPCurves( double pp_val );

private:

	void set_currency_defaults(CURRENCY);

	DayBasis m_basis;
	CURRENCY m_ccy;

	date m_today;
	date m_spot;
	date m_1wk;
	date m_1month;
	date m_2month;
	date m_1stFut;

	bool m_curveGood; // Is the curve in a good state?

	HOLIDAYCAL m_hols;  // holiday cal for the futures

	dateVec m_starts; // start of IMM period
	dateVec m_ends;   // ends of IMM periods
	vector<double> m_adjustments; // convexity adjustments in bp
	vector<double> m_futures; // future prices
	vector<double> m_PDCF;  // IMM period day count fraction
	vector<double> m_gap_DCF;

	discountCurve m_stub_curve; // discount curve from LIBOR rates to get DF to first IMM start date.

	void calculateCurve();
	void calculateDates();

};

} // namespace MCPL

#endif // MCPLFUTURESCURVE_H