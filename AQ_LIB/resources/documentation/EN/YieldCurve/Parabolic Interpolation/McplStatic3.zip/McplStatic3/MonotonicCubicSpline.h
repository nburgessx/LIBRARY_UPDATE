#ifndef _MONOTCUBICSPLINE_H
#define _MONOTCUBICSPLINE_H

#include "mcpldefs.h"
#include <vector>
#include <map>
#include <string>
#include <memory>

using namespace std;

namespace MCPL
{
	class MonotonicCubicSpline
	{

	public:

		struct MCSPoint
		{
			double x, y, dx, dy, m, c1, c2, c3;
			MCSPoint(double x_, double y_) : x(x_), y(y_) {}
		};

		MonotonicCubicSpline() : _curveGood(false) {}

		MonotonicCubicSpline(const vector<double>& xs_, const vector<double>& ys_);

		shared_ptr<vector<double>> interpolate(const vector<double>& interpPts_);

		double interpolate(double x);
		double integrate(double x1_, double x2_);
		double arcLength(double x1_, double x2_);

		void add(double x, double y);
		void erase(unsigned int index_);

		double getFirstLabel() { return _points[0].x; }
		double getLastLabel() { return _points.rbegin()->x; }

		unsigned int getFirstAffectedIndex(double x); //If a change is made at x, what is the smallest affected label.
		double getLabelAtIndex(unsigned int index);

		shared_ptr<vector<MCSPoint>> getPoints() { if (!_curveGood) calculate(); return shared_ptr<vector<MCSPoint>>(new vector<MCSPoint>(_points)); }
		
		shared_ptr<MCSPoint> getPoint(unsigned int index) { return shared_ptr<MCSPoint>(new MCSPoint(_points[index])); }

		//shared_ptr<vector<double>> getC2s() { if (!_curveGood) calculate(); return shared_ptr<vector<double>>(new vector<double>(_c2s)); }
		//shared_ptr<vector<double>> getC3s() { if (!_curveGood) calculate(); return shared_ptr<vector<double>>(new vector<double>(_c3s)); }

		size_t size() { return _points.size(); }

	private:

		vector<MCSPoint> _points;

		/*vector<double> _xs;
		vector<double> _ys;
		vector<double> _dxs;
		vector<double> _dys;
		vector<double> _ms;

		vector<double> _c1s;
		vector<double> _c2s;
		vector<double> _c3s;*/

		bool _curveGood;

		void calculate();
		void calculate(unsigned int badIndex1_);
		double integrate(unsigned int index_, double x_);
		double arcLength(unsigned int i, double x1_, double x2_);
	};

}//MCPL

#endif  //_MONOTCUBICSPLINE_H
