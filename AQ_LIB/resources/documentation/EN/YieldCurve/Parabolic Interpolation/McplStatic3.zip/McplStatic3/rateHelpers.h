#pragma once
#ifndef MCPLRATEHELPERS_H
#define MCPLRATEHELPERS_H

#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "discountcurve.h"
#include "PPCurves.h"
#include "OISSwap.h"
#include "OISFuture.h"
#include "handle.hpp"
#include "numrec/dnr.h"
#include "LinearCurvesHelpers.h"

using namespace std;

// Similar to LinearForwardsCurve, but it uses linear forwards, not constrained to IMM dates, 
// and not required as inputs, so we just give it some 
namespace MCPL
{

	class CurveRateHelper
	{
	private:
		double		_targetRate;
	public:

		
		double		RateFitTolerance;
		bool			UseInCurve;
		bool			ContainsAMeeting;
		unsigned int InputsIndex;

		typedef enum { UNDEF , FUTURE, FFFUTURE, SWAP, CASH, BUNDLE } OISRateHelperType;

		CurveRateHelper()
		{
			UseInCurve = true;
		}


		CurveRateHelper( const CurveRateHelper & that )
		{
			_targetRate = that._targetRate;
			UseInCurve = that.UseInCurve;
			InputsIndex = that.InputsIndex;
			RateFitTolerance = that.RateFitTolerance;
		}

		virtual double getTargetRate()
		{ return _targetRate; }

		virtual void setTargetRate(double value_)
		{ _targetRate = value_; }

		virtual CurveRateHelper* Clone() =0;

		virtual double getRate() const =0;

		virtual string getLabel() const =0;

		virtual void SetCurves(Handle<RatesCurve> discountCurve ,Handle<RatesCurve> forecastCurve) =0;

		virtual date getLastDate() const =0;

		virtual date getMaturityDate() const =0;

		virtual date getAdjMaturityDate() const =0;

		virtual date getStartDate() const =0;

		virtual void perturbUp(double ppVal_ = 0.0001)
		{
			setTargetRate(getTargetRate() + ppVal_);
		}

		virtual void perturbDown(double ppVal_ = 0.0001)
		{
			setTargetRate(getTargetRate() - ppVal_);
		}

		virtual bool cashflowEquals(const Handle<CurveRateHelper> &other)
		{
			return ( UseInCurve == other->UseInCurve ) 
					&& ( getType() == other->getType() 
					&& ( getStartDate() == other->getStartDate() )
					&& ( getMaturityDate() == other->getMaturityDate() )
					&& ( getAdjMaturityDate() == other->getAdjMaturityDate() )
					);
		}

		virtual Handle<Future> getFutureHandle() const { mcpl_error("Polymorphism error in CurveRateHelper"); return Handle<Future>(nullptr); }

		virtual Handle<Swap> getSwapHandle() const { mcpl_error("Polymorphism error in CurveRateHelper"); return Handle<Swap>(nullptr); }

		virtual OISRateHelperType getType() const =0;

	};


		class CashRateHelper : public CurveRateHelper
	{
	private:
		date _start;
		date _maturity;
		date _adjMaturity;
		DatePeriod _tenor;
		CURRENCY _ccy;
		DayBasis _basis;
		Handle<RatesCurve> _forecastCurve;

	public:

		CashRateHelper(date start_, DatePeriod tenor_, CURRENCY ccy_, double rate_, DayBasis basis_)
			: CurveRateHelper()
		{
			_tenor = tenor_;
			_start = start_;
			_ccy = ccy_;
			_maturity = _start + tenor_;
			_adjMaturity = _maturity;
			_adjMaturity.roll(liborHolidays(ccy_), 0, false);
			_basis = basis_;

			setTargetRate( rate_ );
		}

		CashRateHelper( const CashRateHelper & that )
			: CurveRateHelper( that )
		{
			_start = that._start;
			_tenor = that._tenor;
			_ccy = that._ccy;
			_maturity = that._maturity;
			_adjMaturity = that._adjMaturity;
			_basis = that._basis;
		}

		CurveRateHelper* Clone()
		{
			return new CashRateHelper(*this);
		}

		bool cashflowEquals(Handle<CurveRateHelper> & other)
		{
			return ( this->CurveRateHelper::cashflowEquals(other)
				  && _ccy == (dynamic_cast<CashRateHelper*>(other.get()))->_ccy );
		}

		double getRate() const
		{
			return _forecastCurve->getZero(_start, _adjMaturity);
		}

		string getLabel() const
		{
			return ("C" + _tenor.ToString() );
		}

		void SetCurves(Handle<RatesCurve> discountCurve ,Handle<RatesCurve> forecastCurve)
		{
			_forecastCurve = forecastCurve;
		}

		date getLastDate() const
		{
			return _adjMaturity;
		}

		date getMaturityDate() const
		{
			return _maturity;
		}

		date getAdjMaturityDate() const
		{
			return _adjMaturity;
		}

		date getStartDate() const
		{
			return _start;
		}

		DayBasis getBasis() const
		{
			return _basis;
		}
		
		OISRateHelperType getType() const
		{
			return CASH;
		}


	
	};

		//========================================================================================================================

		class FutureRateHelper : public CurveRateHelper
	{
			private:
		Handle<Future> _future;

	public:

		FutureRateHelper(Handle<Future> fut)
			: CurveRateHelper()
		{
			_future = fut;
		}

		FutureRateHelper( const FutureRateHelper & that )
			: CurveRateHelper( that )
		{
			_future = that._future;
		}

		CurveRateHelper* Clone() =0;

		double getRate() const
		{
			return _future->Rate();
		}

		string getLabel() const =0;

		void SetCurves(Handle<RatesCurve> discountCurve ,Handle<RatesCurve> forecastCurve)
		{
			_future->setCurves(discountCurve, forecastCurve);
		}

		date getLastDate() const
		{
			return _future->getLastDate();
		}

		date getMaturityDate() const
		{
			return _future->getLastDate();
		}

		date getAdjMaturityDate() const
		{
			return _future->getLastDate();// left same as non-adjusted
		}

		date getStartDate() const
		{
			return _future->getStartDate();
		}

		Handle<Future> getFutureHandle() const
		{
			return _future;
		}

		double getTargetRate()
		{
			return _future->getTargetRate();
		}

		void setTargetRate(double value_)
		{
			_future->setTargetRate(value_);
		}

		OISRateHelperType getType() const
		{
			return FUTURE;
		}

	};

		//========================================================================================================================

	class OISFutureCurveRateHelper : public FutureRateHelper
	{
	public:

		OISFutureCurveRateHelper(Handle<Future> fut)
			: FutureRateHelper(fut)
		{}

		OISFutureCurveRateHelper( const OISFutureCurveRateHelper & that )
			: FutureRateHelper( that )
		{}

		virtual CurveRateHelper* Clone()
		{
			return new OISFutureCurveRateHelper(*this);
		}

		virtual string getLabel() const
		{
			return ("FF_" + dateToIMMCode(getStartDate()) );
		}

		OISRateHelperType getType() const
		{
			return FFFUTURE;
		}
	};

	//========================================================================================================================

	class IMM3mFutureRateHelper : public FutureRateHelper
	{

	public:

		IMM3mFutureRateHelper(Handle<Future> fut)
			: FutureRateHelper(fut)
		{
		}

		IMM3mFutureRateHelper( const IMM3mFutureRateHelper & that )
			: FutureRateHelper( that )
		{
		}

		virtual CurveRateHelper* Clone()
		{
			return new IMM3mFutureRateHelper(*this);
		}

		virtual string getLabel() const
		{
			return (dateToIMMCode(getStartDate()) );
		}

	};

	//========================================================================================================================

	class SwapCurveRateHelper : public CurveRateHelper
	{
	public:

		SwapCurveRateHelper(Handle<Swap> swap)
			: CurveRateHelper()
		{
			p_swap = swap;
		}

		SwapCurveRateHelper( const SwapCurveRateHelper & that )
			: CurveRateHelper( that )
		{
			p_swap = that.p_swap;
		}

		virtual CurveRateHelper* Clone()
		{
			return new SwapCurveRateHelper(*this);
		}

		virtual double getRate() const
		{
			return p_swap->Solve();
		}

		virtual string getLabel() const
		{
			return ("S" + p_swap->getMaturityDate().toString() );
		}

		virtual void SetCurves(Handle<RatesCurve> discountCurve ,Handle<RatesCurve> forecastCurve)
		{
			p_swap->setCurves(discountCurve, forecastCurve);
		}

		virtual date getLastDate() const
		{
			return p_swap->getLastDate();
		}

		virtual date getMaturityDate() const
		{
			return p_swap->getMaturityDate();
		}

		virtual date getAdjMaturityDate() const
		{
			return p_swap->getAdjMaturityDate();
		}

		virtual date getStartDate() const
		{
			return p_swap->getStartDate();
		}

		virtual Handle<Swap> getSwapHandle() const
		{
			return p_swap;
		}

			double getTargetRate()
		{
			return p_swap->getCoupon();
		}

		void setTargetRate(double value_)
		{
			p_swap->setCoupon(value_);
		}

		virtual OISRateHelperType getType() const
		{
			return SWAP;
		}

	private:
		Handle<Swap> p_swap;
	};


	//========================================================================================================================

	class BundleRateHelper : public CurveRateHelper
	{
	private:

		vector<Handle<FutureRateHelper>> _futures;

	public:

		BundleRateHelper(Handle<FutureRateHelper> fut)
			: CurveRateHelper()
		{
			_futures.push_back(fut);
		}

		BundleRateHelper(vector<Handle<FutureRateHelper>> futs_)
			: CurveRateHelper()
		{
			_futures = vector<Handle<FutureRateHelper>>(futs_);
			sort(_futures.begin(), _futures.end(), [](const Handle<FutureRateHelper>& f1, const Handle<FutureRateHelper>& f2) { return f1->getStartDate() < f2->getStartDate(); });
		}

		BundleRateHelper(const BundleRateHelper & that)
			: CurveRateHelper(that)
		{
			_futures = vector<Handle<FutureRateHelper>>(that._futures);
		}

		CurveRateHelper* Clone()
		{
			return new BundleRateHelper(*this);
		}

		void Add(Handle<FutureRateHelper> f_)
		{
			auto f = find_if(_futures.begin(), _futures.end(), [&](const Handle<FutureRateHelper>& o) { return f_->cashflowEquals(o); });
			if (f == _futures.end())
			{
				_futures.push_back(f_);
				sort(_futures.begin(), _futures.end(), [](const Handle<FutureRateHelper>& f1, const Handle<FutureRateHelper>& f2) { return f1->getStartDate() < f2->getStartDate(); });
			}
			else
			{
				*f = f_;
			}
		}

		double getRate() const
		{
			//Returns an average rate
			double avg = 0;
			

			for (Handle<FutureRateHelper> f : _futures)
				avg += f->getRate();
			
			return avg / _futures.size();
		}

		string getLabel() const
		{
			return _futures.begin()->get()->getLabel() + "->" + _futures.rbegin()->get()->getLabel();
		}

		void SetCurves(Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve)
		{
			for (auto f : _futures)
			{
				f->SetCurves(discountCurve, forecastCurve);
			}
		}

		date getLastDate() const
		{
			return _futures.rbegin()->get()->getLastDate();
		}

		date getMaturityDate() const
		{
			return getLastDate();
		}

		date getAdjMaturityDate() const
		{
			return getLastDate();// left same as non-adjusted
		}

		date getStartDate() const
		{
			return _futures.begin()->get()->getStartDate();
		}

		/*Handle<Future> getFutureHandle() const
		{
			return _future;
		}*/

		void perturbUp(double ppVal_ = 0.0001)
		{
			for (auto& f : _futures)
				f->perturbUp(ppVal_);
		}

		virtual void perturbDown(double ppVal_ = 0.0001)
		{
			for (auto& f : _futures)
				f->perturbDown(ppVal_);
		}

		double getTargetRate()
		{
			//Returns an average rate
			double avg = 0;
			for (auto f : _futures)
				avg += f->getTargetRate();
			
			return avg / _futures.size();
		}

		void setTargetRate(double value_)
		{
			mcpl_error("Doesn't make sense to set a target rate for a futures bundle");
			//_future->setTargetRate(value_);
		}

		vector<Handle<FutureRateHelper>>* getFutures()
		{
			return &_futures;
		}

		bool cashflowEquals(Handle<CurveRateHelper> & other)
		{
			if (this->CurveRateHelper::cashflowEquals(other))
			{
				Handle<BundleRateHelper> obundle = dynamic_pointer_cast<BundleRateHelper> (other);

				if (_futures.size() == obundle->_futures.size())
				{
					for (unsigned int i = 0; i < _futures.size(); i++)
					{
						if (!_futures[i]->cashflowEquals(obundle->_futures[i]))
							return false;
					}
					return true;
				}
			}
			return false;
		}

		OISRateHelperType getType() const
		{
			return BUNDLE;
		}

	};


	//=============================================================================================================
	//=============================================================================================================
	//=============================================================================================================

} // Namespace

#endif // MCPLRATEHELPERS_H