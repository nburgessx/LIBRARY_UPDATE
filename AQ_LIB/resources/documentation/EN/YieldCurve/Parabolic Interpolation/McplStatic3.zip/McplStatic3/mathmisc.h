#pragma once
#ifndef MCPLMATHMISC_H
#define MCPLMATHMISC_H

#include "mcpl.h"
#include "math.h"
#include "MyErf.h"

using namespace std;

namespace MCPL
{

static double Pi = 3.14159265358979;

static double root2Pi = sqrt(2.0*Pi);

//double CND(double x);

//double erfcc(double x);
inline double erf(double x) { return (1-erfcc(x)); }

double CND2(double x);

#define N(x) CND2(x)

/*.....................................................**
** function ppnd() **
** Applied Statistics algorithm AS111, **
** Beasley and Springer **
** compute the inverse distribution function of a **
** standard normal distribution that is set to the **
** value of z satisfying P(Z<z) = p. therefore, **
** 0 < p < 1. all is well. **
**.....................................................*/
double ppnd( double p );

// Calculates the PV of a $1 annuity with a given interest rate.
//   for non-annual payments, divide rate by payments per year.
double annuity_pv( double rate, unsigned long payments);

// Solve a quadratic qun. Two solutions come out as s1 and s2
int solquad(double a, double b, double c, double* s1, double* s2);


template <typename T> int sign(T val) {
    return (val > T(0)) - (val < T(0));
}

} // namespace MCPL

#endif // MCPLMATHMISC_H