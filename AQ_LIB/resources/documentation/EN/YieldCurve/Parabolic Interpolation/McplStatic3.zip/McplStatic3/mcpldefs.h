#pragma once
#ifndef MCPL_H
#define MCPL_H
#pragma warning ( disable : 4251 4786 ) 

#include "MCPL.h"
#include "mcDateClass/dates.h"

#include<string>
#include<vector>
#include <sstream>
//#include "STLHelpers.h"

using namespace std;

namespace MCPL
{

	typedef std::string MCPL_ERROR;
	void mcpl_error(const MCPL_ERROR &);

	typedef enum{PAY=-1, RECEIVE=1} DIRECTIONTYPE;
	//typedef int date;
	DIRECTIONTYPE str2DirectionType( const char * );

	namespace ApolloEnums
	{
		typedef enum 
		{
			OVER_NIGHT,
			O_N, TOM_NEXT,                  // LCH rates
			CASH, EM_FUTURE, ED_FUTURE, ED_FUTURE_SPREAD, YBA_FUTURE, CAD_FUTURE,
			ED_FUTURE_LCH,                  // LCH rates
			FRA,
			SWAP, TURN_SPREAD, CASH_SPREAD, SWAP_SPREAD
		} RateType;

		typedef enum 
		{
			LIBOR, TIBOR, EURIBOR, HIBOR, BA, CHIBOR, SOR, MEXIBOR, NIBOR, CIBOR, STIBOR,
			OIS, FEDFUNDS, EONIA, SONIA, TONAR, CMS,
			MODIFIED, DEFAULT
		} FinancialIndex;
		const char* FinancialIndex2str(FinancialIndex index_);

		namespace CrvGenMethod
		{
			typedef enum 
			{
				OIS, BASE, SPREAD, BASE_BASIS, BASIS_SPREAD, INDEX, INDEX_BASIS_SPREAD, MODIFIED, MODIFIED_MTM
			} CurveGenMethod;
		}

		namespace McStubMethod
		{
			typedef enum 
			{
				APOLLO_STUB, FIRST_FUTURE, CASH, MIN_RATE_FIRST, DIVIDE_FUT
			} McStubMethod;
		}

		typedef enum 
		{
			FLAT, QUADRATIC, PARABOLIC, FLAT_PARA
		} McSmoothingMethod;

		namespace McCurveAlgorithmType
		{
			typedef enum 
			{
				APOLLO, LCH, LCH_REFRESH, APOLLO_NEWTON, OIS, FUND, FUND_CURVE
			} McCurveAlgorithmType;
		}

	}
	// a vanilla swap is one fixed, one float side, single principal.
	// SWAP allows amortization, and exchanges, but two sides only.
	// XCCY swap is cross currency, with exchange of principals.
	// INVERSEFLOATER is multilegged deal.
	// STRUCTURE can have an arbitrary number of legs.
	typedef enum{VANILLASWAP,SWAP,XCCYSWAP,CAPDEAL,FLOORDEAL,CMS_SWAP,CMS_CAP,CMS_FLOOR,INVERSE_FLOATER,STRUCTURE} DEALTYPE;

	typedef enum {MC_FIXED,MC_BOND,MC_PAYMENT, MC_FLOAT, MC_CAP, MC_FLOOR, MC_STRADDLE, MC_CMS} PAYTYPE;

	// Type of accrual to use in the the paymentperiods
	typedef enum { ACCRUAL_FLAT_COMPOUNDING, ACCRUAL_AVERAGE } ACCRUAL_TYPE;

	// the possible types of payment
	PAYTYPE str2PayType( const char * );

	typedef enum {solveFORCOUPON, solveFORSPREAD, solveFORVOLATILITY} SOLVETYPE;
	// the possible things to solve for.

	typedef enum {JGB,BUND,TREASURY,GILT} BONDTYPE;
	//the possible types of government bond.
	BONDTYPE str2BondType( const char *);


	typedef enum {EUROPEAN,BERMUDAN} EXERCISETYPE;
	// the kinds of exercise possible

	typedef enum {ROLL_FORWARD, ROLL_BACKWARD, ROLL_MONTHEND, ROLL_IMM1, ROLL_IMM3, ROLL_FEDFUNDS, ROLL_FORWARD_EOM, ROLL_BACKWARD_EOM} ROLLTYPE;
	// the kinds of rolls possible
	ROLLTYPE str2RollType( const char *);

	typedef enum {
		UNDEF=0, USD=1, DEM=2, GBP=3, CHF=4, JPY=5, FRF=6, ITL=7,  XEU=8,
		ESP=9, CAD=10, AUD=11, HKD=12, NZD=13, FIM=14, SEK=15, DKK=16, NKR=17,
		NLG=18, MYR=19, BEF=20, THB=21, IDR=22, ATS=23, TWD=24, EUR=25, LAST_CCY=EUR
	} CURRENCY;

	CURRENCY str2Currency(const char * strType);
	const char* currency2str( CURRENCY ccy);

	typedef enum tagSwapType
	{
		SB6 = 1, SM6, AB6, AM6, QB6, QM6, SB3, SM3, AB3, AM3, QB3, QM3 , 
		SB12, SM12, AB12, AM12, QB12, QM12, SB1, SM1, AB1, AM1, QB1, QM1, MM1, MB1
	} SwapType;
	SwapType str2SwapType( const char* strSwapType);


	template < class T >
	inline std::string stringify(T x)
	{
		std::ostringstream o;
		if (!(o << x))
			mcpl_error(" BadConversion stringify");
		return o.str();
	} 



	unsigned workingDaysPerYear(const CURRENCY ccy);

	// return the day basis for LIBOR in a given currency.
	DayBasis getLiborBasis(const CURRENCY ccy);

	double workingDayCountFrac(const date & d1,const date & d2, const CURRENCY ccy, const HOLIDAYCAL hol);

	date spot(date &today, CURRENCY ccy);
	// finds the date that makes today spot
	date fixing(date &today, CURRENCY ccy);

	// Gives the correct payments holiday calendays for a ccy.
	HOLIDAYCAL liborHolidays(CURRENCY ccy);

	//Converts a ccy to a holiday calendar
	HOLIDAYCAL Holidays(CURRENCY ccy);

	/*! \def MCPL_ASSERT
	\brief throw an error if the given condition is not verified
	\relates Error
	*/
#define MCPL_ASSERT(condition,description) \
	do { \
	if (!(condition)) \
	mcpl_error(description); \
	} while (false)


	/*! \def MCPL_REQUIRE
	\brief throw an error if the given pre-condition is not verified
	\relates Error
	*/
#define MCPL_REQUIRE(condition,description) \
	do { \
	if (!(condition)) \
	mcpl_error(description); \
	} while (false)


	/*! \def MCPL_ENSURE
	\brief throw an error if the given post-condition is not verified
	\relates Error
	*/
#define MCPL_ENSURE(condition,description) \
	do { \
	if (!(condition)) \
	mcpl_error(description); \
	} while (false)



} // Namespace MCPL

#endif
