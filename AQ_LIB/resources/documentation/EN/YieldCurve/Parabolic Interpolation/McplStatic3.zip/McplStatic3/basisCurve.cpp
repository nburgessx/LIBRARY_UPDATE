#include"basisCurve.h"

#include "numrec/dnrutil.h"


namespace MCPL
{
	bool basisCurve::instrumentsChanged(const vector<Handle<CurveRateHelper>> &Instruments)
	{
		if (Instruments.size() != _instruments.size())
			return true;

		for (unsigned int i = 0; i < _instruments.size(); i++)
		{
			//Just check that we are refering to same object
			if (_instruments[i] != Instruments[i])
				return true;
		}

		return false;
	}

	void basisCurve::set_currency_defaults(CURRENCY ccy)
	{
		m_ccy = ccy;

		switch (ccy)
		{
		case USD: case EUR: case CHF: case JPY:
			m_basis = act_360;
			break;
		case GBP:
			m_basis = act_365f;
			break;
		default:
			mcpl_error(std::string("This currency does not have a money basis defined in parabolicCurve."));
		}

	}
	
	//========================================================================================================================

	double basisCurve::getZero(const date & d1, const date & d2, DayBasis basis)
	{
		double DF1, DF2, dcf, rate;

		DF1 = getDiscountFactor(d1);
		DF2 = getDiscountFactor(d2);
		dcf = dayCountFrac(basis, d1, d2);
		rate = dcf == 0 ? 0 : zero(DF2 / DF1, dcf);
		rate += _basisSpread->get(d1);

		return rate;
	}

	// Get continuously compounded rate
	double basisCurve::getCCRate(date & d1, date & d2, DayBasis basis)
	{
		double DF1, DF2, dcf, rate;

		DF1 = getDiscountFactor(d1);
		DF2 = getDiscountFactor(d2);
		dcf = dayCountFrac(basis, d1, d2);

		rate = dcf == 0 ? 0 : (log(DF1 / DF2) / dcf);

		rate += _basisSpread->get(d1);

		return rate;
	}

	double basisCurve::forecastFixing(date & reset)
	{
		date spotdate = spot(reset, m_ccy);
		return getZero(spotdate, addBusinessMonths(spotdate, m_period_months, m_hols, false), m_basis);
	}

	//========================================================================================================================

	void basisCurve::create(const vector<Handle<CurveRateHelper>> &Instruments,
		date & today,
		CURRENCY ccy,
		Handle<RatesCurve> discountCurve_)
	{

		vector<Handle<CurveRateHelper>> sortedInsts(Instruments);
		sort(sortedInsts.begin(), sortedInsts.end(), [](Handle<CurveRateHelper>& h1, Handle<CurveRateHelper>& h2) -> bool
		{
			if (h1->getType() == h2->getType() && h1->getType() == CurveRateHelper::CASH)
				return h1->getAdjMaturityDate() < h2->getAdjMaturityDate();
			if (h1->getType() == CurveRateHelper::CASH)
				return true;
			if (h2->getType() == CurveRateHelper::CASH)
				return false;

			return h1->getAdjMaturityDate() < h2->getAdjMaturityDate();
		});

		_discountCurve = discountCurve_;

		if ((_today != today)
			|| (ccy != m_ccy)
			|| instrumentsChanged(sortedInsts))
		{

			_instruments = sortedInsts;

			set_currency_defaults(ccy);

			_today = today;
			_spot = spot(today, ccy);

			_basisSpread->clear();
			calculateDates();
			calculateCurve();
		}
		else
		{
			_instruments = sortedInsts;
			_basisSpread->clear();
			calculateCurve();
		}
	}

	void basisCurve::addDependent(Handle<RatesCurve> dependentCurve)
	{
		_dependentCurves.push_back(dependentCurve);
	}

	void basisCurve::calculateDates()
	{
		auto it = find_if(_instruments.begin(), _instruments.end(), [](Handle<CurveRateHelper>& h) { return h->getType() == CurveRateHelper::CASH && (h->getMaturityDate() - h->getStartDate() < 7); });
		_ONCash = (it != _instruments.end()) ? *it : Handle<CurveRateHelper>(nullptr);


		it = find_if(_instruments.begin(), _instruments.end(), [](Handle<CurveRateHelper>& h) { return h->getType() == CurveRateHelper::CASH && (h->getMaturityDate() - h->getStartDate() >= 7); });
		_Cash = (it != _instruments.end()) ? *it : _ONCash;

		if (!_ONCash && !_Cash)
			mcpl_error("You must supply at least one cash instrument to ParabolicCurve");

		//Find all the futures.
		_futures.clear();
		_swaps.clear();
		_firstNonCashIndex = 0;
		for (auto it = _instruments.begin(); it != _instruments.end(); it++)
		{
			if ((*it)->getType() != CurveRateHelper::CASH && (*it)->UseInCurve && _firstNonCashIndex == 0)
				_firstNonCashIndex = it - _instruments.begin();

			if (((*it)->getType() == CurveRateHelper::FUTURE) && ((*it)->UseInCurve))
			{
				_futures.push_back(*it);
			}

			if (((*it)->getType() == CurveRateHelper::SWAP) && ((*it)->UseInCurve))
			{
				_swaps.push_back(*it);
			}

			if ((*it)->getType() == CurveRateHelper::BUNDLE)
			{
				Handle<BundleRateHelper> bundle = dynamic_pointer_cast<BundleRateHelper>((*it));
				for (auto& f : *(bundle->getFutures()))
					_futures.push_back(f);
			}
		}
	}

	double basisCurve::getRateFromDF(date& effDate_, date& matDate_, DayBasis dayBasis_)
	{
		double DF1, DF2, dcf;

		DF1 = getDiscountFactor(effDate_);
		DF2 = getDiscountFactor(matDate_);
		dcf = dayCountFrac(dayBasis_, effDate_, matDate_);
		return dcf == 0 ? 0 : zero(DF2 / DF1, dcf);
	}

	//Set the basis spread at effDate s.t. the calculated forward rate from effDate -> matDate using basis = rate
	//Set the forward extrapolation of this as flat.
	void basisCurve::addFlatFwdRate(date& effDate_, date& matDate_, double rate_, DayBasis dayBasis_)
	{
		double rateFromDF = getRateFromDF(effDate_, matDate_, dayBasis_);
		_basisSpread->set(effDate_, rate_ - rateFromDF);
	}

	//Set the basis spread at effDate s.t. the calculated forward rate from effDate -> matDate using basis = rate
	//Set the forward extrapolation of this as flat.
	//Set the extrapolation (now interpolation as it is no longer the last point) of the previous basisSpread point to linear
	void basisCurve::addLinearFwdRate(date& effDate_, date& matDate_, double rate_, DayBasis dayBasis_)
	{
		addFlatFwdRate(effDate_, matDate_, rate_, dayBasis_);
		auto it = _basisSpread->getBoundingIterator(effDate_); //Greatest less or equal to effDate_
		SmoothFwdInterpolatorData &data2 = it->second;
		it--;
		SmoothFwdInterpolatorData &data1 = it->second;
		date label1 = it->first;
		data1.setB((data2.getC() - data1.getC()) / (effDate_ - label1));
		data1.setA(0);
	}

	//Set the basis spread at effDate.
	//Set the forward extrapolation of this as flat.
	//Set the extrapolation (now interpolation as it is no longer the last point) of the previous basisSpread point to linear
	void basisCurve::addLinearBasis(date& effDate_,  double basisRate_)
	{
		_basisSpread->set(effDate_, basisRate_);

		auto it = _basisSpread->getBoundingIterator(effDate_); //Greatest less or equal to effDate_
		SmoothFwdInterpolatorData &data2 = it->second;
		it--;
		SmoothFwdInterpolatorData &data1 = it->second;
		date label1 = it->first;
		data1.setB((data2.getC() - data1.getC()) / (effDate_ - label1));
		data1.setA(0);
	}

	void basisCurve::calculateCurve()
	{
		_basisSpread->clear();
		addFlatFwdRate(_today, _ONCash->getMaturityDate(), _ONCash->getTargetRate(), dynamic_pointer_cast<CashRateHelper>(_ONCash)->getBasis());
		addFlatFwdRate(_Cash->getStartDate(), _Cash->getMaturityDate(), _Cash->getTargetRate(), dynamic_pointer_cast<CashRateHelper>(_Cash)->getBasis());

		//Fit the futures
		date nextFitDate;
		for (auto &fut : _futures)
		{
			double xguess = fut->getTargetRate() - getRateFromDF(fut->getStartDate(), fut->getAdjMaturityDate(), m_basis); //Best guess for basis
			double x1 = xguess - 0.005;// minus 50bp
			double x2 = xguess + 0.005;// plus 50bp
			addLinearFwdRate(fut->getStartDate(), fut->getAdjMaturityDate(), fut->getTargetRate(), m_basis);
			nextFitDate = fut->getAdjMaturityDate();
			//double funcmin = quadraticFitter([&](double x) { return futuresFitter(x, fut); }, x1, x2, max(1e-7 /*1/1000th of bp*/, fut->RateFitTolerance), maxiterations);
		}


		//Fit the Swaps
		int maxiterations = 5;
		for (auto &swap : _swaps)
		{
			if ((long)swap->getLastDate() > _basisSpread->lastLabel())
			{
				double xguess = getZero(nextFitDate, nextFitDate + 1); //Best guess for basis
				double x1 = xguess - 0.005;// minus 50bp
				double x2 = xguess + 0.005;// plus 50bp
				//addLinearFwdRate(swap->getStartDate(), fut->getAdjMaturityDate(), fut->getRate(), m_basis);
				double funcmin = quadraticFitter([&](double x) { return swapsFitter(x, nextFitDate, swap); }, x1, x2, max(1e-7 /*1/1000th of bp*/, swap->RateFitTolerance), maxiterations);
				if (fabs(funcmin) < 1e10)
					addLinearBasis(nextFitDate, funcmin);
				else
				{
					_basisSpread->erase(nextFitDate);
					_basisSpread->getBoundingIterator(nextFitDate)->second.setB(0); // Back to linear.
				}
				nextFitDate = swap->getMaturityDate();
			}
		}
	}

	double basisCurve::swapsFitter(double basisRate_, date& testDt, Handle<CurveRateHelper> swap)
	{
		addLinearBasis(testDt, basisRate_);
		swap->SetCurves(_discountCurve, Handle<basisCurve>(this, null_deleter()));

		double swapRate = swap->getRate();
		double targetRate = swap->getTargetRate();

		return  (swapRate - targetRate);
	}

} // namespace MCPL