#include"OISFuture.h"

namespace MCPL
{


	OISFuture::OISFuture(MCPL::Month month, int year,  CURRENCY ccy )
		: Future(month, year, ccy)
	{
		date start = date(year, month, 1);
		date end = date(year, month, start.daysInMonth());

		HOLIDAYCAL hols = Holidays(ccy);

		f_Leg = OISLeg( MCPL::PAY , start, end, 1.0e6, 0, 1, ROLL_FEDFUNDS, 1, act_360, hols, ccy, 0, MCPL::ACCRUAL_AVERAGE);
		_dcf = dayCountFrac(act_360, start, end);
	}



	//*************************************************************************************************

 
	void OISFuture::setCurves (Handle<RatesCurve> discountCurve , Handle<RatesCurve> forecastCurve)
	{
		f_Leg.setCurves(discountCurve, forecastCurve);
		f_Leg.updatePaymentsFromCurves();
	}

	//*************************************************************************************************


	double OISFuture::Rate()
	{
		return f_Leg.averageRate();
	}

} //end namespace MCPL