#pragma once
#ifndef MCPLSTORAGECLASSES_H
#define MCPLSTORAGECLASSES_H
#include "MCPL.h"

#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <stdlib.h>
#include "mcDateClass/dates.h"
#include <iostream>
#include "math.h"
#include "mcpldefs.h"
#include "interpolators.h"
#include <functional>
#include "STLExtensions.h"

using namespace std;

namespace MCPL
{


	template< typename T_Label, typename T_data>
	class genericDataStore
	{
	public:
		// Copy Constructor.

		void set (T_Label pszLabel, T_data dVal)
		{
			m_marketDataMap[pszLabel] = dVal;
		}


		T_data get (const T_Label pszLabel)
		{
			MARKET_DATA_MAP::iterator it;

			it = m_marketDataMap.find(pszLabel);
			if (it != m_marketDataMap.end())
			{
				return (*it).second;
			}
			else
			{
				MCPL_ERROR err("Error. No such variable: ");
				err += pszLabel;
				throw err;
			}

			return T_data(0);
		}


	private:

		typedef std::map<T_Label, T_data> MARKET_DATA_MAP;
		MARKET_DATA_MAP		m_marketDataMap;

	};



	/********************************************************************************************************

	Maps a T_Label to a double. Upon retrieval, if T_Label doesn't exist, use T_interpolator to interpolate.

	This makes the storage class very flexible, so that it can be used for i.e. DF, Zero curves with a
	log-lin interpolator, and also for i.e. vols with a different interp

	*********************************************************************************************************/
	template <typename T_Label, typename T_Data, typename T_interpolator>
	class interpolatingStore
	{


	public:
		typedef std::map<T_Label, T_Data> STORE;
		typedef std::vector<std::pair<T_Label, T_Data>> PAIR;

		//default constructor.
		interpolatingStore() : m_secondaryData(false), m_isFlatVol(false), _boundingFunc([&](STORE &map, T_Label const & key){return map.lower_bound(key); })
		{}

		interpolatingStore(PAIR data_)
			:  m_secondaryData(false), m_isFlatVol(false) 
		{
			for ( PAIR::iterator it = data_.begin(); it != data_.end() ; it++ )
			{
				set(it->first, it->second);
			}
		}

		void setFlatVol (T_Data dVal)
		{
			m_isFlatVol = true;
			m_flatVol = dVal;
		}

		void erase(T_Label key)
		{
			//clear the cache after adding any new data
			if (m_secondaryData) clear_cache();
			STORE::iterator it = m_interpolatingStore.find(key);
			if (it != m_interpolatingStore.end())
				m_interpolatingStore.erase(it);
		}

		void set (const T_Label & dLabel, const T_Data dVal)
		{

			// we are no longer a flat vol
			m_isFlatVol = false;

			//clear the cache after adding any new data
			if ( m_secondaryData ) clear_cache();

			// If the label already exists, delete it before adding a new one.
			STORE::iterator it = m_interpolatingStore.find(dLabel);
			if ( it != m_interpolatingStore.end() )
				m_interpolatingStore.erase( it );


			m_interpolatingStore[dLabel] = dVal;
		}

		void setAtIndex(const unsigned int index, const T_Data dVal)
		{
			// we are no longer a flat vol
			m_isFlatVol = false;

			//clear the cache after adding any new data
			if ( m_secondaryData ) clear_cache();

			STORE::iterator it = m_interpolatingStore.begin();
			for ( unsigned int i=0 ; i < index ; i++ )
				it++;

			it->second = dVal;
		}

		std::pair<T_Label, T_Data> getAtIndex(const unsigned int index)
		{
			STORE::iterator it = m_interpolatingStore.begin();
			std::advance( it, index );
			std::pair<T_Label, T_Data> pair(it->first, it->second);
			return pair;
		}

		void setBoundingFunc(std::function<typename STORE::iterator(STORE&, T_Label const&)> boundingFunc_)
		{
			_boundingFunc = boundingFunc_;
		}

		typename STORE::iterator getBoundingIterator(const T_Label & dLabel)
		{
			return _boundingFunc( m_interpolatingStore, dLabel);
		}

		int getLowerBoundIndex(const T_Label & dLabel)
		{
			return getBoundingIterator(dLabel) - m_interpolatingStore.begin();
		}

		virtual double get (const T_Label & dLabel) 
		{
			// if we are a flat vol, just return the value
			if ( m_isFlatVol ) return m_flatVol;

			STORE::iterator it;

			// first check the cache
			it = m_secondaryStore.find(dLabel);
			if (it != m_secondaryStore.end())	
				return (*it).second;

			it = m_interpolatingStore.find(dLabel);
			if (it != m_interpolatingStore.end())
			{
				return (*it).second;
			}
			else  
			{
				// This defaults to the first element in a map with a key value that is equal to or greater than that of a specified key
				// but can be overridden by setting a new boundingFunc.
				it = getBoundingIterator(dLabel);

				if ( (it != m_interpolatingStore.end()) && (it != m_interpolatingStore.begin()) )
				{	
					T_interpolator interpolator;
					T_Data res = interpolator.interpolate(dLabel, it);
					//set_cache(dLabel, res); // Store result in cache.
					return res;
				}
				else
				{
					MCPL_ERROR err("Error. This label is out of the range of available data. Interpolation failed 1: ");
					err += (string) date(dLabel);			
					throw err;
				}
			}

			mcpl_error("interpolating store got to code which should not be executing");
			return 0;
		}

		virtual void clear() 
		{ 
			m_interpolatingStore.clear();
			clear_cache();
			setFlatVol(0);
		}

		//Doesn't clear as much as clear() in derived classes. Useful for e.g. making PP curves.
		virtual void partialClear() 
		{ 
			clear_cache();
			setFlatVol(0);
		}

		STORE & getStore() { return m_interpolatingStore; }

		virtual int size() const { return m_isFlatVol ? 1 : m_interpolatingStore.size(); }

		virtual T_Label firstLabel() 
		{ 
			if ( size() == 0 || m_isFlatVol ) 
				mcpl_error("No labels in interpolating store");

			return m_interpolatingStore.begin()->first;
		}

		virtual T_Label lastLabel() 
		{ 
			if ( size() == 0 || m_isFlatVol ) 
				mcpl_error("No labels in interpolating store");

			return m_interpolatingStore.rbegin()->first;
		}

		typedef shared_ptr<vector<T_Label>> labels;
		virtual labels getLabels() const
		{
			labels output = labels(new vector<T_Label>());

			getLabels(output);

			return output;
		}

		virtual void getLabels(labels & output) const
		{
			STORE::const_iterator it;
			output->clear();

			for ( it = m_interpolatingStore.begin() ; it != m_interpolatingStore.end() ; ++it )
				output->push_back(it->first);

		}


		typedef shared_ptr<vector<T_Data>> data;
		data getData(data & output) const
		{
			//STORE::iterator it;

			for ( auto it = m_interpolatingStore.begin() ; it != m_interpolatingStore.end() ; ++it )
				output->push_back(it->second);

			return output;
		}

		data getData() const
		{
			data output = data(new vector<T_Data>());

			getData(output);

			return output;
		}

		void clear_cache()
		{
			m_secondaryStore.clear();
			m_secondaryData = false;
		}


	protected:
		STORE		m_interpolatingStore;

		bool		m_secondaryData; // true when there is data in the cache.
		STORE		m_secondaryStore; // This is where previous results are cached. It is cleared on new data.

		bool		m_isFlatVol;	// Do we have a plain flat vol?
		double		m_flatVol;		// flat vol value

		std::function<typename STORE::iterator(STORE&, T_Label const&)> _boundingFunc;

		void set_cache (const T_Label & dLabel, const T_Data dVal)
		{
			// If the label already exists, delete it before adding a new one.
			STORE::iterator it = m_secondaryStore.find(dLabel);
			if ( it != m_secondaryStore.end() )
				m_secondaryStore.erase( it );


			m_secondaryStore[dLabel] = dVal;
			m_secondaryData = true;
		}



	};

	template <typename T_Label, typename T_Data, typename T_interpolator>
	class preInterpolatingStore : public interpolatingStore<T_Label, T_Data, T_interpolator>
	{
	public:

		preInterpolatingStore() 
			: interpolatingStore()
		{
			setBoundingFunc([](STORE &map, T_Label const & key){return greatest_lessOrEqual(map, key); });
		}
	};

	typedef genericDataStore<string , double> marketDataStore;


	/********************************************************************************************************

	Maps a T_Label1, T_Label2 pair to a T_Double. Upon retrieval, if T_Label1, TLabel2 doesn't exist, 
	use T_interpolator1 to interpolate over T_Label1, and then T_interpolator2 to interp over T_Label2.
	Interpolates first along T_Label1

	*********************************************************************************************************/

	template <typename T_Label1, typename T_Label2, typename T_Data, 
		typename T_interpolator1, typename T_interpolator2>
	class interpolatingStore2D
	{
	private:

		typedef interpolatingStore<T_Label2, T_Data, T_interpolator2> STORE2;
		typedef std::map<T_Label1 , STORE2>	STORE1; 
		STORE1		m_Store2D;

	public:

		void set (const T_Label1 & dLabel1, const T_Label2 & dLabel2, const T_Data & dVal)
		{
			//Do we already have a 1D store for this label1?
			STORE1::iterator it1;

			it1 = m_Store2D.find(dLabel1);

			//If not, create one, and point the iterator to it.
			if ( it1 == m_Store2D.end() ) {
				STORE2 tmp;
				m_Store2D[dLabel1] = tmp;
				it1 = m_Store2D.find(dLabel1);
			}

			// This should never happen, right?
			if ( it1 == m_Store2D.end() ) {
				MCPL_ERROR err("Error in 2D interp! Don't know where!\n");
				throw err;
			}					

			//Finally set the data!
			(it1->second).set(dLabel2 , dVal);
		}


		T_Data get ( const T_Label1 & dLabel1, const T_Label2 & dLabel2) 
		{
			STORE1::iterator it;

			it = m_Store2D.find(dLabel1);
			if (it != m_Store2D.end())
			{
				return (it->second).get(dLabel2);
			}
			else  
			{
				it = m_Store2D.lower_bound( dLabel1 ); // earliest element in map for which the key < dLabel

				if ( (it != m_Store2D.end()) && (it != m_Store2D.begin()) )
				{	
					T_Data res;
					T_interpolator1 interpolator;

					T_Data  y1, y2;

					T_Label1 x1, x2;

					x1 = it->first;
					y1 = (it->second).get(dLabel2);

					--it;

					x2 = it->first;
					y2 = (it->second).get(dLabel2);

					res = interpolator.interpolate_basic(x1,y1,x2,y2, dLabel1);

					return res;
				}
				else
				{

					MCPL_ERROR err("Error in 2D. This label is out of the range of available data. Interpolation failed 2: ");			
					err +=  string(date(dLabel1));			
					throw err;
				}
			}

			return 0;
		}

		// return a pair with the size of the 2d curve
		// first is the number of expiries.
		// second is the number of tenors.
		void size(pair<unsigned, unsigned> & x) const
		{
			x.first = m_Store2D.size();
			x.second = m_Store2D.begin()->second.size();
		}

		// get the labels of the two axes.
		void getLabels(vector<T_Label1> & labels1, vector<T_Label2> & labels2) const
		{
			STORE1::const_iterator it;
			labels1.clear();

			for ( it = m_Store2D.begin() ; it != m_Store2D.end() ; ++it )
				labels1.push_back(it->first);

			m_Store2D.begin()->second.getLabels( labels2 );
		}

		void clear() { 
			if ( ! m_Store2D.empty() ) 
				m_Store2D.clear( m_Store2D.begin() , m_Store2D.end() ); 
		}

	};



} // namespace MCPL

#endif // MCPLSTOREGECLASSES_H

