#pragma once
#ifndef MCPLOPTION_H
#define MCPLOPTION_H
#include "MCPL.h"

#include "mcpldefs.h"
#include "storageclasses.h"

using namespace std;

namespace MCPL
{


unsigned wdPerYear( CURRENCY c );

/*
****************************************
* Additional Option Definition classes.
****************************************
*/
typedef enum tagOptionType
{
	Put = 1,
	Call,
	Straddle,
	typeNone
}OptionType;

OptionType str2OptionType( const char* strType);

typedef enum tagOptionModel
{
	BlackLogNormal = 1,
	BlackNormal,
	BlackMixed,
	QModel,
	SABR,
	SABRNormal,
	SABRLogNormal,
	AFSABR,
	ModelNone
}OptionModel;

OptionModel str2OptionModel( const char* strType);


typedef enum tagExerciseType
{
	American = 1,
	Bermudan,
	European

}ExerciseType;


/*
**********************************************************
* Generalised option based on a set of templated inputs.
**********************************************************
*/

template<typename T_Underlying, ExerciseType exType, OptionType type, typename T_ContractData>
class Option
{

public:
			
	Option()
	{
		m_type				= type;
		m_exerciseType		= exType;
	}

	typedef OptionType				TYPE;
	typedef T_Underlying			UNDERLYING;
	typedef UNDERLYING*				LPUNDERLYING;
	typedef ExerciseType			EXERCISE_TYPE;
	typedef T_ContractData			CONTRACT_DATA;
			
	double getBSStrike(date);
	double getBSUnderlying(date);
		
	void 
	setUnderlying( T_Underlying & underlying)
	{
		m_underlying = underlying;
	}


	T_Underlying*
	getUnderlying(void)
	{
		return &m_underlying;
	}

	
	double
	getVariable(char* pszLabel)
	{
		return m_contractData.getVariable(pszLabel);
	}


	void
	setVariable(char* pszLabel, double val)
	{
		m_contractData.setVariable(pszLabel, newVal);
	}



	void
	setContractData( T_ContractData & contractData)
	{
		m_contractData = contractData;
	}


	OptionType
	getType(void) 
	{
		return m_type;
	}


	CONTRACT_DATA		m_contractData;

protected:

	TYPE				m_type;
	EXERCISE_TYPE		m_exerciseType;
	UNDERLYING			m_underlying;

};

//**********************************************************************************************
// European options need to store a single expiry date as well as the doubles in the market data.

class EuropeanOptionContractData : public marketDataStore
{

private:

	date	exerciseDate;


public:

	void setExerciseDate(date exDate) { exerciseDate = exDate; }

	date getExerciseDate() { return exerciseDate; }

};


// Templated european option, with access methods for the expiry date in the EuropeanOptionContractData

template <typename T_Underlying, OptionType optionType>
class EuropeanOption : public Option<T_Underlying, European, optionType, EuropeanOptionContractData>
{

public:

	void setExerciseDate(date exDate) { m_contractData.setExerciseDate( exDate ); }

	date getExerciseDate() { return m_contractData.getExerciseDate(); }

};

/*
*************************************************************
* Template specialisation of generic option type. 
* Allows model implementations to switch on an option type
*************************************************************
*/

// Some useful option related functions.
bool inTheMoney(double strike, double forward, OptionType type);
double intrinsicValue(double strike, double forward, OptionType type);
double timeValue(double price, double strike, double forward, double df, OptionType type);



} // namespace MCPL

#endif // MCPLOPTION_H