#pragma once
#ifndef MCPLLEG_H
#define MCPLLEG_H

#include "MCPL.h"

#include<string>
#include<vector>
#include <iostream>

#include "swapData.h"
#include "payment.h"

#include <algorithm>

using namespace std;

namespace MCPL
{


class Leg
{
protected:
	CURRENCY m_currency;
	HOLIDAYCAL m_hols;

	typedef vector<Handle<PaymentPeriod>> vPaymentPeriod;
	vPaymentPeriod v_paymentPeriod;

	typedef vPaymentPeriod::iterator pp_iterator;

	// A dirty bit.
	//  When the dates are dirty, we should regenerate the whole thing
	//  if the curves are dirty, we can simply regenerate the DFs.

	bool m_dirtyDates;
	bool m_dirtyCurves;

	// Private data members which define the leg and allow for payment regeneration.
	DIRECTIONTYPE m_paymentDirection;
	PAYTYPE m_payType;

	DayBasis m_basis;
	int m_paymentMonths; // Number of months in payment period
	int m_floatMonths; // Number of months in float reference index (i.e. 6 = 6month libor)

	unsigned int m_pmtsPerYear;

	double m_CMStenor;
	SwapType m_CMStype;

	date m_lastDate; // this is the earliest date which has to be defined in the curve for the swap to be priced.

	 Handle<RatesCurve> p_DiscountCurve;
	 Handle<RatesCurve> p_ForecastCurve;
	shared_ptr<VolatilityGrid> p_CMSvols;
	shared_ptr<VolatilityGrid> m_pCapVols;
//	CapVolCurve * m_pCapNormalVols;

    bool m_IsFRA;

	void sortPayments();

	void GenerateLeg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, const date & first, 
		const date & mature, const date & roll, ROLLTYPE rolltype, bool longcoupon, double notional, 
		double coupon, double couponStep, long int pmtPerYear, long int floatMonths, DayBasis basis, 
		HOLIDAYCAL hol, OptionModel model, mixing_model &mixing, CURRENCY ccy , date & today, int payDateOffsetDays_, bool IsOIS = false );
	
	void GenerateIMMLeg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, const date & first, 
		const date & mature, bool longcoupon, ROLLTYPE rolltype, double notional, double coupon, double couponStep, 
		long int pmtPerYear, long int floatMonths, DayBasis basis, HOLIDAYCAL hol, 
		OptionModel model, mixing_model & mixing, CURRENCY ccy , date & today , int payDateOffsetDays_, bool IsOIS = false);

	void GenerateGeneralLeg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, const date & first, 
		const date & mature, const date & roll, ROLLTYPE rolltype, bool longcoupon, double notional, 
		double coupon, double couponStep, long int pmtPerYear, long int floatMonths, DayBasis basis, 
		HOLIDAYCAL hol, OptionModel model, mixing_model & mixing, CURRENCY ccy , date & today, int payDateOffsetDays_, bool IsOIS = false);


public:


	//constructors
	//The default constructor sets up an empty leg
	Leg (DIRECTIONTYPE d=PAY, DayBasis b=act_365f) : 
//		m_iNumberOfPaymentPeriods(0), 
		m_paymentDirection(d), 
		p_CMSvols(NULL) ,
		m_pCapVols(NULL) ,
		m_pmtsPerYear(0) ,
//		m_pCapNormalVols(NULL),
		m_basis(b),
        m_IsFRA(false)
		{}

	// Intelligent leg constructor!! (Optional Roll type)
	Leg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, const date & mature,
			double notional, double coupon, long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, 
			ROLLTYPE rolltype = ROLL_BACKWARD, CURRENCY ccy = UNDEF,
			OptionModel model = ModelNone, mixing_model &mixing = mixing_model(), date & today = date(0), bool IsFRA = false, int payDateOffsetDays_ = 0);

			// Intelligent leg constructor with roll date
	Leg (DIRECTIONTYPE dir, PAYTYPE type, date & start, date & mature, date & roll,
			double notional, double coupon, long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, CURRENCY ccy = UNDEF,
			OptionModel model = ModelNone, mixing_model &mixing = mixing_model(), date & today = date(0), bool IsFRA = false, 
            int payDateOffsetDays_ = 0, bool IsOIS = false);


	// For legs where 12 / pmt per year != float index tenor (i.e. CMS)
	Leg (DIRECTIONTYPE dir, PAYTYPE type, date & start, date & target,	double notional, double coupon, 
		long int pmtPerYear, long int floatMonths, SwapType CMStype, DayBasis basis, HOLIDAYCAL hol, ROLLTYPE rolltype, CURRENCY ccy,
		OptionModel model = ModelNone, mixing_model &mixing = mixing_model(), date & today = date(0), bool IsFRA = false, int payDateOffsetDays_ = 0);


	// for SPS
	Leg (DIRECTIONTYPE dir, PAYTYPE type, date & start, date & target,
			double notional, double coupon, DayBasis basis, long int floatMonths, HOLIDAYCAL hol, CURRENCY ccy = UNDEF,
			OptionModel model = ModelNone, mixing_model &mixing = mixing_model(), date & today = date(0), bool IsFRA = false, int payDateOffsetDays_ = 0);

	Leg (DIRECTIONTYPE dir, PAYTYPE type, 
			const date & start, const date & first, const date & mature, const date & roll, ROLLTYPE rolltype,
			bool longcoupon, double notional, double coupon, long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, 
			CURRENCY ccy = UNDEF, OptionModel model = ModelNone, mixing_model &mixing = mixing_model(), date & today = date(0), bool IsFRA = false, int payDateOffsetDays_ = 0);

	// as above, but also has a coupon (spread) step
	Leg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, const date & first, const date & target, const date & roll, 
		  ROLLTYPE rolltype, bool longCoupon, double notional, double coupon, double couponStep, 
		  long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, CURRENCY ccy = UNDEF, OptionModel model = ModelNone,
		  mixing_model &mixing = mixing_model(), date & today = date(0), bool IsFRA = false, int payDateOffsetDays_ = 0);

  // as above, but also has notional and coupon (spread) vectors
  Leg::Leg (DIRECTIONTYPE dir, PAYTYPE type, const date & start, const date & first, 
    const date & target, const date & roll, ROLLTYPE rolltype, bool longCoupon,
    const vector<double> & vNotional, const vector<double> & vcoupon, long int pmtPerYear, 
    DayBasis basis, HOLIDAYCAL hol, CURRENCY ccy = UNDEF, OptionModel model = ModelNone, 
    mixing_model &mixing = mixing_model(), date & today = date(0), bool IsFRA = false, int payDateOffsetDays_ = 0);

  // Clone function which creates a deep clone of cashflows
  virtual shared_ptr<Leg> CloneCashflows();

	pp_iterator getBeginPP() { return v_paymentPeriod.begin(); }

	DayBasis getBasis() const { return m_basis; }
	void setBasis( DayBasis b ) { m_basis = b; }

	virtual double Price() ; // this function aggregates the values for the payment periods.
	double Price( double coupon ) ; // this function aggregates the values for the payment periods.
	double Price(date); // Prices the leg to a value date
	double Price(date firstDate, date lastDate); //Only price the leg using pp which fall entirely between the first nad last dates
	double Vega() ; // this function aggregates the vegas for the payment periods.
	
	double BasisPointValue() ;
	double notionalBasisPointValue() ; // Multiplies each period bpv by that period's notional.

	bool isFixed()  { return (v_paymentPeriod[0]->getType() == MC_FIXED); }
	double getCoupon(unsigned int i=0)  { return v_paymentPeriod[i]->getCoupon(); }
	shared_ptr<vector<double>> getCoupons() const;
	double getNotional(unsigned int i=0)  { return v_paymentPeriod.size() > 0 ? v_paymentPeriod[i]->getNotional() : 0; }
	double getSpread(unsigned int i=0)  { return v_paymentPeriod.size() > 0 ? v_paymentPeriod[i]->getSpread() : 0; }
	long getNumberOfPayments()  { return v_paymentPeriod.size(); }
	unsigned int getPaymentsPerYear() const { return m_pmtsPerYear; }
	PAYTYPE getType(unsigned int i=0)  { return v_paymentPeriod[i]->getType(); }
	Handle<PaymentPeriod> getPayment( date &); // Returns the payment period which contains date

	void setSpread( double);
	void setSpread( unsigned int i, double s) { v_paymentPeriod[i]->setSpread(s); }
	void setSpread(const vector<double> & coupon);

	void setNotional( double);
	void setNotional( unsigned int i, double n) { v_paymentPeriod[i]->setNotional(n); }
	void setNotional( const vector<double> & vNotional);

	void setCoupon( double);
	void setCoupon( unsigned int i, double c) { v_paymentPeriod[i]->setCoupon(c); }
	void setCoupon(const vector<double> & coupon);

	void addPayment( Handle<PaymentPeriod> pp);


	void updatePaymentsFromCurves();
	void updatePaymentsFromCurves(Handle<RatesCurve> DiscountCurve, Handle<RatesCurve> ForecastCurve, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr),
		shared_ptr<VolatilityGrid> pCVols = shared_ptr<VolatilityGrid>(nullptr) )
	{
		setCurves(DiscountCurve, ForecastCurve, pCMSvols, pCVols);
		updatePaymentsFromCurves();
	}


	void setCurves(Handle<RatesCurve> DiscountCurve, Handle<RatesCurve> ForecastCurve, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr),
		shared_ptr<VolatilityGrid> pCVols = shared_ptr<VolatilityGrid>(nullptr))
	{
		p_DiscountCurve =  DiscountCurve;
		p_ForecastCurve =  ForecastCurve;
		if ( pCMSvols ) p_CMSvols = pCMSvols;
		if ( pCVols ) m_pCapVols = pCVols;
	}

	shared_ptr<VolatilityGrid> getCMSVols() { return p_CMSvols; }
	shared_ptr<VolatilityGrid> getCapVols() { return m_pCapVols; }

	date getStartDate(unsigned int i=0) { return v_paymentPeriod[i]->getAdjustedStart(); }
	date getLastDate() { return m_lastDate; };

	void printRates();
	void printDates();

	dateVec & getStartDates( dateVec &);
	dateVec & getAdjStartDates( dateVec &);
	dateVec & getEndDates( dateVec &);
	dateVec & getAdjEndDates( dateVec &);
	dateVec & getPaymentDates( dateVec &);

	vector<double> & getNotionals( vector<double>  & vec );
	vector<double> & getSpreads( vector<double>  & vec );
	vector<double> & getDCFs( vector<double>  & vec );
	vector<double> & getDiscountFactors( vector<double>  & dVec );
	vector<double> & getPayments( vector<double>  & vec );
	vector<double> & getPVs( vector<double>  & vec );
	vector<double> & getRates( vector<double>  & vec );
	vector<double> & getVegas( vector<double>  & vec );
	vector<BlackVol> & getVols(vector<BlackVol>  & vec);

	shared_ptr<vector<date>> getStartDates() { auto v = shared_ptr<vector<date>>(new vector<date>); getStartDates(*v); return v; }
	shared_ptr<vector<date>> getAdjStartDates() { auto v = shared_ptr<vector<date>>(new vector<date>); getAdjStartDates(*v); return v; }
	shared_ptr<vector<date>> getEndDates() { auto v = shared_ptr<vector<date>>(new vector<date>); getEndDates(*v); return v; }
	shared_ptr<vector<date>> getAdjEndDates() { auto v = shared_ptr<vector<date>>(new vector<date>); getAdjEndDates(*v); return v; }
	shared_ptr<vector<date>> getPaymentDates() { auto v = shared_ptr<vector<date>>(new vector<date>); getPaymentDates(*v); return v; }

	shared_ptr<vector<double>> getNotionals() { auto v = shared_ptr<vector<double>>(new vector<double>); getNotionals(*v); return v; }
	shared_ptr<vector<double>> getSpreads() { auto v = shared_ptr<vector<double>>(new vector<double>); getSpreads(*v); return v; }
	shared_ptr<vector<double>> getDCFs() { auto v = shared_ptr<vector<double>>(new vector<double>); getDCFs(*v); return v; }
	shared_ptr<vector<double>> getDiscountFactors() { auto v = shared_ptr<vector<double>>(new vector<double>); getDiscountFactors(*v); return v; }
	shared_ptr<vector<double>> getPayments() { auto v = shared_ptr<vector<double>>(new vector<double>); getPayments(*v); return v; }
	shared_ptr<vector<double>> getPVs() { auto v = shared_ptr<vector<double>>(new vector<double>); getPVs(*v); return v; }
	shared_ptr<vector<double>> getRates() { auto v = shared_ptr<vector<double>>(new vector<double>); getRates(*v); return v; }
	shared_ptr<vector<double>> getVegas() { auto v = shared_ptr<vector<double>>(new vector<double>); getVegas(*v); return v; }
	shared_ptr<vector<BlackVol>> getVols() { auto v = shared_ptr<vector<BlackVol>>(new vector<BlackVol>); getVols(*v); return v; }

	vPaymentPeriod* getCashflow() { return &v_paymentPeriod; }

	vector<PaymentPeriod> & getAllPeriods( vector<PaymentPeriod> & ppVec );

	pp_iterator  firstFixablePeriod();
	pp_iterator  prevFixablePeriod();

	void fixFirst( double rate ) { (*firstFixablePeriod())->fixFloatingRate( rate ); } // fix rate of first pp
	void unfixFirst() { (*firstFixablePeriod())->unfixFloatingRate(); } // unfix first floating rate.
	void fixPrev( double rate ) { (*prevFixablePeriod())->fixFloatingRate( rate ); } // fix rate of first pp


};

} //namespace MCPL

#endif
