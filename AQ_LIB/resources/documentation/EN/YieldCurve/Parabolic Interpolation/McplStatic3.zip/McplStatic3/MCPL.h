#pragma once
#pragma warning ( disable : 4251 4786 ) 


#include "StdAfx.h"
