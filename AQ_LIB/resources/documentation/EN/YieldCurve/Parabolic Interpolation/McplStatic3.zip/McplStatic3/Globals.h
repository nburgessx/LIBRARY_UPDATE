#pragma once
#pragma warning ( disable : 4251 4786 ) 

#ifndef MCPLGLOBALS_H
#define MCPLGLOBALS_H
#include "MCPL.h"

#include "mcpldefs.h"

using namespace std;

namespace MCPL
{


	namespace Globals
	{	

		void SetMatchApollo(bool value);
		bool GetMatchApollo();

		void SetAdjustDates(bool value);
		bool GetAdjustDates();

	}

}

#endif
