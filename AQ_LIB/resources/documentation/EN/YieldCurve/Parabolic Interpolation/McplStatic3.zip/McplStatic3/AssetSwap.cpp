#include"AssetSwap.h"
#include "LinearCurvesHelpers.h"
#include<math.h>

namespace MCPL
{

	//AssetSwap::AssetSwap();

	/* constructs a PAR-PAR asset swap and sets the curves*/
	AssetSwap::AssetSwap(date today, date maturity, date datedDate, date nextCouponDate,
		double coupon, double cleanPrice,
		BONDTYPE bondType, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve)

	{
		/*  this constructor sets up a swap with the right behaviour  */

		long int fixedPmtsPerYear;
		long int floatPmtsPerYear;
		DayBasis fixedBasis;
		DayBasis floatBasis;
		HOLIDAYCAL hol;


		m_cleanPrice = cleanPrice;
		_EvalDate = today;

		switch (bondType)
		{
		case JGB:
			fixedPmtsPerYear = 2;
			floatPmtsPerYear = 2;
			fixedBasis = act_365f;
			floatBasis = act_360;
			hol = JP;
			m_settlement = addBusinessDays(today, 4, hol);
			m_accruedInterest = 100 * coupon*(dayCountFrac(fixedBasis, datedDate, m_settlement) / dayCountFrac(fixedBasis, datedDate, nextCouponDate));
			break;
		
		case GILT:
			fixedPmtsPerYear = 2;
			floatPmtsPerYear = 2;
			fixedBasis = act_act;
			floatBasis = act_365f;
			hol = UK;
			m_settlement = addBusinessDays(today, 1, hol);
			m_accruedInterest = 100.0 / fixedPmtsPerYear*coupon*(dayCountFrac(fixedBasis, datedDate, m_settlement) / dayCountFrac(fixedBasis, datedDate, nextCouponDate));
			//allow for ex-dividend (i.e. negative accrued)
			if (addBusinessDays(m_settlement, 8, hol) >= nextCouponDate)
			{
				//accued interest becomes negative after the cum-dividend day.
				m_accruedInterest = -100 * coupon / fixedPmtsPerYear*dayCountFrac(fixedBasis, m_settlement, nextCouponDate);
			}
			break;
		
		case BUND:
			fixedPmtsPerYear = 1;
			floatPmtsPerYear = 2;
			fixedBasis = act_act;
			floatBasis = act_360;
			hol = EUTARG;
			m_settlement = addBusinessDays(today, 3, hol);
			m_accruedInterest = 100 * coupon / fixedPmtsPerYear*(dayCountFrac(fixedBasis, datedDate, m_settlement) / dayCountFrac(fixedBasis, datedDate, nextCouponDate));
			break;
		
		case TREASURY:
			fixedPmtsPerYear = 2;
			floatPmtsPerYear = 2;
			fixedBasis = _30_360;
			floatBasis = act_360;
			hol = USA;
			m_settlement = addBusinessDays(today, 1, hol);
			m_accruedInterest = 100 * coupon / fixedPmtsPerYear*(dayCountFrac(fixedBasis, datedDate, m_settlement) / dayCountFrac(fixedBasis, datedDate, nextCouponDate));
			break;
		
		default:
			fixedPmtsPerYear = 2;
			floatPmtsPerYear = 2;
			fixedBasis = act_act;
			floatBasis = act_360;
			hol = UK;
			m_settlement = addBusinessDays(today, 1, hol);
			m_accruedInterest = 100 * coupon / fixedPmtsPerYear*(dayCountFrac(fixedBasis, datedDate, m_settlement) / dayCountFrac(fixedBasis, datedDate, nextCouponDate));


		}		//end switch

		date firstFixedCoupon;

		firstFixedCoupon = addBusinessMonths(nextCouponDate, (-12 / fixedPmtsPerYear), hol, true);
		addLeg(Handle<Leg>(new Leg(PAY, MC_BOND, firstFixedCoupon, maturity, 100, coupon, fixedPmtsPerYear, fixedBasis, hol)));
		addLeg(Handle<Leg>(new Leg(RECEIVE, MC_FLOAT, m_settlement, maturity, 100, 0.0, floatPmtsPerYear, floatBasis, hol)));

		//set curves if required KLUDGE (too lazy to write another constructor)
		if (discountCurve && forecastCurve)
		{
			setCurves(discountCurve, forecastCurve);
		}



		/*      add cashflows to swap            */
		Handle<PaymentPeriod> upfront = Handle<PaymentPeriod>(new PaymentPeriod((m_cleanPrice + m_accruedInterest - 100), m_settlement));

		//if curves have been set, calculate discount factor.KLUDGE (too lazy to write another constructor) 
		if (discountCurve && forecastCurve)
		{
			upfront->setDiscountFactor(discountCurve->getDiscountFactor(m_settlement));
		}
		getLeg(MC_BOND)->addPayment(upfront);

		double temp = upfront->Price();
		/*      extra logic for harder cases     */
		switch (bondType)
		{
			//JGBs pay accrued interest if they mature later than expected.
		case JGB:
			Handle<PaymentPeriod> lastPayment = getLeg(MC_BOND)->getPayment(maturity);
			if (lastPayment->getPaymentDate() != maturity)
			{
				PaymentPeriod backEnd((lastPayment->getPaymentDate() - maturity) * coupon * 100 / 365, lastPayment->getPaymentDate());
				backEnd.setDiscountFactor(discountCurve->getDiscountFactor(lastPayment->getPaymentDate()));
			}
		}				//end Switch

	}


	double AssetSwap::BondPrice(date settlement_, date maturity_, double couponRate_, double yield_, double redemption_, int freq_, DayBasis basis_)
	{
		if (freq_ <= 0)
			mcpl_error("freq must ve >0 in AssetSwap::BondPrice");

		double yToMat = dayCountFrac(act_act, settlement_, maturity_);

		int nOutstandingCoupons = yToMat * freq_;
		date nextCouponDate = addMonths(maturity_, -nOutstandingCoupons * 12 / (long)freq_);
		date prevCouponDate = addMonths(nextCouponDate, -12 / freq_);

		double dsc = dayCount(basis_, settlement_, nextCouponDate);
		double e = dayCount(basis_, prevCouponDate, nextCouponDate);
		double a = e - dsc;

		double yfac = 1 + yield_ / freq_;
		double sum = 0, df = 1;

		for (auto i = 0; i <= nOutstandingCoupons; i++)
		{
			df = 1.0 / pow(yfac, i + dsc / e);
			sum += df;
		}
		double discountedCoupons = 100 * couponRate_ / freq_*sum;
		double discountedRedemption = redemption_*df;
		double accruedInt = 100.0 * couponRate_ / freq_ * a / e;

		return discountedCoupons + discountedRedemption - accruedInt;
	}

	double AssetSwap::BondYield(date settlement_, date maturity_, double couponRate_, double price_, double redemption_, int freq_, DayBasis basis_)
	{
		return linearFitter([&](double y) { return BondPrice(settlement_, maturity_, couponRate_, y, redemption_, freq_, basis_) - price_; }, .001, .1, 1e-6); 
	}

	// Price the bond leg of the asset swap using the given rate and the leg's basis and pmt freq to discount the cashflows.
	double AssetSwap::priceWithRate(double rate_)
	{
		double pv = 0;
		auto bondLeg = getLeg(MC_BOND);
		DayBasis basis = bondLeg->getBasis();
		double pmtsPerYear = bondLeg->getPaymentsPerYear();

		date prevCouponDate = (*(bondLeg->getCashflow()))[0]->getTargetStart();
		date nextCouponDate = (*(bondLeg->getCashflow()))[1]->getTargetStart();

		double v = 1 / (1 + rate_ / pmtsPerYear);  //period DF for each coupon period
		double ratio = dayCountFrac(basis, m_settlement, nextCouponDate) / dayCountFrac(basis, prevCouponDate, nextCouponDate);
		double df1 = pow(v , ratio );
		double df = 1;

		pv += -(*(bondLeg->getCashflow()))[0]->getPaymentAmount() * df;

		int n = 0;
		for (auto pp = bondLeg->getCashflow()->begin()+1; pp != bondLeg->getCashflow()->end(); pp++)
		{
			if ((*pp)->getType() == MC_BOND)
			{
				n++;
				df *= v;
				pv += -(*pp)->getPaymentAmount() * df;
			}
		}
		
		//Return of principal
		pv = df1 * (pv +  100 * pow(v,n));

		return pv - m_accruedInterest;
	}

	double AssetSwap::YieldToMaturity(double dirtyPrice)
	{
		return linearFitter([&](double y) { return priceWithRate(y) - dirtyPrice; }, .001, .1, 1e-6 ); // returns continuously compounded flat rate for the segment
	}

	double AssetSwap::getAccruedInterest()
	{
		return m_accruedInterest;
	}
	/* some useful string functions */

	BONDTYPE str2bondType(char * strBondType)
	{

		BONDTYPE retVal;

		if (!_stricmp(strBondType, "bund")) retVal = BUND;
		else if (!_stricmp(strBondType, "gilt")) retVal = GILT;
		else if (!_stricmp(strBondType, "jgb")) retVal = JGB;
		else if (!_stricmp(strBondType, "treasury")) retVal = JGB;
		else mcpl_error(string("no such bond type : ") + string(strBondType));



		return retVal;
	}




} //end namespace MCPL