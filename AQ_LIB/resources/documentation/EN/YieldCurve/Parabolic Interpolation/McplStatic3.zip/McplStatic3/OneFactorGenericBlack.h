#pragma once
#ifndef ONEFACTORGENERICBLACK_H
#define ONEFACTORGENERICBLACK_H
#pragma warning ( disable : 4251 4786 ) 
#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "swap.h"
#include "OneFactorGeneric.h"

#include<string>
#include<vector>


using namespace std;

namespace MCPL
{

	class oneFactorGenericBlack : public oneFactorGeneric
	{
	public:

		// Constructors.
		//oneFactorGenericBlack() : oneFactorGeneric() {}

		oneFactorGenericBlack(shared_ptr<Deal> ULdeal_, int nSteps_, double dFwd_, shared_ptr<vector<date>> exDates_, shared_ptr<vector<double>> fwdVols_, bool priceToCancelCashflows_, bool useLinearGenerator_ = true)
			: oneFactorGeneric(ULdeal_, nSteps_, dFwd_, exDates_, fwdVols_, priceToCancelCashflows_,useLinearGenerator_)
		{}


	protected:

		virtual void calcProbabilities();
		virtual void calcInstrinsic();
		virtual void calcInstrinsicFast();
	};

} // Namespace MCPL

#endif // ONEFACTORGENERICNORMAL_H