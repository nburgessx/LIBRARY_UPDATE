#include"ShortEndCurve.h"



namespace MCPL
{

	void ShortEndCurve::calculateDates()
	{
		

		m_nInputFutures = m_futures.size();

		if ( m_nInputFutures == 0 )
			MCPL_ERROR("LinearFuturesCurve needs at least one input future");

		// Set up IMM start, end dates and day count fractions.
		m_starts.clear(); m_starts.resize(m_nInputFutures);
		m_ends.clear(); m_ends.resize(m_nInputFutures);
		m_PDCF.clear(); m_PDCF.resize( m_nInputFutures );
		m_synthAdjustments.clear();

		m_starts[0] = nthIMMDate(m_1stFut, 1, 3).roll(m_hols, 0, true);
		m_ends[0] = nthIMMDate(m_1stFut, 2, 3).roll(m_hols, 0, true);
		m_PDCF[0] = dayCountFrac(m_basis, m_starts[0] , m_ends[0] );
		m_synthAdjustments.set(m_starts[0], m_adjustments[0] );

		for ( int i = 1 ; i < m_nInputFutures ; ++i ) 
		{
			m_starts[i] = m_ends[i-1];
			m_ends[i] = nthIMMDate(m_1stFut, i+2, 3).roll(m_hols, 0, true);
			m_PDCF[i] = dayCountFrac(m_basis, m_starts[i] , m_ends[i] );
			m_synthAdjustments.set(m_starts[i], m_adjustments[i] );
		}

		m_1stFut = m_starts[0];
		date lastInputFutDate = m_ends.back();

		// Short end curve dates

		m_shortEndStarts.clear();
		m_shortEndEnds.clear();
		m_shortEndPDCFs.clear();
		m_shortEndRates.clear();
		m_shortEndIsFut.clear();
		int futsCounter = 0;
		for ( map<date,double>::const_iterator serialIt = m_serials.begin(); serialIt != m_serials.end(); serialIt++)
		{
			while ( serialIt->first > m_starts[futsCounter] )
			{
				m_shortEndStarts.push_back( m_starts[futsCounter] );
				m_shortEndEnds.push_back( m_ends[futsCounter] );
				m_shortEndPDCFs.push_back( m_PDCF[futsCounter] );
				m_shortEndRates.push_back( (100.0-m_futures[futsCounter])/100.0 - m_adjustments[futsCounter]/10000.0 );
				m_shortEndIsFut.push_back( true );
				futsCounter++;
			}
			m_shortEndStarts.push_back( serialIt->first );
			m_shortEndEnds.push_back( addBusinessMonths(serialIt->first, 3, m_hols) );
			m_shortEndPDCFs.push_back( dayCountFrac(m_basis, m_shortEndStarts.back() , m_shortEndEnds.back() ) );
			m_shortEndRates.push_back( (100.0-serialIt->second)/100.0 - m_synthAdjustments.get(serialIt->first)/10000.0 );
			m_shortEndIsFut.push_back(false);
		}

		// Now for the swaps
		//
		// We have to set up synthetic futures which span the gap from the last input future to the end of the last swap.
		//

		date nextIMMdate = lastInputFutDate;
		date lastSwapEndDate = m_swapLastDates.back();

		double lastFutPrice = m_futures.back();

		while ( nextIMMdate < lastSwapEndDate )
		{
			m_starts.push_back( nextIMMdate );
			
			date endIMMdate = nthIMMDate(nextIMMdate, 2, 3).roll(m_hols, 0, true);
			m_ends.push_back(endIMMdate);

			m_PDCF.push_back(dayCountFrac(m_basis, nextIMMdate , endIMMdate ));

			m_futures.push_back( lastFutPrice );
			m_adjustments.push_back(m_adjustments.back()); // Hack! Need to fix this with proper adjustments input.
			nextIMMdate = endIMMdate;
		}	

		long n_swaps = m_swapParams.size();
		m_firstUsedSwapIndex = 0;

		if ( n_swaps > 0 )
		{
			// Set up swap dates.

			for ( int i=0 ; i < n_swaps ; ++i )
			{
				if ( m_swapLastDates[i] <= lastInputFutDate )
				{
					m_firstUsedSwapIndex = i+1;
				}
				else
				{
					break;
				}
			}
		
			// Set up all pricing swaps
			m_swapCashflows.clear();
			m_linFutsPriceDrops.clear();

			long lastSwapTenor = (long) m_swapTenors.back();
			long firstSwapTenor = (long) m_swapTenors[m_firstUsedSwapIndex];
			
			for ( unsigned int j = m_firstUsedSwapIndex ; j < m_swapTenors.size() ; ++j )
			{

				m_swapCashflows.push_back( Swap(PAY, m_swapType, m_spot, m_swapLastDates[j], m_spot, 1, .05, 0, m_swapHols, m_ccy) );
				m_linFutsPriceDrops.push_back(0.0); 
			}

			// setup indeces of corresponding futures for the swaps
			m_linFutsSwapIndex.clear(); // Index of first fut with start date > swap[-1]'s mat date
			m_linFutsSwapIndex.resize(m_swapCashflows.size() + 1);
			m_linFutsSwapIndex[0] = m_nInputFutures;
			
			int swapIndex = m_firstUsedSwapIndex;
			for ( unsigned int j = m_nInputFutures ; j < m_ends.size() ; j++ )
			{
				if ( m_starts[j] > m_swapLastDates[swapIndex] )
				{
					m_linFutsSwapIndex[swapIndex - m_firstUsedSwapIndex + 1] = j;
					swapIndex++;
				}
			}

			m_linFutsSwapIndex.back() = j;
		}
	}


	void ShortEndCurve::calculateCurve()
	{
		double rate, PDF;
		discountCurve cashCurve;

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );
		cashCurve.set(m_today , 1.0 );
		cashCurve.set(m_spot , spotDF );

		map<date,double>::const_iterator it = m_cashParams.begin();
		++it;
		for (  ; it != m_cashParams.end() ; ++it ) 
		{
			dcf = dayCountFrac( m_basis, m_spot, it->first );

			cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
		}
	

		discountCurve::clear();
		discountCurve::set(m_today , 1.0 );
		discountCurve::set(m_spot , spotDF );

		discountCurve::set(m_1stFut , cashCurve.get(m_1stFut) ); // set first discount from LIBOR

		for ( int i = 0 ; i < m_nInputFutures ; ++i ) 
		{
			date start = m_starts[i];
			date end = m_ends[i];

			rate = (100.0-m_futures[i])/100.0 - m_adjustments[i]/10000.0;

			PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
			discountCurve::set(end , get(start) * PDF );
		}

		// The swaps

		// Set up the linear interp curve of par rates to get the par points between the input points
		for ( unsigned int i=0 ; i < m_swapCashflows.size() ; i++ )
		{
			fitFuturesDrops(i);
		}

	}


	void ShortEndCurve::calculateCurveFromFutures()
	{
		double rate, PDF;
		discountCurve cashCurve;

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );
		cashCurve.set(m_today , 1.0 );
		cashCurve.set(m_spot , spotDF );

		map<date,double>::const_iterator it = m_cashParams.begin();
		++it;
		for (  ; it != m_cashParams.end() ; ++it ) 
		{
			dcf = dayCountFrac( m_basis, m_spot, it->first );

			cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
		}
	

		discountCurve::clear();
		discountCurve::set(m_today , 1.0 );
		discountCurve::set(m_spot , spotDF );

		discountCurve::set(m_1stFut , cashCurve.get(m_1stFut) ); // set first discount from LIBOR

		int nFutures = m_futures.size();
		for ( int i = 0 ; i < nFutures ; ++i ) 
		{
			date start = m_starts[i];
			date end = m_ends[i];

			rate = (100.0-m_futures[i])/100.0 - m_adjustments[i]/10000.0;

			PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
			discountCurve::set(end , get(start) * PDF );
		}

	}





	namespace ShortEndCurveFitFn
	{
		int index;
		ShortEndCurve *fitcurve;

		double func_linear(double drop)
		{

			//ShortEndCurve &curve = *fitcurve;

			for ( int i = fitcurve->m_linFutsSwapIndex[index] ; i < fitcurve->m_linFutsSwapIndex[index+1] ; i++ )
			{
				fitcurve->m_futures[i] = fitcurve->m_futures[i-1] - drop;
				date start = fitcurve->m_starts[i];
				date end = fitcurve->m_ends[i];

				double rate = (100.0-fitcurve->m_futures[i])/100.0 - fitcurve->m_adjustments[i]/10000.0;

				double PDF = 1.0 / ( 1.0 + rate * fitcurve->m_PDCF[i] );
				fitcurve->set(end , fitcurve->get(start) * PDF );
			}

			(fitcurve->m_swapCashflows[index]).setCurves(*fitcurve,*fitcurve);
			return ( (fitcurve->m_swapCashflows[index]).Solve(0, solveFORCOUPON) 
				- fitcurve->m_parRates[index + fitcurve->m_firstUsedSwapIndex] );
		}
	}

	void ShortEndCurve::fitFuturesDrops(int index)
	{
		ShortEndCurveFitFn::index = index;
		ShortEndCurveFitFn::fitcurve = this;

		double drop = NUMREC::zriddr( ShortEndCurveFitFn::func_linear , -10, 10, .001 );

		// Now fix the curve after the fitting!
		for ( int i = m_linFutsSwapIndex[index] ; i < m_linFutsSwapIndex[index+1] ; i++ )
			{
				m_futures[i] = m_futures[i-1] - drop;
				date start = m_starts[i];
				date end = m_ends[i];

				double rate = (100.0-m_futures[i])/100.0 - m_adjustments[i]/10000.0;

				double PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
				set(end , get(start) * PDF );
			}
	}

	void ShortEndCurve::set_currency_defaults(CURRENCY ccy)
	{
		m_ccy = ccy;

		switch(m_ccy)
		{
		case USD:
			set_currency_defaults(ccy, SB3);
			break;
		case EUR:
			set_currency_defaults(ccy, AB6);
			break;
		case JPY:
			set_currency_defaults(ccy, SB6);
			break;
		case GBP:
			set_currency_defaults(ccy, SB6);
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}

	}

	void ShortEndCurve::set_currency_defaults(CURRENCY ccy, SwapType type)
	{

		vanillaSwapParams(ccy, type, m_fixedPmtsPerYear, m_fltPmtsPerYear, m_fixedBasis, m_basis) ;

		m_swapType = type;
		m_ccy = ccy;

		switch(ccy)
		{
		case USD:
			m_swapHols = HOLIDAYCAL(UK | USA);
			m_hols = UK;
			break;
		case EUR:
			m_swapHols = EUTARG;
			m_hols = EUTARG;
			break;
		case JPY:
			m_swapHols = JP;
			m_hols = UK;
			break;
		case GBP:
			m_swapHols = UK;
			m_hols = UK;
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}
	}


	bool ShortEndCurve::cmpvecs( const vector<double> & v1, const vector<double> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}

	bool ShortEndCurve::cmpvecs( const vector<date> & v1, const vector<date> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}

	bool ShortEndCurve::cmpmaps( const map<date,double> & v1, map<date,double> & v2)
	{
		if ( v1.size() != v2.size() ) return false;
		else 
		{
			bool test = true;
			map<date,double>::const_iterator it1 = v1.begin();
			map<date,double>::const_iterator it2 = v2.begin();
			while ( test && ( it1 != v1.end() ) && ( it2 != v2.end() ) )
			{
				if ( it1->first != it2->first ) 
					test = false;
				
				++it1;
				++it2;
			}		
			return test;
		}
		return false; // should not get here.
	}

	void ShortEndCurve::generateSwapVectors()
	{
		m_parRates.clear();
		m_swapTenors.clear();
		m_swapLastDates.clear();

		for ( map<date,double>::const_iterator it = m_swapParams.begin() ; it != m_swapParams.end() ; ++it )
		{
			double tenor = dayCountFrac(_30_360f,  m_spot, it->first );

			m_parRates.push_back( it->second );
			m_swapTenors.push_back( tenor );
			m_swapLastDates.push_back( it->first );
		}
	}

	void ShortEndCurve::generateSwapRateVector()
	{

		for ( unsigned int i=0 ; i < m_swapLastDates.size() ; ++i )
		{
			m_parRates[i] = m_swapParams[ m_swapLastDates[i] ];
		}
	}

	
	// Crate - constructs the object.
	void ShortEndCurve::create( const vector<double> & futures, const vector<double> & adjustments, 
		const map<date,double> & swaps, const SwapType sType,
		date & today, date & firstFut, const map<date,double> & serials, 
		const vector<date> stubDates, CURRENCY ccy)
	{
		if ( (m_today != today) || (m_1stFut != firstFut) || futures.size() != m_futures.size() 
			|| ( ccy != m_ccy )
			|| sType != m_swapType || !cmpmaps(swaps, m_swapParams) 
			|| !cmpmaps(serials, m_serials) || !cmpvecs(stubDates, m_stubDates) ) 
		{
			set_currency_defaults(ccy, sType);
			m_today = today;
			m_spot = spot(today, ccy);
			m_1stFut = firstFut;
			m_futures = futures;
			m_adjustments = adjustments;
			//m_stub_curve = stub;
			m_swapType = sType;
			m_swapParams = swaps;
			m_serials = serials;
			m_stubDates = stubDates;

			generateSwapVectors();
			clear();
			calculateDates();
			calculateCurve();
		} 
		else 
		{
			m_futures = futures;
			m_adjustments = adjustments;
			m_swapParams = swaps;
			m_serials = serials;

			generateSwapRateVector();
			clear();
			calculateCurve();
		}
	}



	// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
	void ShortEndCurve::create_PPCurves( PPCurves & pp_curves, double pp_val )
	{
		int nHedges =  m_futures.size() + m_cashParams.size(); 
		pp_curves.resize( nHedges ); 
		pp_curves.set_ppsize( pp_val/100.0 ); // set the perturb size in factor (i.e. 1 = 1%)

		pp_curves.base() = *this;

		unsigned int i=0;
		// up
		for ( map<date,double>::iterator it = m_serials.begin() ; it != m_serials.end() ; ++it )
		{
			it->second += pp_val/100.0;
			clear();
			calculateCurveFromFutures();
			pp_curves.label(i) = "serial " + (string) it->first;
			pp_curves.up(i++)= *this;
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] -= pp_val;
			clear();
			calculateCurveFromFutures();
			pp_curves.label(i) = "Fut " + (string) m_starts[j];
			pp_curves.up(i++)= *this;
			m_futures[j] += pp_val;
		}


		// dn
		i=0;
		for ( map<date,double>::iterator it = m_serials.begin() ; it != m_serials.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			clear();
			calculateCurveFromFutures();
			pp_curves.dn(i++)= *this;
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			clear();
			calculateCurveFromFutures();
			pp_curves.dn(i++)= *this;
			m_futures[j] -= pp_val;
		}


		//upup
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			m_futures[j] -= pp_val;
		for ( map<date,double>::iterator it = m_serials.begin() ; it != m_serials.end() ; ++it )
			it->second += pp_val/100.0;

		i=0;
		for ( map<date,double>::iterator it = m_serials.begin() ; it != m_serials.end() ; ++it )
		{
			it->second += pp_val/100.0;
			clear();
			calculateCurveFromFutures();
			pp_curves.upup(i++)= *this;
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] -= pp_val;
			clear();
			calculateCurveFromFutures();
			pp_curves.upup(i++)= *this;
			m_futures[j] += pp_val;
		}

		// updn
		i=0;
		for ( map<date,double>::iterator it = m_serials.begin() ; it != m_serials.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			clear();
			calculateCurveFromFutures();
			pp_curves.updn(i++)= *this;
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			clear();
			calculateCurveFromFutures();
			pp_curves.updn(i++)= *this;
			m_futures[j] -= pp_val;
		}


		//dnup
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			m_futures[j] += 2.0*pp_val;
		for ( map<date,double>::iterator it = m_serials.begin() ; it != m_serials.end() ; ++it )
			it->second -= 2.0*pp_val/100.0;

		i=0;
		for ( map<date,double>::iterator it = m_serials.begin() ; it != m_serials.end() ; ++it )
		{
			it->second += pp_val/100.0;
			clear();
			calculateCurveFromFutures();
			pp_curves.dnup(i++)= *this;
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j )
		{
			m_futures[j] -= pp_val;
			clear();
			calculateCurveFromFutures();
			pp_curves.dnup(i++)= *this;
			m_futures[j] += pp_val;
		}

		// dndn
		i=0;
		for ( map<date,double>::iterator it = m_serials.begin() ; it != m_serials.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			clear();
			calculateCurveFromFutures();
			pp_curves.dndn(i++)= *this;
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0  ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			clear();
			calculateCurveFromFutures();
			pp_curves.dndn(i++)= *this;
			m_futures[j] -= pp_val;
		}


		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			m_futures[j] -= pp_val;
		for ( map<date,double>::iterator it = m_serials.begin() ; it != m_serials.end() ; ++it )
			it->second += pp_val/100.0;

		clear();
		calculateCurveFromFutures();

	}


	


} // namespace MCPL