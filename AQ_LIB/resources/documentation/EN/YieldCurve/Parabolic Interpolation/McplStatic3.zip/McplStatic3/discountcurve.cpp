#include "discountcurve.h"

namespace MCPL
{



	double zero( double DF, double dcf)
	{
		return ( (1.0 - DF)/(DF*dcf) );
	}

	void discountCurve::shiftCurve( double dR , DayBasis basis )
	{
		clear_cache();

		discountCurve::STORE & store = getStore();
		date today = firstLabel();

		for ( discountCurve::STORE::iterator it = store.begin() ; it != store.end() ; ++it ) 
		{
			double time = dayCountFrac(basis, today, it->first);
			double df = it->second;

			it->second = df * exp(-dR*time);
		}
	}

	date discountCurve::firstDate()
	{
		return (date) this->firstLabel();
	}

	date discountCurve::lastDate()
	{
		return (date) this->lastLabel();
	}

} // namespace MCPL