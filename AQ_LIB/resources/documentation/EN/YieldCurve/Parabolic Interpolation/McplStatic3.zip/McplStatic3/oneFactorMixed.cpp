#include "stdafx.h"
#include "oneFactorMixed.h"
#include "mathmisc.h"
#include <math.h>

#include <fstream>

//#define DEBUG

namespace MCPL
{



  // Constructor which can set up its own cashflows and work out forward rates etc...
  // Needs to be given the structure's dates etc.., a discount curve, a forecast curve and a swaption vol grid.
  oneFactorMixed::oneFactorMixed( DIRECTIONTYPE dir, date & priceto, date & start, date & first, date & mature, date & roll, bool longCoupon, 
    double notional, double spread, double spreadStep ,long int fixedPmtsPerYear, long int fltPmtsPerYear, 
    double strike, double strikeStep, long int noticeDays, long int lockout,	long int calls,
    DayBasis fixedBasis, DayBasis floatBasis, double stepsize, long int nsteps, long int trunc,
    Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, VolatilityGrid & volGrid, double mixing, HOLIDAYCAL hol) 
    : m_mixing(mixing)
  {

    // Set up the cashflows.
    Swap ULswap( dir, start, first, mature, roll, ROLL_FORWARD, longCoupon, notional, 
      strike, strikeStep, spread, spreadStep, fixedPmtsPerYear, fltPmtsPerYear, 
      fixedBasis, floatBasis, discountCurve, forecastCurve, hol);

    m_ULPV = ULswap.Price();

    Handle<Leg> underlyer = ULswap.getLeg(MC_FIXED);

    // Extract the underlying swap's start dates

    underlyer->getStartDates( m_ULstartDates );
    int nStartDates = m_ULstartDates.size();

    for ( int i = 0 ; i < nStartDates ; ++i)  m_exercise.push_back(false);

    std::vector<double> spreads;
    for ( i = lockout ; i < lockout+calls ; ++i ) 
    {

      if ( i >= nStartDates ) mcpl_error("oneFactorMixed: too many calls or lockouts");

      m_exercise[i] = true;
      m_exerciseDates.push_back( addBusinessDays( m_ULstartDates[i] ,  -noticeDays , hol) );
      m_startDates.push_back( m_ULstartDates[i].rollFwd(hol,true) );
      spreads.push_back( spread + i*spreadStep );
    }


    // set up the arrays to construct the lattice.

    m_nDates = m_exerciseDates.size();
    vector<double> pForwards(m_nDates);
    vector<double> pStrikes(m_nDates);
    vector<double> pForwardLogVols(m_nDates);
    vector<double> pForwardNormalVols(m_nDates);
    vector<double> pNumeraires(m_nDates);

	vector<double> adjStrikes, adjFwds;

    double nvol1, nvol2, lvol1, lvol2, t1, t2;
    for ( i=0 ; i < m_nDates ; ++i ) 
    {

      pStrikes[i] = strike + i*strikeStep;

      // Set up a temp swap to calc forward rates

      Swap tempSwap( dir, m_startDates[i], m_startDates[i], mature, roll, ROLL_FORWARD, longCoupon, notional, 
        pStrikes[i], strikeStep, spreads[i], spreadStep, fixedPmtsPerYear, fltPmtsPerYear, 
        fixedBasis, floatBasis, discountCurve, forecastCurve, hol);
	        
	  Swap tempSwapNoSpread( dir, m_startDates[i], m_startDates[i], mature, roll, ROLL_FORWARD, longCoupon, notional, 
        pStrikes[i], strikeStep, 0, spreadStep, fixedPmtsPerYear, fltPmtsPerYear, 
        fixedBasis, floatBasis, discountCurve, forecastCurve, hol);


      pForwards[i] = tempSwap.Solve(0, solveFORCOUPON);
	  adjFwds.push_back( tempSwapNoSpread.Solve(0, solveFORCOUPON) );
      pNumeraires[i] = tempSwap.notionalBPV();

      // Work out forward variamces
	  // Work out forward variamces
	  if (volGrid.getShift() != 0.0)
		  mcpl_error("oneFactor doesn't work with shifted rate models yet.");

      t2 = dayCountFrac(act_365 , priceto , m_exerciseDates[i] );
      nvol2 = volGrid.get((expiry) (m_startDates[i]   - priceto) , (tenor) dayCountFrac(act_365, m_startDates[i], mature),
													pStrikes[i], pForwards[i] ).vol;
      lvol2 = n2bATMvol(pForwards[i], t2, BlackVol(nvol2,0)).vol;
      if ( i==0 ) 
      {
        pForwardLogVols[0] = lvol2*lvol2*t2;
        pForwardNormalVols[0] = nvol2*nvol2*t2;
      } 
      else 
      {
        pForwardLogVols[i] = lvol2*lvol2*t2  -  lvol1*lvol1*t1;  // Calc forward variance.
        pForwardNormalVols[i] = nvol2*nvol2*t2  -  nvol1*nvol1*t1;  // Calc forward variance.
      }
      t1=t2;
      nvol1 = nvol2;
      lvol1 = lvol2;
      if ( pForwardLogVols[i] <= 0 ) pForwardLogVols[i] = 0;
      if ( pForwardNormalVols[i] <= 0 ) pForwardNormalVols[i] = 0;

	  double offset =  pForwards[i] - adjFwds[i];
	  adjStrikes.push_back( pStrikes[i] - offset );
    }	
    // Set up the lattices
    setup( adjFwds, adjStrikes, pForwardNormalVols, pForwardLogVols, pNumeraires, stepsize, trunc , nsteps, dir == PAY ? 1:0, mixing );

  }



	//========================================================================================================================
	oneFactorMixed::oneFactorMixed(const vector<double> & pforwards, const vector<double> & pstrikes, const vector<double> & pLVols, 
		const vector<double> & pNVols, const vector<double> & pnumeraires, const double pstepsize, const long int ptrunc,
		const long int pnumberOfSteps, const long int ppayerOrReceiver, const double mixing)
	{
		setup(pforwards, pstrikes, pNVols, pLVols, pnumeraires, pstepsize, ptrunc, pnumberOfSteps, ppayerOrReceiver, mixing);
	}

  void oneFactorMixed::setup(const vector<double> & pforwards, const vector<double> & pstrikes, const vector<double> & pNVols, 
		const vector<double> & pLVols, const vector<double> & pnumeraires, const double pstepsize,
		const long int ptrunc, const long int pnumberOfSteps, const long int ppayerOrReceiver, const double pmixing)
  {
    int i, pnumberOfDates;

    pnumberOfDates = pforwards.size();

    m_mixing = pmixing;

    // allocate memory and initialise the arrays we use to store values
    m_presentValues.resize(2*pnumberOfSteps+100);
    m_futureValues.resize(2*pnumberOfSteps+100);
    m_logTransitionProbabilities.resize(2*ptrunc+20);


    m_forwards = pforwards;
    m_strikes = pstrikes;
    m_forwardNVols = pNVols;
    m_forwardLVols = pLVols;
    m_numeraires = pnumeraires;
    // Check inputs are same sized.
    if ( (pnumberOfDates != m_strikes.size()) || 
      (pnumberOfDates != m_forwardNVols.size() ) ||
      (pnumberOfDates != m_numeraires.size() ) )
      mcpl_error("input arrays not all same size for OneFactor.");

    m_nDates=pnumberOfDates;
    m_numberOfSteps=pnumberOfSteps;
    m_trunc=ptrunc;
    m_stepsize=pstepsize;
    m_payerOrReceiver=ppayerOrReceiver;

    for(i = 0 ; i < 2*m_numberOfSteps+100 ; ++i)
    {
      m_futureValues[i]=0;
      m_presentValues[i]=0;
    }


    //determine whether we are pricing a call or a put.

    if (m_payerOrReceiver==0)
    {
      m_payerOrReceiver=-1;		//call
    }
    else
      m_payerOrReceiver=1;		//put

    //calculate the probabilities for moving from the penultimate to the last time.
    //calculateNormalProbabilities(m_forwardNVols[m_nDates-1], m_stepsize, m_numberOfSteps, m_trunc);
    calculateLogProbabilities(m_forwardLVols[m_nDates-1], m_stepsize, m_numberOfSteps, m_trunc);

    //initialise the values at the final date.
    for(i = -1*m_numberOfSteps ; i <= m_numberOfSteps ; ++i)
    {
      double value = m_payerOrReceiver*(exp(m_stepsize*i)*m_forwards[m_nDates-1]-m_strikes[m_nDates-1])*m_numeraires[m_nDates-1];
      m_futureValues[i+m_numberOfSteps] = __max(value, 0.0);
    }
  }

  void oneFactorMixed::calculateLogProbabilities(double volatility,double stepsize,
            long numberOfSteps,long trunc)
  {
    double tempsum=0;
    const double pi = Pi;
    int i;

    for(i = -1*trunc ; i<=trunc ; ++i)
    {
      double temp=(i*stepsize+.5*volatility)*(i*stepsize+.5*volatility);
      tempsum += m_logTransitionProbabilities[i+trunc] = exp(-1*temp  / (2 * volatility));
    }

    //normalise the probabilities, so that they sum to 1.
    // this seems to make the results more stable as a function of trunc.

    for(i = -1*trunc ; i<=trunc ; ++i)
    {
      m_logTransitionProbabilities[i+trunc] = m_logTransitionProbabilities[i+trunc]/tempsum;
    }
  }


  double calculateNormalProbability(double volatility,double stepsize, double S, double Sbar)
  {
    const double pi = Pi;
    double temp=Sbar-S;
    temp *= temp; // temp should now be (S'-S)^2
    return (stepsize *Sbar / sqrt(2.0 * pi * volatility)) * exp(-1*temp  / (2 * volatility));

  }

  double oneFactorMixed::approxPV(int i, int trunc, double vol, double forward)
  {
    //the trunc parameter controls how many probabilities we will use.

    int k;
    int lowerCutOff;
    int upperCutOff;
    double temp=0;

    lowerCutOff = -1*trunc;
    upperCutOff = trunc;

    // now check to see if we get taken over the edge by going trunc steps from i.
    if (i-trunc<0) 
    {
      lowerCutOff=-1*i;
    }

    if (i+trunc > 2*m_numberOfSteps )
    {
      upperCutOff=(2*m_numberOfSteps - i);
    }

    //perform the multiplication
    double S = forward * exp((i-m_numberOfSteps)*m_stepsize);
    for(k = lowerCutOff ; k<=upperCutOff ; ++k)
    {
      double Sbar = S * exp(k * m_stepsize);
      //		double Sbar = forward * exp((i+k-m_numberOfSteps) * m_stepsize);
      double lprob = m_logTransitionProbabilities[k+trunc]; // debug
      double nprob = calculateNormalProbability(vol, m_stepsize, S, Sbar); // debug
      //		double nprob = calculateNormalProbability(vol, m_stepsize, forward*exp(m_stepsize*(i-m_numberOfSteps)), i+k - m_numberOfSteps); // debug
      double fval = m_futureValues[i + k]; // debug

      temp += ( (1-m_mixing)*lprob + 	m_mixing*nprob) * fval;
    }

    return temp;
  }

  // step backwards through the lattice

  double oneFactorMixed::priceStructure()
  {
    int i,m;
    double value;
    double intrinsicValue;

    // backwards induction step.
    // if the PV at the node is less than the instrinsic value, then the PV becomes the intrinsic value.

    for(m=m_nDates-1;m>0;--m)
    {
      double forward = m_forwards[m-1];
      double strike = m_strikes[m-1];
      double vol = m_forwardNVols[m-1];
      double numeraire = m_numeraires[m-1];
      for(i = -1*m_numberOfSteps ; i<=m_numberOfSteps ; ++i)
      {		
        intrinsicValue=m_payerOrReceiver*numeraire*(exp(m_stepsize*i)*forward-strike); //payers
        m_presentValues[i+m_numberOfSteps] = __max( approxPV(i+m_numberOfSteps , m_trunc, vol, forward) , intrinsicValue );	
      }		

      //after calculating all of the values at the current time, step back.
      m_futureValues=m_presentValues;

      calculateLogProbabilities(m_forwardLVols[m-1], m_stepsize, m_numberOfSteps , m_trunc);
      //		value=futureValues[numberOfSteps];
    }

    // now get PV		
    double forward = m_forwards[0];
    double vol = m_forwardNVols[0];

    value=approxPV(m_numberOfSteps,m_trunc, vol, forward);	

    return value;
  }


} // namespace MCPL
