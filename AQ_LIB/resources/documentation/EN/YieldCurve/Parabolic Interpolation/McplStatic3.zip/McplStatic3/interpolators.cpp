#include "interpolators.h"

namespace MCPL
{

Handle<Interpolator> str2interpolator(char *strInterpolator)
{

	if ( ! _stricmp(strInterpolator , "linear")) 
	{ 
		Handle<Interpolator> interpolator( new linearInterpolator );
		return interpolator;
	}
	else if ( ! _stricmp(strInterpolator , "log") ) 
	{ 
		Handle<Interpolator> interpolator( new logLinearInterpolator );
		return interpolator;
	}
	else mcpl_error("bad interpolator " + string(strInterpolator));

}


} // namespace MCPL