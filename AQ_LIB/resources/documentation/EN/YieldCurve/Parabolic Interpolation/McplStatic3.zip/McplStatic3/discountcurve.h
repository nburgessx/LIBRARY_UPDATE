#pragma once
#ifndef DISCOUNTCURVE_H
#define DISCOUNTCURVE_H
#include "MCPL.h"

#include "mcDateClass/dates.h"
#include "interpolators.h"
#include "storageclasses.h"
#include <iostream>
#include "math.h"

using namespace std;

namespace MCPL
{

double zero( double DF, double dcf);

/*********************************************************************************************
linearInterpolator:
	Performs a linear interp between the previous and next date from the one given. The iterator
	already points to the next date.
*********************************************************************************************/


typedef interpolatingStore<double,  double, linearInterpolator> LinearDoubleCurve;

typedef interpolatingStore<long,  double, logLinearInterpolator> logLinearCurve;
typedef interpolatingStore<long,  double, linearInterpolator> CapVolCurve;
typedef interpolatingStore<long,  double, linearInterpolator> LinearCurve;
typedef interpolatingStore<long, SmoothDFInterpolatorData, SmoothDFInterpolator> SmoothCurve;
typedef preInterpolatingStore<long, SmoothFwdInterpolatorData, SmoothFwdInterpolator> SmoothFwdCurve;
//typedef interpolatingStore<date, linearInterpolator> zeroCurve;


// A map using two doubles to reference a double. Interpolates using varianve on the first label (assuming the label is t to 
// expiry of the option)

//typedef interpolatingStore2D<double, double, double, linearInterpolator, linearInterpolator> SwaptionVolGrid;
//typedef interpolatingStore2D<long, long, double, varianceInterpolator, linearInterpolator> SwaptionVolGrid;
//typedef interpolatingStore2D<long, long, double, linearInterpolator, linearInterpolator> SwaptionNormalVolGrid;
//typedef interpolatingStore2D<double, double, double, varianceInterpolator, linearInterpolator> SwaptionVolGrid;
//typedef interpolatingStore2D<double, double, double, linearInterpolator, linearInterpolator> SwaptionNormalVolGrid;

class discountCurve : public logLinearCurve
{
public:
		void shiftCurve( double dR , DayBasis basis );

		date firstDate();

		date lastDate();
};

template <typename T_interpolator>
class termStructureCurve : public interpolatingStore<long,  double, T_interpolator>
{
public:
		void shiftCurve( double dR , DayBasis basis );

		virtual date firstDate();

		virtual date lastDate();
};

template <typename T_interpolator>
class termStructureDiscountCurve : public termStructureCurve<T_interpolator>
{
public:
		void shiftCurve( double dR , DayBasis basis );

		date firstDate();

		date lastDate();
};

} // namespace MCPL

#endif // DISCOUNTCURVE_H