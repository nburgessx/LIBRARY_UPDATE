#pragma warning ( disable : 4251 4786 ) 

#include "OISLeg.h"

namespace MCPL
{

	// Weighted sum of rates. Useful for pricing fed funds futures.
	double OISLeg::averageRate()
	{
		double dSumOfRates = 0.0;
		double dSumDCFs = 0.0;

		for ( vPaymentPeriod::iterator it = v_paymentPeriod.begin() ; it != v_paymentPeriod.end() ; ++it )
		{
			if ( (*it)->getReset() >= p_DiscountCurve->firstDate() )
			{
				dSumOfRates += (*it)->getFloatingRate() * (*it)->getDayCountFraction();
				dSumDCFs += (*it)->getDayCountFraction();
			}
		}
		return dSumOfRates / dSumDCFs;
	}

		// OIS leg.
	OISLeg::OISLeg(DIRECTIONTYPE dir, const date & start, const date & target, double notional, double spread,
		const int rollDay, ROLLTYPE rolltype, long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, CURRENCY ccy, int payDateOffsetDays_,
		MCPL::ACCRUAL_TYPE accrualType)
	{
		GenerateOISLeg ( dir, start, target, notional, spread, rollDay, rolltype,  pmtPerYear, basis, hol, ccy, payDateOffsetDays_, accrualType);
	}

	
	void OISLeg::GenerateOISLeg ( DIRECTIONTYPE dir, const date & start, const date & target, double notional, double spread,
		const int rollDay, ROLLTYPE rolltype, long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, CURRENCY ccy, int payDateOffsetDays_,
		MCPL::ACCRUAL_TYPE accrualType)
	{
		m_paymentDirection = dir;
		m_currency = ccy;
		m_hols = hol;
		m_payType = MC_FLOAT;
		p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		//	m_pCapVols = m_pCapNormalVols = NULL;
		m_pCapVols = NULL;
		p_CMSvols = NULL;
		m_basis = basis;
		m_paymentMonths = 12 / pmtPerYear;
		notional *= (dir == PAY) ? -1 : 1; // -ve notional for paying.

		date adjTarget = target;
		date adjStart = start;

		adjTarget.rollFwd(hol, true);
		adjStart.rollFwd(hol, true);

		if ( adjStart >= adjTarget )
			mcpl_error("The adjusted start date muxt be earlier than the adjusted end date in Leg::GenerateIMMLeg");

		date pStart, pEnd, pmtDate, floatEnd;

		pEnd = adjStart;

		bool isAccrual = true;

		date payDate;
		
		if ( rolltype == ROLL_BACKWARD || rolltype == ROLL_MONTHEND ) // Do we need this for OIS?
		{
			double tenor = dayCountFrac(basis, adjStart, adjTarget);
			int numberOfPayments = (int) (tenor * pmtPerYear);
			payDate = addMonths(adjTarget, -(numberOfPayments * 12 / pmtPerYear));
			if ( (payDate - adjStart) <= 2 )
				payDate = addMonths(payDate, 12/pmtPerYear);
		}
		else if ( rolltype == ROLL_FEDFUNDS )
		{
			payDate = addMonths(start,1);
		}
		else
		{
			payDate = addMonths(start, 12 / pmtPerYear);
		}

		payDate.setDay(rollDay);
		payDate.roll(hol,0,true);

		Handle<PaymentPeriod> prevPP;
		int sequenceNumber = 0;

		do 
		{
			pStart = pEnd;
			pEnd = addBusinessDays(pStart, 1, hol);

			floatEnd = pEnd; // addBusinessDays(pStart, 1, liborHolidays(ccy) );


			//date reset = fixing( pStart , ccy);
			date reset = pStart;
			double dcf = dayCountFrac(basis, pStart, pEnd);

			Handle<PaymentPeriod> pp = Handle<PaymentPeriod>( new PaymentPeriod(MC_FLOAT, notional , 0.0 , dcf, 0.0 , pStart, pStart, pEnd, pEnd,
					reset, payDate.roll(hol, payDateOffsetDays_, false) , floatEnd, reset, reset, 0, spread, 0.0, m_paymentMonths) );

			if ( payDate <= pEnd )
			{
				payDate = addMonths(payDate, 12 / pmtPerYear);
				payDate.setDay(rollDay);
				payDate.roll(hol,0,true);
				isAccrual = false;
			}

			if ( !isAccrual || pEnd >= adjTarget )
			{
				pp->setIsAccrualPeriod(false);
				isAccrual = true;
			}
			else
			{
				pp->setIsAccrualPeriod(true);
			}

			if ( sequenceNumber > 0 )
				pp->setPreviousPaymentInSequence(prevPP);

			pp->setSequenceNumber(sequenceNumber++);
			pp->setAccrualType(accrualType);
			

			addPayment( pp );
			prevPP = pp;
	
			
		} while (pEnd < adjTarget );

		Handle<PaymentPeriod> period_ref = v_paymentPeriod.back();

		m_lastDate = m_payType != MC_FIXED && period_ref->getFloatingPeriodEnd() > period_ref->getAdjustedEnd() ? 
			period_ref->getFloatingPeriodEnd() : period_ref->getAdjustedEnd();

		m_lastDate = m_lastDate < period_ref->getPaymentDate() ? period_ref->getPaymentDate() : m_lastDate;

	}

	// Clone function which creates a deep clone of cashflows
	shared_ptr<Leg> OISLeg::CloneCashflows()
	{
		//First make a shallow copy.
		shared_ptr<OISLeg> copy = shared_ptr<OISLeg>(new OISLeg(*this));

		//Now deep clone the cashflows.
		copy->v_paymentPeriod.clear();
		Handle<PaymentPeriod> prevPP;
		int sequenceNumber = 0;
		for (int sequenceNumber = 0; sequenceNumber < v_paymentPeriod.size(); sequenceNumber++)
		{

			copy->v_paymentPeriod.push_back(shared_ptr<PaymentPeriod>(new PaymentPeriod(*(v_paymentPeriod[sequenceNumber]))));
			copy->v_paymentPeriod.back()->setSequenceNumber(sequenceNumber);
			if (sequenceNumber > 0)
				copy->v_paymentPeriod.back()->setPreviousPaymentInSequence(prevPP);
			prevPP = copy->v_paymentPeriod.back();
		}

		return dynamic_pointer_cast<Leg>(copy);
	}

}//namespace