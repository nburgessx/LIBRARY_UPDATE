#pragma once
#ifndef MCPLFLOATINDEX_H
#define MCPLFLOATINDEX_H

#include "mcpldefs.h"
#include "handle.hpp"
#include "mcDateClass/dates.h"

using namespace std;

namespace MCPL
{

class FloatIndex
{
public:
//	FloatIndex() {} 
	FloatIndex(const char * name, CURRENCY ccy, Handle<RatesCurve> dc) : 
		m_FloatIndexName(name),
		m_ccy(ccy),
		m_dc(dc)
	{
		m_floatPeriod = DatePeriod(0, (long)(12.0/str2FloatIndex(name)), 0); // cludge. Doesn't work for i.e. CMS
		m_dc->setDefaults(m_ccy, m_floatPeriod.getMonths());
	}

	FloatIndex(const char * name, CURRENCY ccy, Handle<RatesCurve> dc, shared_ptr<VolatilityGrid> vols) :
		m_FloatIndexName(name),
		m_ccy(ccy),
		m_dc(dc),
		m_vols(vols)
	{
		m_floatPeriod = DatePeriod(0, (long)(12.0/str2FloatIndex(name)), 0); // cludge. Doesn't work for i.e. CMS
		m_dc->setDefaults(m_ccy, m_floatPeriod.getMonths());
	}

	void setDiscountCurve( Handle<RatesCurve> dc )
	{
		m_dc = dc;
		m_dc->setDefaults(m_ccy, m_floatPeriod.getMonths());
	}

	double reset(date & reset_date) 
	{
		return m_dc->forecastFixing( reset_date );
	}

	long getPeriodMonths() { return (long)(m_floatPeriod.getMonths()+12*m_floatPeriod.getYears()); }
	Handle<RatesCurve>  getDiscountCurve() { return m_dc; }

private:
	std::string m_FloatIndexName;
	Handle<RatesCurve> m_dc;
	shared_ptr<VolatilityGrid> m_vols;
	CURRENCY m_ccy;
	DatePeriod m_floatPeriod;

};

} // namespace MCPL

#endif // MCPLFLOATINDEX_H
