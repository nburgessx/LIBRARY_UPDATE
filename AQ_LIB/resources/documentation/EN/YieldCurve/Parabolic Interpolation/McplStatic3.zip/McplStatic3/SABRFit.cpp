#include "SABRFit.h"

#include "AFSabrTest.h"

#include "numrec3/fitmrq.h"

#include "mathmisc.h"
#include "StorageClasses.h"
#include "discountcurve.h"

using namespace numrec3;

namespace MCPL
{

	namespace SABRFitGlobals
	{
		double g_F;
		double g_T;
		double g_bpv;
		vector<OptionType> g_types;
		vector<double> g_strikes;
		vector<double> g_A;
		vector<double> g_B;

		bool		g_CorrectForFlyArb;					// Attempt to correct for butterfly arb in low strikes.
		double	g_FlyStrikeSpacing;					// Spacing between strikes in fly
		double	g_MaxFlyCorrectionStrike;		// Highest strike for which to correct for fly arb.
		double  g_rateShift;

		static double g_perturb = .00001;

		LinearDoubleCurve g_betas;
	}

	using namespace SABRFitGlobals;


	void vols2x(const vector<double> & vol, vector<double> & xvol)
	{

		xvol.resize(4);
		for ( unsigned int i=0 ; i < 4 ; i++ )
		{
			xvol[i] =  tan((vol[i] - g_A[i]) / g_B[i]);
		}

	}

	void vols2x(const SABRParams & vols, vector<double> & xvol)
	{

		xvol.clear();
		xvol.push_back( tan((vols.alpha() - g_A[0]) / g_B[0]) );
		xvol.push_back( tan((vols.beta() - g_A[1]) / g_B[1]) );
		xvol.push_back( tan((vols.nu() - g_A[2]) / g_B[2]) );
		xvol.push_back( tan((vols.rho() - g_A[3]) / g_B[3]) );

	}

	void x2vols(const vector<double> & xvol, vector<double> & vol)
	{

		vol.resize(4);
		for ( unsigned int i=0 ; i < 4 ; i++ )
		{
			vol[i] =  g_A[i] + g_B[i] * atan(xvol[i]);
		}

	}

	//void x2vols(VecDoub_I & xvol, vector<double> & vol)
	//{

	//	vol.resize(4);
	//	for ( unsigned int i=0 ; i < 4 ; i++ )
	//	{
	//		vol[i] =  g_A[i] + g_B[i] * atan(xvol[i]);
	//	}

	//}

	void x2vols(const vector<double> & xvol, SABRParams & vol)
	{
			vol.alpha( g_A[0] + g_B[0] * atan(xvol[0]) );
			vol.beta( g_A[1] + g_B[1] * atan(xvol[1]) );
			vol.nu( g_A[2] + g_B[2] * atan(xvol[2]) );
			vol.rho( g_A[3] + g_B[3] * atan(xvol[3]) );
			vol.CorrectForFlyArb = g_CorrectForFlyArb;
			vol.FlyStrikeSpacing = g_FlyStrikeSpacing;
			vol.MaxFlyCorrectionStrike = g_MaxFlyCorrectionStrike;
			vol.shift(g_rateShift);
	}

	//void x2vols(VecDoub_I & xvol, SABRParams & vol)
	//{
	//		vol.alpha( g_A[0] + g_B[0] * atan(xvol[0]) );
	//		vol.beta( g_A[1] + g_B[1] * atan(xvol[1]) );
	//		vol.nu( g_A[2] + g_B[2] * atan(xvol[2]) );
	//		vol.rho( g_A[3] + g_B[3] * atan(xvol[3]) );
	//}

	void calcABs(const SABRParams & ParameterMin, const SABRParams & ParameterMax)
	{

		g_A.clear();
		g_B.clear();

		g_A.push_back( (ParameterMin.alpha() + ParameterMax.alpha()) / 2.0 );
		g_B.push_back((ParameterMax.alpha() - ParameterMin.alpha()) / Pi );

		g_A.push_back( (ParameterMin.beta() + ParameterMax.beta()) / 2.0 );
		g_B.push_back((ParameterMax.beta() - ParameterMin.beta()) / Pi );

		g_A.push_back( (ParameterMin.nu() + ParameterMax.nu()) / 2.0 );
		g_B.push_back((ParameterMax.nu() - ParameterMin.nu()) / Pi );

		g_A.push_back( (ParameterMin.rho() + ParameterMax.rho()) / 2.0 );
		g_B.push_back((ParameterMax.rho() - ParameterMin.rho()) / Pi );

	}

	void funcLogVol(const Doub di, VecDoub_I &xvol, Doub &price, VecDoub_O &dpdv)
	{
		int i = (int) di;

		if ( xvol.size() != 4 )
			mcpl_error("debug error: need four parameters for SABR vol in SABRFit func");

		//vector<double> vol, dvol;
		SABRParams vol, dvol;

		x2vols(xvol, vol);

		price = SABR_priceFromATMLogVol( g_strikes[i], g_F, g_T, vol, g_bpv, g_types[i]);

		for ( unsigned int j=0 ; j < 4 ; j++ )
		{

			vector<double> dxvol(xvol);
			dxvol[j] += g_perturb;
			x2vols(dxvol, dvol);
			
			double dprice = SABR_priceFromATMLogVol( g_strikes[i], g_F, g_T, dvol, g_bpv, g_types[i]);
			
			dpdv[j] = (dprice - price)/ (dxvol[j] - xvol[j]);
		}

	}

	void LogSABRFitter(const vector<double> &prices, const vector<double> &errors, const vector<double> &strikes, 
		const vector<OptionType> types,	double forwardRate, double timeToExpInYears, SABRParams & vol, 
		double bpv,  const SABRParams & toFit, const SABRParams & volsMin, const SABRParams & volsMax)
	{
		g_F = forwardRate;
		g_T = timeToExpInYears;
		g_bpv = bpv;
		g_types = types;
		g_strikes = strikes;
		g_CorrectForFlyArb = vol.CorrectForFlyArb;
		g_FlyStrikeSpacing = vol.FlyStrikeSpacing;
		g_MaxFlyCorrectionStrike = vol.MaxFlyCorrectionStrike;
		g_rateShift = vol.shift();

		calcABs(volsMin, volsMax);

		VecDoub indeces(strikes.size());
		for ( unsigned int i=0 ; i < strikes.size() ; i++ )
		{
			indeces[i] = (double) i;
		}

		vector<double> xvols, outvols;
		vols2x(vol, xvols);

		VecDoub_I prices_I(prices);
		VecDoub_I ssig_I(errors);
		VecDoub volGuess(xvols);

		Fitmrq fitter(indeces, prices_I, ssig_I, volGuess, funcLogVol);

		if ( toFit.alpha() == 0 )
			fitter.hold(0,xvols[0] );

		if ( toFit.beta() == 0 )
			fitter.hold(1,xvols[1] );

		if ( toFit.nu() == 0 )
			fitter.hold(2,xvols[2] );

		if ( toFit.rho() == 0 )
			fitter.hold(3,xvols[3] );

		fitter.fit();

		x2vols( fitter.a, vol);
	}



	void funcNormalVol(const Doub di, VecDoub_I &xvol, Doub &price, VecDoub_O &dpdv)
	{
		int i = (int) di;

		if ( xvol.size() != 4 )
			mcpl_error("debug error: need four parameters for SABR vol in SABRFit func");

		SABRParams vol, dvol;

		x2vols(xvol, vol);

		price = SABR_priceFromATMNVol( g_strikes[i], g_F, g_T, vol, g_bpv, g_types[i]);

		for ( unsigned int j=0 ; j < 4 ; j++ )
		{

			vector<double> dxvol(xvol);
			dxvol[j] += g_perturb;
			x2vols(dxvol, dvol);
			
			double dprice = SABR_priceFromATMNVol( g_strikes[i], g_F, g_T, dvol, g_bpv, g_types[i]);
			
			dpdv[j] = (dprice - price)/ (dxvol[j] - xvol[j]);
		}

	}

	void NormalSABRFitter(const vector<double> &prices, const vector<double> &errors, const vector<double> &strikes, 
		const vector<OptionType> types,	double forwardRate, double timeToExpInYears, SABRParams & vol, 
		double bpv,  const SABRParams & toFit, const SABRParams & volsMin, const SABRParams & volsMax)
	{
		g_F = forwardRate;
		g_T = timeToExpInYears;
		g_bpv = bpv;
		g_types = types;
		g_strikes = strikes;
		g_CorrectForFlyArb = vol.CorrectForFlyArb;
		g_FlyStrikeSpacing = vol.FlyStrikeSpacing;
		g_MaxFlyCorrectionStrike = vol.MaxFlyCorrectionStrike;
		g_rateShift = vol.shift();

		calcABs(volsMin, volsMax);

		VecDoub indeces(strikes.size());
		for ( unsigned int i=0 ; i < strikes.size() ; i++ )
		{
			indeces[i] = (double) i;
		}

		vector<double> xvols, outvols;
		vols2x(vol, xvols);

		VecDoub_I prices_I(prices);
		VecDoub_I ssig_I(errors);
		VecDoub volGuess(xvols);

		Fitmrq fitter(indeces, prices_I, ssig_I, volGuess, funcNormalVol);

		if ( toFit.alpha() == 0 )
			fitter.hold(0,xvols[0] );

		if ( toFit.beta() == 0 )
			fitter.hold(1,xvols[1] );

		if ( toFit.nu() == 0 )
			fitter.hold(2,xvols[2] );

		if ( toFit.rho() == 0 )
			fitter.hold(3,xvols[3] );

		fitter.fit();

		x2vols( fitter.a, vol);
	}

	void funcAFSABRVol(const Doub di, VecDoub_I &xvol, Doub &price, VecDoub_O &dpdv)
	{
		int i = (int) di;

		if ( xvol.size() != 4 )
			mcpl_error("debug error: need four parameters for SABR vol in SABRFit func");

		SABRParams vol, dvol;

		x2vols(xvol, vol);

		price = AFSabrTest::AFSABR_price( g_strikes[i], g_F, g_T, vol, g_bpv, g_types[i]);

		for ( unsigned int j=0 ; j < 4 ; j++ )
		{

			vector<double> dxvol(xvol);
			dxvol[j] += g_perturb;
			x2vols(dxvol, dvol);
			
			double dprice = AFSabrTest::AFSABR_price( g_strikes[i], g_F, g_T, dvol, g_bpv, g_types[i]);
			
			dpdv[j] = (dprice - price)/ (dxvol[j] - xvol[j]);
		}

	}

	void AFSABRFitter(const vector<double> &prices, const vector<double> &errors, const vector<double> &strikes, 
		const vector<OptionType> types,	double forwardRate, double timeToExpInYears, SABRParams & vol, 
		double bpv,  const SABRParams & toFit, const SABRParams & volsMin, const SABRParams & volsMax)
	{
		g_F = forwardRate;
		g_T = timeToExpInYears;
		g_bpv = bpv;
		g_types = types;
		g_strikes = strikes;

		calcABs(volsMin, volsMax);

		VecDoub indeces(strikes.size());
		for ( unsigned int i=0 ; i < strikes.size() ; i++ )
		{
			indeces[i] = (double) i;
		}

		vector<double> xvols, outvols;
		vols2x(vol, xvols);

		VecDoub_I prices_I(prices);
		VecDoub_I ssig_I(errors);
		VecDoub volGuess(xvols);

		Fitmrq fitter(indeces, prices_I, ssig_I, volGuess, funcAFSABRVol);

		if ( toFit.alpha() == 0 )
			fitter.hold(0,xvols[0] );

		if ( toFit.beta() == 0 )
			fitter.hold(1,xvols[1] );

		if ( toFit.nu() == 0 )
			fitter.hold(2,xvols[2] );

		if ( toFit.rho() == 0 )
			fitter.hold(3,xvols[3] );

		fitter.fit();

		x2vols( fitter.a, vol);
	}


		void funcNormalVolBetas(const Doub di, VecDoub_I &xvol, Doub &price, VecDoub_O &dpdv)
	{
		int i = (int) di;

		if ( xvol.size() != 4 )
			mcpl_error("debug error: need four parameters for SABR vol in SABRFit func");

		SABRParams vol, dvol;

		x2vols(xvol, vol);

		vol.beta(g_betas.get(g_strikes[i]));

		price = SABR_priceFromATMNVol( g_strikes[i], g_F, g_T, vol, g_bpv, g_types[i]);

		for ( unsigned int j=0 ; j < 4 ; j++ )
		{

			vector<double> dxvol(xvol);
			dxvol[j] += g_perturb;
			x2vols(dxvol, dvol);
			
			double dprice = SABR_priceFromATMNVol( g_strikes[i], g_F, g_T, dvol, g_bpv, g_types[i]);
			
			dpdv[j] = (dprice - price)/ (dxvol[j] - xvol[j]);
		}

	}

		void NormalSABRFitterVectorBeta(const vector<double> &prices, const vector<double> &errors, const vector<double> &strikes, 
		const vector<OptionType> types,	double forwardRate, double timeToExpInYears, SABRParams & vol, std::vector<std::pair<double,double>> betas,
		double bpv,  SABRParams toFit, const SABRParams & volsMin, const SABRParams & volsMax)
	{
		g_F = forwardRate;
		g_T = timeToExpInYears;
		g_bpv = bpv;
		g_types = types;
		g_strikes = strikes;
		g_CorrectForFlyArb = vol.CorrectForFlyArb;
		g_FlyStrikeSpacing = vol.FlyStrikeSpacing;
		g_MaxFlyCorrectionStrike = vol.MaxFlyCorrectionStrike;
		g_betas = LinearDoubleCurve(betas);
		toFit.beta(0); //Force no beta fitting
		calcABs(volsMin, volsMax);

		VecDoub indeces(strikes.size());
		for ( unsigned int i=0 ; i < strikes.size() ; i++ )
		{
			indeces[i] = (double) i;
		}

		vector<double> xvols, outvols;
		vols2x(vol, xvols);

		VecDoub_I prices_I(prices);
		VecDoub_I ssig_I(errors);
		VecDoub volGuess(xvols);

		Fitmrq fitter(indeces, prices_I, ssig_I, volGuess, funcNormalVol);

		if ( toFit.alpha() == 0 )
			fitter.hold(0,xvols[0] );

		if ( toFit.beta() == 0 )
			fitter.hold(1,xvols[1] );

		if ( toFit.nu() == 0 )
			fitter.hold(2,xvols[2] );

		if ( toFit.rho() == 0 )
			fitter.hold(3,xvols[3] );

		fitter.fit();

		x2vols( fitter.a, vol);
	}



		void funcAlphaVol(const Doub di, VecDoub_I &xvol, Doub &price, VecDoub_O &dpdv)
	{
		int i = (int) di;

		if ( xvol.size() != 4 )
			mcpl_error("debug error: need four parameters for SABR vol in SABRFit func");

		SABRParams vol, dvol;

		x2vols(xvol, vol);

		price = SABR_price( g_strikes[i], g_F, g_T, vol, g_bpv, g_types[i]);

		for ( unsigned int j=0 ; j < 4 ; j++ )
		{

			vector<double> dxvol(xvol);
			dxvol[j] += g_perturb;
			x2vols(dxvol, dvol);
			
			double dprice = SABR_price( g_strikes[i], g_F, g_T, dvol, g_bpv, g_types[i]);
			
			dpdv[j] = (dprice - price)/ (dxvol[j] - xvol[j]);
		}

	}

	void AlphaSABRFitter(const vector<double> &prices, const vector<double> &errors, const vector<double> &strikes, 
		const vector<OptionType> types,	double forwardRate, double timeToExpInYears, SABRParams & vol, 
		double bpv,  const SABRParams & toFit, const SABRParams & volsMin, const SABRParams & volsMax)
	{
		g_F = forwardRate;
		g_T = timeToExpInYears;
		g_bpv = bpv;
		g_types = types;
		g_strikes = strikes;
		g_CorrectForFlyArb = vol.CorrectForFlyArb;
		g_FlyStrikeSpacing = vol.FlyStrikeSpacing;
		g_MaxFlyCorrectionStrike = vol.MaxFlyCorrectionStrike;

		calcABs(volsMin, volsMax);

		VecDoub indeces(strikes.size());
		for ( unsigned int i=0 ; i < strikes.size() ; i++ )
		{
			indeces[i] = (double) i;
		}

		vector<double> xvols, outvols;
		vols2x(vol, xvols);

		VecDoub_I prices_I(prices);
		VecDoub_I ssig_I(errors);
		VecDoub volGuess(xvols);

		Fitmrq fitter(indeces, prices_I, ssig_I, volGuess, funcAlphaVol);

		if ( toFit.alpha() == 0 )
			fitter.hold(0,xvols[0] );

		if ( toFit.beta() == 0 )
			fitter.hold(1,xvols[1] );

		if ( toFit.nu() == 0 )
			fitter.hold(2,xvols[2] );

		if ( toFit.rho() == 0 )
			fitter.hold(3,xvols[3] );

		fitter.fit();

		x2vols( fitter.a, vol);
	}

}