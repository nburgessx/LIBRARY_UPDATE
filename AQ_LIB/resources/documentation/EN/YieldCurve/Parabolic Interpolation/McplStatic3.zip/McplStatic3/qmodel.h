#pragma once
#ifndef MCPLQMODEL_H
#define MCPLQMODEL_H

#include "mcpldefs.h"
#include "option.h"

#include <math.h>

//using namespace std;

namespace MCPL
{

double qmodel(double strike, double forward, double T, double vol, double df, double q, OptionType type);
double qmodelVega(double strike, double forward, double T, double vol, double df, double q, OptionType type);
double qmodelDelta(double strike, double forward, double T, double vol, double df, double q, OptionType type);

double n2qATMvol(double forward, double t, double nvol, double q);
double b2qATMvol( double t, double nvol, double q);
double q2nATMvol(double forward, double t, double qvol, double q);
double q2bATMvol( double t, double qvol, double q);

double qImpVol(double targetPrice, double strike, double forward, double T, double df, double q, OptionType type);



} // namespace MCPL

#endif // MCPLQMODEL_H