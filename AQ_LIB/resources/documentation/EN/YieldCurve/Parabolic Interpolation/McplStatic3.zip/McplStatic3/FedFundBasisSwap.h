#pragma once

#ifndef MCPLFEDFUNDBASISSWAP_H
#define MCPLFEDFUNDBASISSWAP_H
#pragma warning ( disable : 4251 4786 ) 

#include "mcpldefs.h"
#include "mathmisc.h"
#include "option.h"
#include "Swap.h"
#include "OISLeg.h"
#include "mcDateClass/dates.h"

using namespace std;
#include<string>
#include<vector>


namespace MCPL
{
	/* the asset swap class is a child of the swap class */
	class FedFundBasisSwap : public Swap
	{	
	public :
		//constructors
		FedFundBasisSwap() {}


		//OIS swap no curves
		FedFundBasisSwap(DIRECTIONTYPE dir, date & start, date & mature, double notional, double FedFundsSpread,
		const int rollDay, ROLLTYPE rolltype, long int FFPmtsPerYear, long int FloatPmtsPerYear, DayBasis FFBasis, DayBasis FloatBasis, 
		HOLIDAYCAL hol, CURRENCY ccy );

		// Solve for spread. legToSolveFor has to be either 0 or 1.
		virtual double Solve(double dPresentValue = 0);

		void fixFirst(double rate);
	private:


	};

}

#endif // MCPLFEDFUNDBASISSWAP_H
