#pragma once

#ifndef MCPLDEFAULTS_H
#define MCPLDEFAULTS_H
#include "MCPL.h"

namespace MCPL
{

class defaults
{
public:
	defaults(void) :
	  m_match_apollo(false),
	  m_cms_adjust(false) 
	  {}

	  ~defaults(void) {}

	// gets
	bool match_apollo() { return m_match_apollo; }
	bool cms_adjust() { return m_cms_adjust; }

	//sets
	bool match_apollo(bool m) { return m_match_apollo = m; }
	bool cms_adjust(bool c)   { return m_cms_adjust = c; }


private:

	bool m_match_apollo;
	bool m_cms_adjust;
};

} // namespace

#endif // MCPLDEFAULTS_H