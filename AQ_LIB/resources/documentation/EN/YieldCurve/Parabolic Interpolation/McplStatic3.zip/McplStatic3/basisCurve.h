#pragma once
#ifndef MCPLBASISCURVE_H
#define MCPLBASISCURVE_H
#include "MCPL.h"

#include<string>
#include<vector>

#include "mcpldefs.h"
#include "storageclasses.h"
#include "discountCurve.h"
#include "RatesCurve.h"
#include "rateHelpers.h"
//#include "PPCurves.h"

using namespace std;

namespace MCPL
{



	/********************************************************************
	a class which contains a zero curve (which can interpolate between
	dates) and a simple string to double map
	********************************************************************/

	class basisCurve : public RatesCurve
	{
	private:

		date _today;
		date _spot;
		DayBasis m_basis;
		CURRENCY m_ccy;

		unsigned m_period_months;
		HOLIDAYCAL m_hols;

		Handle<RatesCurve> _discountCurve;

		unsigned int _firstNonCashIndex;

		vector<Handle<CurveRateHelper>>	_instruments;
		Handle<CurveRateHelper>		_ONCash;
		Handle<CurveRateHelper>		_Cash;
		vector<Handle<CurveRateHelper>> _futures;
		vector<Handle<CurveRateHelper>> _swaps;

		vector<Handle<RatesCurve>>	_dependentCurves;	// Curves that depend on this curve for construction/pricing.
		//	ForecastCurveType m_type; // CMS or LIBOR

		virtual void dummy() {} // Make this a polymorphic object, so dynamic_cast works.

		void calculateCurve();
		void calculateDates();

		void addDependent(Handle<RatesCurve> dependentCurve_);
		bool instrumentsChanged(const vector<Handle<CurveRateHelper>> &Instruments);
		void set_currency_defaults(CURRENCY ccy);

		double getRateFromDF(date& effDate_, date& matDate_, DayBasis basis_);
		void addFlatFwdRate(date& effDate_, date& matDate_, double rate_, DayBasis basis_);
		void addLinearFwdRate(date& effDate_, date& matDate_, double rate_, DayBasis basis_);
		void basisCurve::addLinearBasis(date& effDate_, double basisRate_);

		// fitter functions
		//Handle<CurveRateHelper> _fittingInstrument;
		double basisCurve::swapsFitter(double basis_, date& testDt, Handle<CurveRateHelper> swap);

		shared_ptr<SmoothFwdCurve> _basisSpread;

	public:

		basisCurve() : m_ccy(USD), m_period_months(3)
		{
			m_basis = getLiborBasis(m_ccy);
			m_hols = liborHolidays(m_ccy);
			_basisSpread = shared_ptr<SmoothFwdCurve>(new SmoothFwdCurve());
			_basisSpread->setFlatVol(SmoothFwdInterpolatorData(0));
		} // Default curve is 3m $LIBOR

		basisCurve(const basisCurve& crv) : 
			m_ccy(crv.m_ccy), 
			m_period_months(crv.m_period_months),
			m_basis(crv.m_basis),
			m_hols(crv.m_hols),
			_basisSpread(crv._basisSpread)
		{
			_discountCurve = crv._discountCurve->clone();
		}

		virtual Handle<RatesCurve> clone() { return Handle<basisCurve>(new basisCurve(*this)); }

		void create(const vector<Handle<CurveRateHelper>> &Instruments,
			date & today, CURRENCY ccy, Handle<RatesCurve> swapDiscountCurve = Handle<RatesCurve>());

		virtual void clear()
		{
			_basisSpread->clear();
		}

		//void partialClear() { clear(); }

		//Doesn't clear basis spread data. Gets called from create_PP
		void partialClear()
		{
		}

		double getZero(const date & d1, const date & d2, DayBasis basis); // forward rate from d1 to d2
		double getZero(const date & d1, const date & d2) { return getZero(d1, d2, m_basis); } // forward rate from d1 to d2

		// Get continuously compounded rate
		double getCCRate(date & d1, date & d2, DayBasis basis);

		double forecastFixing(date & reset_date);

		double getDiscountFactor(const date & d) { return _discountCurve->getDiscountFactor(d); }
		double getRatesDiscountFactor(const date & d) { mcpl_error("Not implemented yet in basisCurve"); return 0; }
		DayBasis getDayBasis() { return m_basis; }
		CURRENCY getCurrency() { return m_ccy; }

		void setDiscountFactor(date & d, double value) { mcpl_error("can't manually set a discount factor in a basisCurve"); }
		void setDayBasis(DayBasis basis) { m_basis = basis; }
		void setCurrency(CURRENCY ccy) { m_ccy = ccy; }

		void setDefaults(CURRENCY ccy, unsigned p)
		{
			m_basis = getLiborBasis(ccy);
			m_hols = liborHolidays(ccy);
			m_period_months = p;
		}

		//void setBasisCurve(std::map<date, double> & basisSpread)
		//{
		//	m_basisSpread.clear();
		//	for (auto& bs : basisSpread)
		//		m_basisSpread.set(bs.first, bs.second);
		//}

		shared_ptr<SmoothFwdCurve> getBasisCurve() { return _basisSpread; }

		//typedef discountCurve::labels labels;
		//labels getZeroLabels() { return getLabels(); }
		//labels getDiscountFactorLabels() { return _discountCurve->getLabels(); }

		date firstDate() { return _discountCurve->firstDate(); }//Incomplete!!
		date lastDate() { return _discountCurve->lastDate(); }//Incomplete!!
		void shiftCurve(double dR, DayBasis basis) { _discountCurve->shiftCurve(dR, basis); } //Incomplete!!

		shared_ptr<vector<long>> getLabels() { return _discountCurve->getLabels(); }//Incomplete!!
		//Handle<PPCurves>  create_PPCurves(double pp_val, bool CalculateGammaCurves = true) {};
	};

	//typedef RatesCurveWrapper<swapData> swapData2;

	/*
	class swapData
	{
	private:


	mutable discountCurve m_discountCurve;

	public:


	double getZero(date & d1, date & d2, DayBasis basis); // forward rate from d1 to d2


	double getDiscountFactor(date & d) { return m_discountCurve.get(d); }
	void setDiscountFactor(date & d, double value) { m_discountCurve.set(d, value); }

	typedef discountCurve::labels labels;
	labels getZeroLabels() { return m_discountCurve.getLabels(); }
	labels getDiscountFactorLabels() { return m_discountCurve.getLabels(); }

	void clear() { 	m_discountCurve.clear(); }

	};
	*/

} //namespace MCPL

#endif //MCPLBASISCURVE_H