#pragma once
#ifndef MCPLLINEARCURVESHELPERS_H
#define MCPLLINEARCURVESHELPERS_H

#include <functional>

#include "MCPL.h"
#include "mcpldefs.h"

using namespace std;

namespace MCPL
{

	double linearFitter(std::function<double (double)> func, double x1, double x2, double tol);
	// multi-dimensional Newton-Raphson assuming diagonal Jacobian matrix
	int    multiDummyFitter(std::function<void (const vector<double>&, vector<double>& )> func, int n, double x_lo, double x_hi, double tol);
	//
	void   swapPoints(double & x1, double & y1, double & x2, double & y2);

	//
	void   pointSorter(double & x1, double & y1, double & x2, double & y2, double & x3, double & y3);
	//
	double quadraticFitter(std::function<double(double)> func, double x1, double x3, double tol, int maxiterations = 5);

} // namespace MCPL

#endif // MCPLLINEARCURVESHELPERS_H