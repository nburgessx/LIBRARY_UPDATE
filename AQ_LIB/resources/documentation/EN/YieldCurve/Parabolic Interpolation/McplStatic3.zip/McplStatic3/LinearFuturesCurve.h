#pragma once
#ifndef MCPLLINEARFUTURESCURVE_H
#define MCPLLINEARFUTURESCURVE_H

#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "discountcurve.h"
#include "PPCurves.h"
#include "Swap.h"
#include "numrec/dnr.h"
#include "LinearCurvesHelpers.h"

using namespace std;

namespace MCPL
{

	namespace LinearFuturesCurveFitFn
	{
		double func_linear(double drop);
	}
		
	namespace LinearFuturesCurveMinFn
	{
		double func_minimise(double adjustment);
	}

	namespace LinearFuturesCurveNDimMinFn
	{
		double func_minimise(double adjustment[]);
	}

	class LinearFuturesCurve : public swapData
	{
	public:
		// constructors
		LinearFuturesCurve() : m_curveGood(false) {}


	void LinearFuturesCurve::create( const vector<double> & futures, const LinearCurve & adjustments, 
		const vector<date> swapDates, const vector<double> & swapRates, const vector<double> & swapTolerances,
		const SwapType sType,
		date & today, date & firstFut, const map<date,double> & cashParams, CURRENCY ccy, double fitfactor);
		//void create( const vector<double> & futures, const LinearCurve & adjustments, 
		//	const map<date,double> & swaps, const SwapType sType,
		//	date & today, date & firstFuture, const map<date,double> & cash, CURRENCY ccy, double fitFactor);

		// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
		Handle<PPCurves>  create_PPCurves(  double pp_val );

	private:

		void set_currency_defaults(CURRENCY);
		void set_currency_defaults(CURRENCY, SwapType);

		DayBasis m_basis;
		CURRENCY m_ccy;

		long int m_fixedPmtsPerYear;
		long int m_fltPmtsPerYear;
		DayBasis m_fixedBasis;

		date m_today;
		date m_spot;

		date m_1stFut;

		bool							m_curveGood;					// Is the curve in a good state?

		HOLIDAYCAL				m_hols;								// holiday cal for the futures
		HOLIDAYCAL				m_swapHols;						// holiday cal for the swaps

		SwapType					m_swapType;
		dateVec						m_starts;							// start of IMM period
		dateVec						m_ends;								// ends of IMM periods
		LinearCurve				m_InputAdjustments;		// A linearly interpolable curve for conv adjustments.
		//vector<double>		m_adjustments;				// convexity adjustments in bp
		vector<double>		m_futures;						// future prices
		int								m_nInputFutures;			// Number of input futures
		vector<double>		m_PDCF;								// IMM period day count fraction

		double						m_lastDrop;						// drop of last (four) input futures.
		double						m_fitfactor;
		long							m_firstUsedSwapIndex;	//The index in m_parRates of the first swap to be used (this first swap is priced using futs though!)
		long							m_lastUsedSwapIndex;  // The index of the last used swap in m_swapCashflows
		vector<double>		m_parRates;						// swap par points
		//vector<double>		m_swapTenors;					// swap tenors
		vector<double>		m_swapTolerances;			// Tolerance for fit of swap rate.
		//map<date, double>	m_swapParams;					// Swap maturity - rate pairs.
		vector<date>			m_swapLastDates;			// swap last dates
		vector<date>			m_swapDFDates;				// dates on which we set the discount factor.
		vector<Swap>			m_swapCashflows;			// the swaps we actually use, one per fixed pmt period
		vector<Leg>				m_cashflows;					// the cashflows we actually use, one per fixed pmt period
		vector<double>		m_swapAdjustments;		// swap tenors
		vector<double>		m_linFutsPriceDrops;	// Drops between the futures prices. One for each swap par rate. This is what we solve for. 
		vector<int>				m_linFutsSwapIndex;		// // Index of first fut with mat date > swap[-1]'s mat date

		map<date, double>	m_cashParams;					// cash maturity - rate pairs.

		void calculateCurve();
		void calculateCurveFromFutures();
		void calculateDates();
		void calcFuturesFromSwaps(int index);

		bool cmpvecs( const vector<double> & v1, const vector<double> & v2);
		bool cmpvecs( const vector<date> & v1, const vector<date> & v2);
		bool cmpmaps( const map<date,double> & v1, map<date,double> & v2);

		bool fitFuturesDrops(int index);
		bool fitSwapAdjs(int index);
		bool fitNDimSwapAdjs();

		void generateSwapVectors();
		void generateSwapRateVector();

		friend double LinearFuturesCurveFitFn::func_linear(double);
		friend double LinearFuturesCurveMinFn::func_minimise(double);
		friend double LinearFuturesCurveNDimMinFn::func_minimise(double[]);

	};

} // namespace MCPL

#endif // MCPLLINEARFUTURESCURVE_H