#include "qmodel.h"

#include "blackmodel.h"
#include "mathmisc.h"

#include "numrec/dnr.h"

using namespace NUMREC;

namespace MCPL
{

double qmodel(double strike, double forward, double T, double vol, double df, double q, OptionType type)
{

	if ( (T <= 0) || ( vol <= 0 ) ) 
		return df * intrinsicValue(strike, forward, type);

	// if q=0, we have singularity issues, but qmodel should become normal, so use that.
	if ( q == 0 ) 
		return blackNormal(strike, forward, T, BlackVol(q2nATMvol(forward, T, vol, q),0), df, type);

	double rootT	= sqrt(T);
		
	double sigmaRootT = vol*rootT;

    double d1 = (sigmaRootT*sigmaRootT * q/2.0 + (1.0/q) * log(forward/(q*strike+(1-q)*forward) ) ) / sigmaRootT;
    double d2 = d1 - q*sigmaRootT;
  

	double Nd1 = N(d1);
	double Nd2 = N(d2);

	double Price;
		
	if (type == Call)
	{
		Price = df * (forward/q*Nd1 - (strike-forward*(q-1)/q) * Nd2 );
	}
	else if (type == Put)
	{
		Price = df * ( (strike-forward*(q-1)/q)*(1-Nd2) - forward/q*(1-Nd1) );
	}
	else if (type == Straddle)
	{
		Price = df * (forward/q*(2.0*Nd1-1) - (strike-forward*(q-1)/q)*(2.0*Nd2-1) );
	}
	else
	{
		MCPL_ERROR errMsg = "qmodel cannot price this type of option";
		throw errMsg;
	}
		
	return __max(Price, 0.0);

}

double qmodelDelta(double strike, double forward, double T, double vol, double df, double q, OptionType type)
{
	// if T=0, return 0 or 100% delta
	if ( T<=0 ) 
  {
		if ( inTheMoney(strike, forward, type) ) 
			return df * (type == Call ? 1 : -1);
		else 
			return(0);
	}

	// if q=0, we have singularity issues, but qmodel should become normal, so use that.
	if ( q == 0 ) 
		return blackNormal(strike, forward, T, BlackVol(q2nATMvol(forward, T, vol, q),0), df, type);

	double sigmaRootT = vol*sqrt(T);

    double d1 = (sigmaRootT*sigmaRootT * q/2.0 + (1.0/q) * log(forward/(q*strike+(1-q)*forward) ) ) / sigmaRootT;
    double d2 = d1 - q*sigmaRootT;
  

	double Nd1 = N(d1);
	double Nd2 = N(d2);

	double delta;
		
	if (type == Call)
	{
		delta = df * (Nd1 + (q-1)*Nd2)/q;
	}
	else if (type == Put)
	{
		delta = df * ((Nd1-1) + (q-1)*(Nd2-1))/q;
	}
	else if (type == Straddle) // Call + Put
	{
		delta = df * (2.0*Nd1 - 1.0 + 2.0*(q-1)*Nd2 - (q-1))/q;
	}
	else
	{
		MCPL_ERROR errMsg = "q model cannot price this type of option";
		throw errMsg;
	}
		
	return delta;

}


double qmodelVega(double strike, double forward, double T, double vol, double df, double q, OptionType type)
{

	if ( T==0) return 0;

	// if q=0, we have singularity issues, but qmodel should become normal, so use that.
	if ( q == 0 ) 
		return blackNormalVega(strike, forward, T, BlackVol(q2nATMvol(forward, T, vol, q),0), df, type);

	double rootT = sqrt(T);
	double sigmaRootT = vol*rootT;

    double d1 = (sigmaRootT*sigmaRootT * q/2.0 + (1.0/q) * log(forward/(q*strike+(1-q)*forward) ) ) / sigmaRootT;
	double dNd1 = exp(-d1*d1/2) / (root2Pi);

	double vega;
		
	if (type == Call)
	{
		vega = df * forward * dNd1 * rootT;
	}
	else if (type == Put)
	{
		vega = df * forward * dNd1 * rootT;
	}
	else if (type == Straddle) // Call + Put
	{
		vega = 2.0 * df * forward * dNd1 * rootT;
	}
	else
	{
		MCPL_ERROR errMsg = "qmodel cannot find vega for this type of option";
		throw errMsg;
	}
		
	return vega;

}


double n2qATMvol(double forward, double t, double nvol, double q)
{
	if ( nvol == 0 ) return 0;
	double sqrtt = sqrt(t);
	return ppnd((q*nvol*sqrtt/root2Pi+forward)/(2.0*forward))*2.0/(q*sqrtt);
}


double b2qATMvol( double t, double lvol, double q)
{
	if ( lvol == 0 ) return 0;
	double sqrtt = sqrt(t);
	return ppnd( (1.0-q)/2.0 + q*N(lvol*sqrtt/2.0) ) * 2.0/(q*sqrtt);
}

double q2nATMvol(double forward, double t, double qvol, double q)
{
	if ( qvol == 0 ) return 0;
	double sqrtt = sqrt(t);
	return ( forward * root2Pi / (q*sqrtt) * ( 2.0 * N(qvol * sqrtt * q/2.0) - 1) );
}


double q2bATMvol( double t, double qvol, double q)
{
	if ( qvol == 0 ) return 0;
	double sqrtt = sqrt(t);
	return ppnd( (N(q*qvol*sqrtt/2.0) - (1-q)/2.0)/q ) * 2.0/sqrtt;
}

// Numerical fitting routines.  - find implied vols.
// globals for the NR routines
static double g_target, g_strike, g_forward, g_T, g_vol, g_df, g_q;
static OptionType g_type;

double qImpVol_fn(double vol)
{
	return g_target - qmodel(g_strike , g_forward , g_T, vol, g_df, g_q, g_type);
}

void qImpVol_fitfn(double vol, double & price, double & vega)
{
		price = qImpVol_fn(vol);
		vega = qmodelVega(g_strike , g_forward , g_T, vol, g_df, g_q, g_type);
}


double qImpVol(double targetPrice, double strike, double forward, double T, double df, double q, OptionType type)
{
	if ( T == 0 ) return .0001;

	const double TOL = 1e-8;

	g_target = targetPrice;
	g_strike = strike;
	g_forward = forward;
	g_T = T;
	g_df = df;
	g_q = q;
	g_type = type;

	double x1 = 0;
	double x2 = 1;
	NUMREC::zbrac(qImpVol_fn, &x1, &x2);

	double vol = dtsafe( qImpVol_fitfn, x1,x2, TOL);

	return vol;
}


} // namespace MCPL

