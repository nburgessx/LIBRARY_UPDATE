#pragma once
#ifndef ONEFACTORMIXED_H
#define ONEFACTORMIXED_H
#pragma warning ( disable : 4251 4786 ) 
#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "swap.h"
#include "volatilityGrid.h"

#include<string>
#include<vector>


using namespace std;

namespace MCPL
{

class oneFactorMixed
{
public:
 
	// Constructors.
	oneFactorMixed() {}

	oneFactorMixed( DIRECTIONTYPE dir, date & priceto, date & start, date & first, date & mature, date & roll, bool longCoupon, double notional,  
				 double spread, double spreadStep ,long int fixedPmtsPerYear, long int fltPmtsPerYear, 
				 double strike, double strikeStep, long int noticeDays, long int lockout,	long int calls,
				 DayBasis fixedBasis, DayBasis floatBasis, double stepsize, long int nsteps, long int trunc,
				 Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, VolatilityGrid & volGrid, double mixing, HOLIDAYCAL hol);

	oneFactorMixed(const vector<double> & pforwards, const vector<double> & pstrikes, const vector<double> & pLVols, 
		const vector<double> & pNVols, const vector<double> & pnumeraires, const double pstepsize, const long int ptrunc,
		const long int pnumberOfSteps, const long int ppayerOrReceiver, const double mixing);

	void setup(const vector<double> & pforwards, const vector<double> & pstrikes, const vector<double> & pNVols, const vector<double> & pLVols,
						const vector<double> & pnumeraires, const double pstepsize, const long int ptrunc, const long int pnumberOfSteps,
						const long int ppayerOrReceiver, const double pmixing);


	dateVec & getExerciseDates() { return m_exerciseDates; }
	dateVec & getStartDates() { return m_ULstartDates; }
	vector<bool> & getExercise() { return m_exercise; }

	vector<double> & getNumeraires() { return m_numeraires; }
	vector<double> & getStrikes() { return m_strikes; }
	vector<double> & getForwards() { return m_forwards; }
	vector<double> & getVariances() { return m_forwardNVols; }

	double getUnderlyerPV() { return m_ULPV; }

	// Destructor. (Frees up allocated memory)
	//~oneFactor();


	double priceStructure();


private:

	double m_mixing;

	vector<double> m_numeraires;
	vector<double> m_forwards;
	vector<double> m_strikes;
	vector<double> m_forwardNVols;
	vector<double> m_forwardLVols;

	dateVec m_exerciseDates ,m_startDates , m_ULstartDates;
	vector<bool> m_exercise;
	
	double m_ULPV;

	
	double approxPV(int i, int trunc, double vol, double forward);
	void calculateLogProbabilities(double volatilities,double stepsize,long numberOfSteps,long trunc);
	void calculateNormalProbabilities(double volatilities,double stepsize,long numberOfSteps,long trunc);

	int m_nDates;
	int m_numberOfSteps;
	int m_trunc;
	int m_payerOrReceiver;  // this is -1 or 1, depending on whether we have a put or a call.

	double m_stepsize;

	vector<double> m_futureValues;
	vector<double> m_presentValues;
	vector<double> m_logTransitionProbabilities;


};


} // Namespace MCPL

#endif // ONEFACTORMIXED_H