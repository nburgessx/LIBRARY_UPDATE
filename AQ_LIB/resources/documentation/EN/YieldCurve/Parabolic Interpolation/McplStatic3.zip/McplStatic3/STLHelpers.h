#pragma once
#include <algorithm>
#include <vector>
#include "handle.hpp"

namespace MCPL
{


		template < class vec , class elem>
	inline bool contains(vec &v, elem &e)
	{
		return (find(v.begin(), v.end(), e) != v.end());
	}

	template<class container, class UnaryPredicate>
  inline bool contains_if (container& v, UnaryPredicate& pred)
	{
		return (find_if(v.begin(), v.end(), pred) != v.end());
	}


	//Use this one if you have a vector of intrinsic types.
	template < class vec , class elem>
	inline bool contains2(vec &v, elem e)
	{
		return (find(v.begin(), v.end(), e) != v.end());
	}

	template< class elem >
	bool containsAnyOf(vector<elem>& vec1, vector<elem>& vec2)
	{
		for ( vector<elem>::iterator it = vec2.begin() ; it != vec2.end() ; it++ )
		{
			if ( contains(vec1, *it) )
				return true;
		}
		return false;
	}



	template< class elem1, class selectpred, class sortpred>
	Handle<vector<Handle<elem1>>> copyAndSort(vector<Handle<elem1>>& arr, selectpred sel, sortpred srt)
	{
		Handle<vector<Handle<elem1>>> ret;
		copy_if(arr.begin(), arr.end(), ret->begin() , sel);
		sort(ret->begin(), ret->end(), srt);

		return ret;
	}

	
}