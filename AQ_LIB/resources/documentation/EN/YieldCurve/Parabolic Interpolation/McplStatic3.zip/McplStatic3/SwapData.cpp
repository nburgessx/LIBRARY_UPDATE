#include "SwapData.h"

namespace MCPL
{

	double swapData::getZero(const date & d1, const date & d2, DayBasis basis)
	{
		double DF1, DF2, dcf, rate;

		DF1 = getDiscountFactor(d1);
		DF2 = getDiscountFactor(d2);
		dcf = dayCountFrac(basis, d1, d2);
		rate = dcf==0 ? 0 : zero(DF2/DF1, dcf);
		rate += m_basisSpread.get(d1);

		return rate;
	}

	// Get continuously compounded rate
	double swapData::getCCRate(date & d1, date & d2, DayBasis basis)
	{
		double DF1, DF2, dcf, rate;

		DF1 = getDiscountFactor(d1);
		DF2 = getDiscountFactor(d2);
		dcf = dayCountFrac(basis, d1, d2);

		rate = dcf==0 ? 0 : (log( DF1/DF2 ) / dcf);

		rate += m_basisSpread.get(d1);

		return rate;
	}

	double swapData::forecastFixing(date & reset)
	{
		date spotdate = spot( reset , m_ccy) ;
		return getZero( spotdate, addBusinessMonths(spotdate, m_period_months, m_hols, false), m_basis);
	}


	

} // namespace 