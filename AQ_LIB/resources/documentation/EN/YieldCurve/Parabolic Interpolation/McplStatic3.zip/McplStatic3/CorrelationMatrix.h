#pragma once

#ifndef CorrelationMatrix_H
#define CorrelationMatrix_H

#pragma warning ( disable : 4251 4786 ) 

#include "MCPL.h"
#include "mcDateClass/dates.h"
#include "mcDataClasses/matrix.h"



using namespace std;

namespace MCPL
{

	class CorrelationMatrix : public Matrix<double>
	{
	public:

		typedef enum{ GAUSSIAN, HISTORICAL, EXPONENTIAL, FLAT } SpreadOptionRhoModel;

		CorrelationMatrix(const Matrix<int>& ndays, double CorrelationDecayCoeff = 0.75);



		SpreadOptionRhoModel getCorrelationModel() const { return f_correlationModel; }
		void setCorrelationModel(SpreadOptionRhoModel model) { f_correlationModel = model; }

		double getCorrelationDecayCoeff() const { return f_correlationDecayCoeff; }
		void setCorrelationDecayCoeff(double coeff) { f_correlationDecayCoeff = coeff; }


	private:

		double f_correlationDecayCoeff;
		SpreadOptionRhoModel f_correlationModel;

		void generateCorrMatrix(const Matrix<int>& ndays);

		double get_fwd_rate_correl(int start1, int end1, int start2, int end2);

		double get_fwd_rate_correl_GAUSSIAN(int start1, int end1, int start2, int end2);

		double get_fwd_rate_correl_EXPONENTIAL(int start1, int end1, int start2, int end2);

		double get_fwd_rate_correl_FLAT(int start1, int end1, int start2, int end2);

		double get_fwd_rate_correl_HISTORICAL(int start1, int end1, int start2, int end2);

	};


} // Namespace MCPL

#endif // CorrelationMatrix_H