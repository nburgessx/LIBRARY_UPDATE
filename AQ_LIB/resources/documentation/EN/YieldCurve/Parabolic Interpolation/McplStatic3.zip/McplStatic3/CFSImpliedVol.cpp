#include "CFSImpliedVol.h"

using namespace NUMREC;

namespace MCPL
{

	//namespace CFSImpliedLogVolFns
	//{
	//	// globals for the NR routines
	//	static double g_target;
	//	static double g_RatesShift;
	//	static Leg g_cfs;

	//	double CFSImpVol_fn(double vol)
	//	{
	//		g_cfs.getCapVols()->set(BlackVol(vol,g_RatesShift));
	//		g_cfs.updatePaymentsFromCurves();

	//		return g_target - g_cfs.Price();
	//	}

	//	void blackImpVol_fitfn(double vol, double & price, double & vega)
	//	{
	//		price = CFSImpVol_fn(vol);

	//		vega = g_cfs.Vega();
	//	}

	//}

	double CFSImpliedLogVol(Leg & cfs, double targetPrice, BlackVol volguess)
	{

		const double TOL = 1e-8;

		/*CFSImpliedLogVolFns::g_target = targetPrice;
		CFSImpliedLogVolFns::g_cfs = cfs;
		CFSImpliedLogVolFns::g_RatesShift = volguess.rateShift;*/

		double x1 =  volguess.vol * .8;
		double x2 = volguess.vol * 1.2;
		auto fn = [&](double vol)
		{ 
			cfs.getCapVols()->set(BlackVol(vol, volguess.rateShift));
			cfs.updatePaymentsFromCurves();
			return targetPrice - cfs.Price(); 
		};

		auto fitfn = [&](double vol, double & price, double & vega){price = fn(vol); vega = cfs.Vega(); };

		if (!NUMREC::zbrac(fn, &x1, &x2))
			mcpl_error("COuld not find a solution in CFSImpliedLogVol");

		double vol = dtsafe( fitfn, x1, x2, TOL);

		return vol;
	}

} // namespace