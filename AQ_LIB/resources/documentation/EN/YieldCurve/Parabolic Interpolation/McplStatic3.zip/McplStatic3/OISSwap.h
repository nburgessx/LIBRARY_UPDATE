#pragma once

#ifndef MCPLOISSWAP_H
#define MCPLOISSWAP_H
#pragma warning ( disable : 4251 4786 ) 

#include "mcpldefs.h"
#include "mathmisc.h"
#include "option.h"
#include "Swap.h"
#include "OISLeg.h"
#include "mcDateClass/dates.h"

using namespace std;
#include<string>
#include<vector>


namespace MCPL
{
	/* the asset swap class is a child of the swap class */
	class OISSwap : public Swap
	{	
	public :
		//constructors
		OISSwap() {}


		//OIS swap no curves
		OISSwap(DIRECTIONTYPE dir, const date & start, const date & mature, double notional, double coupon, double FltSpread,
			int rollDay, ROLLTYPE rolltype,
		  long int OISPmtsPerYear, long int FixedPmtsPerYear, DayBasis OISBasis, DayBasis FixedBasis, HOLIDAYCAL hol, 
			CURRENCY ccy, MCPL::ACCRUAL_TYPE accrualType = ACCRUAL_FLAT_COMPOUNDING );

		OISSwap(DIRECTIONTYPE dir, const date & start, const date & mature, double notional, double coupon, double FltSpread,
			int rollDay, ROLLTYPE rolltype,
		  long int OISPmtsPerYear, long int FixedPmtsPerYear, DayBasis OISBasis, DayBasis FixedBasis, HOLIDAYCAL hol, 
			CURRENCY ccy, int pmtOffsetDays_, MCPL::ACCRUAL_TYPE accrualType = ACCRUAL_FLAT_COMPOUNDING );

		virtual double OISSwap::Solve(double dPresentValue = 0);

	private:


	};

}

#endif // MCPLOISSWAP_H
