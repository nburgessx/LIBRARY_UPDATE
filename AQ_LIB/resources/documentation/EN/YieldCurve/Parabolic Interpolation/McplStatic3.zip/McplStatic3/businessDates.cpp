#include "businessDates.h"
#include <algorithm>

namespace MCPL
{
	// ===================================================
	// ===================================================
	// Mcl inspired methods
	// ===================================================

	map<HOLIDAYCAL, shared_ptr<vector<date>>> businessDates::_businessDates;

	shared_ptr<vector<date>> businessDates::genBusinessDates(const date& start_, const date& end_, HOLIDAYCAL hols_)
	{

		auto list = shared_ptr<vector<date>> (new vector<date>(end_ - start_));

		date rollDate = start_;
		rollDate.roll( hols_,0 , false);
		while (rollDate <= end_)
		{
			list->push_back(rollDate);
			rollDate = addBusinessDays(rollDate, 1, hols_);
		}

		return list;
	}

	void businessDates::initBusinessDates(const date&  start_, const date&  end_, HOLIDAYCAL hols_)
	{
		//if (_businessDates.find(hols_) == _businessDates.end())
		//  _businessDates[hols_] = new List<DateTime>());

		// +/- 7 days in case start_ or end_ is holiday
		if (_businessDates[hols_]->size() == 0)
		{
			_businessDates[hols_] = genBusinessDates(start_ - 7, end_ + 7, hols_);
			return;
		}
		if (start_ < (*_businessDates[hols_])[0] || end_ > (*_businessDates[hols_])[_businessDates[hols_]->size() - 1])
		{
			if (start_ < (*_businessDates[hols_])[0])
			{
				auto temp = genBusinessDates(start_ - 7, (*_businessDates[hols_])[0] - 1, hols_);
				_businessDates[hols_]->insert(_businessDates[hols_]->end(), temp->begin(), temp->end() );
			}
			if (end_ > (*_businessDates[hols_])[_businessDates.size() - 1])
			{
				auto temp = genBusinessDates((*_businessDates[hols_])[_businessDates[hols_]->size() - 1] + 1, end_ + 7, hols_);
				_businessDates[hols_]->insert(_businessDates[hols_]->end(), temp->begin(), temp->end() );
			}
			sort(_businessDates[hols_]->begin(), _businessDates[hols_]->end());
		}
	}

	shared_ptr<vector<date>> businessDates::getBusinessDates(const date&  start_, const date&  end_, HOLIDAYCAL hols_)
	{
		date nextStart = (start_.isBusinessDate(hols_)) ? start_ : RollFwd(start_, hols_, false);

		initBusinessDates(nextStart, end_, hols_);

		vector<date>::const_iterator s = find(_businessDates[hols_]->begin(),_businessDates[hols_]->end(), nextStart);
		vector<date>::const_iterator e = find(_businessDates[hols_]->begin(),_businessDates[hols_]->end(), end_);
		auto dtList = shared_ptr<vector<date>>(new vector<date>(s, e));
		if (nextStart != start_)
			dtList->insert(dtList->begin(), start_);
		return dtList;
	}

	shared_ptr<vector<date>> businessDates::genDates(const date& startDate_, const DatePeriod& endPeriod_,
		const DatePeriod& freq_, HOLIDAYCAL hols_, NBDA conv_, NBDA endConv_, ROLLTYPE roll_)
	{

		bool isEOM = (roll_ == ROLL_FORWARD_EOM || roll_ == ROLL_BACKWARD_EOM) &&
			(startDate_ == startDate_.lastWDayInMonth(hols_)) && (endPeriod_.getTotalMonths() > 0);
		date endDate = startDate_ + endPeriod_;
		if (isEOM) endDate = endDate.lastWDayInMonth( hols_);
		return genDates(startDate_, endDate, freq_, hols_, conv_, endConv_, roll_);
	}

	shared_ptr<vector<date>> businessDates::genDates(const date& startDate_, const date& endDate_,
		const DatePeriod& freq_, HOLIDAYCAL hols_, NBDA conv_, NBDA endConv_, ROLLTYPE roll_)
	{

		vector<date> tmpDates;
		date rollDate, lastDate, tmpDate;
		if (freq_.getTotalMonths() == 0 && freq_.getDays() == 0)
			mcpl_error("Cannot generate dates using 0 tenor");

		int i = 0;
		switch (roll_)
		{
		case ROLL_FORWARD:
		case ROLL_FORWARD_EOM:
			rollDate = startDate_;
			lastDate = endDate_;
			tmpDate = rollDate;
			i = 0;
			while (tmpDate < lastDate)
			{
				if (find(tmpDates.begin(), tmpDates.end(), tmpDate) == tmpDates.end())
					tmpDates.push_back(tmpDate);
				tmpDate = rollDate + (freq_ * ++i);
			}
			if (find(tmpDates.begin(), tmpDates.end(), lastDate) == tmpDates.end() )
				tmpDates.push_back(lastDate);
			break;

		case ROLL_BACKWARD:
		case ROLL_MONTHEND:
		case ROLL_BACKWARD_EOM:
			rollDate = endDate_;
			lastDate = startDate_;
			tmpDate = rollDate;
			i = 0;
			while (tmpDate > lastDate)
			{
				if (find(tmpDates.begin(), tmpDates.end(), tmpDate) == tmpDates.end())
					tmpDates.push_back(tmpDate);
				tmpDate =rollDate + ( freq_ * --i);
			}
			if ( find(tmpDates.begin(), tmpDates.end(), lastDate) == tmpDates.end() )
				tmpDates.push_back(lastDate);
			reverse(tmpDates.begin(),tmpDates.end());
			break;

		default:
			mcpl_error("Unknown Roll Convention encountered.");
		}

		bool isEOM = (roll_ == ROLL_FORWARD_EOM || roll_ == ROLL_BACKWARD_EOM || roll_ == ROLL_MONTHEND ) &&
			(startDate_ == startDate_.lastWDayInMonth(hols_)) && (freq_.getTotalMonths() > 0);

		auto retDates = shared_ptr<vector<date>>(new vector<date>(tmpDates.size()));
		i = 0;
		for ( i=0 ; i < (int)tmpDates.size()-1 ; i++ )
		{
			(*retDates)[i] = (isEOM) ? tmpDates[i].lastWDayInMonth(hols_) : Roll(tmpDates[i], conv_, hols_);
		}
		(*retDates)[i] = Roll(tmpDates[i], endConv_, hols_);
		vector<date>::iterator it = unique(retDates->begin(), retDates->end());
		retDates->resize(distance(retDates->begin(), it));
		return retDates;

	}

}