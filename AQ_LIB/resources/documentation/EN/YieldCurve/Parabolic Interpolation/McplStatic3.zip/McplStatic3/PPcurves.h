#pragma once
#ifndef MCPL_PPCURVE_H
#define MCPL_PPCURVE_H

#include "mcpldefs.h"
//#include "FuturesCurve.h"
#include "swapData.h"
#include "volatilityGrid.h"

#include <vector>
#include "mcDataClasses/matrix.h"

using namespace std;

namespace MCPL
{

// Contains per perturb curves, both up and down.
class PPCurves
{
public:

	PPCurves() : m_ppsize(0.000001), _usingGammaCurves(true) {}

	string & label(int i) { return m_labels[i]; }

	Handle<RatesCurve>&  base() { return m_base; };

	Handle<RatesCurve>&  up(int i) { return m_up[i]; }
	Handle<RatesCurve>&  dn(int i) { return m_dn[i]; }
	map<Handle<RatesCurve>,Handle<RatesCurve>>&  up_dependents(int i) { return m_up_dependents[i]; }
	map<Handle<RatesCurve>,Handle<RatesCurve>>&  dn_dependents(int i) { return m_dn_dependents[i]; }

	Handle<RatesCurve>&  upup(int i) { return m_upup[i]; }
	Handle<RatesCurve>&  updn(int i) { return m_updn[i]; }
	Handle<RatesCurve>&  dnup(int i) { return m_dnup[i]; }
	Handle<RatesCurve>&  dndn(int i) { return m_dndn[i]; }

	int size() const { return m_up.size(); }
	void resize(int size);
	void clear();

	void set_ppsize( double ppsize ) { m_ppsize = ppsize; } // get and set the vol pp amount.
	double get_ppsize() { return m_ppsize; }

	void setUsingGamma(bool usingGamma_) { _usingGammaCurves = usingGamma_; }
	bool getUsingGamma() { return _usingGammaCurves; }

  void shiftCurve( double dR , DayBasis basis );

private:

	bool _usingGammaCurves;

	// base curve
	Handle<RatesCurve> m_base;

	// Labels
	vector<string>	m_labels;

	// Par perturbed curves
	vector<Handle<RatesCurve>> m_up;
	vector<map<Handle<RatesCurve>,Handle<RatesCurve>>> m_up_dependents; // map of (original dependent curve handle, pp'ed dependent curve handle) for all curves dependent on the one we par perturb
	vector<Handle<RatesCurve>> m_dn;
	vector<map<Handle<RatesCurve>,Handle<RatesCurve>>> m_dn_dependents; // map of dependents (see above)

	vector<Handle<RatesCurve>> m_upup;
	vector<Handle<RatesCurve>> m_updn;
	vector<Handle<RatesCurve>> m_dnup;
	vector<Handle<RatesCurve>> m_dndn;

	double m_ppsize;
};

class PPCapVols
{
public:

	//Constructors
	PPCapVols() : m_ppsize(0.000001), m_clean(false) {}

	PPCapVols( CapVolCurve & ); // crate PP vols from a cap vol curve.
	CapVolCurve & base() { return m_base; }

	CapVolCurve &  up(int i) { if ( !m_clean ) recreate_ppcurves(); return m_up[i]; }
	CapVolCurve &  dn(int i) { if ( !m_clean ) recreate_ppcurves(); return m_dn[i]; }

	void recreate_ppcurves();

	int size() { 
//		return m_up.size(); 
		return m_base.size(); 
	}
	void resize(int size);
	void clear();

	 // get and set the vol pp amount.
	void set_ppsize( double ppsize ) { 
		if ( ppsize != m_ppsize ) {
			m_ppsize = ppsize;
			m_clean = false;
//			recreate_ppcurves();
		}
	}
	double get_ppsize() { return m_ppsize; }

private:
	// base curve
	CapVolCurve m_base;

	// Par perturbed curves
	vector<CapVolCurve> m_up;
	vector<CapVolCurve> m_dn;

	double m_ppsize;

	bool m_clean; // state flag - have we created the PP curves? 

};


// ******************************************************************************************************
class PPVols
{
public:

	//Constructors
	PPVols() : m_ppsize(0.000001), m_clean(false) {}

	PPVols( shared_ptr<VolatilityGrid> , double ppsize = 0.000001 ); // crate PP vols from a cap vol curve.

	shared_ptr<VolatilityGrid> base() { return m_base; }

	void recreate_ppcurves();

	int size() { 
		return m_nvols; 
	}

	void baseSize( VolatilityGrid::tri & tri ) { m_base->size( tri ); };
	void resize(int size);
	void clear();

	 // get and set the vol pp amount.
	void set_ppsize( double ppsize ) { 
		if ( ppsize != m_ppsize ) {
			m_ppsize = ppsize;
			m_clean = false;
//			recreate_ppcurves();
		}
	}
	double get_ppsize() { return m_ppsize; }

	shared_ptr<VolatilityGrid>  up(int i) { if (!m_clean) recreate_ppcurves(); return m_up[i]; }
	shared_ptr<VolatilityGrid>  dn(int i) { if (!m_clean) recreate_ppcurves(); return m_dn[i]; }

private:
	// base curve
	shared_ptr<VolatilityGrid> m_base;

	// Par perturbed curves
	vector<shared_ptr<VolatilityGrid>> m_up;
	vector<shared_ptr<VolatilityGrid>> m_dn;

	double m_ppsize;
	unsigned m_nvols; // number of elements in grid

	bool m_clean; // state flag - have we created the PP curves? 

};

// ******************************************************************************************************

template < class T >
class PPSwapVols
{
public:

	typedef pair<unsigned, unsigned> pair;

	//Constructors
	PPSwapVols() : m_ppdize(0.000001), m_clean(false) {}

	void recreate_ppcurves();

	PPSwapVols( T & ); // crate PP vols from a cap vol curve.

	void set_ppsize( double ppsize ) { 
		if ( ppsize != m_ppsize ) {
			m_ppsize = ppsize;
			m_clean = false;
			//recreate_ppcurves();
		}
	}
	double get_ppsize() { return m_ppsize; }

	T & base() { return m_base; } 
	const T & base() const { return m_base; }  

	T &  up(int i) { if ( !m_clean ) recreate_ppcurves(); return m_up(i); } 
	const T &  up(int i) const { if ( !m_clean ) recreate_ppcurves(); return m_up(i); } 
	T &  dn(int i) { if ( !m_clean ) recreate_ppcurves(); return m_dn(i); } 
	const T &  dn(int i) const { if ( !m_clean ) recreate_ppcurves(); return m_dn(i); } 

	void size(pair & sz) const { m_base.size(sz); }

	void resize(const pair & sz);
	void resize(const unsigned expiries, const unsigned tenors) { resize( pair(expiries, tenors) ); }

	void clear();


private:

	T m_base;
	Matrix<T> m_up;
	Matrix<T> m_dn;

	double m_ppsize;
	
	bool m_clean; // state flag - have we created the PP curves? 

};


 // crate PP vols from a swap vol curve
template <class T>
PPSwapVols<T>::PPSwapVols( T & curve ) : m_ppsize(0.000001), m_clean(false)
{

	m_base = curve;
//	recreate_ppcurves();
}

template <class T>
void PPSwapVols<T>::recreate_ppcurves()
{
	PPSwapVols<T>::pair size;
	m_base.size( size );

// resize the vectors
//	m_up.clear();
//	m_dn.clear();

	vector<long> dates;
	vector<long> tenors; 
	m_base.getLabels( dates, tenors);

	m_up.redim(size);
	m_dn.redim(size);

	for ( int i=0 ; i < size.first ; ++i )
	{
		for ( int j=0 ; j < size.second ; ++j )
		{
			double baseVol = m_base.get( dates[i], tenors[j] );

			m_up(i,j) = m_base;
			m_up(i,j).set(dates[i], tenors[j] , baseVol + m_ppsize );

			m_dn(i,j) = m_base;
			m_dn(i,j).set(dates[i], tenors[j] , baseVol - m_ppsize );
		}
	}
	m_clean = true;
}

template <class T>
void PPSwapVols<T>::clear()
{
	m_base.clear();
	m_up.clear();
	m_dn.clear();
	m_clean = false;
}

template <class T>
void PPSwapVols<T>::resize( const typename PPSwapVols<T>::pair & size)
{
	m_up.resize(size);
	m_dn.resize(size);
	m_clean = false;
}

} // namespace MCPL

#endif //MCPL_PPCURVE_H
