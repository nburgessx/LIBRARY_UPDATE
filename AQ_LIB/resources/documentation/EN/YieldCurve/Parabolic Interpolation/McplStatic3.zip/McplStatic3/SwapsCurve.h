#pragma once
#ifndef MCPLSWAPSCURVE_H
#define MCPLSWAPSCURVE_H

#include "mcpldefs.h"
#include "Swap.h"
#include "mcDateClass/dates.h"
#include "discountcurve.h"
#include "PPCurves.h"
#include "numrec/dnr.h"

using namespace std;

namespace MCPL
{

class SwapsCurve : public swapData
{
public:
	// constructors
	SwapsCurve() : m_curveGood(false) {}

	
	SwapsCurve(vector<double> & par_rates, vector<double> & tenors, date & spot, SwapType sType, 
				discountCurve & stub, CURRENCY ccy) :
		m_spot(spot),
		m_par_rates(par_rates),
		m_tenors(tenors), 
		m_ccy(ccy),
		m_swap_type(sType)
		{
			set_currency_defaults(ccy, sType);
			clear();
			calculateDates();
			calculateCurve();
		}

	void create( vector<double> & par_rates, vector<double> & tenors, date & spot, SwapType sType, 
					discountCurve & stub, CURRENCY ccy );

//	void create_PPCurves( PPCurves & , double pp_val );

private:

	void set_currency_defaults(CURRENCY);

	CURRENCY m_ccy;

	date m_spot;
	long int m_fxPmtsPerYear, m_fltPmtsPerYear;
	DayBasis m_fxBasis, m_fltBasis;
	SwapType m_swap_type;

	bool m_curveGood; // Is the curve in a good state?

	discountCurve m_stub_curve; // discount curve from LIBOR rates to get DF to first IMM start date.
	vector<double> m_par_rates; // swap par points
	vector<double> m_tenors;  // swap tenors
	vector<date> m_end_dates; // swap end dates
	vector<date> m_last_dates; // swap last dates
	vector<date> m_df_dates; // dates on which we set the discount factor.
	vector<Swap> m_swaps; // the swaps, so that we don't have to keep calcing the dates.

	HOLIDAYCAL m_hols, m_libor_hols;  // holiday cal for the futures

	void calculateCurve();
	void calculateDates();
	void SwapsCurve::set_currency_defaults(CURRENCY ccy, SwapType type);

	friend double func_constant(double);
	friend double func_linear(double);

};

} // namespace MCPL

#endif // MCPLSWAPSCURVE_H
