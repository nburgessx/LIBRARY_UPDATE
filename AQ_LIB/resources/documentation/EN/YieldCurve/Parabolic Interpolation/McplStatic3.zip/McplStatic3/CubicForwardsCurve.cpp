#include"CubicForwardsCurve.h"

//#include "numrec3/nr3.h"
//#include "numrec3/fitmrq.h"

#include "numrec/dnr.h"
#include "numrec/dnrutil.h"



namespace MCPL
{

		void CubicForwardsCurve::create( const vector<date> swapEffDates, const vector<date> swapDates, 
			const vector<double> & swapRates, const vector<double> & swapTolerances, const SwapType sType,
		date & today, const map<date,double> & cashParams, CURRENCY ccy, double fitfactor, int testval, Handle<RatesCurve> swapDiscountCurve)
	{
		m_fitfactor = fitfactor;
		m_swapsDiscountCurve = swapDiscountCurve;
		m_testval = testval;
		if ( (m_today != today) 
			|| ( ccy != m_ccy )
			|| sType != m_swapType 
			|| !cmpvecs(swapEffDates, m_swapEffDates) 
			|| !cmpvecs(swapDates, m_swapMaturityDates) 
			|| !cmpmaps(cashParams, m_cashParams)) 
		{
			set_currency_defaults(ccy, sType);
			m_today = today;
			m_spot = spot(today, ccy);
			
			m_swapType = sType;
			m_swapMaturityDates = swapDates;
			m_swapEffDates = swapEffDates;
			m_parRates = swapRates;
			m_swapTolerances = swapTolerances;
			m_cashParams = cashParams;
			
			clear();
			calculateDates();
			calculateCurve();
		} 
		else 
		{
			m_cashParams = cashParams;
			m_parRates = swapRates;
			m_swapTolerances = swapTolerances;
			clear();
			calculateCurve();
		}
	}



	void CubicForwardsCurve::calculateDates()
	{

		unsigned int n_swaps = m_swapMaturityDates.size();

		if ( n_swaps > 0 )
		{
			// Set up swap dates.

			
			// Set up all pricing swaps
			m_swapCashflows.clear();
			m_cashflows.clear();
			m_linFutsPriceDrops.clear();
			m_segmentLengths.clear();
			m_swapAdjustments.clear();
			m_swapLastDates.clear();

			// Cubic spline arrays
			m_xvals.clear();
			m_yvals.clear();
			m_yvals.resize(n_swaps+1);
			m_xvals.push_back(0);

			for ( unsigned int j = 0 ; j < n_swaps ; ++j )
			{

				if ( m_fltPmtsPerYear != 4 )
				{
					Swap tmpswap = Swap(PAY, m_swapType,  m_swapEffDates[j], m_swapMaturityDates[j], m_swapEffDates[j], 1, .05, 0, m_swapHols, m_ccy);
					m_swapCashflows.push_back( tmpswap );
					m_swapLastDates.push_back( tmpswap.getLastDate() );
				}
				else
				{
					Leg leg = Leg( PAY , MC_FIXED, m_swapEffDates[j] , m_swapMaturityDates[j], 1, .05, m_fixedPmtsPerYear, m_fixedBasis, m_swapHols, ROLL_BACKWARD);
					m_cashflows.push_back( leg );
					m_swapLastDates.push_back( leg.getLastDate() );
				}
				m_linFutsPriceDrops.push_back(0.0); 
				m_segmentLengths.push_back(0.0);
				m_swapAdjustments.push_back(0);

				m_xvals.push_back((double)(m_swapMaturityDates[j] - m_today));
			}

		}

		// Set up IMM start, end dates and day count fractions.
		m_starts.clear();
		m_ends.clear();
		m_PDCF.clear(); 
		m_forwards.clear();

		m_starts.push_back( m_spot );
		m_ends.push_back( addBusinessPeriod(m_spot, DatePeriod(0,3,0), m_hols, true ) );
		m_PDCF.push_back(  dayCountFrac(m_basis, m_starts.back() , m_ends.back() ) );
		m_forwards.push_back(0);

		date lastEndDate = m_ends[0];
		date lastSwapEndDate = m_swapLastDates.back();
		int fwdIndex = 2;
		do
		{
			m_starts.push_back(lastEndDate);
			lastEndDate = addBusinessPeriod(m_spot, DatePeriod(0,fwdIndex * 3,0), m_hols , true );
			m_ends.push_back( lastEndDate );
			m_PDCF.push_back( dayCountFrac(m_basis, m_starts.back() , lastEndDate ) );
			m_forwards.push_back(0);

			fwdIndex++;
		} while ( lastEndDate < lastSwapEndDate );


		// Now for the swap-fowrards index arrays
		if ( n_swaps > 0 )
		{

			// setup indeces of corresponding futures for the swaps
			m_linFutsSwapIndex.clear(); // Index of first fut with start date > swap[-1]'s mat date
			m_linFutsSwapIndex.resize(m_swapAdjustments.size() + 1);
			m_linFutsSwapIndex[0] = 1; //The first forward is just the cash rate, so is constant when fitting swaps.


			int swapIndex = 0;
			for ( unsigned int j = 1 ; j < m_ends.size() ; j++ )
			{
				if ( m_starts[j] >= m_swapLastDates[swapIndex] )
				{
					m_linFutsSwapIndex[swapIndex  + 1] = j;
					swapIndex++;
				}
			}

			m_linFutsSwapIndex.back() = j;
		}
	}


	void CubicForwardsCurve::calculateCurve()
	{

		discountCurve cashCurve;

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );
		cashCurve.set(m_today , 1.0 );
		cashCurve.set(m_spot , spotDF );

		map<date,double>::const_iterator it = m_cashParams.begin();
		++it;
		for (  ; it != m_cashParams.end() ; ++it ) 
		{
			dcf = dayCountFrac( m_basis, m_spot, it->first );

			cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
		}


		discountCurve::clear();
		discountCurve::set(m_today , 1.0 );
		discountCurve::set(m_spot , spotDF );

		discountCurve::set(m_ends[0] , cashCurve.get(m_ends[0]) ); // set first discount from LIBOR
		m_yvals[0] = swapData::getZero(m_spot, m_ends[0], m_basis);

		dcf = dayCountFrac( m_basis, m_spot, m_ends[0] );
		m_forwards[0] = ((spotDF / cashCurve.get(m_ends[0]))-1)/dcf;

		// The swaps

		m_swapAdjustments.clear();
		for (unsigned int i=0 ; i < m_swapMaturityDates.size(); i++ ) 
		{
			m_swapAdjustments.push_back(0);
		}

		calcFuturesFromSwaps(0);

		calcFwdsFromSpline();

		calculateCurveFromFutures();

		if ( m_lastUsedSwapIndex > 0 )
		{
			fitNDimSwapAdjs2();
		}
	}

	void CubicForwardsCurve::calcFwdsFromSpline()
	{

		numrec3::Spline_interp cspline(m_xvals, m_yvals);
		//numrec3::Rat_interp cspline(m_xvals, m_yvals, m_testval );
		//numrec3::Poly_interp cspline(m_xvals, m_yvals, m_testval );

		m_curveLength = 0;
		int nFutures = m_forwards.size();
		for ( int i = 0 ; i < nFutures ; ++i ) 
		{
			date start = m_starts[i];
			m_forwards[i] = cspline.interp((double)(start - m_today));
			if ( i>0 )
			{
				double dx = m_starts[i] - m_starts[i-1];
				double dy = 500000*(m_forwards[i] - m_forwards[i-1]);
				m_curveLength += sqrt(dx*dx + dy*dy);
			}
		}

	}
	
	void CubicForwardsCurve::calcFuturesFromSwaps(int index)
	{

		for ( unsigned int i=index ; i < m_swapAdjustments.size() ; i++ )
		{
			if ( !fitFuturesDrops(i) )
				break;
			m_lastUsedSwapIndex = (long) i;
		}

	}

	void CubicForwardsCurve::calculateCurveFromFutures()
	{
		double rate, PDF;
		discountCurve cashCurve;

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );
		cashCurve.set(m_today , 1.0 );
		cashCurve.set(m_spot , spotDF );

		map<date,double>::const_iterator it = m_cashParams.begin();
		++it;
		for (  ; it != m_cashParams.end() ; ++it ) 
		{
			dcf = dayCountFrac( m_basis, m_spot, it->first );

			cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
		}


		discountCurve::clear();
		discountCurve::set(m_today , 1.0 );
		discountCurve::set(m_spot , spotDF );

		discountCurve::set(m_ends[0] , cashCurve.get(m_ends[0]) ); // set first discount from LIBOR

		int nFutures = m_forwards.size();
		for ( int i = 0 ; i < nFutures ; ++i ) 
		{
			date start = m_starts[i];
			date end = m_ends[i];

			rate = m_forwards[i];

			PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
			discountCurve::set(end , get(start) * PDF );
		}

	}


	//=================================================================================================================
	//  Fitting functions
	//=================================================================================================================


	//
	namespace CubicForwardsCurveFitFn
	{
		int index;
		Handle<CubicForwardsCurve> fitcurve;

		double func_linear(double drop)
		{

			Handle<CubicForwardsCurve> curve = fitcurve;

			for ( int i = curve->m_linFutsSwapIndex[index] ; i < curve->m_linFutsSwapIndex[index+1] ; i++ )
			{
				curve->m_forwards[i] = curve->m_forwards[i-1] - drop;
				date start = curve->m_starts[i];
				date end = curve->m_ends[i];

				double rate = curve->m_forwards[i];

				double PDF = 1.0 / ( 1.0 + rate * curve->m_PDCF[i] );
				curve->set(end , curve->get(start) * PDF );
			}

			double swapRate;
			if ( curve->m_fltPmtsPerYear != 4 )
			{
				if ( curve->m_swapsDiscountCurve ) // Discount using suppplied discount curve (i.e. vs 3s) rather than our own.
				{
					curve->m_swapCashflows[index].setCurves(curve->m_swapsDiscountCurve, curve);
				}
				else
				{
					curve->m_swapCashflows[index].setCurves(curve, curve);
				}
				swapRate = (curve->m_swapCashflows[index]).Solve(0, solveFORCOUPON);
			}
			else
			{
				curve->m_cashflows[index].setCurves(curve, curve);
				curve->m_cashflows[index].updatePaymentsFromCurves();
				date lastDate = curve->m_cashflows[index].getLastDate();

				swapRate = ( curve->get( curve->m_swapEffDates[index] ) - curve->get( lastDate ) )
									/ (curve->m_cashflows[index]).BasisPointValue();
			}
			double targetRate = curve->m_parRates[index];

			return  ( curve->m_swapAdjustments[index] + swapRate - targetRate );
		}
	}

	//
	namespace CubicForwardsCurveNDimMinFn
	{
		Handle<CubicForwardsCurve> fitcurve;

		double func_minimise(double fwdRates[])
		{
			Handle<CubicForwardsCurve> curve = fitcurve;

			int fi = 0;

			for ( int i=1 ; i <= curve->m_lastUsedSwapIndex ; i++ )
				curve->m_yvals[i] = fwdRates[i];

			curve->calcFwdsFromSpline();
			curve->calculateCurveFromFutures();

			double sum2 = 0;
			//double curveLength = 0;

			for ( int index=0 ; index <= curve->m_lastUsedSwapIndex ; index++ )
			{
				double swapRate;
				if ( curve->m_fltPmtsPerYear != 4 )
				{
					if ( curve->m_swapsDiscountCurve ) // Discount using suppplied discount curve (i.e. vs 3s) rather than our own.
					{
						curve->m_swapCashflows[index].setCurves(curve->m_swapsDiscountCurve, curve);
					}
					else
					{
						curve->m_swapCashflows[index].setCurves(curve, curve);
					}
					swapRate = (curve->m_swapCashflows[index]).Solve(0, solveFORCOUPON);
				}
				else
				{
					curve->m_cashflows[index].setCurves(curve, curve);
					curve->m_cashflows[index].updatePaymentsFromCurves();
					date lastDate = curve->m_cashflows[index].getLastDate();

					swapRate = ( curve->get( curve->m_swapEffDates[index] ) - curve->get( lastDate ) )
						/ (curve->m_cashflows[index]).BasisPointValue();
				}
				double targetRate = curve->m_parRates[index];
				swapRate += curve->m_swapAdjustments[index];

				sum2 +=   ( swapRate - targetRate ) * ( swapRate - targetRate ) ;


			}

			return sqrt(sum2);// + curve.m_curveLength * curve.m_fitfactor;

		}

	}

	namespace CubicForwardsCurveNDimMinFn2
	{
		Handle<CubicForwardsCurve> fitcurve;

		double func_minimise(double adjustments[])
		{
			Handle<CubicForwardsCurve> curve = fitcurve;

//			int fi = 0;

			for ( int i=0 ; i <= curve->m_lastUsedSwapIndex ; i++ )
				curve->m_swapAdjustments[i] = adjustments[i+1];

			for ( int j=0 ; j < 2; j++ )
			{
				curve->fitNDimSwapAdjs();
			}

			double adjsSum2 = 0;

			for ( int i=0 ; i <= curve->m_lastUsedSwapIndex ; i++ )
			{
				double stopFactor = fabs(adjustments[i+1]) > curve->m_swapTolerances[i] ? 1000000.0 : 1.0;
				adjsSum2 += stopFactor * adjustments[i+1]*adjustments[i+1];
			}

			return sqrt(adjsSum2)  +  curve->m_fitfactor * sqrt(curve->m_curveLength); // Minimise curve length
		}

	}

	//================================================================================================
	//================================================================================================

	bool CubicForwardsCurve::fitFuturesDrops(int index)
	{
		CubicForwardsCurveFitFn::index = index;
		CubicForwardsCurveFitFn::fitcurve = Handle<CubicForwardsCurve>(this, null_deleter());

		double x1=-.001;
		double x2=.001;

		//double drop=0;
		//if ( NUMREC::zbrac(CubicForwardsCurveFitFn::func_linear, &x1, &x2) == 1 )
		//{
		////	drop =  NUMREC::zriddr( CubicForwardsCurveFitFn::func_linear , x1, x2, .001 );
		////	drop =  NUMREC::zbrent( CubicForwardsCurveFitFn::func_linear , x1, x2, .01 );
		//	drop = linearFitter( CubicForwardsCurveFitFn::func_linear , x1, x2, .00001 );
		////	drop = quadraticFitter( CubicForwardsCurveFitFn::func_linear , x1, x2, .00001 );
		//}
		//else
		//{
		//	return false;
		//}


		double drop = linearFitter( CubicForwardsCurveFitFn::func_linear , x1, x2, .00001 );
		//double drop = quadraticFitter( CubicForwardsCurveFitFn::func_linear , x1, x2, .00001 );

		m_linFutsPriceDrops[index] = drop;
		double segmentDrop = 10000 * drop * (m_linFutsSwapIndex[index+1] - m_linFutsSwapIndex[index]);
		double segmentTime = (double)( m_ends[m_linFutsSwapIndex[index+1]-1] - m_starts[m_linFutsSwapIndex[index]] ) / 365.0;
		m_segmentLengths[index] = sqrt( segmentDrop*segmentDrop + segmentTime*segmentTime );

		// Now fix the curve after the fitting!
		for ( int i = m_linFutsSwapIndex[index] ; i < m_linFutsSwapIndex[index+1] ; i++ )
		{
			m_forwards[i] = m_forwards[i-1] - drop;
			date start = m_starts[i];
			date end = m_ends[i];

			double PDF = 1.0 / ( 1.0 + m_forwards[i] * m_PDCF[i] );
			set(end , get(start) * PDF );
		}

		m_yvals[index+1] = m_forwards[m_linFutsSwapIndex[index+1]-1];

		return true;
	}

	//

	bool CubicForwardsCurve::fitNDimSwapAdjs()
	{
		if ( m_fitfactor == 0 )
		{
			//m_swapAdjustments[index] = 0;
			return true;
		}
		else
		{

			CubicForwardsCurveNDimMinFn::fitcurve = Handle<CubicForwardsCurve>(this, null_deleter());

			double *x, *y, **p;
			int nDims = m_lastUsedSwapIndex;//+1;

			x = NUMREC::vector(1,nDims);
			y = NUMREC::vector(1,nDims+1);
			p = NUMREC::matrix(1,nDims+1 , 1,nDims);

			for ( int i=1; i <= nDims+1 ; i++ )
			{
				for ( int j=1 ; j <= nDims ; j++ )
				{
					x[j] = p[i][j] = m_yvals[j] + (i == (j+1) ? 0.0001 : 0.0);
				}
				y[i] = CubicForwardsCurveNDimMinFn::func_minimise(x);
			}

			int nfunc;
			NUMREC::amoeba(p, y, nDims, 1.0e-4, CubicForwardsCurveNDimMinFn::func_minimise, &nfunc);

			for ( int j=1 ; j <= nDims ; j++ )
			{
				m_yvals[j] = p[1][j];
			}


			// Now fix the curve after the fitting!
			calcFwdsFromSpline();
			calculateCurveFromFutures();

		}

		return true;
	}





	//
	void CubicForwardsCurve::fitNDimSwapAdjs2()
	{
		if ( m_fitfactor == 0 )
		{
			//m_swapAdjustments[index] = 0;
			return;
		}
		else
		{

			CubicForwardsCurveNDimMinFn2::fitcurve = Handle<CubicForwardsCurve>(this, null_deleter());

			double *x, *y, **p;
			int nDims = m_lastUsedSwapIndex+1;

			x = NUMREC::vector(1,nDims);
			y = NUMREC::vector(1,nDims+1);
			p = NUMREC::matrix(1,nDims+1 , 1,nDims);

			for ( int i=1; i <= nDims+1 ; i++ )
			{
				for ( int j=1 ; j <= nDims ; j++ )
				{
					x[j] = p[i][j] = (i == (j+1) ? 0.0001 : 0.0);
				}
				y[i] = CubicForwardsCurveNDimMinFn2::func_minimise(x);
			}

			int nfunc;
			NUMREC::amoeba(p, y, nDims, 1.0e-4, CubicForwardsCurveNDimMinFn2::func_minimise, &nfunc);

			for ( int j=1 ; j <= nDims ; j++ )
			{
				m_swapAdjustments[j-1] = p[1][j];
			}

			//double fRet;
			//NUMREC::powell(x, p, nDims, 1.0e-4, &nfunc, &fRet, LinearForwardsCurveNDimMinFn::func_minimise);
			//for ( int j=1 ; j <= nDims ; j++ )
			//{
			//	m_swapAdjustments[j-1] = x[j];
			//}

			// Now fix the curve after the fitting!
			calcFwdsFromSpline();
			calculateCurveFromFutures();

		}
		return;
	}



	//
	void CubicForwardsCurve::set_currency_defaults(CURRENCY ccy)
	{
		m_ccy = ccy;

		switch(m_ccy)
		{
		case USD:
			set_currency_defaults(ccy, SB3);
			break;
		case EUR:
			set_currency_defaults(ccy, AB6);
			break;
		case JPY:
			set_currency_defaults(ccy, SB6);
			break;
		case GBP:
			set_currency_defaults(ccy, SB6);
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}

	}

	void CubicForwardsCurve::set_currency_defaults(CURRENCY ccy, SwapType type)
	{

		vanillaSwapParams(ccy, type, m_fixedPmtsPerYear, m_fltPmtsPerYear, m_fixedBasis, m_basis) ;

		m_swapType = type;
		m_ccy = ccy;
		this->setCurrency(m_ccy);

		switch(ccy)
		{
		case USD:
			m_swapHols = HOLIDAYCAL(UK | USA);
			m_hols = UK;
			break;
		case EUR:
			m_swapHols = EUTARG;
			m_hols = EUTARG;
			break;
		case JPY:
			m_swapHols = JP;
			m_hols = UK;
			break;
		case GBP:
			m_swapHols = UK;
			m_hols = UK;
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}
	}


	bool CubicForwardsCurve::cmpvecs( const vector<double> & v1, const vector<double> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}
	//
	bool CubicForwardsCurve::cmpvecs( const vector<date> & v1, const vector<date> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}
	//
	bool CubicForwardsCurve::cmpmaps( const map<date,double> & v1, map<date,double> & v2)
	{
		if ( v1.size() != v2.size() ) return false;
		else 
		{
			bool test = true;
			map<date,double>::const_iterator it1 = v1.begin();
			map<date,double>::const_iterator it2 = v2.begin();
			while ( test && ( it1 != v1.end() ) && ( it2 != v2.end() ) )
			{
				if ( it1->first != it2->first ) 
					test = false;

				++it1;
				++it2;
			}		
			return test;
		}
		return false; // should not get here.
	}



	// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
	Handle<PPCurves> CubicForwardsCurve::create_PPCurves( double pp_val )
	{
		Handle<PPCurves> pp_curves = Handle<PPCurves>(new PPCurves());

		int nHedges =  m_forwards.size() + m_cashParams.size(); 
		pp_curves->resize( nHedges ); 
		pp_curves->set_ppsize( pp_val/100.0 ); // set the perturb size in factor (i.e. 1 = 1%)

		pp_curves->base() = Handle<RatesCurve>(new CubicForwardsCurve(*this));

		unsigned int i=0;
		// up
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->label(i) = "cash " + (string) it->first;
			pp_curves->up(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_forwards.size() ; ++j ) 
		{
			m_forwards[j] -= pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->label(i) = "Fut " + (string) m_starts[j];
			pp_curves->up(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			m_forwards[j] += pp_val;
		}


		// dn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dn(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_forwards.size() ; ++j ) 
		{
			m_forwards[j] += pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dn(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			m_forwards[j] -= pp_val;
		}


		//upup
		for ( unsigned int j=0 ; j < m_forwards.size() ; ++j ) 
			m_forwards[j] -= pp_val;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			it->second += pp_val/100.0;

		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->upup(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_forwards.size() ; ++j ) 
		{
			m_forwards[j] -= pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->upup(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			m_forwards[j] += pp_val;
		}

		// updn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->updn(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_forwards.size() ; ++j ) 
		{
			m_forwards[j] += pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->updn(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			m_forwards[j] -= pp_val;
		}


		//dnup
		for ( unsigned int j=0 ; j < m_forwards.size() ; ++j ) 
			m_forwards[j] += 2.0*pp_val;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			it->second -= 2.0*pp_val/100.0;

		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dnup(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_forwards.size() ; ++j )
		{
			m_forwards[j] -= pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dnup(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			m_forwards[j] += pp_val;
		}

		// dndn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dndn(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0  ; j < m_forwards.size() ; ++j ) 
		{
			m_forwards[j] += pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dndn(i++)= Handle<RatesCurve>(new CubicForwardsCurve(*this));
			m_forwards[j] -= pp_val;
		}


		for ( unsigned int j=0 ; j < m_forwards.size() ; ++j ) 
			m_forwards[j] -= pp_val;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			it->second += pp_val/100.0;

		partialClear();
		calculateCurveFromFutures();

		return pp_curves;
	}





} // namespace MCPL