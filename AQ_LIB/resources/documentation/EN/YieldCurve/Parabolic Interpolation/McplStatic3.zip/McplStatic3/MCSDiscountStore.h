#ifndef _MCSDiscountStore_H
#define _MCSDiscountStore_H

#include "mcpldefs.h"
#include "MonotonicCubicSpline.h"

using namespace std;

namespace MCPL
{
	class MCSDiscountStore
	{
	private:

		shared_ptr<MonotonicCubicSpline> _curve;
		map<double, double> _dfCache;

	public:

		MCSDiscountStore()
		{
			_curve = shared_ptr<MonotonicCubicSpline>(new MonotonicCubicSpline());
		}

		MCSDiscountStore(const MCSDiscountStore& other)
		{
			_curve = shared_ptr<MonotonicCubicSpline>(new MonotonicCubicSpline(*(other._curve)));
		}

		shared_ptr<MCSDiscountStore> clone() const { return shared_ptr<MCSDiscountStore>(new MCSDiscountStore(*this)); }

		double getDiscountFactor(double T);
		double getPeriodDiscountFactor(double T1, double T2);
		double getCCRate(const date & d1, const date & d2, DayBasis basis); //Continuously compounded rate
		double getRate(const date & d1, const date & d2, DayBasis basis); //Single period rate

		//void setDiscountFactor(double T, double df);
		//void setCCRate(date & d1, date & d2, DayBasis basis, double rate);
		//void setRate(date & d1, date & d2, DayBasis basis, double rate);
		void setIRate(const date &dt, double value_); //Set the instantaneous forward rate at date to value.
		double getIRate(const date &dt) { return _curve->interpolate((double)dt); } //Get the instantaneous forward rate at date.

		date firstDate() const { return _curve->getFirstLabel(); }
		date lastDate() const { return _curve->getLastLabel(); }

		void clearCache() { _dfCache.clear(); }
		void clearCacheFrom(const date& lastGoodKey);

		double curveLength(const date &d1, const date &d2);
		double curveLength() { return curveLength(firstDate(), lastDate()); }

		shared_ptr<MonotonicCubicSpline> getSpline() { return _curve; }
	};

}//MCPL

#endif  //_MCSDiscountStore_H
