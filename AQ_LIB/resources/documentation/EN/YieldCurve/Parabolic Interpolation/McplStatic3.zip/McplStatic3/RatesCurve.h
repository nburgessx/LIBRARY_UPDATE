#pragma once
#ifndef MCPLRATESCURVE_H
#define MCPLRATESCURVE_H

#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "handle.hpp"
//#include "PPcurves.h"

using namespace std;

namespace MCPL
{

	
	class RatesCurve 
	{
	public:

		// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
		//virtual Handle<PPCurves>  create_PPCurves(double pp_val, bool CalculateGammaCurves = true) = 0;

		//virtual void addDependent(Handle<RatesCurve> dependentCurve) =0;

		virtual void partialClear() = 0; // clear curves, not stored cashflows
		
		//virtual double get(const long& dLabel) =0;

		// Override clone() from swapData. Allows us to clone a Handle<swapData> that is in fact a Handle<ParabolicCurve>
		virtual Handle<RatesCurve> clone() = 0;

		virtual void clear() = 0;

		virtual double getZero(const date & d1, const date & d2, DayBasis basis) = 0; // forward rate from d1 to d2
		virtual double getZero(const date & d1, const date & d2) = 0; // forward rate from d1 to d2
			
		 // Get continuously compounded rate
		virtual double getCCRate(date & d1, date & d2, DayBasis basis) = 0;
		
		virtual double forecastFixing(date & reset_date) = 0;
		
		virtual double getDiscountFactor(const date & d) = 0;
		virtual double getRatesDiscountFactor(const date & d) = 0; //Gets the DF associated with the fwd rates, not the discounting curve.
		virtual DayBasis getDayBasis() = 0;
		virtual CURRENCY getCurrency() = 0;

		virtual void setDiscountFactor(date & d, double value) = 0;
		virtual void setDayBasis(DayBasis basis) = 0;
		virtual void setCurrency(CURRENCY ccy) = 0;

		virtual void setDefaults(CURRENCY ccy, unsigned periodMonths) = 0;

		virtual date firstDate() = 0;
		virtual date lastDate() = 0;
		virtual void shiftCurve(double dR, DayBasis basis) = 0;
		virtual shared_ptr<vector<long>> getLabels() = 0;

		virtual void calculateCurve() = 0;

		virtual void addDependent(Handle<RatesCurve> dependentCurve_) = 0;

		//typedef discountCurve::labels labels;
		//labels getZeroLabels() { return getLabels(); }
		//labels getDiscountFactorLabels() { return getLabels(); }
	};

	template <class C>
	class RatesCurveWrapper : public RatesCurve
	{
	private:
		Handle<C> _curve;

	public:

		RatesCurveWrapper(Handle<C> curve_) : _curve(curve_) {}

		RatesCurveWrapper()
		{
			_curve = Handle<C>(new C());
		}

		//Handle<PPCurves>  create_PPCurves(double pp_val, bool CalculateGammaCurves = true) { return _curve->create_PPCurves(pp_, CalculateGammaCurves); }
		//void addDependent(Handle<RatesCurve> dependentCurve) { _curve->addDependent(dependentCurve); }
		void partialClear() { _curve->partialClear(); }

		Handle<RatesCurve> clone() { return Handle<RatesCurveWrapper>(new RatesCurveWrapper(*this)); }

		void clear() { _curve->clear(); }

		double getZero(const date & d1, const date & d2, DayBasis basis) { return _curve->getZero(d1, d2, basis); }
		double getZero(const date & d1, const date & d2) { return _curve->getZero(d1, d2); }

		virtual double getCCRate(date & d1, date & d2, DayBasis basis) { return _curve->getCCRate(d1, d2, basis); }

		double forecastFixing(date & reset_date) { return _curve->forecastFixing(reset_date); }

		double getDiscountFactor(const date & d) { return _curve->getDiscountFactor(d); }

		DayBasis getDayBasis() { return _curve->getDayBasis(); }
		CURRENCY getCurrency() { return _curve->getCurrency(); }

		void setDiscountFactor(date & d, double value) { _curve->setDiscountFactor(d, value); }
		void setDayBasis(DayBasis basis) { _curve->setDayBasis(basis); }
		void setCurrency(CURRENCY ccy) { _curve->setCurrency(ccy); }

		void setDefaults(CURRENCY ccy, unsigned periodMonths) { _curve->setDefaults(ccy, periodMonths); }
	};
} // namespace MCPL

#endif // MCPLRATESCURVE_H