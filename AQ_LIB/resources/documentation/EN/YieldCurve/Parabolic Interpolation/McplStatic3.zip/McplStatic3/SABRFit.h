#pragma once
#ifndef MCPLSABRFIT_H
#define MCPLSABRFIT_H

#include <vector>
#include "SABR.h"

using namespace std;

namespace MCPL
{


	void LogSABRFitter(const vector<double> &prices, const vector<double> &errors, const vector<double> &strikes, 
		const vector<OptionType> types,	double forwardRate, double timeToExpInYears, SABRParams & vol, 
		double bpv,  const SABRParams & toFit, const SABRParams & volsMin, const SABRParams & volsMax);

	void NormalSABRFitter(const vector<double> &prices, const vector<double> &errors, const vector<double> &strikes, 
		const vector<OptionType> types,	double forwardRate, double timeToExpInYears, SABRParams & vol, 
		double bpv,  const SABRParams & toFit, const SABRParams & volsMin, const SABRParams & volsMax);

	void AlphaSABRFitter(const vector<double> &prices, const vector<double> &errors, const vector<double> &strikes, 
		const vector<OptionType> types,	double forwardRate, double timeToExpInYears, SABRParams & vol, 
		double bpv,  const SABRParams & toFit, const SABRParams & volsMin, const SABRParams & volsMax);

	void AFSABRFitter(const vector<double> &prices, const vector<double> &errors, const vector<double> &strikes, 
		const vector<OptionType> types,	double forwardRate, double timeToExpInYears, SABRParams & vol, 
		double bpv,  const SABRParams & toFit, const SABRParams & volsMin, const SABRParams & volsMax);

}

#endif //MCPLSABRFIT_H