#include"OISSwap.h"

namespace MCPL
{

	//OIS swap no curves
	OISSwap::OISSwap(DIRECTIONTYPE dir, const date & start, const date & mature, double notional, double coupon, double FltSpread,
		int rollDay, ROLLTYPE rolltype,
		long int OISPmtsPerYear, long int FixedPmtsPerYear, DayBasis OISBasis, DayBasis FixedBasis, HOLIDAYCAL hol,
		CURRENCY ccy, int pmtOffsetDays_, MCPL::ACCRUAL_TYPE accrualType)
		: Swap()
	{
		DIRECTIONTYPE dir2;

		m_notional = notional;
		m_coupon = coupon;
		m_spread = FltSpread;
		m_direction = dir;

		m_hols = hol;
		m_effectiveDate = start;
		m_matureDate = mature;
		m_adjMatureDate = m_matureDate;
		m_adjMatureDate.rollFwd(hol, true);
		m_roll = rollDay;
		m_longCoupon = false;

		p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		p_CMSvols = NULL;

		dir2 = dir == PAY ? RECEIVE : PAY;

		int pmtDateOffsetDays = pmtOffsetDays_;

		addLeg(Handle<Leg>(new Leg(dir, MC_FIXED, start, mature, notional, coupon, FixedPmtsPerYear, FixedBasis, hol, rolltype, ccy, MCPL::ModelNone, mixing_model(), date(0), false, pmtDateOffsetDays)));
		addLeg(Handle<OISLeg>(new OISLeg(dir2, start, mature, notional, FltSpread, rollDay, rolltype, OISPmtsPerYear, OISBasis, hol, ccy, pmtDateOffsetDays, accrualType)));

	}


	//OIS swap no curves
	OISSwap::OISSwap(DIRECTIONTYPE dir, const date & start, const date & mature, double notional, double coupon, double FltSpread,
		int rollDay, ROLLTYPE rolltype,
		long int OISPmtsPerYear, long int FixedPmtsPerYear, DayBasis OISBasis, DayBasis FixedBasis, HOLIDAYCAL hol,
		CURRENCY ccy, MCPL::ACCRUAL_TYPE accrualType)
		: Swap()
	{
		DIRECTIONTYPE dir2;

		m_notional = notional;
		m_coupon = coupon;
		m_spread = FltSpread;
		m_direction = dir;

		m_hols = hol;
		m_effectiveDate = start;
		m_matureDate = mature;
		m_adjMatureDate = m_matureDate;
		m_adjMatureDate.rollFwd(hol, true);
		m_roll = rollDay;
		m_longCoupon = false;

		p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = Handle<RatesCurve>();
		p_CMSvols = NULL;

		dir2 = dir == PAY ? RECEIVE : PAY;

		int pmtDateOffsetDays = 2;
		if (ccy == EUR)
			pmtDateOffsetDays = 1;
		else if (ccy == GBP)
			pmtDateOffsetDays = 0;

		addLeg(Handle<Leg>(new Leg(dir, MC_FIXED, start, mature, notional, coupon, FixedPmtsPerYear, FixedBasis, hol, rolltype, ccy, MCPL::ModelNone, mixing_model(), date(0), false, pmtDateOffsetDays)));
		addLeg(Handle<OISLeg>(new OISLeg(dir2, start, mature, notional, FltSpread, rollDay, rolltype, OISPmtsPerYear, OISBasis, hol, ccy, pmtDateOffsetDays, accrualType)));

	}


	double OISSwap::Solve(double dPresentValue)
	{
		double dTarget = 0.0;
		//double dPresentValue = 0.0;

		Handle<Leg> leg = getLeg(MC_FIXED);
		double  dSwapValue = Price(leg->getCoupon());
		double dSwapBpv = leg->BasisPointValue() * leg->getNotional();
		dTarget = (dPresentValue - dSwapValue) / dSwapBpv + leg->getCoupon();

		return dTarget;
	}


	//*************************************************************************************************



} //end namespace MCPL