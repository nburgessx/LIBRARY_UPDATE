#include "option.h"

namespace MCPL
{

  bool inTheMoney(double strike, double forward, OptionType type)
  {
    bool itm = false;
    if ( (type == Call) && ( strike < forward ) ) itm = true;
    else if ( (type == Put) && ( strike > forward ) ) itm = true;
    else if ( type == Straddle ) itm = true;

    return itm;
  }

  double intrinsicValue(double strike, double forward, OptionType type)
  {
    if ( inTheMoney(strike, forward, type) )
      return fabs(forward - strike);
    else
      return 0;
  }

  double timeValue(double price, double strike, double forward, double df, OptionType type)
  {
    return price - df*intrinsicValue( strike,  forward,  type);
  }

  OptionType str2OptionType( const char* strType)
  {
    OptionType retVal = typeNone;

    if      ( ! _stricmp(strType , "call")) retVal = Call;
    else if ( ! _stricmp(strType , "payers") ) retVal = Call;
    else if ( ! _stricmp(strType , "pay") ) retVal = Call;
    else if ( ! _stricmp(strType , "cap") ) retVal = Call;
    else if ( ! _stricmp(strType , "Swptn Pay") ) retVal = Call;

    else if ( ! _stricmp(strType , "put") ) retVal = Put;
    else if ( ! _stricmp(strType , "receivers") ) retVal = Put;
    else if ( ! _stricmp(strType , "rec") ) retVal = Put;
    else if ( ! _stricmp(strType , "floor") ) retVal = Put;
    else if ( ! _stricmp(strType , "Swptn Rec") ) retVal = Put;

    else if ( ! _stricmp(strType , "straddle") ) retVal = Straddle;
    else if ( ! _stricmp(strType , "s") ) retVal = Straddle;

    return retVal;
  }

  OptionModel str2OptionModel( const char* strType)
  {
    OptionModel retVal = ModelNone;

    if      ( ! _stricmp(strType , "Black")) retVal = BlackLogNormal;
    else if ( ! _stricmp(strType , "lognormal") ) retVal = BlackLogNormal;

    else if ( ! _stricmp(strType , "Normal") ) retVal = BlackNormal;
    else if ( ! _stricmp(strType , "BlackNormal") ) retVal = BlackNormal;

    else if ( ! _stricmp(strType , "BlackMixed") ) retVal = BlackMixed;
    else if ( ! _stricmp(strType , "Mixed") ) retVal = BlackMixed;

    else if ( ! _stricmp(strType , "QModel") ) retVal = QModel;
    else if ( ! _stricmp(strType , "Q") ) retVal = QModel;

    else if ( ! _stricmp(strType , "SABR") ) retVal = SABR;

		else if ( ! _stricmp(strType , "AFSABR") ) retVal = AFSABR;

    else if ( ! _stricmp(strType , "SABRN") ) retVal = SABRNormal;
    else if ( ! _stricmp(strType , "SABRNormal") ) retVal = SABRNormal;

    else if ( ! _stricmp(strType , "SABRL") ) retVal = SABRLogNormal;
    else if ( ! _stricmp(strType , "SABRLog") ) retVal = SABRLogNormal;
    else if ( ! _stricmp(strType , "SABRLogNormal") ) retVal = SABRLogNormal;

    else mcpl_error("Bad option type " + string(strType) );

    return retVal;
  }

  unsigned wdPerYear( CURRENCY c )
  {
    unsigned days;
    switch (c)
    {
    case USD:
      days = 252;
      break;
    case EUR:
      days = 256;
      break;
    default:
      mcpl_error("Unknown currency in wdPerYear");
      break;
    }

    return days;
  }


} // namepsace MCPL