#include"BasisSwap.h"
#include<math.h>

namespace MCPL
{

		//Basis swap
	BasisSwap::BasisSwap( date & start, date & mature, double notional, double leg1Spread, double leg2Spread, 
		  long int leg1PmtsPerYear, long int leg2PmtsPerYear, DayBasis leg1Basis, DayBasis leg2Basis, 
		  Handle<RatesCurve> discountCurve, Handle<RatesCurve> leg1forecastCurve, Handle<RatesCurve> leg2forecastCurve, HOLIDAYCAL hol )
			: Swap(start, mature, notional, leg1Spread, leg2Spread, leg1PmtsPerYear, leg2PmtsPerYear, leg1Basis, 
						leg2Basis, discountCurve, leg1forecastCurve, leg2forecastCurve, hol )
	{
		if ( leg1PmtsPerYear > leg2PmtsPerYear )
		{
			p_defaultLeg = 0;
		}
		else
		{
			p_defaultLeg = 1;
		}
	}

		//Basis swap no curves
	BasisSwap::BasisSwap( date & start, date & mature, double notional, double leg1Spread, double leg2Spread, 
		  long int leg1PmtsPerYear, long int leg2PmtsPerYear, DayBasis leg1Basis, DayBasis leg2Basis, HOLIDAYCAL hol )
			: Swap(start, mature, notional, leg1Spread, leg2Spread, leg1PmtsPerYear, leg2PmtsPerYear, leg1Basis, 
						leg2Basis, hol )
	{
		if ( leg1PmtsPerYear > leg2PmtsPerYear )
		{
			p_defaultLeg = 0;
		}
		else
		{
			p_defaultLeg = 1;
		}
	}

	// Solve for spread. legToSolveFor has to be either 0 or 1.
	double BasisSwap::Solve(double dPresentValue, int legToSolveFor)
  {

		if ( (legToSolveFor < 0) || (legToSolveFor > 1) )
		{
			mcpl_error("leg number must be 0 or 1 in BasisSwap::Solve()");
		}

		double dSwapBpv = 0.0;
    double dTarget = 0.0;

    Handle<Leg> leg = getLeg(legToSolveFor);
    double  dSwapValue = Price();
    dSwapBpv = leg->BasisPointValue() * leg->getNotional();
    dTarget = ( dPresentValue - dSwapValue  ) / dSwapBpv  + leg->getSpread();

		return dTarget;
  }


	//*************************************************************************************************

  void BasisSwap::fixFirst(unsigned int legNumber, double rate)
  {

		if (legNumber > getNumberOfLegs() )
		{
			mcpl_error("LegNumber exceeds number of legs in BasisSwap::fixFirst");
		}

		Handle<Leg> leg = getLeg(legNumber);
		if ( ! leg->isFixed() )
		{
			leg->fixFirst(rate);
		}

	}


} //end namespace MCPL