#pragma once
#ifndef MCPLFLATFORWARDSCURVE_H
#define MCPLFLATFORWARDSCURVE_H

#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "discountcurve.h"
#include "PPCurves.h"
#include "Swap.h"
#include "numrec/dnr.h"
#include "LinearCurvesHelpers.h"

using namespace std;

namespace MCPL
{

	namespace FlatForwardsCurveFitFn
	{
		double func_linear(double drop);
	}
		
	class FlatForwardsCurve : public swapData
	{
	public:
		// constructors
		FlatForwardsCurve() : m_curveGood(false) {}

	    void FlatForwardsCurve::create( const vector<double>& Futures, const vector<double>& Adjustmnts, const vector<date>& FuturesDates,
                const vector<date> swapEffDates , const vector<date> swapDates, 
			    const vector<double> & swapRates, const vector<double> & swapTolerances, const SwapType sType,
		        date & today, const map<date,double> & cashParams, CURRENCY ccy, 
                double firstFixRate,
                Handle<RatesCurve> swapDiscountCurve = Handle<RatesCurve>() );

		// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
    Handle<PPCurves> create_PPCurves( double pp_val, bool CalculateGammaCurves = true );

	private:

		void set_currency_defaults(CURRENCY);
		void set_currency_defaults(CURRENCY, SwapType);

		DayBasis m_basis;
		CURRENCY m_ccy;

		long int m_fixedPmtsPerYear;
		long int m_fltPmtsPerYear;
		DayBasis m_fixedBasis;

		date m_today;
		date m_spot;

		Handle<RatesCurve>		m_swapsDiscountCurve;   // discount curve to use for swaps

		bool					m_curveGood;            // Is the curve in a good state?

		HOLIDAYCAL				m_hols;					// holiday cal for the futures
		HOLIDAYCAL				m_swapHols;				// holiday cal for the swaps

		SwapType				m_swapType;

		vector<double>		    m_futures;				// futures prices
		vector<double>		    m_futuresAdj;			// futures convexity adjustments
		vector<date>		    m_futuresStarts;	    // futures start dates
		vector<date>		    m_futuresEnds;	    	// futures end dates
		vector<double>		    m_futuresDCF;		    // futures day count fractions

        date                    m_lastFittedDate;

		vector<double>		    m_parRates;				// swap par points
		vector<double>		    m_swapTolerances;		// Tolerance for fit of swap rate.
		vector<date>			m_swapLastDates;		// swap last dates (last date on which swap depends on the curve)
		vector<date>			m_swapMaturityDates;	// swap maturity dates
		vector<date>			m_swapEffDates;			// The effective dates for the swaps. Allows us to use fwd swaps!
		vector<Swap>			m_swapCashflows;		// the swaps we actually use, one per fixed pmt period

		map<date, double>	    m_cashParams;			// cash maturity/rate pairs.
        double                  m_firstFixRate;         // first coupon rate on float leg

		void calculateDates();
		void calculateCurve();
		void calculateCurveFromFutures();
		void calcFuturesFromSwaps(int index);

		bool cmpvecs( const vector<double> & v1, const vector<double> & v2);
		bool cmpvecs( const vector<date> & v1, const vector<date> & v2);
		bool cmpmaps( const map<date,double> & v1, map<date,double> & v2);

		bool fitParSwap(int index);

		void generateSwapVectors();
		void generateSwapRateVector();

		friend double FlatForwardsCurveFitFn::func_linear(double);
	};

} // namespace MCPL

#endif // MCPLFLATFORWARDSCURVE_H