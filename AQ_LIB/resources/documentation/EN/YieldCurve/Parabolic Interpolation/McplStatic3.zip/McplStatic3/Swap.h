#pragma once
#pragma warning ( disable : 4251 4786 ) 

#ifndef MCPLSWAP_H
#define MCPLSWAP_H
#include "MCPL.h"

#include "mcpldefs.h"

#include<string>
#include<vector>

#include "swapData.h"

#include "leg.h"
#include "Deal.h"

using namespace std;

namespace MCPL
{


class Swap : public Deal
{	
protected:

	DIRECTIONTYPE m_direction;
	HOLIDAYCAL m_hols;
	double m_notional;
	double m_spread;
	double m_coupon;
	bool m_sps; // is this a single period swap?
	bool m_longCoupon;


	typedef vector<Handle<Leg>> vLeg;
	vLeg  v_Leg; 

	date m_matureDate;//unadjusted maturity date
	date m_adjMatureDate;//bad-day-adjusted maturity date
	date m_effectiveDate;
	unsigned int m_roll;

	Handle<RatesCurve> p_DiscountCurve;
	Handle<RatesCurve> p_ForecastCurve;
	Handle<RatesCurve> p_Leg2ForecastCurve;
	shared_ptr<VolatilityGrid> p_CMSvols;

    bool m_IsFRA;
public:
	//constructors
	Swap() :
			p_DiscountCurve(Handle<RatesCurve>()),
			p_ForecastCurve(Handle<RatesCurve>()),
			p_Leg2ForecastCurve(Handle<RatesCurve>()),
			p_CMSvols(shared_ptr<VolatilityGrid>(nullptr))
{ }
//	Swap(const Swap &);

	// Intelligent swap constructor!!
	Swap( DIRECTIONTYPE dir, date & start, date & mature, double notional, double coupon, double spread, 
			long int fixedPmtsPerYear, long int fltPmtsPerYear, DayBasis fixedBasis, DayBasis floatBasis, HOLIDAYCAL hol, bool IsFRA = false);

	// Intelligent swap constructor with a roll date
	Swap( DIRECTIONTYPE dir, date & start, date & mature, date & roll, double notional, double coupon, double spread, 
			long int fixedPmtsPerYear, long int fltPmtsPerYear, DayBasis fixedBasis, DayBasis floatBasis, HOLIDAYCAL hol);

	// Vanilla swap constructor.
	Swap( DIRECTIONTYPE dir, date & start, date & mature, double notional, double coupon, double spread, 
		HOLIDAYCAL hol, CURRENCY ccy);

	// SwapType swap constructor.
	Swap( DIRECTIONTYPE dir, SwapType sType, date & start, date & mature, double notional, double coupon, double spread, 
		HOLIDAYCAL hol, CURRENCY ccy, ROLLTYPE rolltype = ROLL_BACKWARD, bool IsFRA = false);

	// SwapType swap constructor with roll
	Swap( DIRECTIONTYPE dir, SwapType sType, date & start, date & mature, date & roll , double notional, double coupon, double spread, 
		HOLIDAYCAL hol, CURRENCY ccy, bool IsOIS = false);

	// for SPS. floatMonths is numebr of months in floating index.
	Swap (DIRECTIONTYPE dir, date & start, date & mature, double notional, double coupon, double spread, 
			DayBasis fixedBasis, DayBasis floatBasis, long floatMonths, HOLIDAYCAL hol);

	Swap( DIRECTIONTYPE dir, date & start, date & mature, double notional, double coupon, double spread, 
			long int fixedPmtsPerYear, long int fltPmtsPerYear, DayBasis fixedBasis, DayBasis floatBasis, 
			Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, HOLIDAYCAL hol, 
			shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr));
	
	//Can specify the types of both legs
	Swap( PAYTYPE sideOneType, PAYTYPE sideTwoType, date & start, date & firstFixedCoupon, date & mature, 
		  double notional, double coupon, double spread, 
		  long int fixedPmtsPerYear, long int fltPmtsPerYear, DayBasis fixedBasis, DayBasis floatBasis, 
		  Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, HOLIDAYCAL hol, 
		  shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr));

	//Basis swap
	Swap( date & start, date & mature, double notional, double leg1Spread, double leg2Spread, 
		  long int leg1PmtsPerYear, long int leg2PmtsPerYear, DayBasis leg1Basis, DayBasis leg2Basis, 
		  Handle<RatesCurve> discountCurve, Handle<RatesCurve> leg1forecastCurve, Handle<RatesCurve> leg2forecastCurve, HOLIDAYCAL hol );

		//Basis swap no curves
	Swap( date & start, date & mature, double notional, double leg1Spread, double leg2Spread, 
		  long int leg1PmtsPerYear, long int leg2PmtsPerYear, DayBasis leg1Basis, DayBasis leg2Basis, HOLIDAYCAL hol );


	//// As above (i.e. lets you specify the two leg types ) and also alows for index tenors which differ from 12/pmtsperyear
	//// i.e. for CMS swaps.
	//Swap( PAYTYPE sideOneType, PAYTYPE sideTwoType, date & start, date & mature, 
	//	  double notional, double coupon, double spread, 
	//	  long int fixedPmtsPerYear, long int fltPmtsPerYear, long int sideOneTenorMnths, long int sideTwoTenorMnths, 
	//	  SwapType CMStype1, SwapType CMStype2, DayBasis Basis1, DayBasis Basis2, 
	//	  Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, HOLIDAYCAL hol, CURRENCY ccy, 
	//	  VolatilityGrid * pCMSvols = NULL, OptionModel CMSmodel = BlackLogNormal);

	Swap( DIRECTIONTYPE dir, date & start, date & first, date & mature, date & roll, ROLLTYPE rollType, 
		   bool longCoupon, double notional, double coupon, double couponStep, double spread, double spreadStep, 
		   long int fixedPmtsPerYear, long int fltPmtsPerYear, DayBasis fixedBasis, DayBasis floatBasis, 
		   Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, HOLIDAYCAL hol, 
		   shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr));

  // In this constructor, can specify notional, coupon and spread as vectors, one element per
  // payment. If the notional vector has only one element, it is used as a flat notional.
  // Has a roll date, roll fwd/back.
  Swap::Swap( DIRECTIONTYPE dir, date & start, date & first, date & mature, date & roll, 
    ROLLTYPE rolltype, bool longCoupon, const vector<double> & vNotional, const vector<double> & vcoupon, 
    const vector<double> & vspread, long int fixedPmtsPerYear, long int fltPmtsPerYear, 
    DayBasis fixedBasis, DayBasis floatBasis, Handle<RatesCurve> discountCurve, 
	Handle<RatesCurve> forecastCurve, HOLIDAYCAL hol, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr));

  // Clone function which creates a deep clone of cashflows
  virtual shared_ptr<Swap> CloneCashflows();

  shared_ptr<Deal> CloneDealCashflows() { return dynamic_pointer_cast<Deal>(CloneCashflows()); }

	//typedef swapData* LPDATA; // so that templated classes can make pointers to our data
	typedef Handle<RatesCurve> LPDATA; // so that templated classes can make pointers to our data

	
	void addLeg (Handle<Leg> leg);


	void setCoupon(double); //Sets the coupon in all the fixed legs
	void setCoupon(const vector<double>& Coupons); //Sets the coupon in all the fixed legs
	void setSpread(double); //Sets the spread in all the float legs
	void setSpread(const vector<double>& Spreads); //Sets the spread in all the float legs

	void setNotional(const vector<double>& notionals);
	void setNotional(double motional);
	
	Handle<Leg> getLastLeg(); //pops the last leg off the swap.
	Handle<Leg> getLeg(PAYTYPE);
	shared_ptr<Leg> getFirstFixedLeg() { return getLeg(PAYTYPE::MC_FIXED); }
	Handle<Leg> getLeg(unsigned int i) { return v_Leg[i]; }

	void popLeg();

	double Price(); 
	double Price( double coupon ); 
	double PriceLeg(PAYTYPE type, date & payDate );

	double Price(date &); // Price to date
	double Price(date & firstDate, date& lastDate); // Price only pp which fall entorely between dates
	double Price(date &, double rate);
	double Price(date & firstDate, date& lastDate, double rate);
	double Solve(double dPresentValue, SOLVETYPE stSolveType);
	double SolveRateNumeric(double dPresentValue, date priceFrom_);
	double SolveRateNumeric(double dPresentValue_, date priceFrom_, date priceTo_);
	virtual double Solve(double dPresentValue = 0) { return Solve(dPresentValue, solveFORCOUPON ); }
	virtual double SolveForSpread(double dPresentValue = 0) { return Solve(dPresentValue, solveFORSPREAD); }
	double BPV();
	double numericalBPV();
	double notionalBPV();

	void PrintLegPrices();


	void setCurves(Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr));
	void setCurves(Handle<RatesCurve> discCurve, Handle<RatesCurve> leg1fcastCurve, Handle<RatesCurve> leg2fcastCurve, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr));
	void updatePaymentsFromCurves();

	// Fopr a swap, this is the same as set curves. It makes it possible to treat a swap the same as a leg in certain templated hedging functions
	void updatePaymentsFromCurves(Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr))
	{ setCurves( discountCurve , forecastCurve, pCMSvols ); }

	DIRECTIONTYPE getPayOrRec() const { return m_direction; }
	HOLIDAYCAL getHols() const { return m_hols; }

	double getNotional() const { return m_notional; }
	double getCoupon() const { return m_coupon; }
	shared_ptr<vector<double>> getCoupons() const;
	double getSpread() const { return m_spread; }

	unsigned long getNumberOfLegs() { return v_Leg.size(); }

	date getStartDate() { return v_Leg[0]->getStartDate(); }
	date getLastDate();
	date getLastDateFixed();
	date getEffectiveDate() const { return m_effectiveDate; }
	date getMaturityDate() const { return m_matureDate; }
	date getAdjMaturityDate() const { return m_adjMatureDate; }
	unsigned int  getRollDay() const { return m_roll; }
	bool getLongCoupon() const { return m_longCoupon; }


	// A load of eget functions which return the details of the cashflows within the swap.
	// Each one returns a vector of vectors of (whatever);
	// each vector corresponds to the cashflows in each leg.
	// getLegTypes returns a vector of leg types in the same order as the legs are returned in the other fns
	vector<PAYTYPE> & getLegTypes( vector<PAYTYPE> & typeVec );
	
	vector<dateVec> & getStartDates( vector<dateVec> & vecvec );
	vector<dateVec> & getAdjStartDates( vector<dateVec> & vecvec );
	vector<dateVec> & getEndDates( vector<dateVec> & vecvec );
	vector<dateVec> & getAdjEndDates( vector<dateVec> & vecvec );
	vector<dateVec> & getPaymentDates( vector<dateVec> & vecvec );

	vector< vector<double> > & getNotionals( vector< vector<double> > & vecvec );

	vector< vector<double> > & getDCFs( vector< vector<double> > & vecvec );
	vector< vector<double> > & getDiscountFactors( vector< vector<double> > & vecVec );

	vector< vector<double> > & getPayments( vector< vector<double> > & vecvec );
	vector< vector<double> > & getRates( vector< vector<double> > & vecvec );

	Handle<RatesCurve> getDiscountPtr() { return p_DiscountCurve; }
	Handle<RatesCurve> getForecastPtr() { return p_ForecastCurve; }
	Handle<RatesCurve> getLeg2ForecastPtr() { return p_Leg2ForecastCurve; }
	shared_ptr<VolatilityGrid> getVolGridPtr() { return p_CMSvols; }

	virtual void fixFirst( double rate );
	void unfixFirst();

	dealtype getDealType() { return dealtype_swap; }
};

void vanillaSwapParams(CURRENCY ccy, SwapType type,
					   long int & fixedPmtsPerYear, long int & fltPmtsPerYear, 
					   DayBasis & fixedBasis, DayBasis & floatBasis); 

void vanillaSwapParams(CURRENCY ccy, long int & fixedPmtsPerYear, long int & fltPmtsPerYear, 
					   DayBasis & fixedBasis, DayBasis & floatBasis); 


} //namespace MCPL
#endif

// End.
