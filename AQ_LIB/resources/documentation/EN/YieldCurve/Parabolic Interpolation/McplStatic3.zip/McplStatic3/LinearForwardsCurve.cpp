#include"LinearForwardsCurve.h"

#include "numrec/dnrutil.h"


namespace MCPL
{

		void LinearForwardsCurve::create( const vector<date> swapEffDates, const vector<date> swapDates, 
			const vector<double> & swapRates, const vector<double> & swapTolerances, const SwapType sType,
		date & today, const map<date,double> & cashParams, CURRENCY ccy, double fitfactor, Handle<RatesCurve> swapDiscountCurve)
	{
		m_fitfactor = fitfactor;
		
		m_swapsDiscountCurve = swapDiscountCurve;
		if ( !m_swapsDiscountCurve )
			m_swapsDiscountCurve = Handle<RatesCurve>(this,null_deleter());

		if ( (m_today != today) 
			|| ( ccy != m_ccy )
			|| sType != m_swapType 
			|| !cmpvecs(swapEffDates, m_swapEffDates) 
			|| !cmpvecs(swapDates, m_swapMaturityDates) 
			|| !cmpmaps(cashParams, m_cashParams)) 
		{
			set_currency_defaults(ccy, sType);
			m_today = today;
			m_spot = spot(today, ccy);
			
			m_swapType = sType;
			m_swapMaturityDates = swapDates;
			m_swapEffDates = swapEffDates;
			m_parRates = swapRates;
			m_swapTolerances = swapTolerances;
			m_cashParams = cashParams;
			
			clear();
			calculateDates();
			calculateCurve();
		} 
		else 
		{
			m_cashParams = cashParams;
			m_parRates = swapRates;
			m_swapTolerances = swapTolerances;
			clear();
			calculateCurve();
		}
	}



	void LinearForwardsCurve::calculateDates()
	{

		unsigned int n_swaps = m_swapMaturityDates.size();

		if ( n_swaps > 0 )
		{
			// Set up swap dates.

			
			// Set up all pricing swaps
			m_swapCashflows.clear();
			m_cashflows.clear();
			m_linFutsPriceDrops.clear();
			m_segmentLengths.clear();
			m_swapAdjustments.clear();
			m_swapLastDates.clear();


			for ( unsigned int j = 0 ; j < n_swaps ; ++j )
			{

				/*if ( m_fltPmtsPerYear != 4 )
				{*/
					Swap tmpswap = Swap(PAY, m_swapType,  m_swapEffDates[j], m_swapMaturityDates[j], m_swapEffDates[j], 1, .05, 0, m_swapHols, m_ccy);
					m_swapCashflows.push_back( tmpswap );
					m_swapLastDates.push_back( tmpswap.getLastDate() );
				/*}
				else
				{
					Leg leg = Leg( PAY , MC_FIXED, m_swapEffDates[j] , m_swapMaturityDates[j], 1, .05, m_fixedPmtsPerYear, m_fixedBasis, m_swapHols, ROLL_BACKWARD);
					m_cashflows.push_back( leg );
					m_swapLastDates.push_back( leg.getLastDate() );
				}*/
				m_linFutsPriceDrops.push_back(0.0); 
				m_segmentLengths.push_back(0.0);
				m_swapAdjustments.push_back(0);
			}

		}

		// Set up IMM start, end dates and day count fractions.
		m_starts.clear();
		m_ends.clear();
		m_PDCF.clear(); 
		m_futures.clear();

		m_starts.push_back( m_spot );
		m_ends.push_back( addBusinessPeriod(m_spot, DatePeriod(0,3,0), m_hols, true ) );
		m_PDCF.push_back(  dayCountFrac(m_basis, m_starts.back() , m_ends.back() ) );
		m_futures.push_back(0);

		date lastEndDate = m_ends[0];
		date lastSwapEndDate = m_swapLastDates.back();
		int fwdIndex = 2;
		do
		{
			m_starts.push_back(lastEndDate);
			lastEndDate = addBusinessPeriod(m_spot, DatePeriod(0,fwdIndex * 3,0), m_hols , true );
			m_ends.push_back( lastEndDate );
			m_PDCF.push_back( dayCountFrac(m_basis, m_starts.back() , lastEndDate ) );
			m_futures.push_back(0);

			fwdIndex++;
		} while ( lastEndDate < lastSwapEndDate );

		// Now for the swaps


		if ( n_swaps > 0 )
		{

			// setup indeces of corresponding futures for the swaps
			m_linFutsSwapIndex.clear(); // Index of first fut with start date > swap[-1]'s mat date
			m_linFutsSwapIndex.resize(m_swapAdjustments.size() + 1);
			m_linFutsSwapIndex[0] = 1; //The first forward is just the cash rate, so is constant when fitting swaps.

			int swapIndex = 0;
			for ( unsigned int j = 1 ; j < m_ends.size() ; j++ )
			{
				if ( m_starts[j] >= m_swapLastDates[swapIndex] )
				{
					m_linFutsSwapIndex[swapIndex  + 1] = j;
					swapIndex++;
				}
			}

			m_linFutsSwapIndex.back() = j;
		}
	}


	void LinearForwardsCurve::calculateCurve()
	{

		discountCurve cashCurve;

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );
		cashCurve.set(m_today , 1.0 );
		cashCurve.set(m_spot , spotDF );

		map<date,double>::const_iterator it = m_cashParams.begin();
		++it;
		for (  ; it != m_cashParams.end() ; ++it ) 
		{
			dcf = dayCountFrac( m_basis, m_spot, it->first );

			cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
		}


		discountCurve::clear();
		discountCurve::set(m_today , 1.0 );
		discountCurve::set(m_spot , spotDF );

		discountCurve::set(m_ends[0] , cashCurve.get(m_ends[0]) ); // set first discount from LIBOR

		dcf = dayCountFrac( m_basis, m_spot, m_ends[0] );
		m_futures[0] = ((spotDF / cashCurve.get(m_ends[0]))-1)/dcf;

		// The swaps

		m_swapAdjustments.clear();
		for (unsigned int i=0 ; i < m_swapMaturityDates.size(); i++ ) 
		{
			m_swapAdjustments.push_back(0);
		}

		calcFuturesFromSwaps(0);

			/*for ( unsigned int i=0 ; i < m_swapCashflows.size() ; i++ )
			{
			fitSwapAdjs(i);
			}*/
		if ( m_lastUsedSwapIndex > 0 )
		{
			fitNDimSwapAdjs();
		}
	}

	void LinearForwardsCurve::calcFuturesFromSwaps(int index)
	{

		for ( unsigned int i=index ; i < m_swapAdjustments.size() ; i++ )
		{
			if ( !fitFuturesDrops(i) )
				break;
			m_lastUsedSwapIndex = (long) i;
		}

	}

	void LinearForwardsCurve::calculateCurveFromFutures()
	{
		double rate, PDF;
		discountCurve cashCurve;

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );
		cashCurve.set(m_today , 1.0 );
		cashCurve.set(m_spot , spotDF );

		map<date,double>::const_iterator it = m_cashParams.begin();
		++it;
		for (  ; it != m_cashParams.end() ; ++it ) 
		{
			dcf = dayCountFrac( m_basis, m_spot, it->first );

			cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
		}


		discountCurve::clear();
		discountCurve::set(m_today , 1.0 );
		discountCurve::set(m_spot , spotDF );

		discountCurve::set(m_ends[0] , cashCurve.get(m_ends[0]) ); // set first discount from LIBOR

		int nFutures = m_futures.size();
		for ( int i = 0 ; i < nFutures ; ++i ) 
		{
			date start = m_starts[i];
			date end = m_ends[i];

			rate = m_futures[i];

			PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
			discountCurve::set(end , get(start) * PDF );
		}

	}


	//=================================================================================================================
	//  Fitting functions
	//=================================================================================================================


	//
	namespace LinearForwardsCurveFitFn
	{
		int index;
		Handle<LinearForwardsCurve> fitcurve;

		double func_linear(double drop)
		{

			Handle<LinearForwardsCurve> curve = fitcurve;

			for ( int i = curve->m_linFutsSwapIndex[index] ; i < curve->m_linFutsSwapIndex[index+1] ; i++ )
			{
				curve->m_futures[i] = curve->m_futures[i-1] - drop;
				date start = curve->m_starts[i];
				date end = curve->m_ends[i];

				double rate = curve->m_futures[i];

				double PDF = 1.0 / ( 1.0 + rate * curve->m_PDCF[i] );
				curve->set(end , curve->get(start) * PDF );
			}

			double swapRate;
			//if ( curve->m_fltPmtsPerYear != 4 )
			//{
				if ( curve->m_swapsDiscountCurve ) // Discount using suppplied discount curve (i.e. vs 3s) rather than our own.
				{
					curve->m_swapCashflows[index].setCurves(curve->m_swapsDiscountCurve, curve);
				}
				else
				{
					curve->m_swapCashflows[index].setCurves(curve, curve);
				}
				swapRate = (curve->m_swapCashflows[index]).Solve(0, solveFORCOUPON);
			//}
			//else
			//{
			//	curve->m_cashflows[index].setCurves(*curve->m_swapsDiscountCurve, curve);
			//	curve->m_cashflows[index].updatePaymentsFromCurves();
			//	date lastDate = curve->m_cashflows[index].getLastDate();

			//	swapRate = ( curve->get( curve->m_swapEffDates[index] ) - curve->get( lastDate ) )
			//						/ (curve->m_cashflows[index]).BasisPointValue();
			//}
			double targetRate = curve->m_parRates[index];

			return  ( curve->m_swapAdjustments[index] + swapRate - targetRate );
		}
	}

	//
	namespace LinearForwardsCurveMinFn
	{
		int index;
		Handle<LinearForwardsCurve> fitcurve;

		double func_minimise(double adjustment)
		{
			Handle<LinearForwardsCurve> curve = fitcurve;
			int tmpIndex = index;

			fitcurve->m_swapAdjustments[index] = adjustment;
			fitcurve->calcFuturesFromSwaps(index);

			double dDropSum2=0;

			for ( int i=index ; i <= fitcurve->m_lastUsedSwapIndex ; i++ )
			{
				double dDrop;
				if ( i == 0 )
				{
					dDrop = 0;
				}
				else
				{
					dDrop = fitcurve->m_linFutsPriceDrops[i] - fitcurve->m_linFutsPriceDrops[i-1];
				}
				dDropSum2 += dDrop*dDrop;
			}

			double stopFactor = fabs(adjustment) > .005 ? 1000000.0 : 1.0;

			return stopFactor * (sqrt(adjustment*adjustment)  +  fitcurve->m_fitfactor * sqrt(dDropSum2));
		}

	}

	namespace LinearForwardsCurveNDimMinFn
	{
		Handle<LinearForwardsCurve> fitcurve;

		double func_minimise(double adjustments[])
		{
			Handle<LinearForwardsCurve> curve = fitcurve;

			int fi = 0;

			for ( int i=0 ; i <= curve->m_lastUsedSwapIndex ; i++ )
				curve->m_swapAdjustments[i] = adjustments[i+1];

			curve->calcFuturesFromSwaps(0);

			//double dDropSum2 = 0;
			double adjsSum2 = 0;
			double curveLength = 0;

			for ( int i=0 ; i <= curve->m_lastUsedSwapIndex ; i++ )
			{
				/*double dDrop;
				if ( i == 0 )
				{
					dDrop = 0;
				}
				else
				{
					dDrop = curve->m_linFutsPriceDrops[i] - curve->m_linFutsPriceDrops[i-1];
				}*/
				curveLength += curve->m_segmentLengths[i];
				//dDropSum2 += dDrop*dDrop;
				double stopFactor = fabs(adjustments[i+1]) > curve->m_swapTolerances[i + fi] ? 1000000.0 : 1.0;
				adjsSum2 += stopFactor * adjustments[i+1]*adjustments[i+1];
			}

			return sqrt(adjsSum2)  +  curve->m_fitfactor * sqrt(curveLength); // Minimise curve length

//			return sqrt(adjsSum2)  +  curve->m_fitfactor * sqrt(dDropSum2); // minimise dDrops
		}

	}

	//================================================================================================
	//================================================================================================

	bool LinearForwardsCurve::fitFuturesDrops(int index)
	{
		LinearForwardsCurveFitFn::index = index;
		LinearForwardsCurveFitFn::fitcurve = Handle<LinearForwardsCurve>(this,null_deleter());

		double x1=-.001;
		double x2=.001;

		//double drop=0;
		//if ( NUMREC::zbrac(LinearForwardsCurveFitFn::func_linear, &x1, &x2) == 1 )
		//{
		////	drop =  NUMREC::zriddr( LinearForwardsCurveFitFn::func_linear , x1, x2, .001 );
		////	drop =  NUMREC::zbrent( LinearForwardsCurveFitFn::func_linear , x1, x2, .01 );
		//	drop = linearFitter( LinearForwardsCurveFitFn::func_linear , x1, x2, .00001 );
		////	drop = quadraticFitter( LinearForwardsCurveFitFn::func_linear , x1, x2, .00001 );
		//}
		//else
		//{
		//	return false;
		//}


		double drop = linearFitter( LinearForwardsCurveFitFn::func_linear , x1, x2, .00001 );
		//double drop = quadraticFitter( LinearForwardsCurveFitFn::func_linear , x1, x2, .00001 );

		m_linFutsPriceDrops[index] = drop;
		double segmentDrop = 10000 * drop * (m_linFutsSwapIndex[index+1] - m_linFutsSwapIndex[index]);
		double segmentTime = (double)( m_ends[m_linFutsSwapIndex[index+1]-1] - m_starts[m_linFutsSwapIndex[index]] ) / 365.0;
		m_segmentLengths[index] = sqrt( segmentDrop*segmentDrop + segmentTime*segmentTime );

		// Now fix the curve after the fitting!
		for ( int i = m_linFutsSwapIndex[index] ; i < m_linFutsSwapIndex[index+1] ; i++ )
		{
			m_futures[i] = m_futures[i-1] - drop;
			date start = m_starts[i];
			date end = m_ends[i];

			double PDF = 1.0 / ( 1.0 + m_futures[i] * m_PDCF[i] );
			set(end , get(start) * PDF );
		}

		return true;
	}

	//
	bool LinearForwardsCurve::fitSwapAdjs(int index)
	{
		if ( m_fitfactor == 0 )
		{
			m_swapAdjustments[index] = 0;
			return true;
		}
		else
		{

			LinearForwardsCurveMinFn::index = index;
			LinearForwardsCurveMinFn::fitcurve =  Handle<LinearForwardsCurve>(this,null_deleter());

			double x1=-.0005;
			double x2=.0005;
			double x3, f1, f2, f3, xmin;

			NUMREC::mnbrak(&x1, &x2, &x3, &f1, &f2, &f3, LinearForwardsCurveMinFn::func_minimise);

			//NUMREC::golden(x1, x2, x3, LinearForwardsCurveMinFn::func_minimise, .01, &xmin);
			NUMREC::brent(x1, x2, x3, LinearForwardsCurveMinFn::func_minimise, .01, &xmin);

			m_swapAdjustments[index] = xmin;

			// Now fix the curve after the fitting!
			return fitFuturesDrops(index);
		}
	}

	//
	bool LinearForwardsCurve::fitNDimSwapAdjs()
	{
		if ( m_fitfactor == 0 )
		{
			//m_swapAdjustments[index] = 0;
			return true;
		}
		else
		{

			LinearForwardsCurveNDimMinFn::fitcurve =  Handle<LinearForwardsCurve>(this,null_deleter());

			double *x, *y, **p;
			int nDims = m_lastUsedSwapIndex+1;

			x = NUMREC::vector(1,nDims);
			y = NUMREC::vector(1,nDims+1);
			p = NUMREC::matrix(1,nDims+1 , 1,nDims);

			for ( int i=1; i <= nDims+1 ; i++ )
			{
				for ( int j=1 ; j <= nDims ; j++ )
				{
					x[j] = p[i][j] = (i == (j+1) ? 0.00001 : 0.0);
				}
				y[i] = LinearForwardsCurveNDimMinFn::func_minimise(x);
			}

			int nfunc;
			NUMREC::amoeba(p, y, nDims, 1.0e-4, LinearForwardsCurveNDimMinFn::func_minimise, &nfunc);

			for ( int j=1 ; j <= nDims ; j++ )
			{
				m_swapAdjustments[j-1] = p[1][j];
			}

			//double fRet;
			//NUMREC::powell(x, p, nDims, 1.0e-4, &nfunc, &fRet, LinearForwardsCurveNDimMinFn::func_minimise);
			//for ( int j=1 ; j <= nDims ; j++ )
			//{
			//	m_swapAdjustments[j-1] = x[j];
			//}

			// Now fix the curve after the fitting!
			return fitFuturesDrops(0);
		}
	}



	void LinearForwardsCurve::set_currency_defaults(CURRENCY ccy)
	{
		m_ccy = ccy;

		switch(m_ccy)
		{
		case USD:
			set_currency_defaults(ccy, SB3);
			break;
		case EUR:
			set_currency_defaults(ccy, AB6);
			break;
		case JPY:
			set_currency_defaults(ccy, SB6);
			break;
		case GBP:
			set_currency_defaults(ccy, SB6);
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}

	}

	void LinearForwardsCurve::set_currency_defaults(CURRENCY ccy, SwapType type)
	{

		vanillaSwapParams(ccy, type, m_fixedPmtsPerYear, m_fltPmtsPerYear, m_fixedBasis, m_basis) ;

		m_swapType = type;
		m_ccy = ccy;
		this->setCurrency(m_ccy);

		switch(ccy)
		{
		case USD:
			m_swapHols = HOLIDAYCAL(UK | USA);
			m_hols = UK;
			break;
		case EUR:
			m_swapHols = EUTARG;
			m_hols = EUTARG;
			break;
		case JPY:
			m_swapHols = JP;
			m_hols = UK;
			break;
		case GBP:
			m_swapHols = UK;
			m_hols = UK;
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}
	}


	bool LinearForwardsCurve::cmpvecs( const vector<double> & v1, const vector<double> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}
	//
	bool LinearForwardsCurve::cmpvecs( const vector<date> & v1, const vector<date> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}
	//
	bool LinearForwardsCurve::cmpmaps( const map<date,double> & v1, map<date,double> & v2)
	{
		if ( v1.size() != v2.size() ) return false;
		else 
		{
			bool test = true;
			map<date,double>::const_iterator it1 = v1.begin();
			map<date,double>::const_iterator it2 = v2.begin();
			while ( test && ( it1 != v1.end() ) && ( it2 != v2.end() ) )
			{
				if ( it1->first != it2->first ) 
					test = false;

				++it1;
				++it2;
			}		
			return test;
		}
		return false; // should not get here.
	}



	// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
	Handle<PPCurves> LinearForwardsCurve::create_PPCurves( double pp_val )
	{
		Handle<PPCurves> pp_curves = Handle<PPCurves>(new PPCurves());

		int nHedges =  m_futures.size() + m_cashParams.size(); 
		pp_curves->resize( nHedges ); 
		pp_curves->set_ppsize( pp_val/100.0 ); // set the perturb size in factor (i.e. 1 = 1%)

		pp_curves->base() = Handle<RatesCurve>(new LinearForwardsCurve(*this));

		unsigned int i=0;
		// up
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->label(i) = "cash " + (string) it->first;
			pp_curves->up(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] -= pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->label(i) = "Fut " + (string) m_starts[j];
			pp_curves->up(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			m_futures[j] += pp_val;
		}


		// dn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dn(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dn(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			m_futures[j] -= pp_val;
		}


		//upup
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			m_futures[j] -= pp_val;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			it->second += pp_val/100.0;

		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->upup(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] -= pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->upup(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			m_futures[j] += pp_val;
		}

		// updn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->updn(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->updn(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			m_futures[j] -= pp_val;
		}


		//dnup
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			m_futures[j] += 2.0*pp_val;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			it->second -= 2.0*pp_val/100.0;

		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dnup(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j )
		{
			m_futures[j] -= pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dnup(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			m_futures[j] += pp_val;
		}

		// dndn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dndn(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0  ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dndn(i++)= Handle<RatesCurve>(new LinearForwardsCurve(*this));
			m_futures[j] -= pp_val;
		}


		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			m_futures[j] -= pp_val;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			it->second += pp_val/100.0;

		partialClear();
		calculateCurveFromFutures();

		return pp_curves;
	}





} // namespace MCPL