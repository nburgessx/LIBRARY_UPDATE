#include"LinearCurvesHelpers.h"
#include <limits>

namespace MCPL
{
	double linearFitter(std::function<double(double)> func, double x1, double x2, double tol)
	{
		double x=0;

		double ix1 = x1;
		double ix2 = x2;

		double y1 = func(x1);
		double y2 = func(x2);

		if (y1 == std::numeric_limits<double>::infinity() || y2 == std::numeric_limits<double>::infinity() || y1!=y1 /*isnan*/ || y2!=y2 )
			mcpl_error("cannot find solution. NaN or infinity encountered");

		double y = 0.0;

		const int MAX_ITERATIONS = 5;


		for ( int i=0 ; i < MAX_ITERATIONS ; i++ )
		{

			double m = (y2-y1)/(x2-x1);

			x = x1 - y1 / m;

			//if ( x < ix1 )
			//	x = ix1;
			//else if ( x > ix2 )
			//	x = ix2;


			y = func(x);

			if ( tol > fabs(y) )
			{
				return x;
			}
			else
			{
				if ( fabs(y1) > fabs(y2) )
				{
					x1 = x;
					y1 = y;
				}
				else
				{
					x2 = x;
					y2 = y;
				}
			}
		}
		if ( i == MAX_ITERATIONS  &&  (!(tol < fabs(y))  || y == std::numeric_limits<double>::infinity() || y1!=y1 /*isnan*/  ) )
			mcpl_error("cannot find solution. maximum number of iterations reached");
		return x;
	}



	int multiDummyFitter( std::function<void (const vector<double>&, vector<double>&)> func, int n, double x_lo, double x_hi, double tol)
	{
		const int MAX_ITERATIONS = n*2;

		vector<double> x(n);
		vector<double> ix_lo(n);
		vector<double> ix_hi(n);
		vector<double> y_lo(n);
		vector<double> y_hi(n);
		vector<double> y(n);

		for (int i=0; i<n; i++)
		{
			x[i] = 0.0;
			// set the initial solution boundaries
			ix_lo[i] = x_lo;
			ix_hi[i] = x_hi;
			y[i] = 0.0;
		}
		// evaluate function
		func(ix_lo, y_lo);
		func(ix_hi, y_hi);

		// check for infinity and NaNs
//		if (y1 == std::numeric_limits<double>::infinity() || y2 == std::numeric_limits<double>::infinity() || y1!=y1 /*isnan*/ || y2!=y2 )
//			mcpl_error("cannot find solution. NaN or infinity encountered");

		vector<double> m(n);

		// iterate
		for ( int i=0 ; i < MAX_ITERATIONS ; i++ )
		{
			bool solution_found = true;
			// find a better guess
			for (int j=0; j < n; j++)
			{
				if (fabs(y_lo[j])>tol || fabs(y_hi[j])>tol)
				{   // to avoid the dimensions that are not part of solving process
					m[j] = (y_hi[j] - y_lo[j]) / (ix_hi[j] - ix_lo[j]);
					x[j] = ix_lo[j] - y_lo[j] / m[j];
				}
				else
				{
					x[j] = ix_lo[j];
				}
			}
			// evaluate function
			func(x, y);
			for (int j=0; j < n; j++)
			{
				if ( tol > fabs(y[j]) )
				{
				}
				else
				{
					solution_found = false;
					if ( fabs(y_lo[j]) > fabs(y_hi[j]) )
					{
						ix_lo[j] = x[j];
						y_lo[j]  = y[j];
					}
					else
					{
						ix_hi[j] = x[j];
						y_hi[j]  = y[j];
					}
				}
			}// for j
			if (solution_found)
				break;
		}// for i

		if (i >= MAX_ITERATIONS)
			return 1; //failure to converge

		// check the results for infinity or NaN
//		if ( i == MAX_ITERATIONS  &&  (!(tol < fabs(y))  || y == std::numeric_limits<double>::infinity() || y1!=y1 /*isnan*/  ) )
//			mcpl_error("cannot find solution. maximum number of iterations reached");

		return 0; // everything worked ok. found a solution
	}



	//
	void swapPoints(double & x1, double & y1, double & x2, double & y2)
	{
		double tmpx = x2; 
		double tmpy = y2;
		x2 = x1  ; y2 = y1;
		x1 = tmpx; y1 = tmpy;
	}

	//
	void pointSorter(double & x1, double & y1, double & x2, double & y2, double & x3, double & y3)
	{
		if ( x1 > x2 )
		{
			swapPoints(x1,y1,x2,y2);
		}
		if ( x2 > x3 )
		{
			swapPoints(x2,y2,x3,y3);
		}
		if ( x1 > x2 )
		{
			swapPoints(x1,y1,x2,y2);
		}
	}

	//
	double quadraticFitter(std::function<double(double)> func, double x1, double x3, double tol, int maxiterations)
	{

		double x2 = (x3+x1)/2.0;

		double y1 = func(x1);
		double y2 = func(x2);
		double y3 = func(x3);

		//double ix1 = x1;
		//double ix3 = x3;
		//double iy1 = y1;
		//double iy3 = y3;

		pointSorter(x1,y1,x2,y2,x3,y3);

		double x=0;
        double y=0;
		for ( int i=0 ; i < maxiterations ; i++ )
		{

			double R = y2/y3;
			double S = y2/y1;
			double T = y1/y3;

			double P = S*(T*(R-T)*(x3-x2)-(1-R)*(x2-x1));
			double Q = (T-1)*(R-1)*(S-1);

			x = x2 + P/Q;

			y = func(x);

			if ( tol > fabs(y) )
			{
				return x;
			}
			else
			{
				pointSorter(x1,y1,x2,y2,x3,y3);
				if ( fabs(y1) > fabs(y3) )
				{
					x1 = x2;
					y1 = y2;
				}
				else
				{
					x3 = x2;
					y3 = y2;
				}
				x2 = x;
				y2 = y;

				pointSorter(x1,y1,x2,y2,x3,y3);

	/*			if ( x1 < ix1 )
				{
					x1 = ix1;
					y1 = iy1;
					if ( x1 > x2 )
					{
						x2 = (x1+x3)/2.0;
						y2 = (*func)(x2);
					}
				}

				if ( x3 > ix3 )
				{
					x3 = ix3;
					y3 = iy3;
					if ( x3 < x2 )
					{
						x2 = (x1+x3)/2.0;
						y2 = (*func)(x2);
					}
				}*/


			}
		}
		return x;
	}

}