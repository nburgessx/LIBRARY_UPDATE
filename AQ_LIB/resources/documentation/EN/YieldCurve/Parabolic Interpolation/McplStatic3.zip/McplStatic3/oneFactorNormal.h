#pragma once
#ifndef ONEFACTORNORMAL_H
#define ONEFACTORNORMAL_H
#pragma warning ( disable : 4251 4786 ) 
#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "swap.h"
#include "volatilityGrid.h"

#include<string>
#include<vector>


using namespace std;

namespace MCPL
{

class oneFactorNormal
{
public:
 
	// Constructors.
	oneFactorNormal() {}


  // Constructor which can set up its own cashflows and work out forward rates etc...
  // Needs to be given the structure's dates etc.., a discount curve, a forecast curve 
  // and a swaption vol grid. 

  oneFactorNormal( DIRECTIONTYPE dir, date & priceto, date & start, 
    date & first, date & mature, date & roll, bool longCoupon, const vector<double> & vNotionals, 
    vector<double> &vSpread, long int fixedPmtsPerYear, long int fltPmtsPerYear, 
    vector<double> &vStrike, long int noticeDays, long int lockout,	
    long int calls, DayBasis fixedBasis, DayBasis floatBasis, double stepsize, 
    long int nsteps, long int trunc, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, 
    VolatilityGrid & volGrid, HOLIDAYCAL hol);


/*	oneFactor(double* forwards,double* strikes,double* volatilities,
		double* numeraires,double stepsize,long int numberOfSteps,long int trunc,long int numberOfDates,long int ppayerOrReceiver);
*/
	oneFactorNormal(const vector<double> & forwards, const vector<double> & strikes, const vector<double> & volatilities,
		const vector<double> & numeraires, const double stepsize, const long int trunc, const long int numberOfDates, const long int ppayerOrReceiver);

	void setup(const vector<double> & pforwards, const vector<double> & pstrikes, const vector<double> & pvolatilities, 
				const vector<double> & pnumeraires, const double pstepsize, const long int ptrunc, 
				const long int pnumberOfDates, const long int ppayerOrReceiver);


	dateVec & getExerciseDates() { return exerciseDates; }
	dateVec & getStartDates() { return ULstartDates; }
	vector<bool> & getExercise() { return exercise; }

	vector<double> & getNumeraires() { return numeraires; }
	vector<double> & getStrikes() { return strikes; }
	vector<double> & getForwards() { return forwards; }
	vector<double> & getVariances() { return volatilities; }

	 
	shared_ptr<vector<double>> getfutureValues() { return shared_ptr<vector<double>>(new vector<double>(futureValues)); }
	shared_ptr<vector<double>> getpresentValues() { return shared_ptr<vector<double>>(new vector<double>(presentValues)); }
	shared_ptr<vector<double>> getProbabilities() { return shared_ptr<vector<double>>(new vector<double>(transitionProbabilities)); }


	double getUnderlyerPV() { return m_ULPV; }

	// Destructor. (Frees up allocated memory)
	//~oneFactor();


	double priceStructure();


private:


	double approxPV(int i, int trunc);
	void calculateProbabilities(double volatilities,double stepsize,long numberOfSteps,long trunc);

	int numberOfDates;
	int numberOfSteps;
	int trunc;
	int payerOrReceiver;  // this is -1 or 1, depending on whether we have a put or a call.

	double stepsize;
	double m_ULPV;
/*	double* numeraires;
	double* forwards;
	double* strikes;
	double* volatilities;

	double* futureValues;
	double* presentValues;
	double* transitionProbabilities;*/

	vector<double> numeraires;
	vector<double> forwards;
	vector<double> strikes;
	vector<double> volatilities;

	vector<double> futureValues;
	vector<double> presentValues;
	vector<double> transitionProbabilities;


	dateVec exerciseDates ,startDates , ULstartDates;
	vector<bool> exercise;
};

} // Namespace MCPL

#endif // ONEFACTOR_H