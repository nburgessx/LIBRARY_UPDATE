#pragma once
#ifndef _MCPLVOLATILITYGRIDS_H
#define _MCPLVOLATILITYGRIDS_H

#pragma warning ( disable : 4251 4786 ) 
#include "MCPL.h"
//#include "McDataClasses.h"
#include "mcDataClasses/mcDataClasses.h"
#include "mcDateClass/Dates.h"
#include "handle.hpp"
#include "Interpolators.h"
#include "option.h"
#include "blackmodel.h"
#include "SABR.h"

//using namespace std;

namespace MCPL
{


	class strike
	{
	public:
		double m_strike;
		strike() {}
		strike(const strike & stk) : m_strike(stk.m_strike) {}  // Copy constructor
		strike(int stk) : m_strike((double)stk) {}
		strike(double stk) : m_strike(stk) {}
		operator double() const { return  (double)m_strike; }
		operator int() const { return  (int)m_strike; }
		operator unsigned() const { return  (unsigned)m_strike; }
		operator long() const { return  (long)m_strike; }
		friend std::ostream& operator<< (std::ostream&, const strike &);
	};

	class tenor
	{
	public:
		double m_tenor;
		tenor() {};
		tenor(const tenor & tnr) : m_tenor(tnr.m_tenor) {}  // Copy constructor
		tenor(double tnr) : m_tenor(tnr) {}
		tenor(int tnr) : m_tenor((double)tnr) {}
		operator double() const { return  (double)m_tenor; }
		operator int() const { return  (int)m_tenor; }
		operator unsigned() const { return  (unsigned)m_tenor; }
		operator long() const { return  (long)m_tenor; }
		friend std::ostream& operator<< (std::ostream&, const tenor &);
	};

	class expiry
	{
	public:
		long m_expiry;
		expiry() {};
		expiry(const expiry & exp) : m_expiry(exp.m_expiry) {}  // Copy constructor
		expiry(int i) : m_expiry(i) {}  // constructor
		operator double() const { return  (double)m_expiry; }
		operator int() const { return  (int)m_expiry; }
		operator unsigned() const { return  (unsigned)m_expiry; }
		operator long() const { return  (long)m_expiry; }
		friend std::ostream& operator<< (std::ostream&, const expiry &);
	};


	// ******************************************************************************************************

	typedef enum{ STRIKETYPE_ATM, STRIKETYPE_ABSOLUTE } VOLGRID_STRIKETYPE;
	typedef enum{ OFFSETTYPE_SUM, OFFSETTYPE_PRODUCT } VOLGRID_OFFSETTYPE;

	// ******************************************************************************************************

	// VolatilityGrid can give vol for a VolatilityDeal, so derive from this if you want to do this.
	class VolatilityDeal
	{
	public:
		VolatilityDeal() {};
		virtual ~VolatilityDeal() {};

		virtual tenor get_tenor() = 0;
		virtual date get_expiry() = 0;
		virtual strike get_strike() = 0;
		virtual strike get_strikeOffset() { return (strike)(get_forward() - (double)get_strike()); } // How far are we from the ATM
		virtual double get_forward() = 0;
		virtual BlackVol get_vol() = 0;

	};

	// ******************************************************************************************************

	class VolatilityGridBase
	{
	public:

		typedef Cube<double> data_cube;
		typedef data_cube::tri tri;

		VolatilityGridBase() :
			m_strikeType(STRIKETYPE_ABSOLUTE),
			m_today_set(false),
			m_cube_reset(false),
			m_permit_extrapolation(true),
			m_mixing(mixing_model()),
			_shift(0)
		{
			resetAxes();
			Handle<Interpolator> linear_interpolator(new linearInterpolator);
			h_expiry_interpolator = linear_interpolator;
			h_tenor_interpolator = linear_interpolator;
			h_strike_interpolator = linear_interpolator;
		}

		date getSpot(date & spot) const { return (spot = m_today); }
		date getBaseDate() const { return m_today; }

		VOLGRID_STRIKETYPE getStrikeType() const { return m_strikeType; }

		BlackVol get(date & date) const; // Get volatility associated with a date
		BlackVol get(expiry days_to_expiry) const;

		BlackVol get(date & date, tenor) const; // Get volatility with (date,tenor)
		BlackVol get(expiry days_to_exp, tenor) const;

		BlackVol get(date & date, strike) const; // Get volatility with (date,strike)
		BlackVol get(expiry days_to_exp, strike) const;

		BlackVol get(date & date, tenor, strike) const; // Get volatility with (date,tenor,strike)
		BlackVol get(expiry, tenor, strike) const;

		BlackVol get(date & date, tenor, strike, double forward) const; // Get volatility with (date,tenor,strike)
		BlackVol get(expiry, tenor, strike, double forward) const;

		BlackVol get(VolatilityDeal & deal)
		{
			if (m_strikeType == STRIKETYPE_ABSOLUTE)
				return get(deal.get_expiry(), deal.get_tenor(), deal.get_strike());
			else
				return get(deal.get_expiry(), deal.get_tenor(), deal.get_strikeOffset());
		}

		mixing_model & get_mixing() { return m_mixing; }
		double get_mixing(VolatilityDeal & deal) const
		{
			return m_mixing.get_mixing(deal.get_strike(), deal.get_forward(), deal.get_expiry() - m_today, deal.get_vol());
		}
		double get_mixing(strike s, double forward, double days_to_expiry, BlackVol vol) const
		{
			return m_mixing.get_mixing((double)s, forward, days_to_expiry, vol);
		}

		mixing_model get_mixing_model() { return m_mixing; }

		void size(data_cube::tri & size) const { m_data.size(size); }
		unsigned long size() const { return m_data.size(); }


		void setStrikeType(VOLGRID_STRIKETYPE strikeType) { m_strikeType = strikeType; }


		void set(BlackVol flat_vol);

		//		 void set(unsigned index, double vol); // index whole grid as a flat vector.

		void set(date & date, double vol);
		void set(date & date, tenor, double vol);
		//		void set(date & date, unsigned long tenor, double vol) ;
		//		void set(date & date, double strike, double vol) ;
		void set(date & date, strike, double vol);
		//		void set(date & date, unsigned long tenor, double strike, double vol) ;
		void set(date & date, tenor, strike, double vol);

		// 		void set(unsigned long days_to_expiry, double vol) ; 
		void set(expiry days_to_expiry, double vol);
		//		void set(unsigned long days_to_expiry, unsigned long tenor, double vol) ;
		void set(expiry, tenor, double vol);
		//		void set(unsigned long days_to_expiry, double strike, double vol) ;
		void set(expiry, strike, double vol);
		//		void set(unsigned long days_to_expiry, unsigned long tenor, double strike, double vol) ;
		void set(expiry, tenor, strike, double vol);


		void getExpiries(vector<date> & date_vector) const;
		void getExpiries(vector<long> & date_vector) const;
		void getTenors(vector<double> & tenors_vector) const;
		void getStrikes(vector<double> & strikes_vector) const;

		unsigned getNumberOfExpiries() const { return m_days_to_expiry.size(); }
		unsigned getNumberOfTenors() const { return m_tenor_months.size(); }
		unsigned getNumberOfStrikes() const { return m_strikes.size(); }

		double getShift() const { return _shift; }


		void setExpiries(const date & today, const vector<date> & date_vector);
		void setExpiries(const vector<long> & expiry_vector);
		void setTenors(const vector<double> & tenor_vector);
		void setStrikes(const vector<double> & strike_vector);

		void setExpiryInterpolator(Handle<Interpolator> & Interpolator) { h_expiry_interpolator = Interpolator; }
		void setTenorInterpolator(Handle<Interpolator> & Interpolator)  { h_tenor_interpolator = Interpolator; }
		void setStrikeInterpolator(Handle<Interpolator> & Interpolator) { h_strike_interpolator = Interpolator; }

		void set_mixing(double ATM_mixing, double t0_mixing_slope, double min, double max)
		{
			m_mixing.set_mixing(ATM_mixing, t0_mixing_slope, min, max);
		}

		void set_mixing(mixing_model & mixing) { m_mixing = mixing; }

		void setShift(double shift_) { _shift = shift_; }

		Handle<Interpolator> getExpiryInterpolator() { return h_expiry_interpolator; }
		Handle<Interpolator> getTenorInterpolator() { return h_tenor_interpolator; }
		Handle<Interpolator> getStrikeInterpolator() { return h_strike_interpolator; }

		double& operator() (unsigned i) { return m_data(i); } // Call with just one index. Makes it easier to step through all the elements
		const double& operator() (unsigned i) const { return m_data(i); }

		void clear() { m_today_set = false; m_cube_reset = false; m_data.clear(); }

	private:

		CURRENCY m_ccy;
		//OptionModel m_option_model; 

		VOLGRID_STRIKETYPE m_strikeType;  // Is strike an absolute rate, or relative to the ATM rate?

		mixing_model m_mixing;

		double _shift;

		date m_today;
		bool m_today_set;

		bool m_permit_extrapolation;

		bool m_cube_reset;

		Handle<Interpolator> h_expiry_interpolator;
		Handle<Interpolator> h_tenor_interpolator;
		Handle<Interpolator> h_strike_interpolator;

		typedef std::map<long, unsigned long> t_expiry_map;
		typedef std::map<long, unsigned long> t_tenor_map;
		typedef std::map<long, unsigned long> t_strikes_map;

		t_expiry_map m_days_to_expiry;
		t_tenor_map m_tenor_months;
		t_strikes_map m_strikes;

		data_cube m_data;

		void redim_cube();
		void resetAxes();

		double get_nocheck1(expiry days_to_expiry, unsigned col, unsigned  plane) const;
		double get_nocheck2(expiry days_to_expiry, tenor, unsigned  plane) const;
		double get_nocheck3(expiry days_to_expiry, unsigned col, strike) const;

	};

	// ******************************************************************************************************

	class VolatilityGrid : public VolatilityGridBase
	{
	public:

		bool		CorrectForFlyArb;					// Attempt to correct for butterfly arb in low strikes.
		double	FlyStrikeSpacing;					// Spacing between strikes in fly
		double	MaxFlyCorrectionStrike;		// Highest strike for which to correct for fly arb.

		VolatilityGrid() :
			m_option_model(BlackNormal)
		{
			m_nuGrid = shared_ptr<VolatilityGridBase>(new VolatilityGridBase());
			m_rhoGrid = shared_ptr<VolatilityGridBase>(new VolatilityGridBase());
			m_betaGrid = shared_ptr<VolatilityGridBase>(new VolatilityGridBase());
		}


		double getNu(date & date) const { return m_nuGrid->get(date).vol; } // Get volatility associated with a date
		double getNu(expiry days_to_expiry) const { return m_nuGrid->get(days_to_expiry).vol; }
		double getNu(date & date, tenor t) const { return m_nuGrid->get(date, t).vol; } // Get volatility with (date,tenor)
		double getNu(expiry days_to_exp, tenor t) const { return m_nuGrid->get(days_to_exp, t).vol; }

		double getNu(VolatilityDeal & deal) { return getNu(deal.get_expiry(), deal.get_tenor()); }

		double& getNu(unsigned i) { return (*m_nuGrid)(i); } // Call with just one index. Makes it easier to step through all the elements
		const double& getNu(unsigned i) const { return (*m_nuGrid)(i); }

		double getRho(date & date) const { return m_rhoGrid->get(date).vol; } // Get volatility associated with a date
		double getRho(expiry days_to_expiry) const { return m_rhoGrid->get(days_to_expiry).vol; }
		double getRho(date & date, tenor t) const { return m_rhoGrid->get(date, t).vol; } // Get volatility with (date,tenor)
		double getRho(expiry days_to_exp, tenor t) const { return m_rhoGrid->get(days_to_exp, t).vol; }

		double getRho(VolatilityDeal & deal) { return getRho(deal.get_expiry(), deal.get_tenor()); }

		double& getRho(unsigned i) { return (*m_rhoGrid)(i); } // Call with just one index. Makes it easier to step through all the elements
		const double& getRho(unsigned i) const { return (*m_rhoGrid)(i); }

		double getBeta(date & date) const { return m_betaGrid->get(date).vol; } // Get volatility associated with a date
		double getBeta(expiry days_to_expiry) const { return m_betaGrid->get(days_to_expiry).vol; }
		double getBeta(date & date, tenor t) const { return m_betaGrid->get(date, t).vol; } // Get volatility with (date,tenor)
		double getBeta(expiry days_to_exp, tenor t) const { return m_betaGrid->get(days_to_exp, t).vol; }

		double getBeta(VolatilityDeal & deal) { return getBeta(deal.get_expiry(), deal.get_tenor()); }

		double& getBeta(unsigned i) { return (*m_betaGrid)(i); } // Call with just one index. Makes it easier to step through all the elements
		const double& getBeta(unsigned i) const { return (*m_betaGrid)(i); }

		shared_ptr<VolatilityGridBase> getNuGrid() { return m_nuGrid; } // return reference to Nu grid
		shared_ptr<VolatilityGridBase> getRhoGrid() { return m_rhoGrid; } // return reference to Rho grid
		shared_ptr<VolatilityGridBase> getBetaGrid() { return m_betaGrid; } // return reference to Beta grid

		//double getBeta() const { return m_dBeta; }

		SABRParams getSABRParams(date & date) const; // Get volatility associated with a date
		SABRParams getSABRParams(expiry days_to_expiry) const;
		SABRParams getSABRParams(date & date, tenor t) const;
		SABRParams getSABRParams(expiry days_to_exp, tenor t) const;

		SABRParams getSABRParams(VolatilityDeal & deal) const;


		void setNu(double flat_nu) { m_nuGrid->set(BlackVol(flat_nu, 0)); }

		void setNu(date & date, double nu) { m_nuGrid->set(date, nu); }
		void setNu(date & date, tenor t, double nu) { m_nuGrid->set(date, t, nu); }
		void setNu(expiry days_to_expiry, double nu) { m_nuGrid->set(days_to_expiry, nu); }
		void setNu(expiry days_to_expiry, tenor t, double nu) { m_nuGrid->set(days_to_expiry, t, nu); }

		void setRho(date & date, double rho) { m_rhoGrid->set(date, rho); }
		void setRho(date & date, tenor t, double rho) { m_rhoGrid->set(date, t, rho); }
		void setRho(expiry days_to_expiry, double rho) { m_rhoGrid->set(days_to_expiry, rho); }
		void setRho(expiry days_to_expiry, tenor t, double rho) { m_rhoGrid->set(days_to_expiry, t, rho); }

		void setBeta(date & date, double rho) { m_betaGrid->set(date, rho); }
		void setBeta(date & date, tenor t, double rho) { m_betaGrid->set(date, t, rho); }
		void setBeta(expiry days_to_expiry, double rho) { m_betaGrid->set(days_to_expiry, rho); }
		void setBeta(expiry days_to_expiry, tenor t, double rho) { m_betaGrid->set(days_to_expiry, t, rho); }
		//void setFlatBeta(double beta) {  = beta; }

		void setExpiries(const date & today, const vector<date> & date_vector)
		{
			VolatilityGridBase::setExpiries(today, date_vector);
			m_nuGrid->setExpiries(today, date_vector);
			m_rhoGrid->setExpiries(today, date_vector);
			m_betaGrid->setExpiries(today, date_vector);
		}

		void setExpiries(const vector<long> & expiry_vector)
		{
			VolatilityGridBase::setExpiries(expiry_vector);
			m_nuGrid->setExpiries(expiry_vector);
			m_rhoGrid->setExpiries(expiry_vector);
			m_betaGrid->setExpiries(expiry_vector);
		}

		void setTenors(const vector<double> & tenor_vector)
		{
			VolatilityGridBase::setTenors(tenor_vector);
			m_nuGrid->setTenors(tenor_vector);
			m_rhoGrid->setTenors(tenor_vector);
			m_betaGrid->setTenors(tenor_vector);
		}

		void clear()
		{
			VolatilityGridBase::clear();
			m_rhoGrid->clear();
			m_nuGrid->clear();
			m_betaGrid->clear();
		}

	private:

		//double m_dBeta;  // Flat beta
		shared_ptr<VolatilityGridBase> m_rhoGrid; //Correlation grid
		shared_ptr<VolatilityGridBase> m_nuGrid; // Vol of vol grid
		shared_ptr<VolatilityGridBase> m_betaGrid; // Vol of vol grid

		OptionModel m_option_model;
	};




} //namespace MCPL

#endif // _MCPLVOLATILITYGRIDS_H

