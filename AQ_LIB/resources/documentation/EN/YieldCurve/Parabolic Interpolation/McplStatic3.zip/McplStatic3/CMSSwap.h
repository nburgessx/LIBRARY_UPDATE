#pragma once

#ifndef MCPLCMSSWAP_H
#define MCPLCMSSWAP_H

#include "mcpldefs.h"
#include "mathmisc.h"
#include "option.h"
#include "Swap.h"
#include "OISLeg.h"
#include "mcDateClass/dates.h"

using namespace std;
#include<string>
#include<vector>


namespace MCPL
{
	/* the asset swap class is a child of the swap class */
	class CMSSwap : public Swap
	{
	public:
		//constructors
		CMSSwap() {}


		////OIS swap no curves
		//CMSSwap(DIRECTIONTYPE dir, date & start, date & mature, double notional, double FedFundsSpread,
		//	const int rollDay, ROLLTYPE rolltype, long int FFPmtsPerYear, long int FloatPmtsPerYear, DayBasis FFBasis, DayBasis FloatBasis,
		//	HOLIDAYCAL hol, CURRENCY ccy);

		CMSSwap(PAYTYPE sideOneType, PAYTYPE sideTwoType, date & start, date & mature,
			double notional, double spread1, double spread2,
			long int leg1PmtsPerYear, long int leg2PmtsPerYear, long int leg1TenorMnths,
			long int leg2TenorMnths, SwapType CMStype1, SwapType CMStype2,
			DayBasis leg1Basis, DayBasis leg2Basis, HOLIDAYCAL hol, ROLLTYPE rolltype, CURRENCY ccy,
			OptionModel CMSmodel);

	private:

		// Solve for spread. legToSolveFor has to be either 0 or 1.
		virtual double Solve(double dPresentValue) { return SolveForSpread(dPresentValue); }

		virtual double SolveForSpread(double dPresentValue = 0);
	};

}

#endif // MCPLCMSSWAP_H
