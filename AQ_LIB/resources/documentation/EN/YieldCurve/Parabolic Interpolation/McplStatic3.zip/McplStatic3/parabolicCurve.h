#pragma once
#ifndef MCPLPARABOLICCURVE_H
#define MCPLPARABOLICCURVE_H

#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "discountcurve.h"
#include "PPCurves.h"
#include "Swap.h"
#include "numrec/dnr.h"
#include "LinearCurvesHelpers.h"
#include "rateHelpers.h"

using namespace std;

namespace MCPL
{

	namespace ParabolicCurveFitFn
	{
		double func_linear(double flatRate);
		double func_smoothPrev(double b);
		double func_smoothCurr(double b);
	}

	class ParabolicCurve : public swapData, private SmoothCurve
	{
	public:
		// constructors
		ParabolicCurve() : m_curveGood(false), m_appearAsFlat(true), m_prevSmoothData(1.0), m_currSmoothData(1.0) {}

		void ParabolicCurve::create( const vector<Handle<CurveRateHelper>> &Instruments , 
			date & today, CURRENCY ccy, Handle<RatesCurve> swapDiscountCurve = Handle<RatesCurve>(),
			bool IsOIS = false);

		// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
		Handle<PPCurves>  create_PPCurves( double pp_val, bool CalculateGammaCurves = true );

		void addDependent(Handle<RatesCurve> dependentCurve);

		virtual void ParabolicCurve::partialClear() // redefine
		{ 
			swapData::clear_cache();
			swapData::setFlatVol(0);
			SmoothCurve::clear_cache();
			SmoothCurve::setFlatVol(0);
		}

		// this will switch between swapData and SmoothCurve representations!
		virtual double get (const long& dLabel) ;

		// Override clone() from swapData. Allows us to clone a Handle<swapData> that is in fact a Handle<ParabolicCurve>
		virtual Handle<RatesCurve> clone() { return Handle<swapData>(new ParabolicCurve(*this)); }

	private:

		void set_currency_defaults(CURRENCY);
		void set_currency_defaults(CURRENCY, SwapType);

		bool instrumentsChanged(const vector<Handle<CurveRateHelper>> &Instruments);

		DayBasis m_basis;
		CURRENCY m_ccy;

		date m_today;
		date m_spot;

		bool m_IsOIS;

		unsigned int _firstNonCashIndex;

		vector<Handle<CurveRateHelper>>	_instruments;
		Handle<CurveRateHelper>		_ONCash;
		Handle<CurveRateHelper>		_Cash;
		vector<Handle<CurveRateHelper>> _futures;

		Handle<RatesCurve>		m_swapsDiscountCurve;   // discount curve to use for swaps
		vector<Handle<RatesCurve>>	m_dependentCurves;	// Curves that depend on this curve for construction/pricing.

		bool						m_curveGood;            // Is the curve in a good state?

		date						m_lastFittedDate;

		void calculateDates();
		void calculateCurve();
		void calculateCurveFromFutures();
		void calcFuturesFromSwaps(int index);

		bool fitParSwap(int index);

		//Fitting functions.
		static double func_linear2(shared_ptr<ParabolicCurve> fitcurve, unsigned int index, double flatSegmentRate);
		static double func_smoothPrev2(shared_ptr<ParabolicCurve> fitcurve, unsigned int index, double a);
		static double func_smoothCurr2(shared_ptr<ParabolicCurve> fitcurve, unsigned int index, double a);

		date m_prevSmoothDate;// start date of previous parabolic segment
		date m_currSmoothDate;// start date of current parabolic segment
		date m_nextSmoothDate;// start date of the next parabolic segment
		SmoothDFInterpolatorData m_prevSmoothData; // smooth segment parameters for previous segment
		SmoothDFInterpolatorData m_currSmoothData; // smooth segment parameters for the currently fitted segment
		bool  m_appearAsFlat;
		void addSmoothSegment(date start, double df);

		static double convertSimpleRate(double f, double DCF, double dcf);

	};

} // namespace MCPL

#endif // MCPLPARABOLICCURVE_H