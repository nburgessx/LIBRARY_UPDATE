#include "mathmisc.h"
#include "mcpldefs.h"

#include <float.h>

namespace MCPL
{

	static double a1 = 0.31938153;
	static double a2 = -0.356563782;
	static double a3 = 1.781477937;
	static double a4 = -1.821255978;
	static double a5 = 1.330274429;

	/*double CND(double x)
	{
		double dRetValue;

		double L = fabs(x);
		double k = 1.0/(1.0 + 0.2316419*L);

		dRetValue = 1.0 - (1.0/(root2Pi))*(exp(-L*L*0.50)) * (a1*k + a2*k*k + a3*k*k*k + a4*k*k*k*k + a5*k*k*k*k*k);
		if (x < 0.0)
		{
			dRetValue = 1.0 - dRetValue;
		}

		return dRetValue;
	}*/


	/*double erfcc(double x)
	{
		double t,z,ans;

		z=fabs(x);
		t=1.0/(1.0+0.5*z);
		ans=t*exp(-z*z-1.26551223+t*(1.00002368+t*(0.37409196+t*(0.09678418+
			t*(-0.18628806+t*(0.27886807+t*(-1.13520398+t*(1.48851587+
			t*(-0.82215223+t*0.17087277)))))))));
		return x >= 0.0 ? ans : 2.0-ans;
	}*/
	/* (C) Copr. 1986-92 Numerical Recipes Software 21%. */

	double CND2(double x)
	{
		 Normaldist n;
		 return n.cdf(x);
		//static double sqrt2 = sqrt(2.0);
		//return (2.0 - erfcc(x/sqrt2))/2.;
	}




	/*.....................................................**
	** function ppnd() **
	** Applied Statistics algorithm AS111, **
	** Beasley and Springer **
	** compute the inverse distribution function of a **
	** standard normal distribution that is set to the **
	** value of z satisfying P(Z<z) = p. therefore, **
	** 0 < p < 1. ifault = 0 means that all is well. **
	**.....................................................
	double ppnd( double p )
	{ 
	double ppnd1, q,
	zero = 0., 
	split = 0.42,
	half = 0.5,
	one = 1.;
	double r,
	a0 = 2.50662823884,
	a1 = -18.61500062529,
	a2 = 41.39119773534,
	a3 = -25.44106049637,
	b1 = -8.47351093090,
	b2 = 23.08336743743, 
	b3 = -21.06224101826,
	b4 = 3.13082909833,
	c0 = -2.78718931138,
	c1 = -2.29796479134,
	c2 = 4.85014127135,
	c3 = 2.32121276858,
	d1 = 3.54388924762,
	d2 = 1.63706781897;

	int ifault = 0; 

	q = p - half;
	if( fabs(q) > split )
	{
	r = p;
	if ( q > zero ) r = one - p;
	if ( r <= zero )
	{
	mcpl_error("ppnd failed.");
	}
	else
	{
	r = sqrt(-log(r));
	ppnd1 = ((( c3 * r + c2 ) * r + c1 ) * r + c0 );
	ppnd1 = ppnd1 / (( d2 * r + d1 ) * r + one );
	if ( q < 0 ) ppnd1 = -ppnd1;
	return(ppnd1);
	}
	} 
	else
	{
	r = q * q;
	ppnd1 = q * ((( a3 * r + a2 ) * r + a1 ) * r + a0 );
	ppnd1 = ppnd1 / (((( b4 * r + b3 ) * r + b2 ) * r + b1 ) * r + one );
	return( ppnd1 );
	}
	}*/

	/*
	* The inverse standard normal distribution.
	*
	*   Author:      Peter J. Acklam <jacklam@math.uio.no>
	*   URL:         http://www.math.uio.no/~jacklam
	*
	* This function is based on the Matlab code from the address above,
	* translated to C, and adapted for our purposes.
	*/


	//Second attempt

	double ppnd(double p)
	{
		const double a[6] = {
			-3.969683028665376e+01,  2.209460984245205e+02,
			-2.759285104469687e+02,  1.383577518672690e+02,
			-3.066479806614716e+01,  2.506628277459239e+00
		};
		const double b[5] = {
			-5.447609879822406e+01,  1.615858368580409e+02,
			-1.556989798598866e+02,  6.680131188771972e+01,
			-1.328068155288572e+01
		};
		const double c[6] = {
			-7.784894002430293e-03, -3.223964580411365e-01,
			-2.400758277161838e+00, -2.549732539343734e+00,
			4.374664141464968e+00,  2.938163982698783e+00
		};
		const double d[4] = {
			7.784695709041462e-03,  3.224671290700398e-01,
			2.445134137142996e+00,  3.754408661907416e+00
		};

		register double q, t, u;

		if (_isnan(p) || p > 1.0 || p < 0.0)
			mcpl_error("Nan in ppnd (inverse normal)");
		if (p == 0.0)
			mcpl_error("Inf in ppnd (inverse normal)");
		if (p == 1.0)
			mcpl_error("Inf in ppnd (inverse normal)");
		q = __min(p,1-p);
		if (q > 0.02425) 
		{
			/* Rational approximation for central region. */
			u = q-0.5;
			t = u*u;
			u = u*(((((a[0]*t+a[1])*t+a[2])*t+a[3])*t+a[4])*t+a[5])
				/(((((b[0]*t+b[1])*t+b[2])*t+b[3])*t+b[4])*t+1);
		} 
		else 
		{
			/* Rational approximation for tail region. */
			t = sqrt(-2*log(q));
			u = (((((c[0]*t+c[1])*t+c[2])*t+c[3])*t+c[4])*t+c[5])
				/((((d[0]*t+d[1])*t+d[2])*t+d[3])*t+1);
		}
		/* The relative error of the approximation has absolute value less
		than 1.15e-9.  One iteration of Halley's rational method (third
		order) gives full machine precision... */
		t = N(u)-q;    /* error */
		t = t*root2Pi*exp(u*u/2);   /* f(u)/df(u) */
		u = u-t/(1+u*t/2);     /* Halley's method */

		return (p > 0.5 ? -u : u);
	}

	// Calculates the PV of a $1 annuity with a given interest rate.
	//   for non-annual payments, divide rate by payments per year.
	double annuity_pv( double rate, unsigned long payments)
	{
		return (1/rate * ( 1/ - pow(1.0+rate, (double) payments) ));
	}

	int solquad(double a, double b, double c, double* s1, double* s2)
	{
		*s1 = *s2 = 0;

		double dd = b * b - 4.0 * a * c;
		if (dd < 0.0)
		{
			//solution is not real
			return 1;
		}
		double q = -.5 * (b + b / abs(b) * sqrt(b * b - 4.0 * a * c));
		*s1 = q / a;
		*s2 = c / q;
		return 0;
	}

//double ppnd(double p)
//{
//	Normaldist n;
//	return n.invcdf(p);
//}
} // namespace MCPL