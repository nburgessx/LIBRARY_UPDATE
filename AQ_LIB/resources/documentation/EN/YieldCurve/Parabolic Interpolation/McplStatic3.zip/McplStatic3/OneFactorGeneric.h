#pragma once
#ifndef ONEFACTORGENERIC_H
#define ONEFACTORGENERIC_H
#pragma warning ( disable : 4251 4786 ) 
#include "MCPL.h"
#include "mcpldefs.h"
#include "mcDateClass/dates.h"
#include "swap.h"

#include <functional>
#include <string>
#include <vector>


using namespace std;

namespace MCPL
{

	class oneFactorGeneric
	{
	public:

		// Constructors.
		//oneFactorGeneric() {}

		oneFactorGeneric(shared_ptr<Deal> ULdeal_, int nSteps_, double dFwd_, shared_ptr<vector<date>> exDates_, shared_ptr<vector<double>> fwdVols_, bool priceToCancelCashflows_, bool useLinearGenerator_);

		double priceStructure();

		
		shared_ptr<Matrix<double>> getIntrinsicValues() { return shared_ptr<Matrix<double>>(new Matrix<double>(_intrinsicValues)); }
		shared_ptr<Matrix<double>> getValues() { return shared_ptr<Matrix<double>>(new Matrix<double>(_Values)); }
		shared_ptr<Matrix<double>> getProbabilities() { return shared_ptr<Matrix<double>>(new Matrix<double>(_Probabilities)); }
		shared_ptr<Matrix<double>> getExProbMatrix() { return shared_ptr<Matrix<double>>(new Matrix<double>(_ExerciseProbMatrix)); }

		shared_ptr<vector<double>> getExerciseProbs() { return shared_ptr<vector<double>>(new vector<double>(_ExProbs)); }
		shared_ptr<vector<double>> getCumulativeExProbs() { return shared_ptr<vector<double>>(new vector<double>(_CumulativeExProbs)); }
		shared_ptr<vector<double>> getForwardPVs() { return shared_ptr<vector<double>>(new vector<double>(_ForwardPVs)); }


	protected:

		int _nSteps;
		double _dFwd;
		bool _priceToCancelCashflows;
		Matrix<double> _intrinsicValues;
		Matrix<double> _Values;
		Matrix<double> _Probabilities;
		Matrix<double> _ExerciseProbMatrix;
		vector<double> _ExProbs;
		vector<double> _CumulativeExProbs;
		vector<double> _ForwardPVs;
		vector<date> _exDates;
		vector<double> _fwdVols;
		shared_ptr<Deal> _ULdeal;
		bool _useLinearGenerator;

		double approxPV(int i, int trunc);

		virtual void calcInstrinsic() =0;
		virtual void calcInstrinsicFast() = 0;
		virtual void calcProbabilities() = 0;
		double singleBackwardCompute(int nT, int i, std::function<double(int,int)> payoff);
		double BackwardCompute();

		void BackwardComputeExProbs();
		
	};

} // Namespace MCPL

#endif // ONEFACTORGENERIC_H