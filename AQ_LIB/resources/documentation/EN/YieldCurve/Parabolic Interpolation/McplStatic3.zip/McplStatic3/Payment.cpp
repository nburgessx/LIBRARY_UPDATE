#include "payment.h"
#include <iostream>
#include <iomanip>
#include "AFSabrTest.h"

namespace MCPL
{



  double PaymentPeriod::Price()
  {
    return getPaymentAmount() * m_dDiscountFactor;
  }

  double PaymentPeriod::Price( double coupon )
  {
    return getPaymentAmount( coupon ) * m_dDiscountFactor;
  }

	// Gets the number of payments in the current accrual sequence, upto and including this period. Needed for average accrual. 
	double	PaymentPeriod::sumOfDCFInSequence() 
	{
		if ( (m_sequenceNumber > 0) && ( !m_prevPayment.expired() ) &&  m_prevPayment.lock()->getIsAccrualPeriod() )
		{
			return this[-1].sumOfDCFInSequence() + m_dDayCountFraction;
		}
		else
			return m_dDayCountFraction;
	}

  //**************************************************************************************************

	double PaymentPeriod::getAccruedAmount( double coupon)
	{
		double dValueOfPeriod = 0;

		switch(m_ePaymentType)
		{
		case MC_FLOAT:
			if ( (m_sequenceNumber > 0) && ( !m_prevPayment.expired() ) &&  m_prevPayment.lock()->getIsAccrualPeriod()  )
			{
				double prevAcc =   m_prevPayment.lock()->getAccruedAmount(coupon);
				if ( m_accrualType == ACCRUAL_FLAT_COMPOUNDING )
					return prevAcc + (m_dFloatingRate + m_dSpread) * m_dDayCountFraction * (m_dNotional + prevAcc);
				else if (  m_accrualType == ACCRUAL_AVERAGE )
					return prevAcc + (m_dFloatingRate + m_dSpread) * m_dDayCountFraction * m_dNotional;
				else
					mcpl_error("unknown accrual type in MCPL::PaymentPeriod::getAccruedAmount()");
			}
			else
			{
				dValueOfPeriod = (m_dFloatingRate + m_dSpread) * m_dDayCountFraction * m_dNotional;
			}
			break;
		case MC_FIXED:
			dValueOfPeriod = coupon * m_dDayCountFraction * m_dNotional;
			break;
		case MC_BOND:
			dValueOfPeriod = coupon * m_dDayCountFraction * m_dNotional;
			break;
		case MC_PAYMENT:
			dValueOfPeriod = m_dFee;
			break;
		case MC_CMS:
			dValueOfPeriod = (m_dFloatingRate + m_dSpread + m_dCMSAdjustment) * m_dDayCountFraction * m_dNotional;
			break;
		case MC_CAP:
		case MC_FLOOR:
		case MC_STRADDLE:
			OptionType type;
			if ( m_ePaymentType == MC_CAP ) type = Call;
			else if ( m_ePaymentType == MC_FLOOR ) type = Put;
			else type = Straddle;

			if ( m_pVolGrid == NULL )
			{
				dValueOfPeriod = 0;
			}
			else
			{
				switch (m_optionModel)
				{

				case BlackLogNormal:
					dValueOfPeriod = m_dNotional * black(coupon, m_dFloatingRate, m_timeToExpiry,
						m_dVolatility, m_dDayCountFraction, type);
					break;
				case BlackNormal:
					dValueOfPeriod = m_dNotional * blackNormal(coupon, m_dFloatingRate,
						m_timeToExpiry, m_dVolatility, m_dDayCountFraction, type);
					break;
				case BlackMixed:
					dValueOfPeriod = m_dNotional * blackMixed(coupon, m_dFloatingRate,
						m_timeToExpiry, m_dVolatility, m_dDayCountFraction, m_mixing, type);
					break;
				case SABR:
					dValueOfPeriod = m_dNotional * SABR_price(coupon, m_dFloatingRate,
						m_timeToExpiry, m_pVolGrid->getSABRParams(*this), m_dDayCountFraction, type);
					break;
				case SABRNormal:
					dValueOfPeriod = m_dNotional * SABR_priceFromATMNVol(coupon, m_dFloatingRate,
						m_timeToExpiry, m_pVolGrid->getSABRParams(*this), m_dDayCountFraction, type);
					break;
				case SABRLogNormal:
					dValueOfPeriod = m_dNotional * SABR_priceFromATMLogVol(coupon, m_dFloatingRate,
						m_timeToExpiry, m_pVolGrid->getSABRParams(*this), m_dDayCountFraction, type);
					break;
				case AFSABR:
					dValueOfPeriod = m_dNotional * AFSabrTest::AFSABR_price(coupon, m_dFloatingRate,
						m_timeToExpiry, m_pVolGrid->getSABRParams(*this), m_dDayCountFraction, type);
					break;
				}
				break;
			}
		}

        if (m_IsFRA) // FRA is paid at the start, so final payment needs to be brought to effective date using FLOATING INDEX RATE
            dValueOfPeriod /= (1.0 + m_dFloatingRate*m_dDayCountFraction);

		return dValueOfPeriod;
	}


	double PaymentPeriod::getPaymentAmount( double coupon )
	{
		if ( m_isAccrualPeriod ) // If this is an accrual period, payment is zero!
		{
			return 0;
		}
		else
		{
			if ( m_accrualType == ACCRUAL_AVERAGE )
				return getAccruedAmount(coupon);
			else
				return getAccruedAmount(coupon);
		}
	}


  //**************************************************************************************************


  double PaymentPeriod::getPaymentAmount()
  {
    return getPaymentAmount( m_dCoupon );
  }


	double PaymentPeriod::getAccruedAmount()
  {
    return getAccruedAmount( m_dCoupon );
  }

  //**************************************************************************************************


  double PaymentPeriod::getVega()
  {
    double dVega = 0.0;
    switch(m_ePaymentType)
    {
    case MC_FLOAT:
    case MC_FIXED:
    case MC_BOND:
    case MC_PAYMENT:
    case MC_CMS:
      dVega = 0.0;
      break;
    case MC_CAP:
    case MC_FLOOR:
    case MC_STRADDLE:
      OptionType type;
      if ( m_ePaymentType == MC_CAP ) type = Call;
      else if ( m_ePaymentType == MC_FLOOR ) type = Put;
      else type = Straddle;

      switch( m_optionModel )
      {
      case BlackLogNormal:
        dVega = m_dNotional * blackVega( m_dCoupon, m_dFloatingRate, m_timeToExpiry, 
          m_dVolatility, m_dDayCountFraction, type );
        break;
      case BlackNormal:
        dVega = m_dNotional * blackNormalVega( m_dCoupon, m_dFloatingRate, m_timeToExpiry, 
          m_dVolatility, m_dDayCountFraction, type );
        break;
      case BlackMixed:
        dVega = m_dNotional * blackMixedVega( m_dCoupon, m_dFloatingRate, m_timeToExpiry, 
          m_dVolatility, m_dDayCountFraction, m_mixing, type );
        break;
      }
      break;
    }
    return dVega;
  }

} //Namespace MCPL
