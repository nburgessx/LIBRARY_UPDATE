#pragma once

#ifndef CFSIMPLIEDVOL_H
#define CFSIMPLIEDVOL_H

#include "mcpldefs.h"
#include "mathmisc.h"
#include "option.h"
#include "leg.h"
#include "numrec/dnr.h"

using namespace std;

namespace MCPL
{

		double CFSImpliedLogVol(Leg & cfs, double targetPrice, BlackVol volGuess);


}  // namepsace

#endif // CFSIMPLIEDVOL_H