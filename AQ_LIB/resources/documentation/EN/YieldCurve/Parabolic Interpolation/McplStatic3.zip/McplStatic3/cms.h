#pragma once
#ifndef _MCPLCMS_H
#define _MCPLCMS_H

#pragma warning ( disable : 4251 4786 ) 
#include "MCPL.h"

using namespace std;

namespace MCPL
{

//typedef double (*CMSADJF)(double strike, double fwd_rate, double vol, int days2swap, int swap_years, int);

double cms_swap_adj(double unused_var, double fwd_cms_rate, double vol, double years2swap,
			   int swap_years, double freq);

double cms_swap_normal_adj(double unused_var, double fwd_cms_rate, double vol, double years2swap,
			   int swap_years, double freq);

double cms_cap_adj(double strike, double fwd_cms_rate, double vol, int days2swap,
		    int swap_years, int freq);

double cms_floor_adj(double strike, double fwd_cms_rate, double vol, int days2swap,
		    int swap_years, int freq);
double cms_caplet_price(double strike, double fwd_cms_rate, double vol, int days2swap,
		    int swap_years, int freq);

double cms_floorlet_price(double strike, double fwd_cms_rate, double vol, int days2swap,
		    int swap_years, int freq);

} //namespace MCPL

#endif

