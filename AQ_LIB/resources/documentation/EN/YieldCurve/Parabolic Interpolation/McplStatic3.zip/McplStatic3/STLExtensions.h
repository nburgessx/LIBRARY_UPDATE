#pragma once
#ifndef STLExtensions_H
#define STLExtensions_H
#pragma warning ( disable : 4251 4786 ) 

#include "MCPL.h"

using namespace std;

namespace MCPL
{
	//Return the greatest element that is less than the supplied key, or .end if there isn't one
	template<typename Map> typename Map::const_iterator
		greatest_less(Map const& m, typename Map::key_type const& k) {
			typename Map::const_iterator it = m.lower_bound(k);
			if (it != m.begin()) {
				return --it;
			}
			return m.end();
		}

	template<typename Map> typename Map::iterator
		greatest_less(Map & m, typename Map::key_type const& k) {
			typename Map::iterator it = m.lower_bound(k);
			if (it != m.begin()) {
				return --it;
			}
			return m.end();
		}

	template<typename Map> typename Map::const_iterator
		greatest_lessOrEqual(Map const& m, typename Map::key_type const& k) {
			typename Map::const_iterator it = m.upper_bound(k);
			if (it != m.begin()) {
				return --it;
			}
			return m.end();
		}

	template<typename Map> typename Map::iterator
		greatest_lessOrEqual(Map & m, typename Map::key_type const& k) {
			typename Map::iterator it = m.upper_bound(k);
			if (it != m.begin()) {
				return --it;
			}
			return m.end();
		}
} //namespace MCPL

#endif //STLExtensions_H
