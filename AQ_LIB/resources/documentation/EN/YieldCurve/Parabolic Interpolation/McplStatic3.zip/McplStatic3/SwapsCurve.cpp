#include"SwapsCurve.h"


using namespace NUMREC;

namespace MCPL
{

  void SwapsCurve::calculateDates()
  {

    long n_swaps = m_tenors.size();

    // Set up IMM start, end dates and day count fractions.
    m_swaps.clear(); m_swaps.resize(n_swaps);
    m_end_dates.clear(); m_end_dates.resize(n_swaps);
    m_last_dates.clear(); m_last_dates.resize(n_swaps);
    m_df_dates.clear(); 

    // Set up swap dates.
    for ( int i = 0 ; i < n_swaps ; ++i ) 
    {
      m_end_dates[i] = addBusinessMonths( m_spot, (long)(12*m_tenors[i]), m_hols);
      m_swaps[i] = Swap(PAY, m_swap_type, m_spot, m_end_dates[i], 1, m_par_rates[i], 0, m_hols, m_ccy);
      m_last_dates[i] = m_swaps[i].getLastDate();
      m_df_dates.push_back( m_last_dates[i] );
    }

    // set up 3m fwds dates
    date futureDate = addMonths(m_spot, 3);
    date adjFutureDate = futureDate;
    date lastDate = m_last_dates.back();
    adjFutureDate.rollFwd(m_hols, true);
    while ( adjFutureDate < lastDate ) 
    {
      m_df_dates.push_back( adjFutureDate );
      adjFutureDate = futureDate = addMonths( futureDate, 3);
      adjFutureDate.rollFwd(m_hols, true);
    }
    sort( m_df_dates.begin(), m_df_dates.end() );
  }

  Handle<SwapsCurve> fitcurve;
  int index;
  double func_constant(double x)
  {
    fitcurve->set( fitcurve->m_last_dates[index], x);
    (fitcurve->m_swaps[index]).setCurves(fitcurve,fitcurve);
    return ( (fitcurve->m_swaps[index]).Solve(0, solveFORCOUPON) - fitcurve->m_par_rates[index] );
  }

  double func_linear(double x)
  {
    fitcurve->set( fitcurve->m_last_dates[index], x);
    (fitcurve->m_swaps[index]).setCurves(fitcurve,fitcurve);
    return ( (fitcurve->m_swaps[index]).Solve(0, solveFORCOUPON) - fitcurve->m_par_rates[index] );
  }

  void SwapsCurve::calculateCurve()
  {
    int n_swaps = m_par_rates.size();
    date first_floating_end;
    double df;

    fitcurve = Handle<SwapsCurve>(this,null_deleter());

    set(m_spot , m_stub_curve.get(m_spot) ); // set spot discount factor.

    // find first floating reset
    first_floating_end = addBusinessMonths( m_spot, (long)(12.0/m_fltPmtsPerYear), m_libor_hols, false);
    set(first_floating_end , m_stub_curve.get(first_floating_end) ); // set first fixing.

    for ( int i = 0 ; i < n_swaps ; ++i ) 
    {
      index = i;
      df = zriddr( func_constant, .1, 1, .001 );
      set( m_last_dates[i], df );
    }		
  }

  void SwapsCurve::set_currency_defaults(CURRENCY ccy, SwapType type)
  {

    vanillaSwapParams(ccy, type, m_fxPmtsPerYear, m_fltPmtsPerYear, m_fxBasis, m_fltBasis) ;
		this->setCurrency(ccy);

    switch(m_ccy)
    {
    case USD:
      m_hols = HOLIDAYCAL(UK | USA);
      m_libor_hols = UK;
      break;
    case EUR:
      m_hols = EUTARG;
      m_libor_hols = EUTARG;
      break;
    case JPY:
      m_hols = JP;
      m_libor_hols = UK;
      break;
    case GBP:
      m_hols = UK;
      m_libor_hols = UK;
      break;
    default:
      mcpl_error("No such currency in Swaps curve");
    }

  }
  bool cmpvecs( vector<double> & v1, vector<double> & v2)
  {
    int len;
    if ( (len = v1.size()) != v2.size() ) return false;
    else 
    {
      bool test = true;
      for ( int i=0 ; (i < len) && test ; ++i )
        if (v1[i] != v2[i]) test = false;
      return test;
    }
    return false; // should not get here.
  }


  void SwapsCurve::create( vector<double> & par_rates, vector<double> & tenors, date & spot, SwapType sType, 
    discountCurve & stub, CURRENCY ccy )
  {
    if ( (m_spot != spot) || sType != m_swap_type || ccy != m_ccy || !cmpvecs(m_tenors, tenors)  ) 
    {
      m_ccy = ccy;
      m_swap_type = sType;
      set_currency_defaults(ccy, sType);
      m_spot = spot;
      m_par_rates = par_rates;
      m_tenors = tenors;
      m_stub_curve = stub;
      clear();
      calculateDates();
      calculateCurve();
    } 
    else 
    {
      m_par_rates = par_rates;
      m_stub_curve = stub;
      clear();
      calculateCurve();
    }
  }


} // namespace MCPL
