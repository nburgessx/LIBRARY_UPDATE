#include "GenericBermudan.h"
#include "CorrelationMatrix.h"
#include <math.h>

namespace MCPL
{

	double calamtvol(const Matrix<double>& spnvol, const Matrix<double>& notional, const Matrix<double>& dfgrid, const Matrix<double>& cor);

	GenericBermudan::GenericBermudan(const date & priceto, const shared_ptr<Swap>&  underlyer,
		const vector<double> & vStrikes, long int noticeDays, const vector<bool>& toExercise,
		double stepsize, long int nsteps, long int trunc, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve,
		shared_ptr<VolatilityGrid> volGrid, bool includeSwapPV, bool useAmortisingVolCorrection, OptionModel optModel, double Beta, bool useLinear_)
		:
		Swap(*underlyer),
		m_priceto(priceto),
		m_inputStrikes(vStrikes),
		m_noticeDays(noticeDays),
		m_lockout(0),
		m_calls(0),
		m_stepsize(stepsize),
		m_nsteps(nsteps),
		m_trunc(trunc),
		m_includeSwapPV(includeSwapPV),
		m_optModel(optModel),
		m_beta(Beta),
		_useLinear(useLinear_)
	{
		m_numeraires = shared_ptr<vector<double>>(new vector<double>());
		m_forwards = shared_ptr<vector<double>>(new vector<double>());
		m_zeroOffsetForwards = shared_ptr<vector<double>>(new vector<double>());
		m_strikes = shared_ptr<vector<double>>(new vector<double>());
		m_volStrikes = shared_ptr<vector<double>>(new vector<double>());
		m_adjustedstrikes = shared_ptr<vector<double>>(new vector<double>());
		m_forwardVols = shared_ptr<vector<double>>(new vector<double>());
		m_vols = shared_ptr<vector<double>>(new vector<double>());
		m_ammrtVols = shared_ptr<vector<double>>(new vector<double>());
		m_inputEffectiveStrikes = shared_ptr<vector<double>>(new vector<double>());

		m_ULstartDates = shared_ptr<dateVec>(new dateVec());
		m_exerciseDates = shared_ptr<dateVec>(new dateVec());
		m_startDates = shared_ptr<dateVec>(new dateVec());

		m_exercise = shared_ptr<vector<bool>>(new vector<bool>());
		m_inputExercises = shared_ptr<vector<bool>>(new vector<bool>());

		setCurves(discountCurve, forecastCurve, volGrid);
		int nDates;

		m_ULPV = Swap::Price();

		m_ULstartDates = getLeg(MC_FIXED)->getStartDates();
		unsigned int nStartDates = m_ULstartDates->size();

		if (m_inputStrikes.size() > 1 && m_inputStrikes.size() < nStartDates)
			mcpl_error("There aren't enough strikes in the strikes array.");

		//Always use generic lattice
		_useGenericLattice = true;
		/*double firstStrike = m_inputStrikes[0];

		for (unsigned int i = 1; i < nStartDates; i++)
		{
			if (m_inputStrikes[i] != firstStrike)
			{
				_useGenericLattice = true;
				break;
			}
		}*/

		auto notionals = getLeg(MC_FIXED)->getNotionals();
		for (unsigned int i = 0; i < nStartDates; ++i)
		{
			m_exercise->push_back(false);
			double sum = 0, sumNot=0;
			for (unsigned int j = i; j < nStartDates; j++)
			{
				sum += m_inputStrikes[j] * (*notionals)[j];
				sumNot += (*notionals)[j];
			}
			m_inputEffectiveStrikes->push_back(sum / sumNot);
		}

		for (unsigned int i = 0; i < (unsigned int)min(toExercise.size(), (unsigned int)nStartDates); ++i)
		{
			if (toExercise[i])
			{
				(*m_exercise)[i] = true;
				m_exerciseDates->push_back(addBusinessDays((*m_ULstartDates)[i], -((int)m_noticeDays), this->getHols()));
				m_startDates->push_back((*m_ULstartDates)[i].rollFwd(this->getHols(), true));
			}
		}


		nDates = m_exerciseDates->size();
		m_forwards->resize(nDates);
		m_zeroOffsetForwards->resize(nDates);
		m_strikes->resize(nDates);
		m_volStrikes->resize(nDates);

		m_adjustedstrikes->resize(nDates);
		m_forwardVols->resize(nDates);
		m_vols->resize(nDates);
		m_ammrtVols->resize(nDates);
		m_numeraires->resize(nDates);

		if (useAmortisingVolCorrection)
			setupAmmortisingCurves();
		else
			setupCurves();

	}



	//===============================================================================================
	//===============================================================================================
	void   GenericBermudan::setupCurves()
	{
		// set up the arrays to construct the lattice.

		unsigned long nDates = m_exerciseDates->size();
		unsigned long nULDates = m_ULstartDates->size();
		int n_strike = 0;

		vector<double> ulNotionals, ulSpreads;
		getLeg(MC_FIXED)->getNotionals(ulNotionals);
		getLeg(MC_FLOAT)->getSpreads(ulSpreads);

		//vector<double> adjStrikes , adjFwds;

		for (unsigned int i = 0; i < nULDates; ++i)
		{
			if ((*m_exercise)[i] == true)
			{
				//double vol1, vol2;
				int j = (int)(i * (double(getLeg(MC_FLOAT)->getPaymentsPerYear()) / double(getLeg(MC_FIXED)->getPaymentsPerYear())));
				(*m_strikes)[n_strike] = m_inputStrikes[i];
				(*m_volStrikes)[n_strike] = (*m_inputEffectiveStrikes)[i];

				vector<double> tmpStrikes, tmpSpreads, tmpzeroSpreads, tmpNotionals;

				for (unsigned int k = i; k < m_inputEffectiveStrikes->size(); ++k) tmpStrikes.push_back(m_inputStrikes[k]);
				for (unsigned int k = j; k < ulSpreads.size(); ++k) tmpSpreads.push_back(ulSpreads[k]);
				for (unsigned int k = j; k < ulSpreads.size(); ++k) tmpzeroSpreads.push_back(0);
				for (unsigned int k = i; k < ulNotionals.size(); ++k) tmpNotionals.push_back(abs(ulNotionals[k]));

				// Set up a temp swap to calc forward rates
				//		Swap tempSwap(dir, startDates[i], mature, notional, 0, spreads[i], fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis,
				//					discountCurve, forecastCurve, hol);

				Swap tempSwap(this->getPayOrRec(), (*m_startDates)[n_strike], (*m_startDates)[n_strike], getMaturityDate(), date(2010, 1, getRollDay()), ROLL_FORWARD, m_longCoupon, tmpNotionals,
					tmpStrikes, tmpSpreads, getLeg(MC_FIXED)->getPaymentsPerYear(), getLeg(MC_FLOAT)->getPaymentsPerYear(),
					getLeg(MC_FIXED)->getBasis(), getLeg(MC_FLOAT)->getBasis(), getDiscountPtr(), getForecastPtr(), this->getHols());

				Swap tempZeroSpreadSwap(this->getPayOrRec(), (*m_startDates)[n_strike], (*m_startDates)[n_strike], getMaturityDate(), date(2010, 1, getRollDay()), ROLL_FORWARD, m_longCoupon, tmpNotionals,
					tmpStrikes, tmpzeroSpreads, getLeg(MC_FIXED)->getPaymentsPerYear(), getLeg(MC_FLOAT)->getPaymentsPerYear(),
					getLeg(MC_FIXED)->getBasis(), getLeg(MC_FLOAT)->getBasis(), getDiscountPtr(), getForecastPtr(), this->getHols());

				(*m_forwards)[n_strike] = tempSwap.Solve(0, solveFORCOUPON);
				(*m_zeroOffsetForwards)[n_strike] = tempZeroSpreadSwap.Solve(0, solveFORCOUPON);
				(*m_numeraires)[n_strike] = tempSwap.notionalBPV();
				
				//test
				double offset = (*m_forwards)[n_strike] - (*m_zeroOffsetForwards)[n_strike];
				(*m_adjustedstrikes)[n_strike] = (*m_strikes)[n_strike] - offset;
				(*m_volStrikes)[n_strike] = (*m_volStrikes)[n_strike] - offset;

				// Work out forward variamces
				if (getVolGridPtr()->getShift() != 0.0)
					mcpl_error("GenericBermudan doesn't work with shifted rate models yet.");

				(*m_vols)[n_strike] = getVolGridPtr()->get((expiry)((*m_exerciseDates)[n_strike] - m_priceto), (tenor)dayCountFrac(_30_360f, (*m_startDates)[n_strike],
					getMaturityDate()), (strike)(*m_volStrikes)[n_strike], (*m_zeroOffsetForwards)[n_strike]).vol;
				if (n_strike == 0)
				{
					(*m_forwardVols)[0] = (*m_vols)[0] * (*m_vols)[0] * dayCountFrac(act_365, m_priceto, (*m_exerciseDates)[0]);
				}
				else
				{
					double t2 = dayCountFrac(act_365, m_priceto, (*m_exerciseDates)[n_strike]);
					double t1 = dayCountFrac(act_365, m_priceto, (*m_exerciseDates)[n_strike - 1]);
					double v2 = (*m_vols)[n_strike];
					double v1 = (*m_vols)[n_strike - 1];

					(*m_forwardVols)[n_strike] = v2*v2*t2 - v1*v1*t1 * exp(-2.0*m_beta*(t2 - t1));  // Calc forward variance with beta fudge param.
				}

				if ((*m_forwardVols)[n_strike] <= 0) (*m_forwardVols)[n_strike] = 1e-9;

				



				++n_strike;
			}
		}

		if (nDates > 0)
		{
			// Set up the lattice
			switch (m_optModel)
			{
			case BlackLogNormal:
				if (_useGenericLattice)
					m_Glattice = shared_ptr<oneFactorGeneric>(new oneFactorGenericBlack(shared_ptr<Swap>(this, null_deleter()), m_nsteps, m_stepsize, m_exerciseDates, m_forwardVols, _buy, _useLinear));
				else
					m_lattice = oneFactor(*m_zeroOffsetForwards, *m_adjustedstrikes, *m_forwardVols, *m_numeraires, m_stepsize, m_trunc, m_nsteps, this->getPayOrRec() == PAY ? 0 : 1);
				break;
			case BlackNormal:
				if (_useGenericLattice)
					m_Glattice = shared_ptr<oneFactorGeneric>(new oneFactorGenericNormal(shared_ptr<Swap>(this, null_deleter()), m_nsteps, m_stepsize, m_exerciseDates, m_forwardVols, _buy, _useLinear));
				else
					m_normalLattice = shared_ptr<oneFactorNormal>(new oneFactorNormal(*m_zeroOffsetForwards, *m_adjustedstrikes, *m_forwardVols, *m_numeraires, m_stepsize, m_trunc, m_nsteps, this->getPayOrRec() == PAY ? 0 : 1));
				break;
			default:
				mcpl_error("Bermudan Swap cannot price this type of option yet");
			}
		}
	}



	void   GenericBermudan::setupAmmortisingCurves()
	{
		// set up the arrays to construct the lattice.

		unsigned long nDates = m_exerciseDates->size();
		unsigned long nULDates = m_ULstartDates->size();
		int n_strike = 0;
		double swapRate = 0;

		vector<double> ulNotionals, ulSpreads;
		getLeg(MC_FIXED)->getNotionals(ulNotionals);
		auto ulStrikes = getLeg(MC_FIXED)->getCoupons();
		getLeg(MC_FLOAT)->getSpreads(ulSpreads);


		Matrix<int> ngrid(nULDates + 1, 1);
		Matrix<double> dfgrid(nULDates + 1, 1);
		Matrix<double> notional(nULDates + 1, 1);
		vector<double> vec_dfs;
		vector<date> vec_payDates;
		//vector<double> adjStrikes , adjFwds;

		getLeg(MC_FIXED)->getDiscountFactors(vec_dfs);
		getLeg(MC_FIXED)->getPaymentDates(vec_payDates);

		dfgrid(0) = this->getDiscountPtr()->getDiscountFactor((*m_ULstartDates)[0]);
		ngrid(0) = ((*m_ULstartDates)[0] - m_priceto);
		for (unsigned i = 0; i < nULDates; ++i)
		{
			notional(i) = abs(ulNotionals[i]);
			dfgrid(i + 1) = vec_dfs[i];
			ngrid(i + 1) = (vec_payDates[i] - m_priceto);
		}

		CorrelationMatrix corr(ngrid);

		for (unsigned int i = 0; i < nULDates; ++i)
		{
			if ((*m_exercise)[i] == true)
			{
				int j = (int)(i * (double(getLeg(MC_FLOAT)->getPaymentsPerYear()) / double(getLeg(MC_FIXED)->getPaymentsPerYear())));
				(*m_strikes)[n_strike] = m_inputStrikes[i];
				(*m_volStrikes)[n_strike] = (*m_inputEffectiveStrikes)[i];

				vector<double> tmpStrikes, tmpSpreads, tmpzeroSpreads, tmpNotionals;
				vector<date> fwdSwapStarts, fwdSwapEnds;

				for (unsigned int k = i; k < ulNotionals.size(); ++k) tmpStrikes.push_back(m_inputStrikes[k]);
				for (unsigned int k = j; k < ulSpreads.size(); ++k) tmpSpreads.push_back(ulSpreads[k]);
				for (unsigned int k = j; k < ulSpreads.size(); ++k) tmpzeroSpreads.push_back(0);
				for (unsigned int k = i; k < ulNotionals.size(); ++k) tmpNotionals.push_back(abs(ulNotionals[k]));

				// Set up a temp swap to calc forward rates
				Swap tempSwap(this->getPayOrRec(), (*m_startDates)[n_strike], (*m_startDates)[n_strike], getMaturityDate(), date(2010, 1, getRollDay()), ROLL_FORWARD, m_longCoupon, tmpNotionals,
					tmpStrikes, tmpSpreads, getLeg(MC_FIXED)->getPaymentsPerYear(), getLeg(MC_FLOAT)->getPaymentsPerYear(),
					getLeg(MC_FIXED)->getBasis(), getLeg(MC_FLOAT)->getBasis(), getDiscountPtr(), getForecastPtr(), this->getHols());
				Swap tempZeroSpreadSwap(this->getPayOrRec(), (*m_startDates)[n_strike], (*m_startDates)[n_strike], getMaturityDate(), date(2010, 1, getRollDay()), ROLL_FORWARD, m_longCoupon, tmpNotionals,
					tmpStrikes, tmpzeroSpreads, getLeg(MC_FIXED)->getPaymentsPerYear(), getLeg(MC_FLOAT)->getPaymentsPerYear(),
					getLeg(MC_FIXED)->getBasis(), getLeg(MC_FLOAT)->getBasis(), getDiscountPtr(), getForecastPtr(), this->getHols());



				(*m_forwards)[n_strike] = tempSwap.Solve(0, solveFORCOUPON);
				(*m_zeroOffsetForwards)[n_strike] = tempZeroSpreadSwap.Solve(0, solveFORCOUPON);
				(*m_numeraires)[n_strike] = tempSwap.notionalBPV();

				//test
				double offset = (*m_forwards)[n_strike] - (*m_zeroOffsetForwards)[n_strike];
				(*m_adjustedstrikes)[n_strike] = (*m_strikes)[n_strike] - offset;
				(*m_volStrikes)[n_strike] = (*m_volStrikes)[n_strike] - offset;

				if (n_strike == 0)
					swapRate = (*m_forwards)[n_strike];

				expiry expdt = (expiry)((*m_exerciseDates)[n_strike] - m_priceto);

				if (getVolGridPtr()->getShift() != 0.0)
					mcpl_error("GenericBermudan doesn't work with shifted rate models yet.");

				(*m_vols)[n_strike] = getVolGridPtr()->get(expdt, (tenor)dayCountFrac(_30_360f, (*m_startDates)[n_strike], getMaturityDate()),
					(strike)(*m_volStrikes)[n_strike], (*m_zeroOffsetForwards)[n_strike]).vol;

				Handle<Leg>  fxdLeg = tempSwap.getLeg(MC_FIXED);
				fxdLeg->getAdjStartDates(fwdSwapStarts);
				fxdLeg->getAdjEndDates(fwdSwapEnds);

				Matrix<double> tmpspnvol(tmpNotionals.size(), 1);
				double fwdNotionalSum = 0;
				double fwdNotCouponSum = 0;
				//vector<double> test; // Just for debugging.
				for (unsigned n_pp = 0; n_pp < fwdSwapStarts.size(); ++n_pp)
				{
					double fwdVolFwdRate = tempSwap.SolveRateNumeric(0, (*m_startDates)[n_strike], fwdSwapEnds[n_pp]); 
					double fwdVolZeroOffsetFwdRate = tempZeroSpreadSwap.SolveRateNumeric(0, (*m_startDates)[n_strike], fwdSwapEnds[n_pp]);
					double fwdOffset = fwdVolFwdRate - fwdVolZeroOffsetFwdRate;
					unsigned int indexOffset = nULDates - fwdSwapStarts.size();
					fwdNotionalSum += ulNotionals[i + n_pp];
					fwdNotCouponSum += ulNotionals[i + n_pp] * ulStrikes->operator[](i+n_pp);
					double fwdVolStrike = fwdNotCouponSum/fwdNotionalSum - offset;

					tenor t = dayCountFrac(_30_360f, (*m_startDates)[n_strike], fwdSwapEnds[n_pp]);
					tmpspnvol(n_pp) = getVolGridPtr()->get(expdt, t, (strike)fwdVolStrike, fwdVolZeroOffsetFwdRate).vol;
					//test.push_back(tmpspnvol(n_pp));
				}
				tmpspnvol(tmpNotionals.size() - 1) = (*m_vols)[n_strike];
				//test.push_back(tmpspnvol(tmpNotionals.size() - 1));

				Matrix<double> tmpcor = corr(i, i, nULDates - 1, nULDates - 1);

				(*m_ammrtVols)[n_strike] = calamtvol(tmpspnvol, notional(i, 0, nULDates - 1, 0), dfgrid(i, 0, nULDates, 0), tmpcor);

				// Work out forward variamces
				if (n_strike == 0)
				{
					(*m_forwardVols)[0] = (*m_ammrtVols)[n_strike] * (*m_ammrtVols)[n_strike] * dayCountFrac(act_365, m_priceto, (*m_exerciseDates)[0]);
				}
				else
				{
					double t2 = dayCountFrac(act_365, m_priceto, (*m_exerciseDates)[n_strike]);
					double t1 = dayCountFrac(act_365, m_priceto, (*m_exerciseDates)[n_strike - 1]);
					double v2 = (*m_ammrtVols)[n_strike];
					double v1 = (*m_ammrtVols)[n_strike - 1];

					(*m_forwardVols)[n_strike] = v2*v2*t2 - v1*v1*t1 * exp(-2.0*m_beta*(t2 - t1));  // Calc forward variance with beta fudge param.
				}

				if ((*m_forwardVols)[n_strike] <= 0) (*m_forwardVols)[n_strike] = 1e-9;

				

				++n_strike;
			}
		}

		if (nDates > 0)
		{
			// Set up the lattice
			switch (m_optModel)
			{
			case BlackLogNormal:
				if (_useGenericLattice)
					m_Glattice = shared_ptr<oneFactorGeneric>(new oneFactorGenericBlack(shared_ptr<Swap>(this, null_deleter()), m_nsteps, m_stepsize, m_exerciseDates, m_forwardVols, _buy, _useLinear));
				else
					m_lattice = oneFactor(*m_zeroOffsetForwards, *m_adjustedstrikes, *m_forwardVols, *m_numeraires, m_stepsize, m_trunc, m_nsteps, this->getPayOrRec() == PAY ? 0 : 1);

				break;
			case BlackNormal:
				if (_useGenericLattice)
					m_Glattice = shared_ptr<oneFactorGeneric>(new oneFactorGenericNormal(shared_ptr<Swap>(this, null_deleter()), m_nsteps, m_stepsize, m_exerciseDates, m_forwardVols, _buy, _useLinear));
				else
					m_normalLattice = shared_ptr<oneFactorNormal>(new oneFactorNormal(*m_zeroOffsetForwards, *m_adjustedstrikes, *m_forwardVols, *m_numeraires, m_stepsize, m_trunc, m_nsteps, this->getPayOrRec() == PAY ? 0 : 1));
				break;
			default:
				mcpl_error("Bermudan Swap cannot price this type of option yet");
			}
		}
	}


	void GenericBermudan::updatePaymentsFromCurves(Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, shared_ptr<VolatilityGrid> swaptionVols)
	{
		if (m_exerciseDates->size() > 0)
		{
			Swap::setCurves(discountCurve, forecastCurve, swaptionVols);
			setupCurves();
		}
	}



	double GenericBermudan::Price()
	{
		double price = 0;
		m_ULPV = Swap::Price();
		if (m_exerciseDates->size() > 0)
		{
			if (_useGenericLattice)
				price = m_Glattice->priceStructure()*(_buy ? 1 : -1) + (m_includeSwapPV ? m_ULPV : 0);
			else
			{
				switch (m_optModel)
				{
				case BlackLogNormal:
					price = m_lattice.priceStructure()*(_buy ? 1 : -1) + (m_includeSwapPV ? m_ULPV : 0);
					break;
				case BlackNormal:
					price = m_normalLattice->priceStructure() + (m_includeSwapPV ? m_ULPV : 0);
					break;
				default:
					mcpl_error("Bermudan Swap cannot price this type of option yet");
				}
			}
		}
		return price;
	}




} // namespace MCPL