#include "BermudanSwap.h"
#include "CorrelationMatrix.h"
#include <math.h>

namespace MCPL
{

	double calamtvol(const Matrix<double>& spnvol, const Matrix<double>& notional, const Matrix<double>& dfgrid, const Matrix<double>& cor)
    {
      int i, j;

      int numfxd = spnvol.size();
      vector<double> fwdvol(numfxd);
      double sum = 0.0;

      fwdvol[0] = spnvol(0);

      for (i = 1; i < numfxd; i++)
      {
        Matrix<double> wg(i, 1);
        for (j = 0; j < i; j++)
        {
          wg(j) = (dfgrid(j) - dfgrid(j + 1)) / (dfgrid(0) - dfgrid(i + 1)) * fwdvol[j];
        }

		double b = 2.0 * Matrix<double>::innerProduct(wg, cor(0, i, i-1, i))(0);
        double c = (wg.transpose() * cor(0, 0, i-1, i-1) * wg)(0) - spnvol(i) * spnvol(i);

        double s1, s2;
        int err = solquad(1.0, b, c, &s1, &s2);
        if (err != 0) return -1.0;

        fwdvol[i] = s2 * (dfgrid(0) - dfgrid(i + 1)) / (dfgrid(i) - dfgrid(i + 1));
      }

      sum = 0.0;
      Matrix<double> amtwg(numfxd, 1);

      for (i = 0; i < numfxd; i++)
      {
        amtwg(i) = notional(i) * (dfgrid(i) - dfgrid(i + 1)) * fwdvol[i];
        sum += notional(i) * (dfgrid(i) - dfgrid(i + 1));
      }

      double vmv = (amtwg.transpose() * cor * amtwg)(0);

      if (vmv >= 0.0)
        return sqrt(vmv) / sum;
      else
        return -1.0;
    }


	
	BermudanSwap::BermudanSwap( DIRECTIONTYPE dir, date & priceto, date & start, 
		date & first, date & mature, date & roll, bool longCoupon, const vector<double>& vNotionals, 
		const vector<double> &vSpreads, unsigned int fixedPmtsPerYear, unsigned int fltPmtsPerYear, 
		const vector<double> &vStrikes, long int noticeDays, long int lockout,	
		long int calls, DayBasis fixedBasis, DayBasis floatBasis, double stepsize, 
		long int nsteps, long int trunc, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, 
		shared_ptr<VolatilityGrid> volGrid, HOLIDAYCAL hol, bool includeSwapPV, OptionModel optModel, double Beta)
		:
	Swap(dir, start, first, mature, roll, ROLL_FORWARD, longCoupon, vNotionals, 
		vStrikes, vSpreads, fixedPmtsPerYear, fltPmtsPerYear, 
		fixedBasis, floatBasis, discountCurve, forecastCurve, hol, volGrid),
		m_priceto(priceto),
		m_inputStrikes(vStrikes),
		m_noticeDays(noticeDays),
		m_lockout(lockout),
		m_calls(calls),
		m_stepsize(stepsize),
		m_nsteps(nsteps),
		m_trunc(trunc),
		m_includeSwapPV(includeSwapPV),
		m_optModel(optModel),
		m_beta(Beta)
	{
		int nDates;

		m_ULPV = Swap::Price();

		// Extract the underlying swap's start dates
		//dateVec exerciseDates ,startDates , m_ULstartDates;

		getLeg(MC_FIXED)->getStartDates( m_ULstartDates );
		int nStartDates = m_ULstartDates.size();

		m_inputExercises.clear();
		for ( int i = 0 ; i < nStartDates ; ++i)  
		{
			m_exercise.push_back(false);
			m_inputExercises.push_back(false);
		}

		for ( unsigned int i = m_lockout ; i < m_lockout + m_calls ; ++i ) 
		{

			if ( i >= (unsigned int) nStartDates ) mcpl_error("oneFactorNormal: too many calls or lockouts");

			m_exercise[i] = true;
			m_exerciseDates.push_back( addBusinessDays( m_ULstartDates[i] ,  -((int)m_noticeDays) , this->getHols() ) );
			m_startDates.push_back( m_ULstartDates[i].rollFwd(this->getHols(),true) );
		}

		nDates = m_exerciseDates.size();
		m_forwards.resize(nDates);
		m_strikes.resize(nDates);

		m_forwardVols.resize(nDates);
		m_vols.resize(nDates);
		m_ammrtVols.resize(nDates);
		m_numeraires.resize(nDates);


		setupCurves();
	}

	//===============================================================================================

	BermudanSwap::BermudanSwap( const date & priceto, const Swap&  underlyer,  
      const vector<double> & vStrikes, long int noticeDays, const vector<bool>& toExercise,  
      double stepsize, long int nsteps, long int trunc, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, 
	  shared_ptr<VolatilityGrid> volGrid, bool includeSwapPV, bool useAmortisingVolCorrection, OptionModel optModel, double Beta)
			:
			Swap(underlyer),
		m_priceto(priceto),
		m_inputStrikes(vStrikes),
		m_noticeDays(noticeDays),
		m_lockout(0),
		m_calls(0),
		m_stepsize(stepsize),
		m_nsteps(nsteps),
		m_trunc(trunc),
		m_includeSwapPV(includeSwapPV),
		m_optModel(optModel),
		m_beta(Beta)
	{
		setCurves(discountCurve, forecastCurve, volGrid);
		int nDates;

		m_ULPV = Swap::Price();

		getLeg(MC_FIXED)->getStartDates( m_ULstartDates );
		int nStartDates = m_ULstartDates.size();

		for ( int i = 0 ; i < nStartDates ; ++i)  m_exercise.push_back(false);

		for ( unsigned int i = 0 ; i < (unsigned int) min(toExercise.size(),(unsigned int)nStartDates) ; ++i ) 
		{
			if ( toExercise[i] )
			{
				m_exercise[i] = true;
				m_exerciseDates.push_back( addBusinessDays( m_ULstartDates[i] ,  -((int)m_noticeDays) , this->getHols()) );
				m_startDates.push_back( m_ULstartDates[i].rollFwd(this->getHols(),true) );
			}
		}

		nDates = m_exerciseDates.size();
		m_forwards.resize(nDates);
		m_zeroOffsetForwards.resize(nDates);
		m_strikes.resize(nDates);

		m_adjustedstrikes.resize(nDates);
		m_forwardVols.resize(nDates);
		m_vols.resize(nDates);
		m_ammrtVols.resize(nDates);
		m_numeraires.resize(nDates);

		if ( useAmortisingVolCorrection )
			setupAmmortisingCurves();
		else
			setupCurves();
	}


				//===============================================================================================

	BermudanSwap::BermudanSwap( DIRECTIONTYPE dir, date & priceto, date & start, 
		date & first, date & mature, date & roll, bool longCoupon, const vector<double> & vNotional, 
		const vector<double> &vSpreads, unsigned int fixedPmtsPerYear, unsigned int fltPmtsPerYear, 
		const vector<double> &vStrikes, long int noticeDays, const vector<bool> toExercise, 
		DayBasis fixedBasis, DayBasis floatBasis, double stepsize, 
		long int nsteps, long int trunc, Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, 
		shared_ptr<VolatilityGrid> volGrid, HOLIDAYCAL hol, bool includeSwapPV, OptionModel optModel, double Beta)
		:
	Swap(dir, start, first, mature, roll, ROLL_FORWARD, longCoupon, vNotional, 
		vStrikes, vSpreads, fixedPmtsPerYear, fltPmtsPerYear, 
		fixedBasis, floatBasis, discountCurve, forecastCurve, hol, volGrid),
		m_priceto(priceto),
		m_inputStrikes(vStrikes),
		m_noticeDays(noticeDays),
		m_lockout(0),
		m_calls(0),
		m_stepsize(stepsize),
		m_nsteps(nsteps),
		m_trunc(trunc),
		m_includeSwapPV(includeSwapPV),
		m_optModel(optModel),
		m_beta(Beta)
	{
		int nDates;

		m_ULPV = Swap::Price();

		// Extract the underlying swap's start dates
		//dateVec exerciseDates ,startDates , m_ULstartDates;

		getLeg(MC_FIXED)->getStartDates( m_ULstartDates );
		int nStartDates = m_ULstartDates.size();

		for ( int i = 0 ; i < nStartDates ; ++i)  m_exercise.push_back(false);

		for ( unsigned int i = 0 ; i < (unsigned int) min(toExercise.size(),(unsigned int)nStartDates) ; ++i ) 
		{
			if ( toExercise[i] )
			{
				m_exercise[i] = true;
				m_exerciseDates.push_back( addBusinessDays( m_ULstartDates[i] ,  -((int)m_noticeDays) , this->getHols()) );
				m_startDates.push_back( m_ULstartDates[i].rollFwd(this->getHols(),true) );
			}
		}

		nDates = m_exerciseDates.size();
		m_forwards.resize(nDates);
		m_zeroOffsetForwards.resize(nDates);
		m_adjustedstrikes.resize(nDates);
		m_strikes.resize(nDates);
		m_forwardVols.resize(nDates);
		m_vols.resize(nDates);
		m_ammrtVols.resize(nDates);
		m_numeraires.resize(nDates);


		setupCurves();
	}

	//===============================================================================================
	//===============================================================================================
	void   BermudanSwap::setupCurves()
	{
		// set up the arrays to construct the lattice.

		unsigned long nDates = m_exerciseDates.size();
		unsigned long nULDates = m_ULstartDates.size();
		int n_strike = 0;

		vector<double> ulNotionals, ulSpreads;
		getLeg(MC_FIXED)->getNotionals(ulNotionals);
		getLeg(MC_FLOAT)->getSpreads(ulSpreads);

		//vector<double> adjStrikes , adjFwds;

		for ( unsigned int i=0 ; i < nULDates ; ++i ) 
		{
			if ( m_exercise[i] == true )
			{
				//double vol1, vol2;
				int j = (int)(i * (double(getLeg(MC_FLOAT)->getPaymentsPerYear())/double(getLeg(MC_FIXED)->getPaymentsPerYear())));
				m_strikes[n_strike] = m_inputStrikes[i];

				vector<double> tmpStrikes, tmpSpreads, tmpzeroSpreads, tmpNotionals;

				for ( unsigned int k=i ; k < m_inputStrikes.size() ; ++k ) tmpStrikes.push_back(m_inputStrikes[k]);
				for ( unsigned int k=j ; k < ulSpreads.size() ; ++k ) tmpSpreads.push_back(ulSpreads[k]);
				for ( unsigned int k=j ; k < ulSpreads.size() ; ++k ) tmpzeroSpreads.push_back(0);
				for ( unsigned int k=i ; k < ulNotionals.size() ; ++k ) tmpNotionals.push_back(abs(ulNotionals[k]));

				// Set up a temp swap to calc forward rates
				//		Swap tempSwap(dir, startDates[i], mature, notional, 0, spreads[i], fixedPmtsPerYear, fltPmtsPerYear, fixedBasis, floatBasis,
				//					discountCurve, forecastCurve, hol);

				Swap tempSwap( this->getPayOrRec(), m_startDates[n_strike], m_startDates[n_strike], getMaturityDate(), date(2010,1,getRollDay()), ROLL_FORWARD, m_longCoupon, tmpNotionals, 
					tmpStrikes, tmpSpreads, getLeg(MC_FIXED)->getPaymentsPerYear(), getLeg(MC_FLOAT)->getPaymentsPerYear(), 
					getLeg(MC_FIXED)->getBasis(), getLeg(MC_FLOAT)->getBasis(), getDiscountPtr(), getForecastPtr(), this->getHols());

				Swap tempZeroSpreadSwap( this->getPayOrRec(), m_startDates[n_strike], m_startDates[n_strike], getMaturityDate(), date(2010,1,getRollDay()), ROLL_FORWARD, m_longCoupon, tmpNotionals, 
					tmpStrikes, tmpzeroSpreads, getLeg(MC_FIXED)->getPaymentsPerYear(), getLeg(MC_FLOAT)->getPaymentsPerYear(), 
					getLeg(MC_FIXED)->getBasis(), getLeg(MC_FLOAT)->getBasis(), getDiscountPtr(), getForecastPtr(), this->getHols());

				m_forwards[n_strike] = tempSwap.Solve(0, solveFORCOUPON);
				m_zeroOffsetForwards[n_strike] = tempZeroSpreadSwap.Solve(0, solveFORCOUPON);
				m_numeraires[n_strike] = tempSwap.notionalBPV();

				// Work out forward variamces
				if (getVolGridPtr()->getShift() != 0.0)
					mcpl_error("Bermudan swap doesn't work with shifted rate models yet.");

				m_vols[n_strike] = getVolGridPtr()->get( (expiry) (m_exerciseDates[n_strike]   - m_priceto) , (tenor) dayCountFrac(_30_360f, m_startDates[n_strike], 
																							getMaturityDate()),	(strike) m_strikes[n_strike], m_forwards[n_strike] ).vol;
				if ( n_strike==0 ) 
				{
					m_forwardVols[0] = m_vols[0]*m_vols[0] * dayCountFrac(act_365, m_priceto ,m_exerciseDates[0]) ;
				} 
				else 
				{
					double t2 = dayCountFrac(act_365 , m_priceto , m_exerciseDates[n_strike] );
					double t1 = dayCountFrac(act_365 , m_priceto , m_exerciseDates[n_strike-1]);
					double v2 = m_vols[n_strike];
					double v1 = m_vols[n_strike-1];

					m_forwardVols[n_strike] = v2*v2*t2  -  v1*v1*t1 * exp(-2.0*m_beta*(t2-t1));  // Calc forward variance with beta fudge param.
				}

				if ( m_forwardVols[n_strike] <= 0 ) m_forwardVols[n_strike] = 1e-9;

				//test
				double offset =  m_forwards[n_strike] - m_zeroOffsetForwards[n_strike];
				m_adjustedstrikes[n_strike] =  m_strikes[n_strike] - offset;
				


				++n_strike;
			}
		}

		if ( nDates > 0 )
		{
			// Set up the lattice
			switch (m_optModel)
			{
			case BlackLogNormal:
				m_lattice = oneFactor( m_zeroOffsetForwards, m_adjustedstrikes, m_forwardVols, m_numeraires, m_stepsize, m_trunc , m_nsteps, this->getPayOrRec() == PAY ? 0:1 );
				break;
			case BlackNormal:
				m_normalLattice = oneFactorNormal( m_zeroOffsetForwards, m_adjustedstrikes, m_forwardVols, m_numeraires, m_stepsize, m_trunc , m_nsteps, this->getPayOrRec() == PAY ? 0:1 );
				break;
			default:
				mcpl_error("Bermudan Swap cannot price this type of option yet");
			}
		}
	}



	void   BermudanSwap::setupAmmortisingCurves()
	{
		// set up the arrays to construct the lattice.

		unsigned long nDates = m_exerciseDates.size();
		unsigned long nULDates = m_ULstartDates.size();
		int n_strike = 0;
		double swapRate = 0;

		vector<double> ulNotionals, ulSpreads;
		getLeg(MC_FIXED)->getNotionals(ulNotionals);
		getLeg(MC_FLOAT)->getSpreads(ulSpreads);

		Matrix<int> ngrid(nULDates+1,1);
		Matrix<double> dfgrid(nULDates+1,1);
		Matrix<double> notional(nULDates+1,1);
		vector<double> vec_dfs;
		vector<date> vec_payDates;
		//vector<double> adjStrikes , adjFwds;

		getLeg(MC_FIXED)->getDiscountFactors(vec_dfs);
		getLeg(MC_FIXED)->getPaymentDates(vec_payDates);

		dfgrid(0) = this->getDiscountPtr()->getDiscountFactor(m_ULstartDates[0]);
		ngrid(0) = ( m_ULstartDates[0] - m_priceto );
		for ( unsigned i=0 ; i < nULDates ; ++i )
		{
			notional(i) = abs(ulNotionals[i]);
			dfgrid(i+1) = vec_dfs[i];
			ngrid(i+1) = ( vec_payDates[i] - m_priceto );
		}

		CorrelationMatrix corr(ngrid);

		for ( unsigned int i=0 ; i < nULDates ; ++i ) 
		{
			if ( m_exercise[i] == true )
			{
				int j = (int)(i * (double(getLeg(MC_FLOAT)->getPaymentsPerYear())/double(getLeg(MC_FIXED)->getPaymentsPerYear())));
				m_strikes[n_strike] = m_inputStrikes[i];

				vector<double> tmpStrikes, tmpSpreads, tmpzeroSpreads, tmpNotionals;
				vector<date> tmpStarts, tmpEnds;

				for ( unsigned int k=i ; k < ulNotionals.size() ; ++k ) tmpStrikes.push_back(m_inputStrikes[k]);
				for ( unsigned int k=j ; k < ulSpreads.size() ; ++k ) tmpSpreads.push_back(ulSpreads[k]);
				for ( unsigned int k=j ; k < ulSpreads.size() ; ++k ) tmpzeroSpreads.push_back(0);
				for ( unsigned int k=i ; k < ulNotionals.size() ; ++k ) tmpNotionals.push_back(abs(ulNotionals[k]));

				// Set up a temp swap to calc forward rates
				Swap tempSwap( this->getPayOrRec(), m_startDates[n_strike], m_startDates[n_strike], getMaturityDate(), date(2010,1,getRollDay()), ROLL_FORWARD, m_longCoupon, tmpNotionals, 
					tmpStrikes, tmpSpreads, getLeg(MC_FIXED)->getPaymentsPerYear(), getLeg(MC_FLOAT)->getPaymentsPerYear(), 
					getLeg(MC_FIXED)->getBasis(), getLeg(MC_FLOAT)->getBasis(), getDiscountPtr(), getForecastPtr(), this->getHols());
				Swap tempZeroSpreadSwap( this->getPayOrRec(), m_startDates[n_strike], m_startDates[n_strike], getMaturityDate(), date(2010,1,getRollDay()), ROLL_FORWARD, m_longCoupon, tmpNotionals, 
					tmpStrikes, tmpzeroSpreads, getLeg(MC_FIXED)->getPaymentsPerYear(), getLeg(MC_FLOAT)->getPaymentsPerYear(), 
					getLeg(MC_FIXED)->getBasis(), getLeg(MC_FLOAT)->getBasis(), getDiscountPtr(), getForecastPtr(), this->getHols());
	
				Handle<Leg>  fxdLeg = tempSwap.getLeg(MC_FIXED);
				fxdLeg->getAdjStartDates(tmpStarts);
				fxdLeg->getAdjEndDates(tmpEnds);
				
				m_forwards[n_strike] = tempSwap.Solve(0, solveFORCOUPON);
				m_zeroOffsetForwards[n_strike] = tempZeroSpreadSwap.Solve(0, solveFORCOUPON);
				m_numeraires[n_strike] = tempSwap.notionalBPV();

				if ( n_strike==0 ) 
					swapRate = m_forwards[n_strike];

				expiry expdt = (expiry) (m_exerciseDates[n_strike]   - m_priceto); 

				if (getVolGridPtr()->getShift() != 0.0)
					mcpl_error("Bermudan swap doesn't work with shifted rate models yet.");

				m_vols[n_strike] = getVolGridPtr()->get( expdt , (tenor) dayCountFrac(_30_360f, m_startDates[n_strike], getMaturityDate()),
																								(strike) m_strikes[n_strike], m_forwards[n_strike] ).vol;

				Matrix<double> tmpspnvol(tmpNotionals.size(),1);
				for ( unsigned n_pp=0 ; n_pp < tmpStarts.size() ; ++n_pp )
				{
					tenor t = dayCountFrac(_30_360f, m_startDates[n_strike], tmpEnds[n_pp]);
					tmpspnvol(n_pp) = getVolGridPtr()->get( expdt , t, (strike) swapRate, swapRate ).vol;
				}
				tmpspnvol(tmpNotionals.size()-1) = m_vols[n_strike];

				Matrix<double> tmpcor = corr(i,i,nULDates-1,nULDates-1);

				m_ammrtVols[n_strike] = calamtvol(tmpspnvol, notional(i,0,nULDates-1,0), dfgrid(i,0,nULDates,0), tmpcor);

				// Work out forward variamces
				if ( n_strike==0 ) 
				{
					m_forwardVols[0] = m_ammrtVols[n_strike]*m_ammrtVols[n_strike] * dayCountFrac(act_365, m_priceto ,m_exerciseDates[0]) ;
				} 
				else 
				{
					double t2 = dayCountFrac(act_365 , m_priceto , m_exerciseDates[n_strike] );
					double t1 = dayCountFrac(act_365 , m_priceto , m_exerciseDates[n_strike-1]);
					double v2 = m_ammrtVols[n_strike];
					double v1 = m_ammrtVols[n_strike-1];

					m_forwardVols[n_strike] = v2*v2*t2  -  v1*v1*t1 * exp(-2.0*m_beta*(t2-t1));  // Calc forward variance with beta fudge param.
				}

				if ( m_forwardVols[n_strike] <= 0 ) m_forwardVols[n_strike] = 1e-9;

				//test
				double offset =  m_forwards[n_strike] - m_zeroOffsetForwards[n_strike];
				m_adjustedstrikes[n_strike] = m_strikes[n_strike] - offset ;
				
				++n_strike;
			}
		}

		if ( nDates > 0 )
		{
			// Set up the lattice
			switch (m_optModel)
			{
			case BlackLogNormal:
				m_lattice = oneFactor( m_zeroOffsetForwards, m_adjustedstrikes,  m_forwardVols, m_numeraires, m_stepsize, m_trunc , m_nsteps, this->getPayOrRec() == PAY ? 0:1 );
				break;
			case BlackNormal:
				m_normalLattice = oneFactorNormal( m_zeroOffsetForwards, m_adjustedstrikes, m_forwardVols, m_numeraires, m_stepsize, m_trunc , m_nsteps, this->getPayOrRec() == PAY ? 0:1 );
				break;
			default:
				mcpl_error("Bermudan Swap cannot price this type of option yet");
			}
		}
	}


	void BermudanSwap::updatePaymentsFromCurves(Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, shared_ptr<VolatilityGrid> swaptionVols)
	{
		if ( m_exerciseDates.size() > 0 )
		{
			Swap::setCurves(discountCurve, forecastCurve, swaptionVols);
			setupCurves();
		}
	}



	double BermudanSwap::Price()
	{
		double price = 0;
		m_ULPV = Swap::Price();
		if ( m_exerciseDates.size() > 0 )
		{
			switch (m_optModel)
			{
			case BlackLogNormal:
				price = m_lattice.priceStructure() + (m_includeSwapPV ? m_ULPV : 0);
				break;
			case BlackNormal:
				price = m_normalLattice.priceStructure() + (m_includeSwapPV ? m_ULPV : 0);
				break;
			default:
				mcpl_error("Bermudan Swap cannot price this type of option yet");
			}    
		}
		return price;
	}




} // namespace MCPL