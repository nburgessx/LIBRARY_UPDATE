#include "cms.h"

#include <stdio.h>
#include <math.h>
#include <NumRec/dnr.h>

#include "mcpldefs.h"

#define E 2.718281828459045
#define WIDTH 6.0
#define SQRTWOPI 2.506628274631L

using namespace NUMREC;

namespace MCPL
{

  double  f, mu, t, sigma, sspread, nu, n,strikeK;

  /*********************************************************************/

  double cvxintegrand_swap(double x)
  {
    /*  extern double  f, mu, t, sigma,sspread, nu,n; */
    int i; 
    double y, numerator,denominator, pdf,cf,pinumerator,pidenominator;

    pinumerator=1.0;
    pidenominator=1.0;
    numerator=0.0;
    denominator=0.0;
    sspread=0.0;
    mu=0.0;
    y=(f+sspread)*exp(-x*sigma*sqrt(t)+ (mu-0.5*sigma*sigma)*t)-sspread;
    pdf=1.0/SQRTWOPI * exp(-x*x/2.0);

    for(i=1; i<=n*nu; i++)
    {
      pinumerator=pinumerator/(1.0+f/nu);
      pidenominator=pidenominator/(1.0+y/nu);
      numerator+=pinumerator;
      denominator+=pidenominator;
    }
    if(denominator==0)
      mcpl_error("Zero denominator in cvxintegrand_swap(): index maturity must be above one year");
    cf=(y-f)*numerator/denominator;
    if ( cf == 0 ) mcpl_error( "error in CMS convexity" );
    return cf*pdf;
  }

  /*********************************************************************/

  double cvxintegrand_normal_swap(double x)
  {
    /*  extern double  f, mu, t, sigma,sspread, nu,n; */
    int i; 
    double y, numerator,denominator, pdf,cf,pinumerator,pidenominator;

    pinumerator=1.0;
    pidenominator=1.0;
    numerator=0.0;
    denominator=0.0;
    sspread=0.0;
    mu=0.0;
    y=f-x*sigma*sqrt(t);
    pdf=1.0/SQRTWOPI * exp(-x*x/2.0);

    for(i=1; i<=n*nu; i++)
    {
      pinumerator=pinumerator/(1.0+f/nu);
      pidenominator=pidenominator/(1.0+y/nu);
      numerator+=pinumerator;
      denominator+=pidenominator;
    }
    if(denominator==0)
      mcpl_error("Zero denominator in cvxintegrand_swap(): index maturity must be above one year");
    cf=(y-f)*numerator/denominator;
    //  if ( cf == 0 ) mcpl_error( "error in CMS convexity" );
    return cf*pdf;
  }

  /*********************************************************************/

  double cvxintegrand_cap(double x)
  {
    /*  extern double  f, mu, t, sigma,sspread, nu,n; */
    int i; 
    double y, numerator,denominator, pdf,cf,pinumerator,pidenominator;

    pinumerator=1.0;
    pidenominator=1.0;
    numerator=0.0;
    denominator=0.0;
    sspread=0.0;
    mu=0.0;
    y=(f+sspread)*exp(-x*sigma*sqrt(t)+ (mu-0.5*sigma*sigma)*t)-sspread;
    pdf=1.0/SQRTWOPI * exp(-x*x/2.0);

    for(i=1; i<=n*nu; i++)
    {
      pinumerator=pinumerator/(1.0+f/nu);
      pidenominator=pidenominator/(1.0+y/nu);
      numerator+=pinumerator;
      denominator+=pidenominator;
    }
    if(denominator==0)
      mcpl_error("Zero denominator in cvxintegrand_cap(): index maturity must be above one year");
    cf=(y-strikeK)*numerator/denominator; 


    return cf*pdf;
  }






	/*********************************************************************/
  /*********************************************************************/

  double cms_swap_adj(double unused_var, double fwd_cms_rate, double vol, double years2swap,
    int swap_years, double freq)
  {
    //  double dqromb(double (*cvxintegrand_swap)(double), double a, double b);
    //  double cvxintegrand_swap(double x);

    if ( years2swap <= 0 ) return 0;
    if ( fwd_cms_rate <= 0 ) mcpl_error("bad forward CMS rate.");
    if ( vol <= 0 ) mcpl_error("bad CMS vol.");
    if ( freq <= 0) mcpl_error("bad CMS frequency");

    double a,b;
    double integral;

    f = fwd_cms_rate;
    sigma = vol;
    //  t = (days2swap-2)/365.0;
    t = years2swap;
    n = swap_years;

    nu = freq;
    a=-WIDTH;
    b=WIDTH;
    integral=dqromb(cvxintegrand_swap,a,b);

    return integral;
  }

  double cms_swap_normal_adj(double unused_var, double fwd_cms_rate, double vol, double years2swap,
    int swap_years, double freq)
  {
    //  double dqromb(double (*cvxintegrand_swap)(double), double a, double b);
    //  double cvxintegrand_swap(double x);
    if ( years2swap <= 0 ) return 0;
    if ( fwd_cms_rate <= 0 ) mcpl_error("bad forward CMS rate.");
    if ( vol <= 0 ) mcpl_error("bad CMS vol.");
    if ( freq <= 0) mcpl_error("bad CMS frequency");

    double a,b;
    double integral;

    f = fwd_cms_rate;
    sigma = vol;
    //  t = (days2swap-2)/365.0;
    t = years2swap;
    n = swap_years;

    nu = freq;
    a=-WIDTH;
    b=WIDTH;
    integral=dqromb(cvxintegrand_normal_swap,a,b);

    return integral;
  }

  /*********************************************************************/
  double cms_cap_adj(double strike, double fwd_cms_rate, double vol, int days2swap,
    int swap_years, int freq)
  {
    return 0;
  }
  /********************************************************************/
  double cms_floor_adj(double strike, double fwd_cms_rate, double vol, int days2swap,
    int swap_years, int freq)
  {
    return 0;
  }
  /********************************************************************/

  double cms_caplet_price(double strike, double fwd_cms_rate, double vol, int days2swap,
    int swap_years, int freq)
  {
    if ( days2swap <= 0 ) return 0;
    if ( fwd_cms_rate <= 0 ) mcpl_error("bad forward CMS rate.");
    if ( vol <= 0 ) mcpl_error("bad CMS vol.");
    if(strike==0) mcpl_error("Zero Strike."); 
    if (freq <= 0) mcpl_error("bad CMS frequency");

    double cvxintegrand_cap(double x);
    double a,b;
    double integral;

    f = fwd_cms_rate ;
    strikeK=strike;
    sigma = vol;
    t = (days2swap-2)/365.0;
    if (t <= 0) 
    {
      return ((strike < fwd_cms_rate) ? (fwd_cms_rate- strike) :0);
    }
    n = swap_years;
    nu = freq;
    /*the lower integration bound is obtained by substituting y=strike into fromula for d2 */
    b=(log(f/strikeK)-0.5*sigma*sigma*t)/(sigma*sqrt(t));
    b = ((b > WIDTH) ?  WIDTH  : b) ;
    a=-WIDTH;


    integral=dqromb(cvxintegrand_cap,a,b);

    return integral;
  }

  /*********************************************************************/

  double cms_floorlet_price(double strike, double fwd_cms_rate, double vol, int days2swap,
    int swap_years, int freq)
  {
    double cvxintegrand_cap(double x);
    double a,b;
    double integral;
    f = fwd_cms_rate ;
    strikeK=strike;
    if(strike==0) 
    {
      mcpl_error("Zero Strike. Enter Strike in Misc. Deal Info Screen"); 
    }
    sigma = vol;
    t = (days2swap-2)/365.0;
    if (t <= 0) 
    {
      return ((strike> fwd_cms_rate) ? (strike-fwd_cms_rate) :0);
    }

    n = swap_years;
    if (freq <= 0)
      mcpl_error("bad CMS frequency");
    nu = freq;
    /*the lower integration bound is obtained by substituting y=strike into fromula for d2 */

    a=(log(f/strike)-0.5*sigma*sigma*t)/(sigma*sqrt(t));
    a=((a < -WIDTH) ? -WIDTH : a) ;
    b=WIDTH;
    integral=-dqromb(cvxintegrand_cap,a,b);

    return integral;
  }

  /*********************************************************************/

} // namespace MCPL

