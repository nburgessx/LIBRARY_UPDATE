#include "MCSDiscountStore.h"

namespace MCPL
{

	double MCSDiscountStore::getDiscountFactor(double T)
	{
		auto it = _dfCache.find(T);
		if (it != _dfCache.end())
			return it->second;
		else
		{
			double T0 = _curve->getFirstLabel();
			double df = getPeriodDiscountFactor(T0, T);
			_dfCache[T] = df;
			return df;
		}
	}

	double MCSDiscountStore::getPeriodDiscountFactor(double T1_, double T2_)
	{
		double pdf = exp(-_curve->integrate(T1_, T2_)/365.0);
		return pdf;
	}

	double MCSDiscountStore::getCCRate(const date & d1, const date & d2, DayBasis basis) //Continuously compounded rate
	{
		double rT, dcf, rate;

		rT = _curve->integrate((double)d1, (double)d2)/365.0;
		dcf = dayCountFrac(basis, d1, d2);

		rate = dcf == 0 ? 0 : (rT / dcf);

		return rate;
	}

	
	double MCSDiscountStore::getRate(const date & d1, const date & d2, DayBasis basis) //Rate compounded in nPeriods periods. Defaults to 1 for zero rate
	{
		double  dcf, rate;

		dcf = dayCountFrac(basis, d1, d2);
		rate = dcf == 0 ? 0 : (1.0 / getPeriodDiscountFactor(d1, d2) - 1) / dcf;

		return rate;
	}

	void MCSDiscountStore::setIRate(const date &dt_, double value_) //Set the instantaneous forward rate at date to value.
	{
		_curve->add((double)dt_, value_);
		clearCacheFrom(_curve->getLabelAtIndex(_curve->getFirstAffectedIndex((double)dt_)));
	}

	void MCSDiscountStore::clearCacheFrom(const date& lastGoodKey)
	{
		auto it = _dfCache.lower_bound((double)lastGoodKey);
		if (it != _dfCache.end() && it != _dfCache.begin())
			it--;

		_dfCache.erase(it, _dfCache.end());
	}

	double MCSDiscountStore::curveLength(const date &d1, const date &d2)
	{
		return _curve->arcLength(d1, d2) / 365.0; 
	}


	/*void MCSDiscountStore::setDiscountFactor(double T, double df);
	void MCSDiscountStore::setCCRate(date & d1, date & d2, DayBasis basis, double rate);
	void MCSDiscountStore::setRate(date & d1, date & d2, DayBasis basis, double rate);
*/
}