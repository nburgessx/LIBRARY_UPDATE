#include "AFSabrTest.h"
#include <math.h>


namespace MCPL
{

	double AFSabrTest::qvMAXIMUMBETAVALUE = 1.05;
	double AFSabrTest::qvMINIMUMBETAVALUE = 0;

	void AFSabrTest::qvzzNATriDiag(vector<double>& U, long j0, long jN, vector<double>& A, vector<double>& B, vector<double>& C, vector<double>& R)
	{
		vector<double> Gam(jN + 1);
		double bet;
		long j;

		if (B[j0] == 0)
			mcpl_error("bad B[0] in qvzzNATriDiag");

		j = j0;
		bet = B[j];
		U[j] = R[j] / bet;
		Gam[j] = C[j] / bet;
		for (j = j0 + 1; j <= jN; j++)
		{
			bet = B[j] - A[j] * Gam[j - 1];
			if (bet == 0)
				mcpl_error("error in qvzzNATriDiag");
			Gam[j] = C[j] / bet;
			U[j] = (R[j] - A[j] * U[j - 1]) / bet;
		}
		for (j = jN - 1; j >= j0; j--)
			U[j] = U[j] - Gam[j] * U[j + 1];
	}

	void AFSabrTest::AFSABRSolve(vector<double>& Q, double& QLeft, double& QRight, double FMin, double h, long m, double T0, double dt, long n, bool AbLowBC, bool AbHighBC,
		double fwd, double alpha, double beta, double rho, double VolVol)
	{
		vector<double> D0(m + 2), d1(m + 2), arg(m + 2), A(m + 2), B(m + 2), C(m + 2), RHS(m + 2);
		double F, z, temp, Gamma, delta;
		long i, j;

		if ((h <= 0) || (dt <= 0.000001) || (m < zAFSABRMinNGridPts) || (m > zAFSABRMaxNGridPts)
			|| (n < zAFSABRMinNTSteps) || (n > zAFSABRMaxNTSteps))
			mcpl_error("Bad grid params in AFSABRSolve");

		delta = 0.5 * dt / (h * h);

		// Prepare for finite difference scheme
		// Calculate D0(j) = delta*D(T0 + [i-1]*dt, h*j); D1(j) = delta*D(T0 + i*dt, h*j) = D0(j) * [1+arg(j)]
		for (j = 0; j <= m + 1; j++)
		{
			F = FMin + (j - 0.5) * h;

			if (fabs(1 - beta) > 0.002)
			{
				if (F > 0)
					z = (pow(F, (1 - beta)) - pow(fwd, (1 - beta))) / (1 - beta);
				else
					z = -(pow(fabs(F), (1 - beta)) + pow(fwd, (1 - beta))) / (1 - beta);
			}
			else
			{
				if (fabs(F / fwd) < 0.0001)
					temp = log(0.0001);
				else
					temp = log(fabs(F / fwd));
				z = pow(fabs(F * fwd), 0.5 - 0.5 * beta) * temp * (1 + (1 - beta) * (1 - beta) * temp * temp / 24);
			}

			D0[j] = 0.5 * delta * (alpha * alpha + 2 * rho * VolVol * alpha * z + VolVol * VolVol * z * z) * pow(fabs(F), beta + beta);
			if (fabs(F / fwd - 1) < 0.001)
			{
				temp = (1 - beta * beta) * (F - fwd) * (F - fwd) / (F * fwd) / 24;
				Gamma = (beta / pow((fwd * F), 0.5 - 0.5 * beta)) * (1 - temp);
			}
			else
				Gamma = (pow(fabs(F), beta) - pow(fwd, beta)) / (F - fwd);

			arg[j] = rho * VolVol * alpha * Gamma;
			D0[j] = D0[j] * exp(arg[j] * T0);
			d1[j] = D0[j];
			arg[j] = exp(arg[j] * dt);
		}

		// time steps ...
		for (i = 1; i <= n; i++)
		{
			// Update diffusion coefficients
			for (j = 0; j <= m + 1; j++)
			{
				D0[j] = d1[j];
				d1[j] = D0[j] * arg[j];
			}

			// Set up tridiagonal problem:
			//   A[j]*Qnew[j-1] + B[j]*Qnew[j] + C[j]*Qnew[j+1] = RHS[j] for j = 1, 2, ..., m
			for (j = 1; j <= m; j++)
			{
				A[j] = -d1[j - 1];
				B[j] = (1 + 2 * d1[j]);
				C[j] = -d1[j + 1];
				RHS[j] = Q[j] + (D0[j + 1] * Q[j + 1] - 2 * D0[j] * Q[j] + D0[j - 1] * Q[j - 1]);
			}

			// boundary conditions
			A[0] = 0;
			B[0] = d1[0];
			C[0] = AbLowBC == true ? d1[1] : -d1[1];
			RHS[0] = 0;

			A[m + 1] = AbHighBC == true ? d1[m] : -d1[m];
			B[m + 1] = d1[m + 1];
			C[m + 1] = 0;
			RHS[m + 1] = 0;

			QLeft = QLeft + Q[1] * D0[1] - D0[0] * Q[0];                   // the boundary leaks are calculated from half before, half after timestep
			QRight = QRight + Q[m] * D0[m] - D0[m + 1] * Q[m + 1];         // the boundary leaks are calculated from half before, half after timestep

			qvzzNATriDiag(Q, 0, m + 1, A, B, C, RHS);

			QLeft = QLeft + Q[1] * d1[1] - d1[0] * Q[0];                   // the boundary leaks are calculated from half before, half after timestep
			QRight = QRight + Q[m] * d1[m] - d1[m + 1] * Q[m + 1];         // the boundary leaks are calculated from half before, half after timestep
		}

	}

	// Check FMin, FMax, fwd; replace nGrid and nSteps with defaults if warranted
	// Find h = (FMax - FMin)/nGrid, and then re-adjust h so that fwd falls exactly in the middle of its interval
	void AFSabrTest::AFSABRGrid(double& h, long& nGrid, double& FMin, double& FMax, double& dt, long& nSteps, double fwd, double yExp)
	{
		long j;

		if (yExp <= 0.001 || yExp > 50)
			mcpl_error("Error in AFSABRGrid");

		if (fwd <= 0 || FMax < 1.05 * fwd || FMin > 0.95 * fwd)
			mcpl_error("Error in AFSABRGrid");

		if (nGrid < zAFSABRMinNGridPts || nGrid > zAFSABRMaxNGridPts)
			nGrid = zAFSABRDefNGridPts;
		if (nSteps < zAFSABRMinNTSteps || nSteps > zAFSABRMaxNTSteps)
			nSteps = zAFSABRDefNTSteps;

		h = (FMax - FMin) / double(nGrid);
		j = long((1 + (fwd - FMin) / h));
		h = (fwd - FMin) / double((j - 0.5));             // adjust grid size so initial point falls in the middle of a cell
		FMax = FMin + h * nGrid;                         // new FMax
		dt = yExp / nSteps;
	}

	// Solves the PDE to obtain the probability density Q(F) for Fmin < F < Fmax at T = yExp.
	// Q[j] is the density at Fmin + (j-0.5)*h, for j = 1, 2, ..., nGrid. Specifically, h*Q[j] is
	// the probability between Fmin + (j-1)*h < F < Fmin + j*h for j=1, 2, ..., nGrid. Internally,
	// the shadow points Q[0] and Q[nGrid+1] are used to get the boundary conditions right. Upon return,
	// they are set so that h*Q[0] is the probability in the delta function at Fmin and h*Q[nGrid+1] is
	// the probability in the delta function at F = FMax.
	// WARNING: Upon return, FMax is usually slightly different from the input value, as it is changed
	// internally so that fwd is exactly at the center of a cell, but h = (Fmax - Fmin)/nGrid is always true.
	// Use absorbing or reflecting boundary conditions at FMin or FMax, depending if AbLowBC and AbHighBC are true/false.
	void AFSabrTest::qvzzOptAFSABRSolve(double& FMin, double& FMax, long& nGrid, vector<double>& Q,
		double fwd, double yExp, double alpha, double beta, double rho, double VolVol,
		bool AbLowBC, bool AbHighBC, long nSteps)
	{
		double QLeft = 0, QRight = 0;
		long j;
		double T0, dt, h;// , x;

		// check inputs
		alpha = fabs(alpha);
		VolVol = fabs(VolVol);
		if (rho < -1 || rho > 1)
			mcpl_error("rho not in [-1,1] in qvzzOptAFSABRSolve");
		if (beta < 0 || beta > qvMAXIMUMBETAVALUE)
			mcpl_error("beta not in [0,qvMAXIMUMBETAVALUE] in qvzzOptAFSABRSolve");
		if (VolVol > 10)
			mcpl_error("VolVol > 10 in qvzzOptAFSABRSolve");

		// Set up grid
		AFSABRGrid(h, nGrid, FMin, FMax, dt, nSteps, fwd, yExp);

		// Set up initial condition
		Q.resize(nGrid + 2);
		for (j = 0; j <= nGrid + 1; j++)
			Q[j] = 0;

		j = long(1 + (fwd - FMin) / h);
		Q[j] = 1 / h;
		T0 = 0;

		// Solve PDE for nSteps time steps of size dt
		AFSABRSolve(Q, QLeft, QRight, FMin, h, nGrid, T0, dt, nSteps, AbLowBC, AbHighBC, fwd, alpha, beta, rho, VolVol);
		Q[0] = QLeft;
		Q[nGrid + 1] = QRight;
	}


	// Calculate the probability density for all points on the grid. If nStrikes<=0, calculate the options
	// values for strikes at each grid point, and return nStrikes, Strike(1, 2, ..., nStrikes), and Value(1, 2, ..., nStrikes)
	// If nStrikes>0, then just calculate the option values for the strikes in Strikes(1, 2, ..., nStrikes) and return
	// nStrikes, Strikes (same as input), and Value().
	// WARNING: Strike() and Values() must be dimensioned at least 1 to nStrikes
	void AFSabrTest::qvzzOptAFSABRTimeValues(long& nStrikes, vector<double>& strikes, vector<double>& Values, double fwd, double yExp,
		double alpha, double beta, double rho, double VolVol, bool AbLowBC, bool AbHighBC,
		double FMin, double FMax, long nGrid, long nSteps)
	{
		vector<double> Q;
		long j, k;
		double h, sum0, sum1;
		OptionType opt;


		// Solve ...
		qvzzOptAFSABRSolve(FMin, FMax, nGrid, Q, fwd, yExp, alpha, beta, rho, VolVol, AbLowBC, AbHighBC, nSteps);
		h = (FMax - FMin) / double(nGrid);

		// compute option values
		if (nStrikes <= 0)                                       //calculate the time value for each strike on the grid
		{
			nStrikes = nGrid - 1;

			// calculate put values for strikes below the fwd
			sum0 = Q[0];                                             // the delta function at FMin
			sum1 = 0;
			for (k = 1; k <= nGrid - 1; k++)
			{
				strikes[k - 1] = FMin + k * h;
				if (strikes[k - 1] > fwd)
					break;
				sum0 = sum0 + Q[k];
				sum1 = sum1 + (k - 0.5) * Q[k];
				Values[k - 1] = h * h * (k * sum0 - sum1);                // put price
			}

			// calculate call values for strikes above the fwd
			sum0 = Q[nGrid + 1];                                     // the delta function at FMax
			sum1 = 0;
			for (j = nGrid; j >= 1; j--)
			{
				k = j - 1;
				strikes[k - 1] = FMin + k * h;
				if (strikes[k - 1] < fwd)
					break;
				sum0 = sum0 + Q[j];
				sum1 = sum1 + (nGrid - j + 0.5) * Q[j];
				Values[k - 1] = h * h * ((nGrid - k) * sum0 - sum1);      // the call price
			}
		}
		else
		{
			for (k = 1; k <= nStrikes; k++)
			{
				opt = strikes[k - 1] >= fwd ? Call : Put;
				Values[k - 1] = OptValueFromDensity(strikes[k - 1], opt, Q, FMin, h, nGrid);
			}
		}
	}

	// Calculate the value of a call or put option based on the the density stored in QLeft, Q(*,1,2,..., m, *), QRight
	// Here, QLeft is in Q(0) and QRight is in Q(m+1)
	double  AFSabrTest::OptValueFromDensity(double strike, OptionType opt, vector<double>& Q, double FMin, double h, long m)
	{
		long j;
		double F, FMax, Halfh, AvgPayoff, term, value;

		Halfh = 0.5 * h;

		//    FMax = FMin + h * m
		if (opt == Call)
		{
			value = 0;
			if (FMin - strike > 0)
			{
				AvgPayoff = FMin - strike;
				term = AvgPayoff * Q[0] * h;
				value = value + term;
			}
			F = FMin;
			for (j = 1; j <= m; j++)
			{
				F = F + h;
				if (F - h - strike > 0)
				{
					AvgPayoff = F - strike - Halfh;
					term = AvgPayoff * Q[j] * h;
					value = value + term;
				}
				else if (F - strike > 0)
				{
					AvgPayoff = 0.5 * (F - strike) * (F - strike) / h;
					term = AvgPayoff * Q[j] * h;
					value = value + term;
				}
			}
			FMax = FMin + h * m;
			if (FMax - strike > 0)
			{
				AvgPayoff = FMax - strike;
				term = AvgPayoff * Q[m + 1] * h;
				value = value + term;
			}
			//OptValueFromDensity = True
		}
		else if (opt == Put)
		{
			value = 0;
			if (strike - FMin > 0)
			{
				AvgPayoff = strike - FMin;
				term = AvgPayoff * Q[0] * h;
				value = value + term;
			}
			F = FMin;
			for (j = 1; j <= m; j++)
			{
				F = F + h;
				if (strike - F > 0)
				{
					AvgPayoff = strike - F + Halfh;
					term = AvgPayoff * Q[j] * h;
					value = value + term;
				}
				else if (strike - F + h > 0)
				{
					AvgPayoff = 0.5 * (strike - F + h) * (strike - F + h) / h;
					term = AvgPayoff * Q[j] * h;
					value = value + term;
				}
			}
			FMax = FMin + h * m;
			if (strike - FMax > 0)
			{
				AvgPayoff = strike - FMax;
				term = AvgPayoff * Q[m + 1] * h;
				value = value + term;
			}
			//OptValueFromDensity = True
		}
		else if (opt == Straddle)
		{
			value = 0;
			AvgPayoff = fabs(strike - FMin);
			term = AvgPayoff * Q[0] * h;
			value = value + term;
			F = FMin;
			for (j = 1; j <= m; j++)
			{
				F = F + h;
				if (strike - F > 0 || F - h - strike > 0)
				{
					AvgPayoff = 0.5 * (strike - F) + 0.5 * fabs(strike - F + h);
					term = AvgPayoff * Q[j] * h;
					value = value + term;
				}
				else
				{
					AvgPayoff = 0.5 * ((strike - F + h) * (strike - F + h) + (F - strike) * (F - strike)) / h;
					term = AvgPayoff * Q[j] * h;
					value = value + term;
				}
			}
			FMax = FMin + h * m;
			AvgPayoff = fabs(strike - FMax);
			term = AvgPayoff * Q[m + 1] * h;
			value = value + term;
			//OptValueFromDensity = True
		}
		else
			mcpl_error("bad option type in OptValueFromDensity");

		return value;
	}


	shared_ptr<Matrix<double>> AFSabrTest::qvOptAFSABRValues(double fwd, double yExp, vector<double>& StrikeVec, OptionType opt,
		double alpha, double beta, double rho, double VolVol, double FMinAct, double FMaxAct,
		long nGridPts, long nTSteps)
	{
		long j;// , nTemp;
		bool AbLowBC, AbHighBC;
		long nStrikes;
		bool DoAllStrikes;
		vector<double> Values;
		shared_ptr<Matrix<double>> answer(new Matrix<double>());

		// find the strikes to use
		nStrikes = StrikeVec.size();
		if (nStrikes <= 0)
			nStrikes = -1;//                               ' this will cause the option values to be calculated for strikes at each grid poit
		else if (nStrikes > zAFSABRMaxNumStrikes)
			mcpl_error("Too many strikes");

		// find the model
		alpha = fabs(alpha);
		VolVol = fabs(VolVol);
		if (yExp <= 0.001 || yExp > 50)
			mcpl_error("#Need yExp>0.001");
		else if (fwd <= 0)
			mcpl_error("#Need fwd>=0");
		else if (rho < -1 || rho > 1)
			mcpl_error("#Need -1 <= rho <= 1");
		else if (beta < 0 || beta > qvMAXIMUMBETAVALUE)
			mcpl_error("#Need 0 <= beta <= qvMAXIMUMBETAVALUE");
		else if (VolVol > 10)
			mcpl_error("#VolOfVol is too large");


		AbLowBC = true;
		AbHighBC = true;

		// calculate the time values at each strike. If nStrikes<=0 then calculate the time value for strikes at each grid point
		// In either case, return the nStrikes, Strikes(1, 2, ..., nStrikes), Values(1, 2, ..., nStrikes)
		DoAllStrikes = nStrikes <= 0;
		if (DoAllStrikes)
		{
			if (nGridPts < zAFSABRMinNGridPts || nGridPts > zAFSABRMaxNGridPts)
				nGridPts = zAFSABRDefNGridPts;
			Values.resize(nGridPts + 1);
			StrikeVec.resize(nGridPts + 1);
		}
		else
			Values.resize(nStrikes + 1);

		qvzzOptAFSABRTimeValues(nStrikes, StrikeVec, Values,
			fwd, yExp, alpha, beta, rho, VolVol, AbLowBC, AbHighBC,
			FMinAct, FMaxAct, nGridPts, nTSteps);

		// add time value
		for (j = 0; j <nStrikes; j++)
		{
			if ((opt == Call && fwd > StrikeVec[j]) ||
				(opt == Put && fwd < StrikeVec[j]) ||
				(opt == Straddle))
				Values[j] = Values[j] + fabs(fwd - StrikeVec[j]);

		}

		if (DoAllStrikes)
		{
			answer->redim(nStrikes, 2);
			for (j = 0; j < nStrikes; j++)
			{
				(*answer)(j, 0) = StrikeVec[j];
				(*answer)(j, 1) = Values[j];
			}
		}
		else
		{
			answer->redim(nStrikes, 1);
			for (j = 0; j < nStrikes; j++)
				(*answer)(j, 0) = Values[j];
		}
		return answer;
	}


	double  AFSabrTest::AFSABR_price(double K, double fwd, double yExp, SABRParams & par, double bpv, OptionType type, double FMinAct, double FMaxAct,
		long nGridPts, long nTSteps)
	{

		vector<double> strikes;
		strikes.push_back(K);
		return (*qvOptAFSABRValues(fwd, yExp, strikes, type, par.alpha(), par.beta(), par.rho(), par.nu(), FMinAct, FMaxAct, nGridPts, nTSteps))(0, 0);
	}

	//======================================================

	tr1::shared_ptr<Matrix<double>> AFSabrTest::qvOptAFSABRValues(double fwd, double yExp, vector<double>& StrikeVec, vector<OptionType>& optTypes,
		double alpha, double beta, double rho, double VolVol, double FMinAct, double FMaxAct,
		long nGridPts, long nTSteps)
	{
		long j;// , nTemp;
		bool AbLowBC, AbHighBC;
		long nStrikes;
		bool DoAllStrikes;
		vector<double> Values;
		tr1::shared_ptr<Matrix<double>> answer(new Matrix<double>());

		// find the strikes to use
		nStrikes = StrikeVec.size();
		if (nStrikes > zAFSABRMaxNumStrikes)
			mcpl_error("Too many strikes");

		if (optTypes.size() != nStrikes)
			mcpl_error("types and strikes vector sizes do not match");

		// find the model
		alpha = fabs(alpha);
		VolVol = fabs(VolVol);
		if (yExp <= 0.001 || yExp > 50)
			mcpl_error("#Need yExp>0.001");
		else if (fwd <= 0)
			mcpl_error("#Need fwd>=0");
		else if (rho < -1 || rho > 1)
			mcpl_error("#Need -1 <= rho <= 1");
		else if (beta < 0 || beta > qvMAXIMUMBETAVALUE)
			mcpl_error("#Need 0 <= beta <= qvMAXIMUMBETAVALUE");
		else if (VolVol > 10)
			mcpl_error("#VolOfVol is too large");


		AbLowBC = true;
		AbHighBC = true;

		// calculate the time values at each strike.  return the nStrikes, Strikes(1, 2, ..., nStrikes), Values(1, 2, ..., nStrikes)
		DoAllStrikes = nStrikes <= 0;

		Values.resize(nStrikes + 1);

		qvzzOptAFSABRTimeValues(nStrikes, StrikeVec, Values,
			fwd, yExp, alpha, beta, rho, VolVol, AbLowBC, AbHighBC,
			FMinAct, FMaxAct, nGridPts, nTSteps);

		// add time value
		for (j = 0; j <nStrikes; j++)
		{
			if ((optTypes[j] == Call && fwd > StrikeVec[j]) ||
				(optTypes[j] == Put && fwd < StrikeVec[j]) ||
				(optTypes[j] == Straddle))
				Values[j] = Values[j] + fabs(fwd - StrikeVec[j]);

		}

		if (DoAllStrikes)
		{
			answer->redim(nStrikes, 2);
			for (j = 0; j < nStrikes; j++)
			{
				(*answer)(j, 0) = StrikeVec[j];
				(*answer)(j, 1) = Values[j];
			}
		}
		else
		{
			answer->redim(nStrikes, 1);
			for (j = 0; j < nStrikes; j++)
				(*answer)(j, 0) = Values[j];
		}
		return answer;
	}


	shared_ptr<vector<double>>  AFSabrTest::AFSABR_price(vector<double>& strikes, double fwd, double yExp, SABRParams & par, double bpv, vector<OptionType>& optTypes, double FMinAct, double FMaxAct,
		long nGridPts, long nTSteps)
	{
		shared_ptr<vector<double>> retvals = shared_ptr<vector<double>>(new vector<double>());
		auto vals = qvOptAFSABRValues(fwd, yExp, strikes, optTypes, par.alpha(), par.beta(), par.rho(), par.nu(), FMinAct, FMaxAct, nGridPts, nTSteps);
		for (unsigned int i = 0; i < vals->Rows(); i++)
		{
			retvals->push_back((*vals)(i, 0));
		}
		return retvals;
	}
}