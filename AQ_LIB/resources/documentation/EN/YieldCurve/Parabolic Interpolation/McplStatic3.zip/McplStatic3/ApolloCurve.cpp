#include"ApolloCurve.h"

#include "math.h"
#include "Globals.h"


namespace MCPL
{

	void ApolloCurve::calculateDates()
	{


		m_extrapolateLastFutRate = false;

		int n_futures = m_futures.size();

		// Set up IMM start, end dates and day count fractions.
		m_starts.clear(); m_starts.resize(n_futures);
		m_ends.clear(); m_ends.resize(n_futures);
		m_PDCF.clear(); m_PDCF.resize( n_futures );

		m_starts[0] = nthIMMDate(m_1stFut, 1, 3).roll(m_hols, 0, true);
		m_ends[0] = nthIMMDate(m_1stFut, 2, 3).roll(m_hols, 0, true);
		m_PDCF[0] = dayCountFrac(m_basis, m_starts[0] , m_ends[0] );

		for ( int i = 1 ; i < n_futures ; ++i ) 
		{
			m_starts[i] = m_ends[i-1];
			m_ends[i] = nthIMMDate(m_1stFut, i+2, 3).roll(m_hols, 0, true);
			m_PDCF[i] = dayCountFrac(m_basis, m_starts[i] , m_ends[i] );
		}
		//m_ends[n_futures-1] = addBusinessMonths(m_starts[n_futures-1], 3, m_hols, true);

		m_1stFut = m_starts[0];
		date lastFutDate = m_ends[n_futures-1];

		// Cash params.
		// First find the 3m

		m_3mDate = addBusinessMonths(m_spot, 3, m_hols, true); // Use Month End Rolls if spot is month end.


		m_3mDCF = dayCountFrac(m_basis, m_spot, m_3mDate);
		m_ffDCF = dayCountFrac(m_basis, m_starts[0], m_starts[1]);
		m_t1 = dayCountFrac(m_basis, m_spot, m_starts[0]);

		// Now for the swaps
		long n_swaps = m_swapParams.size();
		m_firstUsedSwapIndex = 0;

		if ( n_swaps > 0 )
		{
			// Set up swap dates.

			for ( int i=0 ; i < n_swaps ; ++i )
			{
				if ( m_swapLastDates[i] <= (lastFutDate + 14) )
				{
					m_firstUsedSwapIndex = i;

					if ( m_swapLastDates[i] > lastFutDate  )
						m_extrapolateLastFutRate = true;
				}
				else
				{
					break;
				}
			}

			if ( m_extrapolateLastFutRate )
			{
				m_extraStart = m_ends[n_futures-1];
				m_extraEnd = m_swapLastDates[m_firstUsedSwapIndex];
				m_extraPDCF = dayCountFrac(m_basis, m_extraStart , m_extraEnd );
			}

			// Set up all pricing swaps
			m_usedSwaps.clear();
			m_useSwapInCurve.clear();

			//long lastSwapTenor = (long) m_swapTenors.back();
			//long firstSwapTenor = (long) m_swapTenors[m_firstUsedSwapIndex];
			//long j = m_firstUsedSwapIndex;

			m_usedSwaps.push_back( Swap(PAY, m_swapType, m_spot, m_swapLastDates[m_firstUsedSwapIndex], m_spot, 1, .05, 0, m_swapHols, m_ccy) );

			m_usedSwaps.push_back( Swap(PAY, m_swapType, m_spot, m_swapLastDates.back(), m_spot, 1, .05, 0, m_swapHols, m_ccy) );
		}
	}


	void ApolloCurve::calculateSpreadDates()
	{

		calculateDates();

		// Cash params.
		// 

		m_fut_t.clear();
		m_fut_DCF.clear();

		m_cashDate = addBusinessPeriod(m_spot, m_spreadCashTenor, m_hols, true); // Use Month End Rolls if spot is month end.
		m_cashDateFuture = 0;
		for ( unsigned int i=0 ; i < m_futures.size()-1 ; i++)
		{
			m_fut_t.push_back( dayCountFrac(m_basis, m_spot, m_starts[i]) );
			m_fut_DCF.push_back( dayCountFrac(m_basis, m_starts[i], m_starts[i+1]) );

			if ( ( m_starts[i] < m_cashDate ) && ( m_starts[i+1] >= m_cashDate ) )
			{
				m_cashDateFuture = i;
				break;
			}
		}

		m_cashDate = addBusinessPeriod(m_spot, m_spreadCashTenor, m_hols, true); // Use Month End Rolls if spot is month end.
		m_cashDCF = dayCountFrac(m_basis, m_spot, m_cashDate);

		long n_swaps = m_swapParams.size();

		if ( n_swaps > 0 )
		{

			long spreadFreq = (long) 12.0/m_spreadTenor.getTotalMonths();

			m_spreadLeg = Leg( PAY , MC_FLOAT, m_spot, m_swapLastDates.back(), m_spot, 1, 0, spreadFreq, m_spreadBasis, m_swapHols);

			m_firstBasisSwap = BasisSwap(m_spot, m_swapLastDates[m_firstUsedSwapIndex], 1.0, 0, 0, m_fltPmtsPerYear, spreadFreq, m_basis,
				m_spreadBasis, m_swapHols ); 


			vector<date> spreadPpEndDates;
			m_spreadLeg.getAdjEndDates(spreadPpEndDates);
			vector<date> basePpEndDates;
			m_usedSwaps.back().getLeg(MC_FLOAT)->getAdjEndDates(basePpEndDates);

			// Go through the pp end dates for the base and spread curves, and make two vectors, with the index number of the pp in
			// each curve with its end date the same (roughly) as each swap tenor.

			m_spreadPpIndexWithEndDateSameAsSwap.clear();
			m_spreadPpTenorMonths.clear();
			m_basePpIndexWithEndDateSameAsSwap.clear();
			m_basePpIndexWithEndDateSameAsSpreadPp.clear();
			m_spreadPpIndexWithEndDateSameAsBasePp.clear();

			for ( unsigned int i=0 ; i < m_swapLastDates.size() ; i++ )
			{
				date swapEndDate = m_swapLastDates[i];

				for ( unsigned int iSpd = 0 ; iSpd < spreadPpEndDates.size() ; iSpd++ )
				{
					int dateDiff = spreadPpEndDates[iSpd] - swapEndDate;
					if ( abs(dateDiff) < 4 )
					{
						m_spreadPpIndexWithEndDateSameAsSwap.push_back(iSpd);
						break;
					}
				}

				for ( unsigned int iBse = 0 ; iBse < basePpEndDates.size() ; iBse++ )
				{
					int dateDiff = basePpEndDates[iBse] - swapEndDate;
					if ( abs(dateDiff) < 4 )
					{
						m_basePpIndexWithEndDateSameAsSwap.push_back(iBse);
						break;
					}
				}
			}

			for ( unsigned int i=0 ; i < spreadPpEndDates.size() ; i++ )
			{
				m_spreadPpTenorMonths.push_back(  (long)(12 * dayCountFrac(_30_360f,  m_spot, spreadPpEndDates[i] ) ) );

				for ( unsigned int iBse = 0 ; ( i < basePpEndDates.size() ) && ( iBse < basePpEndDates.size() ) ; iBse++ )
				{
					int dateDiff = basePpEndDates[iBse] - spreadPpEndDates[i];
					if ( abs(dateDiff) < 4 )
					{
						m_basePpIndexWithEndDateSameAsSpreadPp[i] = iBse;
						//m_basePpIndexWithEndDateSameAsSpreadPp.push_back(iBse);
						break;
					}
				}
			}

			if ( m_spreadTenor.getTotalMonths() < 3 ) // Basically 1m spreads are a special case
			{
				for ( unsigned int i=0 ; i < basePpEndDates.size() ; i++ )
				{
					m_basePpTenorMonths.push_back(  (long)(12 * dayCountFrac(_30_360f,  m_spot, basePpEndDates[i] ) ) );
					for ( unsigned int iSpread = 0 ;  i < spreadPpEndDates.size() ; iSpread++ )
					{
						int dateDiff = basePpEndDates[i] - spreadPpEndDates[iSpread];
						if ( abs(dateDiff) < 4 )
						{
							m_spreadPpIndexWithEndDateSameAsBasePp[i] = iSpread;
							break;
						}
					}
				}
			}


		}
	}


	void ApolloCurve::calculateCurve()
	{
		double rate, PDF;
		int n_futures = m_futures.size();

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );

		discountCurve::clear();
		discountCurve::set(m_today , 1.0 );
		discountCurve::set(m_spot , spotDF );

		if ( m_useMinRateFirstStub )
		{
			// Min rate first stub
			double cc3mRate = log(1.0 + m_cashParams[m_3mDate]*m_3mDCF) / m_3mDCF;
			double ffRate = (100.0-m_futures[0])/100.0 - m_adjustments[0]/10000.0;
			double ccffRate = log(1.0 + ffRate*m_ffDCF)/m_ffDCF;
			double ccStubRate = (cc3mRate * m_3mDCF - ccffRate * (m_3mDCF - m_t1) ) / m_t1;
			discountCurve::set(m_1stFut, spotDF * exp(-ccStubRate * m_t1) );
		}
		else
		{
			// Apollo2 stub
			discountCurve cashCurve;
			cashCurve.set(m_today , 1.0 );
			cashCurve.set(m_spot , spotDF );

			map<date,double>::const_iterator it = m_cashParams.begin();
			++it;
			for (  ; it != m_cashParams.end() ; ++it ) 
			{
				dcf = dayCountFrac( m_basis, m_spot, it->first );

				cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
			}

			discountCurve::set(m_1stFut , cashCurve.get(m_1stFut) ); // set first discount from LIBOR

		}

		// The futures
		for ( int i = 0 ; i < n_futures ; ++i ) 
		{
			date start = m_starts[i];
			date end = m_ends[i];

			rate = (100.0-m_futures[i])/100.0 - m_adjustments[i]/10000.0;

			PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
			discountCurve::set(end , get(start) * PDF );
		}

		// Sometimes we extrapolate the last future to ensure that the number of swaps in the hedge doesn't change.
		if ( m_extrapolateLastFutRate )
		{
			date firstSwapMatDt = m_swapLastDates[m_firstUsedSwapIndex];

			rate = (100.0-m_futures[n_futures-1])/100.0 - m_adjustments[n_futures-1]/10000.0; //Use same forward as last future.
			PDF = 1.0 / ( 1.0 + rate * m_extraPDCF );

			discountCurve::set(m_extraEnd , get(m_extraStart) * PDF );
		}
		// The swaps

		// Set up the linear interp curve of par rates to get the par points between the input points
		if ( m_parRates.size() > 0 )
		{
			LinearCurve swapsLinCurve;

			long lastSwapTenor = (long) m_swapTenors.back();
			long firstSwapTenor = (long) m_swapTenors[m_firstUsedSwapIndex];

			// First swap is solved from futures curve.
			m_usedSwaps[0].setCurves( Handle<swapData>(this,null_deleter()), Handle<swapData>(this,null_deleter()) );
			swapsLinCurve.set(firstSwapTenor*12, m_usedSwaps[0].Solve(0, solveFORCOUPON) );

			for ( unsigned int i=m_firstUsedSwapIndex+1 ; i < m_parRates.size() ; ++i )
			{
				swapsLinCurve.set((long)(m_swapTenors[i]*12) , m_parRates[i]);
			}


			Handle<Leg> fixedLeg = m_usedSwaps[1].getLeg(MC_FIXED);

			dateVec pmtDates;
			fixedLeg->getPaymentDates( pmtDates );

			vector<double> DCFs;
			fixedLeg->getDCFs( DCFs );

			long firstSwapPeriodIndex = (long)(firstSwapTenor * m_fixedPmtsPerYear) - 1;
			long lastSwapPeriodIndex = DCFs.size() - 1;

			// Check that the first payment DF we calc is going to be after the last future!
			while ( (firstSwapPeriodIndex < lastSwapPeriodIndex) 
				&& (pmtDates[firstSwapPeriodIndex+1] <= this->lastDate() ) )
			{
				firstSwapPeriodIndex++;
			} 

			double sum = 0;
			for ( long i = 0 ; i <= firstSwapPeriodIndex ; ++i )
			{
				sum += DCFs[i] * this->get(pmtDates[i]);
			}

			for ( long i = firstSwapPeriodIndex+1; i <= lastSwapPeriodIndex ; ++i )
			{
				double couponRate = swapsLinCurve.get((long)((i+1)*12.0/m_fixedPmtsPerYear));

				double lastDF = ( spotDF - couponRate * sum ) / ( 1.0 + couponRate * DCFs[i] );

				discountCurve::set(pmtDates[i], lastDF);

				sum += DCFs[i] * lastDF;

			}

			//  Do a second pass to put in semi annual points if we need to.
			if ( (m_fixedPmtsPerYear < 2) && (swapsLinCurve.size() > 1) )
			{
				for ( int swapMonths = (int)swapsLinCurve.firstLabel() + 6 ; 
					swapMonths < swapsLinCurve.lastLabel() ; 
					swapMonths += 12 )
				{

					double swapRate = swapsLinCurve.get(swapMonths);
					double prvSwapRate = swapsLinCurve.get(swapMonths - 6);
					double nxtSwapRate = swapsLinCurve.get(swapMonths + 6);

					date endDate = addBusinessMonths(m_spot, swapMonths, m_swapHols);
					date prvEndDate = addBusinessMonths(m_spot, swapMonths - 6, m_swapHols);
					date nxtEndDate = addBusinessMonths(m_spot, swapMonths + 6, m_swapHols);
					if (!Globals::GetAdjustDates())
					{
						prvEndDate = addBusinessMonths(m_spot, swapMonths - 6, NONE);
						nxtEndDate = addBusinessMonths(m_spot, swapMonths + 6, NONE);
					}

					double daysToInterp = dayCount(m_fixedBasis, prvEndDate, endDate);
					double daysToNext = dayCount(m_fixedBasis, prvEndDate, nxtEndDate);
					double daysToInterpFrac = dayCountFrac(m_fixedBasis, prvEndDate, endDate);
					double daysToNextFrac = dayCountFrac(m_fixedBasis, prvEndDate, nxtEndDate);

					double prevSwapDF = this->get(prvEndDate);
					double nextSwapDF = this->get(nxtEndDate);

					double numerator = spotDF - (swapRate / prvSwapRate) * (spotDF - prevSwapDF);
					double denominator = 1.0 + (pow(1.0 + swapRate, daysToInterp / daysToNext) - 1.0) * daysToNextFrac;

					discountCurve::set(endDate , numerator/denominator);
				}
			}
		}

	}


	void ApolloCurve::calculateSpreadCurve()
	{
		double rate, PDF;
		int n_futures = m_futures.size();

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );

		discountCurve::clear();
		discountCurve::set(m_today , 1.0 );
		discountCurve::set(m_spot , spotDF );

		if ( m_useMinRateFirstStub )
		{
			if ( m_cashDate <= m_starts[0] ) // Cash rate endds before first future.
			{
				double cashDF = 1.0 / (1.0 + m_cashParams[m_cashDate]*m_cashDCF );
				discountCurve::set(m_cashDate, spotDF * cashDF );
				//Cludge!!! There must be a DF for the first future start date.
				double firstFutDF = 1.0 / (1.0 + m_cashParams[m_cashDate]*m_t1 );
				discountCurve::set(m_1stFut, spotDF * firstFutDF );
			}
			else
			{
				double ccCashRate = log(1.0 + m_cashParams[m_cashDate]*m_cashDCF) / m_cashDCF;
				double cashDateFutRate = (100.0-m_futures[m_cashDateFuture])/100.0 - m_adjustments[m_cashDateFuture]/10000.0;
				double ccCashDateFutRate = log( 1.0 + cashDateFutRate * m_fut_DCF[m_cashDateFuture] ) / m_fut_DCF[m_cashDateFuture];
				double sum = ccCashDateFutRate * (m_cashDCF - m_fut_t[m_cashDateFuture]);
				for ( int i=0 ; i < m_cashDateFuture ; i++ )
				{
					double futRate = (100.0-m_futures[i])/100.0 - m_adjustments[i]/10000.0;
					double ccFutRate = log( 1.0 + futRate * m_fut_DCF[i] ) / m_fut_DCF[i];
					sum += ccFutRate * (m_fut_t[i+1] - m_fut_t[i]);
				}

				double ccStubRateT = (ccCashRate * m_cashDCF - sum);

				discountCurve::set(m_1stFut, spotDF * exp(-ccStubRateT) );
			}
		}
		else
		{
			// Apollo2 stub
			discountCurve cashCurve;
			cashCurve.set(m_today , 1.0 );
			cashCurve.set(m_spot , spotDF );

			map<date,double>::const_iterator it = m_cashParams.begin();
			++it;
			for (  ; it != m_cashParams.end() ; ++it ) 
			{
				dcf = dayCountFrac( m_basis, m_spot, it->first );

				cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
			}

			discountCurve::set(m_1stFut , cashCurve.get(m_1stFut) ); // set first discount from LIBOR

		}

		// The futures
		for ( int i = 0 ; i < n_futures ; ++i ) 
		{
			date start = m_starts[i];
			date end = m_ends[i];

			rate = (100.0-m_futures[i])/100.0 - m_adjustments[i]/10000.0;

			PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
			discountCurve::set(end , get(start) * PDF );
		}

		// Sometimes we extrapolate the last future to ensure that the number of swaps in the hedge doesn't change.
		if ( m_extrapolateLastFutRate )
		{
			date firstSwapMatDt = m_swapLastDates[m_firstUsedSwapIndex];

			rate = (100.0-m_futures[n_futures-1])/100.0 - m_adjustments[n_futures-1]/10000.0; //Use same forward as last future.
			PDF = 1.0 / ( 1.0 + rate * m_extraPDCF );

			discountCurve::set(m_extraEnd , get(m_extraStart) * PDF );
		}

		// The swaps

		// Set up the linear interp curve of spreads to get the spreads between the input points
		if ( m_parRates.size() > 0 )
		{

			long lastSwapTenor = (long) m_swapTenors.back();
			long firstSwapTenor = (long) m_swapTenors[m_firstUsedSwapIndex];

			// First basis swap is solved from futures curve.
			m_firstBasisSwap.setCurves(m_baseCurve, m_baseCurve, Handle<swapData>(this,null_deleter()));
			m_TenorSpreads.set(firstSwapTenor*12, m_firstBasisSwap.Solve(0,0) );

			// Setup the various parts of the quantities we have to sum up.
			Handle<Leg> floatLeg = m_usedSwaps[1].getLeg(MC_FLOAT);

			floatLeg->updatePaymentsFromCurves(m_baseCurve, m_baseCurve);
			vector<PaymentPeriod> basePPs;
			floatLeg->getAllPeriods( basePPs );

			double baseFtDsum=0;
			double basetDsum=0;

			for ( unsigned int i= 0 ; i <= m_basePpIndexWithEndDateSameAsSwap[m_firstUsedSwapIndex] ; ++i )
			{
				double tD =  basePPs[i].getDayCountFraction() * basePPs[i].getDiscountFactor();
				basetDsum += tD;
				baseFtDsum += basePPs[i].getFloatingRate() * tD;
			}

			vector<PaymentPeriod> spreadPPs;
			m_spreadLeg.getAllPeriods( spreadPPs );

			double spreadFtDsum=0;

			for ( i= 0 ; i <= m_spreadPpIndexWithEndDateSameAsSwap[m_firstUsedSwapIndex] ; ++i )
			{
				double F = this->getZero( spreadPPs[i].getAdjustedStart() , spreadPPs[i].getAdjustedEnd() , m_spreadBasis);
				double t = spreadPPs[i].getDayCountFraction();
				double D = m_baseCurve->getDiscountFactor( spreadPPs[i].getPaymentDate() );

				spreadFtDsum += F*t*D;
			}


			// Now loop through the spreadPPs calculating the DFs
			if ( basePPs.size() >= spreadPPs.size() ) // Is the tenor of the base curve smaller or equal to the spread curve tenor.
			{
				double spreadD = this->getDiscountFactor(spreadPPs[m_spreadPpIndexWithEndDateSameAsSwap[m_firstUsedSwapIndex]].getPaymentDate());
				for ( i = m_spreadPpIndexWithEndDateSameAsSwap[m_firstUsedSwapIndex]+1 ; i < spreadPPs.size() ; ++i )
				{

					for ( unsigned int j = m_basePpIndexWithEndDateSameAsSpreadPp[i-1]+1 ; j <= m_basePpIndexWithEndDateSameAsSpreadPp[i] ; j++ )
					{
						double tD =  basePPs[j].getDayCountFraction() * basePPs[j].getDiscountFactor();
						basetDsum += tD;
						baseFtDsum += basePPs[j].getFloatingRate() * tD;
					}

					double spread = m_TenorSpreads.get( m_spreadPpTenorMonths[i] );
					double D = m_baseCurve->getDiscountFactor( spreadPPs[i].getPaymentDate() );
					spreadD = spreadD / ( ( (baseFtDsum + spread*basetDsum - spreadFtDsum )/ D ) + 1 );

					this->set(spreadPPs[i].getPaymentDate(), spreadD);

					double F = this->getZero( spreadPPs[i].getAdjustedStart() , spreadPPs[i].getAdjustedEnd() , m_spreadBasis);
					double t = spreadPPs[i].getDayCountFraction();

					spreadFtDsum += F*t*D;

				}
			}
			else
			{
				i = m_spreadPpIndexWithEndDateSameAsSwap[m_firstUsedSwapIndex];
				double spreadD = this->getDiscountFactor(spreadPPs[i].getPaymentDate());
				double F = this->getZero( spreadPPs[i].getAdjustedStart() , spreadPPs[i].getAdjustedEnd() , m_spreadBasis);
				double t = spreadPPs[i].getDayCountFraction();

				for ( i = m_basePpIndexWithEndDateSameAsSwap[m_firstUsedSwapIndex]+1 ; i < basePPs.size() ; ++i )
				{

					unsigned int startIndex = m_spreadPpIndexWithEndDateSameAsBasePp[i-1];
					double spreadTDsum = 0;
					double spreadXTDsum = 0;
					for ( unsigned int j = startIndex+1 ; j <= m_spreadPpIndexWithEndDateSameAsBasePp[i] ; j++ )
					{
						double tD =  spreadPPs[j].getDayCountFraction() * m_baseCurve->getDiscountFactor( spreadPPs[j].getPaymentDate() );
						spreadTDsum += tD;
						spreadXTDsum += (j - startIndex) * tD;
					}

					double tD =  basePPs[i].getDayCountFraction() * basePPs[i].getDiscountFactor();
					basetDsum += tD;
					baseFtDsum += basePPs[i].getFloatingRate() * tD;

					double spread = m_TenorSpreads.get( m_basePpTenorMonths[i] );

					double b = ( baseFtDsum + spread * basetDsum - spreadFtDsum - F * spreadTDsum ) / spreadXTDsum;

					for ( unsigned int j = startIndex+1 ; j <= m_spreadPpIndexWithEndDateSameAsBasePp[i] ; j++ )
					{
						double Fi = F+(j-startIndex)*b;
						double ti = spreadPPs[j].getDayCountFraction();
						double D = m_baseCurve->getDiscountFactor( spreadPPs[j].getPaymentDate() );

						spreadD = spreadD / ( 1.0 + Fi*ti );
						this->set(spreadPPs[i].getPaymentDate(), spreadD);

						spreadFtDsum += Fi * ti * D;
					}

				}
			}

			//for ( i= 0 ; i <= m_spreadPpIndexWithEndDateSameAsSwap[m_firstUsedSwapIndex] ; ++i )
			//{
			//	double F = this->getCCRate( spreadPPs[i].getAdjustedStart() , spreadPPs[i].getAdjustedEnd() , m_spreadBasis);
			//	double t = spreadPPs[i].getDayCountFraction();
			//	double D = m_baseCurve->getDiscountFactor( spreadPPs[i].getPaymentDate() );

			//	spreadFtDsum += F*t*D;
			//}


			//// Now loop through the spreadPPs calculating the DFs
			//double logSpreadD = log( this->getDiscountFactor(spreadPPs[m_spreadPpIndexWithEndDateSameAsSwap[m_firstUsedSwapIndex]].getPaymentDate()) );
			//for ( i = m_spreadPpIndexWithEndDateSameAsSwap[m_firstUsedSwapIndex]+1 ; i < spreadPPs.size() ; ++i )
			//{

			//	for ( unsigned int j = m_basePpIndexWithEndDateSameAsSpreadPp[i-1]+1 ; j <= m_basePpIndexWithEndDateSameAsSpreadPp[i] ; j++ )
			//	{
			//		double tD =  basePPs[j].getDayCountFraction() * basePPs[j].getDiscountFactor();
			//		basetDsum += tD;
			//		baseFtDsum += basePPs[j].getFloatingRate() * tD;
			//	}

			//	double spread = m_TenorSpreads.get( m_spreadPpTenorMonths[i] );
			//	double D = m_baseCurve->getDiscountFactor( spreadPPs[i].getPaymentDate() );
			//	logSpreadD = logSpreadD + (spreadFtDsum - baseFtDsum - spread*basetDsum)/ D;

			//	this->set(spreadPPs[i].getPaymentDate(), exp(logSpreadD));

			//	double F = this->getCCRate( spreadPPs[i].getAdjustedStart() , spreadPPs[i].getAdjustedEnd() , m_spreadBasis);
			//	double t = spreadPPs[i].getDayCountFraction();

			//	spreadFtDsum += F*t*D;

			//}
		}
	}

	void ApolloCurve::set_currency_defaults(CURRENCY ccy)
	{
		switch(ccy)
		{
		case USD:
			set_currency_defaults(ccy, SB3);
			break;
		case EUR:
			set_currency_defaults(ccy, AB6);
			break;
		case JPY:
			set_currency_defaults(ccy, SB6);
			break;
		case GBP:
			set_currency_defaults(ccy, SB6);
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}

	}

	void ApolloCurve::set_currency_defaults(CURRENCY ccy, SwapType type)
	{

		vanillaSwapParams(ccy, type, m_fixedPmtsPerYear, m_fltPmtsPerYear, m_fixedBasis, m_basis) ;

		m_swapType = type;
		setCurrency(ccy);

		switch(ccy)
		{
		case USD:
			m_swapHols = HOLIDAYCAL(UK | USA);
			m_hols = HOLIDAYCAL(USA+UK);
			break;
		case EUR:
			m_swapHols = EUTARG;
			m_hols = EUTARG;
			break;
		case JPY:
			m_swapHols = JP;
			m_hols = UK;
			break;
		case GBP:
			m_swapHols = UK;
			m_hols = UK;
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}
	}


	bool ApolloCurve::cmpvecs( const vector<double> & v1, const vector<double> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}

	bool ApolloCurve::cmpmaps( const map<date,double> & v1, map<date,double> & v2)
	{
		if ( v1.size() != v2.size() ) return false;
		else 
		{
			bool test = true;
			map<date,double>::const_iterator it1 = v1.begin();
			map<date,double>::const_iterator it2 = v2.begin();
			while ( test && ( it1 != v1.end() ) && ( it2 != v2.end() ) )
			{
				if ( it1->first != it2->first ) 
					test = false;

				++it1;
				++it2;
			}		
			return test;
		}
		return false; // should not get here.
	}

	void ApolloCurve::generateSpreadVectors(const map<date,double> spreads)
	{
		m_TenorSpreads.clear();
		m_SpreadTenorDCFs.clear();
		for ( map<date,double>::const_iterator it = spreads.begin() ; it != spreads.end() ; ++it )
		{
			double tenor = dayCountFrac(_30_360f,  m_spot, it->first );
			m_TenorSpreads.set((long)tenor*12, it->second);
			m_SpreadTenorDCFs.push_back((long)tenor*12);
		}
	}

	void ApolloCurve::generateSwapVectors()
	{
		m_parRates.clear();
		m_swapTenors.clear();
		m_swapLastDates.clear();

		for ( map<date,double>::const_iterator it = m_swapParams.begin() ; it != m_swapParams.end() ; ++it )
		{
			double tenor = dayCountFrac(_30_360f,  m_spot, it->first );

			m_parRates.push_back( it->second );
			m_swapTenors.push_back( tenor );
			m_swapLastDates.push_back( it->first );
		}
	}

	void ApolloCurve::generateSwapRateVector()
	{

		for ( unsigned int i=0 ; i < m_swapLastDates.size() ; ++i )
		{
			m_parRates[i] = m_swapParams[ m_swapLastDates[i] ];
		}
	}

	// Generate a spread curve off a base curve and a set of spreads.


	void ApolloCurve::createSpreadCurve( Handle<ApolloCurve> baseCurve, const map<date,double> & cashSpreads, const vector<double> & futuresSpreads,
		const map<date,double> & swapsSpreads, const DayBasis spreadBasis, const DatePeriod & spreadTenor	, const DatePeriod & spreadCashTenor	)
	{
		m_useMinRateFirstStub = baseCurve->m_useMinRateFirstStub;
		set_currency_defaults(baseCurve->m_ccy, baseCurve->m_swapType);
		m_today = baseCurve->m_today;
		m_spot = baseCurve->m_spot;
		m_1stFut = baseCurve->m_1stFut;
		m_futures = vector<double>(baseCurve->m_futures);
		m_adjustments = vector<double>(baseCurve->m_adjustments);
		m_swapParams = map<date, double>(baseCurve->m_swapParams);
		m_cashParams = map<date, double>(baseCurve->m_cashParams);
		m_spreadBasis = spreadBasis;
		m_spreadTenor = DatePeriod( spreadTenor );
		m_spreadCashTenor = DatePeriod( spreadCashTenor );
		m_baseCurve = baseCurve;
		if (baseCurve)
			baseCurve->addDependent(Handle<ApolloCurve>(this));
		m_dependentCurves.clear();

		for ( map<date,double>::iterator cash_it = m_cashParams.begin() ; cash_it != m_cashParams.end() ; ++cash_it )
		{
			cash_it->second += cashSpreads.find(cash_it->first)->second;
		}

		/*for ( map<date,double>::iterator swap_it = m_swapParams.begin() ; swap_it != m_swapParams.end() ; ++swap_it )
		{
		swap_it->second += swapsSpreads.find(swap_it->first)->second;
		}*/

		for ( unsigned int i=0 ; i < m_futures.size() ; i++ )
		{
			m_futures[i] += futuresSpreads[i];
		}

		generateSwapVectors();
		generateSpreadVectors(swapsSpreads);
		clear();
		calculateSpreadDates();
		calculateSpreadCurve();
	}

	void ApolloCurve::create( const vector<double> & futures, const vector<double> & adjustments, 
		const map<date,double> & swaps, const SwapType sType,
		date & today, date & firstFut, const map<date,double> & cashParams, CURRENCY ccy, bool useMinRateFirstStub)
	{
		if ( (m_today != today) || (m_1stFut != firstFut) || futures.size() != m_futures.size() 
			|| ( ccy != m_ccy )
			|| sType != m_swapType || !cmpmaps(swaps, m_swapParams) || !cmpmaps(cashParams, m_cashParams)
			|| (useMinRateFirstStub != m_useMinRateFirstStub) ) 
		{
			m_useMinRateFirstStub = useMinRateFirstStub;
			set_currency_defaults(ccy, sType);
			m_today = today;
			m_spot = spot(today, ccy);
			m_1stFut = firstFut;
			m_futures = futures;
			m_adjustments = adjustments;
			//m_stub_curve = stub;
			m_swapType = sType;
			m_swapParams = swaps;
			m_cashParams = cashParams;
			generateSwapVectors();
			clear();
			calculateDates();
			calculateCurve();
		} 
		else 
		{
			m_futures = futures;
			m_adjustments = adjustments;
			//m_stub_curve = stub;
			m_swapParams = swaps;
			m_cashParams = cashParams;
			generateSwapRateVector();
			clear();
			calculateCurve();
		}
	}

	void ApolloCurve::addDependent(Handle<ApolloCurve> dependentCurve)
	{
		m_dependentCurves.push_back(dependentCurve);
	}

	// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
	Handle<PPCurves> ApolloCurve::create_PPCurves( double pp_val )
	{
		Handle<PPCurves> pp_curves = Handle<PPCurves>(new PPCurves());

		int nHedges = m_swapParams.size() + m_futures.size() + m_cashParams.size(); 
		pp_curves->resize( nHedges ); 
		pp_curves->set_ppsize( pp_val/100.0 ); // set the perturb size in factor (i.e. 1 = 1%)

		pp_curves->base() = Handle<swapData>(new ApolloCurve(*this));

		unsigned int i=0;
		// up
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			partialClear();
			calculateCurve();
			pp_curves->label(i) = "cash " + (string) it->first;
			pp_curves->up(i++) = Handle<swapData>(new ApolloCurve(*this));
			for (vector<Handle<ApolloCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			{
				((*it2))->calculateSpreadCurve();
				pp_curves->up_dependents(i-1)[(*it2)] = Handle<ApolloCurve>(new ApolloCurve(*(*it2)));
			}
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] -= pp_val;
			partialClear();
			calculateCurve();
			pp_curves->label(i) = "Fut " + (string) m_starts[j];
			pp_curves->up(i++) = Handle<swapData>(new ApolloCurve(*this));
			for (vector<Handle<ApolloCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			{
				((*it2))->calculateSpreadCurve();
				pp_curves->up_dependents(i-1)[(*it2)] = Handle<ApolloCurve>(new ApolloCurve(*(*it2)));
			}
			m_futures[j] += pp_val;
		}
		for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
		{
			if (!m_TenorSpreads.size()) // base curve
			{
				m_parRates[j] += pp_val/100.0;
				partialClear();
				calculateCurve();
				pp_curves->label(i) = "Swap " + stringify( m_swapTenors[j] ) + "Y";
				pp_curves->up(i++) = Handle<swapData>(new ApolloCurve(*this));
				for (vector<Handle<ApolloCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
				{
					((*it2))->calculateSpreadCurve();
					pp_curves->up_dependents(i-1)[(*it2)] = Handle<ApolloCurve>(new ApolloCurve(*(*it2)));
				}
				m_parRates[j] -= pp_val/100.0;
			}
			else // spread curve
			{
				m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) + pp_val/100.0);
				partialClear();
				calculateSpreadCurve();
				pp_curves->label(i) = "Swap " + stringify( m_swapTenors[j] ) + "Y";
				pp_curves->up(i++) = Handle<swapData>(new ApolloCurve(*this));
				for (vector<Handle<ApolloCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
				{
					((*it2))->calculateSpreadCurve();
					pp_curves->up_dependents(i-1)[(*it2)] = Handle<ApolloCurve>(new ApolloCurve(*(*it2)));
				}
				m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) - pp_val/100.0);
			}
		}

		// dn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			partialClear();
			calculateCurve();
			pp_curves->dn(i++)= Handle<swapData>(new ApolloCurve(*this));
			for (vector<Handle<ApolloCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			{
				((*it2))->calculateSpreadCurve();
				pp_curves->dn_dependents(i-1)[(*it2)] = Handle<ApolloCurve>(new ApolloCurve(*(*it2)));
			}
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			partialClear();
			calculateCurve();
			pp_curves->dn(i++)= Handle<swapData>(new ApolloCurve(*this));
			for (vector<Handle<ApolloCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			{
				((*it2))->calculateSpreadCurve();
				pp_curves->dn_dependents(i-1)[(*it2)] = Handle<ApolloCurve>(new ApolloCurve(*(*it2)));
			}
			m_futures[j] -= pp_val;
		}
		for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
		{
			if (!m_TenorSpreads.size()) // base curve
			{
				m_parRates[j] -= pp_val/100.0;
				partialClear();
				calculateCurve();
				pp_curves->dn(i++)= Handle<swapData>(new ApolloCurve(*this));
				for (vector<Handle<ApolloCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
				{
					((*it2))->calculateSpreadCurve();
					pp_curves->dn_dependents(i-1)[(*it2)] = Handle<ApolloCurve>(new ApolloCurve(*(*it2)));
				}
				m_parRates[j] += pp_val/100.0;
			}
			else // spread curve
			{
				m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) - pp_val/100.0);
				partialClear();
				calculateSpreadCurve();
				pp_curves->label(i) = "Swap " + stringify( m_swapTenors[j] ) + "Y";
				pp_curves->dn(i++) = Handle<swapData>(new ApolloCurve(*this));
				for (vector<Handle<ApolloCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
				{
					((*it2))->calculateSpreadCurve();
					pp_curves->dn_dependents(i-1)[(*it2)] = Handle<ApolloCurve>(new ApolloCurve(*(*it2)));
				}
				m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) + pp_val/100.0);
			}
		}

		//upup
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			m_futures[j] -= pp_val;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			it->second += pp_val/100.0;
		for ( unsigned int j=m_firstUsedSwapIndex ; j < m_parRates.size() ; ++j ) 
			if (!m_TenorSpreads.size()) // base curve
			{
				m_parRates[j] += pp_val/100.0;
			}
			else
			{
				m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) + pp_val/100.0);
			}

			i=0;
			for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			{
				it->second += pp_val/100.0;
				partialClear();
				calculateCurve();
				pp_curves->upup(i++)= Handle<swapData>(new ApolloCurve(*this));
				it->second -= pp_val/100.0;
			}
			for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			{
				m_futures[j] -= pp_val;
				partialClear();
				calculateCurve();
				pp_curves->upup(i++)= Handle<swapData>(new ApolloCurve(*this));
				m_futures[j] += pp_val;
			}
			for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
			{
				if (!m_TenorSpreads.size()) // base curve
				{
					m_parRates[j] += pp_val/100.0;
					partialClear();
					calculateCurve();
					pp_curves->upup(i++)= Handle<swapData>(new ApolloCurve(*this));
					m_parRates[j] -= pp_val/100.0;
				}
				else // spread curve
				{
					m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) + pp_val/100.0);
					partialClear();
					calculateSpreadCurve();
					pp_curves->label(i) = "Swap " + stringify( m_swapTenors[j] ) + "Y";
					pp_curves->upup(i++) = Handle<swapData>(new ApolloCurve(*this));
					m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) - pp_val/100.0);
				}
			}

			// updn
			i=0;
			for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			{
				it->second -= pp_val/100.0;
				partialClear();
				calculateCurve();
				pp_curves->updn(i++)= Handle<swapData>(new ApolloCurve(*this));
				it->second += pp_val/100.0;
			}
			for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			{
				m_futures[j] += pp_val;
				partialClear();
				calculateCurve();
				pp_curves->updn(i++)= Handle<swapData>(new ApolloCurve(*this));
				m_futures[j] -= pp_val;
			}
			for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
			{
				if (!m_TenorSpreads.size()) // base curve
				{
					m_parRates[j] -= pp_val/100.0;
					partialClear();
					calculateCurve();
					pp_curves->updn(i++)= Handle<swapData>(new ApolloCurve(*this));
					m_parRates[j] += pp_val/100.0;
				}
				else // spread curve
				{
					m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) - pp_val/100.0);
					partialClear();
					calculateSpreadCurve();
					pp_curves->label(i) = "Swap " + stringify( m_swapTenors[j] ) + "Y";
					pp_curves->updn(i++) = Handle<swapData>(new ApolloCurve(*this));
					m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) + pp_val/100.0);
				}
			}

			//dnup
			for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
				m_futures[j] += 2.0*pp_val;
			for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
				it->second -= 2.0*pp_val/100.0;
			for ( unsigned int j=m_firstUsedSwapIndex ; j < m_parRates.size() ; ++j ) 
				if (!m_TenorSpreads.size()) // base curve
				{
					m_parRates[j] -= 2.0*pp_val/100.0;
				}
				else
				{
					m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) - 2*pp_val/100.0);
				}

				i=0;
				for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
				{
					it->second += pp_val/100.0;
					partialClear();
					calculateCurve();
					pp_curves->dnup(i++)= Handle<swapData>(new ApolloCurve(*this));
					it->second -= pp_val/100.0;
				}
				for ( unsigned int j=0 ; j < m_futures.size() ; ++j )
				{
					m_futures[j] -= pp_val;
					partialClear();
					calculateCurve();
					pp_curves->dnup(i++)= Handle<swapData>(new ApolloCurve(*this));
					m_futures[j] += pp_val;
				}
				for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
				{
					if (!m_TenorSpreads.size()) // base curve
					{
						m_parRates[j] += pp_val/100.0;
						partialClear();
						calculateCurve();
						pp_curves->dnup(i++)= Handle<swapData>(new ApolloCurve(*this));
						m_parRates[j] -= pp_val/100.0;
					}
					else // spread curve
					{
						m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) + pp_val/100.0);
						partialClear();
						calculateSpreadCurve();
						pp_curves->label(i) = "Swap " + stringify( m_swapTenors[j] ) + "Y";
						pp_curves->dnup(i++) = Handle<swapData>(new ApolloCurve(*this));
						m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) - pp_val/100.0);
					}
				}

				// dndn
				i=0;
				for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
				{
					it->second -= pp_val/100.0;
					partialClear();
					calculateCurve();
					pp_curves->dndn(i++)= Handle<swapData>(new ApolloCurve(*this));
					it->second += pp_val/100.0;
				}
				for ( unsigned int j=0  ; j < m_futures.size() ; ++j ) 
				{
					m_futures[j] += pp_val;
					partialClear();
					calculateCurve();
					pp_curves->dndn(i++)= Handle<swapData>(new ApolloCurve(*this));
					m_futures[j] -= pp_val;
				}
				for ( unsigned int j=0 ; j < m_parRates.size() ; ++j ) 
				{
					if (!m_TenorSpreads.size()) // base curve
					{
						m_parRates[j] -= pp_val/100.0;
						partialClear();
						calculateCurve();
						pp_curves->dndn(i++)= Handle<swapData>(new ApolloCurve(*this));
						m_parRates[j] += pp_val/100.0;
					}
					else // spread curve
					{
						m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) - pp_val/100.0);
						partialClear();
						calculateSpreadCurve();
						pp_curves->label(i) = "Swap " + stringify( m_swapTenors[j] ) + "Y";
						pp_curves->dndn(i++) = Handle<swapData>(new ApolloCurve(*this));
						m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) + pp_val/100.0);
					}
				}

				for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
					m_futures[j] -= pp_val;
				for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
					it->second += pp_val/100.0;
				for ( unsigned int j=m_firstUsedSwapIndex ; j < m_parRates.size() ; ++j ) 
					if (!m_TenorSpreads.size()) // base curve
					{
						m_parRates[j] += pp_val/100.0;
					}
					else
					{
						m_TenorSpreads.set(m_SpreadTenorDCFs[j], m_TenorSpreads.get(m_SpreadTenorDCFs[j]) + pp_val/100.0);
					}

					partialClear();
					if (!m_TenorSpreads.size()) // base curve
						calculateCurve();
					else
						calculateSpreadCurve();

					//recalculateDependents
					for (vector<Handle<ApolloCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
					{
						((*it2))->calculateSpreadCurve();
					}

					return pp_curves;

	}





} // namespace MCPL