#include"SmoothForwardsCurve.h"

#include "numrec/dnrutil.h"


namespace MCPL
{
	double SmoothForwardsCurve::get(const long& dLabel)
	{
		if (m_appearAsFlat)
			return swapData::get(dLabel);
		else
			return SmoothCurve::get(dLabel);
	}

	void SmoothForwardsCurve::create(
		const vector<double>&   Futures,
		const vector<double>&   Adjustmnts,
		const vector<date>&     FuturesDates,
		const vector<date>      swapEffDates,
		const vector<date>      swapDates,
		const vector<double> &  swapRates,
		const vector<double> &  swapTolerances,
		const SwapType          sType,
		date &            today,
		const map<date, double>& cashParams,
		CURRENCY          ccy,
		double            firstFixRate,
		Handle<RatesCurve>  swapDiscountCurve,
		bool              IsOIS)
	{
		m_appearAsFlat = true;
		m_IsOIS = IsOIS;

		if (!swapDiscountCurve)
		{
			m_swapsDiscountCurve = Handle<RatesCurve>(this, null_deleter());
		}
		else
		{
			m_swapsDiscountCurve = swapDiscountCurve;
			m_swapsDiscountCurve->addDependent(Handle<RatesCurve>(this, null_deleter()));
		}
		m_dependentCurves.clear();



		if ((m_today != today)
			|| (ccy != m_ccy)
			|| sType != m_swapType
			|| !cmpvecs(swapEffDates, m_swapEffDates)
			|| !cmpvecs(swapDates, m_swapMaturityDates)
			|| !cmpmaps(cashParams, m_cashParams)
			|| !cmpvecs(FuturesDates, m_futuresEnds)
			|| !cmpvecs(Futures, m_futures)
			|| !cmpvecs(Adjustmnts, m_futuresAdj)
			|| firstFixRate != m_firstFixRate
			)
		{
			set_currency_defaults(ccy, sType);
			m_today = today;
			m_spot = spot(today, ccy);

			m_swapType = sType;
			m_swapMaturityDates = swapDates;
			m_swapEffDates = swapEffDates;
			m_parRates = swapRates;
			m_swapTolerances = swapTolerances;
			m_cashParams = cashParams;

			m_firstFixRate = firstFixRate;

			m_futures.clear();
			if (Futures.size() > 0)
			for (unsigned int i = 0; i<Futures.size(); i++)
			{
				m_futures.push_back(Futures[i]);
			}

			m_futuresAdj.clear();
			m_futuresAdj.resize(m_futures.size(), 0.0);
			if (Adjustmnts.size() > 0)
			for (unsigned int i = 0; i<Adjustmnts.size(); i++)
			{
				m_futuresAdj[i] = Adjustmnts[i];
			}

			m_futuresStarts.clear();
			m_futuresStarts.resize(m_futures.size(), 0.0);
			if (FuturesDates.size() > 0)
			for (unsigned int i = 0; i < Adjustmnts.size(); i++)
			{
				m_futuresStarts[i] = nthIMMDate(FuturesDates[i], 1, 3).roll(m_hols, 0, true);
			}

			swapData::clear();
			SmoothCurve::clear();
			calculateDates();
			calculateCurve();
		}
		else
		{
			m_cashParams = cashParams;
			m_parRates = swapRates;
			m_swapTolerances = swapTolerances;

			m_futures.clear();
			if (Futures.size() > 0)
			for (unsigned int i = 0; i<Futures.size(); i++)
			{
				m_futures.push_back(Futures[i]);
			}
			m_futuresAdj.clear();
			m_futuresAdj.resize(m_futures.size(), 0.0);
			if (Adjustmnts.size() > 0)
			for (unsigned int i = 0; i < Adjustmnts.size(); i++)
			{
				m_futuresAdj[i] = Adjustmnts[i];
			}
			swapData::clear();
			SmoothCurve::clear();
			calculateCurve();
		}
	}

		void SmoothForwardsCurve::addDependent(Handle<RatesCurve> dependentCurve)
	{
		m_dependentCurves.push_back(dependentCurve);
	}

	void SmoothForwardsCurve::calculateDates()
	{
		unsigned int n_futures = m_futures.size();

		if (n_futures)
		{
			// Set up IMM start, end dates and day count fractions.
			m_futuresEnds.clear(); m_futuresEnds.resize(n_futures);
			m_futuresDCF.clear();  m_futuresDCF.resize(n_futures);

			for (unsigned int i = 0; i < n_futures; ++i)
			{
				//allows for non-contiguous futures, starts in IMM, matures +3m, not next IMM
				m_futuresEnds[i] = addBusinessMonths(m_futuresStarts[i], 3, m_hols);//nthIMMDate(m_futuresStarts[i], 2, 3).roll(m_hols, 0, true);
				//				if (i>0 && m_futuresStarts[i] != m_futuresEnds[i-1])
				//					mcpl_error("futures dates do not form a contiguous strip");
				m_futuresDCF[i] = dayCountFrac(m_basis, m_futuresStarts[i], m_futuresEnds[i]);
			}
		}

		unsigned int n_swaps = m_swapMaturityDates.size();
		if (n_swaps > 0)
		{
			// Set up swaps data
			m_swapCashflows.clear();
			m_swapLastDates.clear();

			for (unsigned int j = 0; j < n_swaps; ++j)
			{
				Swap tmpswap = Swap(PAY, m_swapType, m_swapEffDates[j], m_swapMaturityDates[j], m_swapEffDates[j], 1, m_parRates[j], 0, m_swapHols, m_ccy, m_IsOIS);
				m_swapCashflows.push_back(tmpswap);
				if (n_futures > 0) // this is a proxy condition for 'we are building OIS curve'
					m_swapLastDates.push_back(tmpswap.getLastDate());
				else
					m_swapLastDates.push_back(tmpswap.getLastDateFixed());
			}
		}
	}

	void SmoothForwardsCurve::addSmoothSegment(date start, double df)
	{
		// make the current segment the previous one
		m_prevSmoothDate = m_currSmoothDate;
		m_prevSmoothData = m_currSmoothData;
		// add the new segment
		m_currSmoothDate = start;
		m_currSmoothData = SmoothDFInterpolatorData(df, 0.0, 0.0, 0.0, act_365f);
		SmoothCurve::set(m_currSmoothDate, m_currSmoothData);

		// update prev smooth segment with correct flat rate
		if (fabs(m_prevSmoothData.getB()) < 1e-14 && (m_prevSmoothDate != m_currSmoothDate))
		{   // only do it if it is flat segment. should be continuous rate
			double smoothSegmentFlatRate = log(m_prevSmoothData.getDF() / m_currSmoothData.getDF()) / dayCountFrac(act_365f, m_prevSmoothDate, m_currSmoothDate);
			m_prevSmoothData.setFlat(smoothSegmentFlatRate);
			SmoothCurve::set(m_prevSmoothDate, m_prevSmoothData);
		}
	}

	// convert simply compounded rate over period DCF to equivalent simply compounded rate over smaller compounding period dcf
	double convertSimpleRate(double f, double DCF, double dcf)
	{
		return (pow(1.0 + f*DCF, -DCF / dcf) - 1.0) / dcf;
	}

	void SmoothForwardsCurve::calculateCurve()
	{
		discountCurve cashCurve;

		// bootstrap cash part of the curve
		// initialise curve, DF==1
		cashCurve.set(m_today, 1.0);
		swapData::set(m_today, 1.0);
		m_lastFittedDate = m_today;

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot] * dcf);

		// add first point to smoothCurve

		m_prevSmoothDate = m_today;
		m_prevSmoothData = SmoothDFInterpolatorData(1.0, 0.0, 0.0, 0.0, act_365f);
		if (m_spot > m_today)
		{
			double smoothSegmentFlatRate = log(m_prevSmoothData.getDF() / spotDF) / dayCountFrac(act_365f, m_prevSmoothDate, m_spot);
			m_prevSmoothData.setFlat(smoothSegmentFlatRate);
		}
		else
		{
			m_prevSmoothData.setFlat(m_cashParams[m_spot]);
		}
		SmoothCurve::set(m_prevSmoothDate, m_prevSmoothData);

		// bootstrap spot date point
		cashCurve.set(m_spot, spotDF);
		swapData::set(m_spot, spotDF);
		m_lastFittedDate = m_spot;
		// add the same point to smoothCurve
		m_currSmoothDate = m_today;
		m_currSmoothData = m_prevSmoothData;
		addSmoothSegment(m_spot, spotDF);

		date cashDateAfterIMM1(0); // date of the first cash rate after the first futures date
		date cashDateAfterIMM2(0); // non-zero if cash covers second IMM (in case of 6m cash point used for Risk curve)
		map<date, double>::const_iterator it = m_cashParams.begin();
		++it;
		for (; it != m_cashParams.end(); ++it)
		{
			dcf = dayCountFrac(m_basis, m_spot, it->first);
			double df = spotDF / (1 + it->second*dcf);
			cashCurve.set(it->first, df);
			swapData::set(it->first, df);
			m_lastFittedDate = it->first;
			if ((long)cashDateAfterIMM1 == 0l)
			if (m_futuresStarts.size())
			{
				if (it->first >= m_futuresStarts[0])
					cashDateAfterIMM1 = it->first;
			}
			else
				cashDateAfterIMM1 = it->first;
			if ((long)cashDateAfterIMM2 == 0l && (long)cashDateAfterIMM1 > 0l)
			if (m_futuresStarts.size())
			{
				if (it->first >= addBusinessMonths(m_futuresStarts[0], 3, m_hols))
					cashDateAfterIMM2 = it->first;
			}
			else
				cashDateAfterIMM2 = it->first;
			// add the same point to smoothCurve
			addSmoothSegment(m_lastFittedDate, df);
		}

		// to cover the case when on IMM date 3M cash falls short of start of next future.
		//        if ((long)cashDateAfterIMM1 == 0l && m_futuresStarts.size())
		//            cashDateAfterIMM1 = m_lastFittedDate;

		// set the stub discount factor by taking the DF at first cash maturity after IMM1 date and 
		//   interpolating back to IMM1 using the flat rate assumption and the first futures rate
		// OR if cash ends before futures, extrapolate last cash rate till first future
		double immDF = 0.0;
		if (m_futures.size())
		{
			swapData::clear();
			SmoothCurve::clear();
			swapData::set(m_today, 1.0);
			swapData::set(m_spot, spotDF);
			// add the first point to SmoothCurve
			m_prevSmoothDate = m_today;
			m_prevSmoothData = SmoothDFInterpolatorData(1.0, 0.0, 0.0, 0.0, act_365f);
			double smoothSegmentFlatRate = log(m_prevSmoothData.getDF() / spotDF) / dayCountFrac(act_365f, m_prevSmoothDate, m_spot);
			m_prevSmoothData.setFlat(smoothSegmentFlatRate);
			SmoothCurve::set(m_prevSmoothDate, m_prevSmoothData);
			// add the same point to smoothCurve
			m_currSmoothDate = m_today;
			m_currSmoothData = m_prevSmoothData;
			addSmoothSegment(m_spot, spotDF);

			// working out stub DF
			if ((long)cashDateAfterIMM2 > 0l && (long)cashDateAfterIMM1 > 0l)
			{   // last cash date after second IMM
				double cashDF = cashCurve.get(cashDateAfterIMM2);
				double ffRate = (100.0 - m_futures[0]) / 100.0 - m_futuresAdj[0] / 10000.0; // first futs rate
				double sfRate = (100.0 - m_futures[1]) / 100.0 - m_futuresAdj[1] / 10000.0; // second futs rate
				discountCurve futCurve;
				futCurve.set(m_futuresStarts[0], 1.0);
				futCurve.set(m_futuresEnds[0], 1.0 / (1 + ffRate*m_futuresDCF[0]));
				futCurve.set(m_futuresEnds[1], 1.0 / (1 + ffRate*m_futuresDCF[0]) / (1 + sfRate*m_futuresDCF[1]));
				immDF = cashDF / futCurve.get(cashDateAfterIMM2);
			}
			else
			if ((long)cashDateAfterIMM1 > 0l)
			{   // last cash date after first IMM
				double cashDF = cashCurve.get(cashDateAfterIMM1);
				double ffRate = (100.0 - m_futures[0]) / 100.0 - m_futuresAdj[0] / 10000.0;
				discountCurve futCurve;
				futCurve.set(m_futuresStarts[0], 1.0);
				futCurve.set(m_futuresEnds[0], 1.0 / (1 + ffRate*m_futuresDCF[0]));
				immDF = cashDF / futCurve.get(cashDateAfterIMM1);
			}
			else
			{   // last cash date before first future
				double cashDF = cashCurve.get(m_lastFittedDate);

				double DF1 = cashCurve.get(m_lastFittedDate - 1);
				double DF2 = cashCurve.get(m_lastFittedDate);
				double dcf = dayCountFrac(act_365f, m_lastFittedDate - 1, m_lastFittedDate);
				double rate = dcf == 0 ? 0 : zero(DF2 / DF1, dcf);
				immDF = cashDF / (1 + rate*dayCountFrac(act_365f, m_lastFittedDate, m_futuresStarts[0]));
			}

			swapData::set(m_futuresStarts[0], immDF);
			// add the same point to smoothCurve
			addSmoothSegment(m_futuresStarts[0], immDF);
		}
		else
		{
			// if no futures, just use the cash curve. do nothing as we extended both curves simultaneously up to now.
		}

		// bootstrap futures
		for (unsigned int i = 0; i < m_futures.size(); i++)
		{
			double ffRate = (100.0 - m_futures[i]) / 100.0 - m_futuresAdj[i] / 10000.0;
			immDF /= (1.0 + ffRate * m_futuresDCF[i]); // the first immDF was set above!
			swapData::set(m_futuresEnds[i], immDF);
			m_lastFittedDate = m_futuresEnds[i];
			// add the same point to smoothCurve
			addSmoothSegment(m_lastFittedDate, immDF);
			// if there is gap till next future start, extrapolate till next IMM
			if (i<(m_futures.size() - 1) && m_futuresStarts[i + 1] > m_futuresEnds[i])
			{
				double dcf = dayCountFrac(act_365f, m_futuresStarts[i], m_futuresEnds[i]);
				double r = log(1.0 + ffRate*dcf) / dcf;// continuously compounded rate
				dcf = dayCountFrac(act_365f, m_futuresEnds[i], m_futuresStarts[i + 1]);
				immDF /= exp(r * dcf);
				swapData::set(m_futuresStarts[i + 1], immDF);
				m_lastFittedDate = m_futuresStarts[i + 1];
				addSmoothSegment(m_lastFittedDate, immDF);
			}
			// if there is overlap, re-calculate immDF for the next future bootstrap
			else if (i < (m_futures.size() - 1) && m_futuresStarts[i + 1] < m_futuresEnds[i])
			{
				double dcf = dayCountFrac(act_365f, m_futuresStarts[i], m_futuresEnds[i]);
				double r = log(1.0 + ffRate*dcf) / dcf;// continuously compounded rate
				dcf = dayCountFrac(act_365f, m_futuresStarts[i + 1], m_futuresEnds[i]);
				immDF *= exp(r * dcf);
			}
		}
		// bootstrap swaps
		for (unsigned int i = 0; i < m_parRates.size(); i++)
		{
			if (m_futures.size() == 0 || (m_swapLastDates[i] > m_futuresEnds[m_futures.size() - 1]))
			{
				m_swapCashflows[i].setCoupon(m_parRates[i]);
				if (!fitParSwap(i)) // fit swap number i
					break;
				else
					m_lastFittedDate = m_swapLastDates[i];
			}
		}
		if (m_parRates.size())
		{
			// update smooth discount factor of last segment
			m_currSmoothData.setDF(m_prevSmoothData.InterpolatedDF(m_prevSmoothDate, m_currSmoothDate));
			// final segment is flat to infinity
			m_currSmoothData.setFlat(m_prevSmoothData.getY(dayCountFrac(act_365f, m_prevSmoothDate, m_currSmoothDate)));
			SmoothCurve::set(m_currSmoothDate, m_currSmoothData);
			// extend for 1 extra week. to cover 1 day delay of payment on OIS
			m_currSmoothData.setDF(m_currSmoothData.InterpolatedDF(m_currSmoothDate, m_currSmoothDate + 7));
			m_currSmoothData.setFlat(m_currSmoothData.getY(dayCountFrac(act_365f, m_currSmoothDate, m_currSmoothDate + 7)));
			SmoothCurve::set(m_currSmoothDate + 7, m_currSmoothData);
		}
	}


	namespace SmoothForwardsCurveFitFn
	{
		int index;
		Handle<SmoothForwardsCurve> fitcurve;
	}

	bool SmoothForwardsCurve::fitParSwap(int index) // index is the swap index we are working on fitting now
	{
		SmoothForwardsCurveFitFn::index = index;
		SmoothForwardsCurveFitFn::fitcurve = Handle<SmoothForwardsCurve>(this, null_deleter());

		// extend the flat forwards curve using this swap
		double x1 = -0.0005;
		double x2 = 0.003;
		m_appearAsFlat = true;
		double flatSegmentRate = linearFitter(SmoothForwardsCurveFitFn::func_linear, x1, x2, max(1e-7 /*1/1000th of bp*/, m_swapTolerances[index])); // returns continuously compounded flat rate for the segment

		// extend the smooth forwards curve using this swap
		m_appearAsFlat = false;
		m_nextSmoothDate = m_swapLastDates[index];
		double lastDF = swapData::get(m_nextSmoothDate);
		// now make the dummy new current segment in the curve, but not move curr/prev just yet
		SmoothCurve::set(m_nextSmoothDate, SmoothDFInterpolatorData(lastDF, 0.0, 0.0, 0.0, act_365f));
		// re-fit the previous smooth forwards segment
		double xguess = 0.0;
		double funcmin = 0.0;
		int maxiterations = 5;
		if (index) // not the first swap after futures
		{
			double dcf = dayCountFrac(act_365f, m_prevSmoothDate, m_currSmoothDate);
			x1 = -5.0 / dcf;// minus 500%
			x2 = 5.0 / dcf;// plus  500%
			xguess = m_prevSmoothData.getA(); // guessing the previously fit quadratic coefficient
			//			NUMREC::brent(x1, xguess, x2, SmoothForwardsCurveFitFn::func_smoothPrev, max(1e-7 /*1/1000th of bp*/, m_swapTolerances[index]), &funcmin);
			funcmin = quadraticFitter(SmoothForwardsCurveFitFn::func_smoothPrev, x1, x2, max(1e-7 /*1/1000th of bp*/, m_swapTolerances[index]), maxiterations);
		}
		else
		{
		}
		// fit the current smooth forwards segment using this swap. guessing the quadratic coefficient a in f(t)=a*t*t+b*t+c
		double dcf = dayCountFrac(act_365f, m_currSmoothDate, m_nextSmoothDate);
		x1 = -5.0 / dcf;// minus 500%
		x2 = 5.0 / dcf;// plus  500%
		xguess = 0.0; // guessing the linear segment
		//		NUMREC::brent(x1, xguess, x2, SmoothForwardsCurveFitFn::func_smoothCurr, max(1e-7 /*1/1000th of bp*/, m_swapTolerances[index]), &funcmin);
		funcmin = quadraticFitter(SmoothForwardsCurveFitFn::func_smoothCurr, x1, x2, max(1e-7 /*1/1000th of bp*/, m_swapTolerances[index]), maxiterations);
		// now move prev to what used to be curr
		addSmoothSegment(m_swapLastDates[index], lastDF);

		return true;
	}


	namespace SmoothForwardsCurveFitFn
	{
		double func_linear(double flatSegmentRate)
		{
			// update the curve
			double dcf = dayCountFrac(act_365f, fitcurve->m_lastFittedDate, fitcurve->m_swapLastDates[index]);
			double dfLast = fitcurve->swapData::get(fitcurve->m_lastFittedDate);
			double dfFwd = exp(-flatSegmentRate*dcf); // assume the flatSegmentRate is continuously compounded rate
			fitcurve->swapData::set(fitcurve->m_swapLastDates[index], dfLast * dfFwd);
			// re-price the swap
			if (fitcurve->m_swapsDiscountCurve) // Discount using suppplied discount curve rather than the curve being built
			{
				fitcurve->m_swapCashflows[index].setCurves(fitcurve->m_swapsDiscountCurve, fitcurve);
			}
			else
			{
				fitcurve->m_swapCashflows[index].setCurves(fitcurve, fitcurve);
			}
			// careful. we use swaps with first coupon unfixed when we build the curve. then we hedge swaps with first fixing and see risk in the front end. this is to match apollo
			if (fitcurve->m_firstFixRate != 0.0)
				fitcurve->m_swapCashflows[index].fixFirst(fitcurve->m_firstFixRate);
			double swapRate = (fitcurve->m_swapCashflows[index]).Solve(0, solveFORCOUPON);
			double targetRate = fitcurve->m_parRates[index];

			return  (swapRate - targetRate);
		}

		double func_smoothPrev(double a)
		{//re-fit the previous parabolic segment replacing the condition at the end from zero derivative to mid-rate between flat segments
			SmoothForwardsCurve& debugCurve = *fitcurve;
			double prevStartRate = fitcurve->m_prevSmoothData.getFirst();
			double prevDCF = dayCountFrac(act_365f, fitcurve->m_prevSmoothDate, fitcurve->m_currSmoothDate);
			double currDCF = dayCountFrac(act_365f, fitcurve->m_currSmoothDate, fitcurve->m_nextSmoothDate);
			double prevFlatRate = log(fitcurve->swapData::get(fitcurve->m_prevSmoothDate) / fitcurve->swapData::get(fitcurve->m_currSmoothDate)) / prevDCF;
			double currFlatRate = log(fitcurve->swapData::get(fitcurve->m_currSmoothDate) / fitcurve->swapData::get(fitcurve->m_nextSmoothDate)) / currDCF;
			// TODO should be duration-weighted using discount curve?
			double b = ((prevFlatRate*currDCF + currFlatRate*prevDCF) / (prevDCF + currDCF) - prevStartRate) / prevDCF - a*prevDCF;
			fitcurve->m_prevSmoothData.setA(a);
			fitcurve->m_prevSmoothData.setB(b);
			// keeping C unchanged

			// update the curve, prev segment parabola
			fitcurve->SmoothCurve::set(fitcurve->m_prevSmoothDate, fitcurve->m_prevSmoothData);
			// update the curve, current segment smooth discount factor
			fitcurve->m_currSmoothData.setDF(fitcurve->m_prevSmoothData.InterpolatedDF(fitcurve->m_prevSmoothDate, fitcurve->m_currSmoothDate));
			fitcurve->SmoothCurve::set(fitcurve->m_currSmoothDate, fitcurve->m_currSmoothData);

			// re-price the swap
			if (fitcurve->m_swapsDiscountCurve) // Discount using suppplied discount curve rather than the curve being built
			{
				fitcurve->m_swapCashflows[index - 1].setCurves(fitcurve->m_swapsDiscountCurve, fitcurve);
			}
			else
			{
				fitcurve->m_swapCashflows[index - 1].setCurves(fitcurve, fitcurve);
			}
			if (fitcurve->m_firstFixRate != 0.0)
				fitcurve->m_swapCashflows[index - 1].fixFirst(fitcurve->m_firstFixRate);
			double swapRate = (fitcurve->m_swapCashflows[index - 1]).Solve(0, solveFORCOUPON);
			double targetRate = fitcurve->m_parRates[index - 1];

			return  (swapRate - targetRate);
		}

		double func_smoothCurr(double a)
		{
			SmoothForwardsCurve& debugCurve = *fitcurve;
			int debigIndex = index;

			// fit the current segment as if it is the new parabolic segment
			// guessing the first parabolic coefficient a
			double prevEndRate = fitcurve->m_prevSmoothData.getY(dayCountFrac(act_365f, fitcurve->m_prevSmoothDate, fitcurve->m_currSmoothDate));
			double c = prevEndRate;
			double currDCF = dayCountFrac(act_365f, fitcurve->m_currSmoothDate, fitcurve->m_nextSmoothDate);
			if (!index) // first swap after futures
			{
				double prevDCF = dayCountFrac(act_365f, fitcurve->m_prevSmoothDate, fitcurve->m_currSmoothDate);
				double currFlatRate = log(fitcurve->swapData::get(fitcurve->m_currSmoothDate) / fitcurve->swapData::get(fitcurve->m_nextSmoothDate)) / currDCF;
				double prevFlatRate = prevDCF == 0 ? currFlatRate : log(fitcurve->swapData::get(fitcurve->m_prevSmoothDate) / fitcurve->swapData::get(fitcurve->m_currSmoothDate)) / prevDCF;
				c = (currFlatRate * prevDCF + prevFlatRate * currDCF) / (currDCF + prevDCF);
			}
			double b = -2.0*a*currDCF; // D(Y)=0 @ x=currDCF
			// update parabola
			fitcurve->m_currSmoothData.setFlat(c);
			fitcurve->m_currSmoothData.setA(a);
			fitcurve->m_currSmoothData.setB(b);

			// update the curve
			fitcurve->SmoothCurve::set(fitcurve->m_currSmoothDate, fitcurve->m_currSmoothData);

			// Update next DF if we are fitting the last swap.
			if (index == fitcurve->m_parRates.size() - 1)
			{
				// update smooth discount factor of last segment
				double lastDF = fitcurve->m_currSmoothData.InterpolatedDF(fitcurve->m_currSmoothDate, fitcurve->m_nextSmoothDate);
				fitcurve->SmoothCurve::set(fitcurve->m_nextSmoothDate, SmoothDFInterpolatorData(lastDF, 0.0, 0.0, 0.0, act_365f));
			}

			// re-price the swap
			if (fitcurve->m_swapsDiscountCurve) // Discount using suppplied discount curve rather than the curve being built
			{
				fitcurve->m_swapCashflows[index].setCurves(fitcurve->m_swapsDiscountCurve, fitcurve);
			}
			else
			{
				fitcurve->m_swapCashflows[index].setCurves(fitcurve, fitcurve);
			}
			// careful! we use swaps with first coupon unfixed when we build the curve. then we hedge swaps with first fixing and see risk in the front end. this is to match apollo
			if (fitcurve->m_firstFixRate != 0.0)
				fitcurve->m_swapCashflows[index].fixFirst(fitcurve->m_firstFixRate);
			double swapRate = (fitcurve->m_swapCashflows[index]).Solve(0, solveFORCOUPON);
			double targetRate = fitcurve->m_parRates[index];

			return  (swapRate - targetRate);
		}
	}




	void SmoothForwardsCurve::set_currency_defaults(CURRENCY ccy)
	{
		m_ccy = ccy;

		switch (m_ccy)
		{
		case USD:
			set_currency_defaults(ccy, SB3);
			break;
		case EUR:
			set_currency_defaults(ccy, AB6);
			break;
		case JPY:
			set_currency_defaults(ccy, SB6);
			break;
		case GBP:
			set_currency_defaults(ccy, SB6);
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}

	}

	void SmoothForwardsCurve::set_currency_defaults(CURRENCY ccy, SwapType type)
	{

		vanillaSwapParams(ccy, type, m_fixedPmtsPerYear, m_fltPmtsPerYear, m_fixedBasis, m_basis);

		m_swapType = type;
		m_ccy = ccy;
		this->setCurrency(m_ccy);

		switch (ccy)
		{
		case USD:
			m_swapHols = HOLIDAYCAL(UK | USA);
			m_hols = UK;
			break;
		case EUR:
			m_swapHols = EUTARG;
			m_hols = EUTARG;
			break;
		case JPY:
			m_swapHols = JP;
			m_hols = UK;
			break;
		case GBP:
			m_swapHols = UK;
			m_hols = UK;
			break;
		default:
			mcpl_error("Currency not yet supported in SmoothCurve");
		}
	}


	bool SmoothForwardsCurve::cmpvecs(const vector<double> & v1, const vector<double> & v2)
	{
		int len;
		if ((len = v1.size()) != v2.size()) return false;
		else
		{
			bool test = true;
			for (int i = 0; (i < len) && test; ++i)
			if (v1[i] != v2[i])
			{
				test = false;
				break;
			}
			return test;
		}
		return false; // should not get here.
	}
	//
	bool SmoothForwardsCurve::cmpvecs(const vector<date> & v1, const vector<date> & v2)
	{
		int len;
		if ((len = v1.size()) != v2.size()) return false;
		else
		{
			bool test = true;
			for (int i = 0; (i < len) && test; ++i)
			if (v1[i] != v2[i])
			{
				test = false;
				break;
			}
			return test;
		}
		return false; // should not get here.
	}
	//
	bool SmoothForwardsCurve::cmpmaps(const map<date, double> & v1, map<date, double> & v2)
	{
		if (v1.size() != v2.size()) return false;
		else
		{
			bool test = true;
			map<date, double>::const_iterator it1 = v1.begin();
			map<date, double>::const_iterator it2 = v2.begin();
			while (test && (it1 != v1.end()) && (it2 != v2.end()))
			{
				if (it1->first != it2->first)
					test = false;

				++it1;
				++it2;
			}
			return test;
		}
		return false; // should not get here.
	}



	// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
	Handle<PPCurves> SmoothForwardsCurve::create_PPCurves(double pp_val, bool CalculateGammaCurves)
	{
		Handle<PPCurves> pp_curves = Handle<PPCurves>(new PPCurves());
		pp_curves->setUsingGamma(CalculateGammaCurves);

		int nHedges = m_futures.size() + m_cashParams.size() + m_parRates.size();

		pp_curves->resize(nHedges);
		pp_curves->set_ppsize(pp_val / 100.0); // set the perturb size in factor (i.e. 1 = 1%)

		pp_curves->base() = this->clone();

		unsigned int i = 0;
		// up
		for (auto it = m_cashParams.begin(); it != m_cashParams.end(); ++it)
		{
			it->second += pp_val / 100.0;
			partialClear();
			calculateCurve();
			pp_curves->label(i) = "cash " + (string)it->first;
			pp_curves->up(i++) = this->clone();
			for (auto it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			{
				/*((*it2))->calculateCurve();
				pp_curves->up_dependents(i - 1)[(*it2)] = Handle<RatesCurve>(new SmoothForwardsCurve(*dynamic_pointer_cast<SmoothForwardsCurve>(*it2)));*/
				auto depCrv = (*it2)->clone();
				depCrv->calculateCurve();
				pp_curves->dn_dependents(i)[*it2] = depCrv;
			}
			it->second -= pp_val / 100.0;
		}
		for (unsigned int j = 0; j < m_futures.size(); ++j)
		{
			m_futures[j] -= pp_val;
			partialClear();
			calculateCurve();
			pp_curves->label(i) = "Fut " + (string)m_futuresStarts[j];
			pp_curves->up(i++) = this->clone();
			for (auto it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			{
				auto depCrv = (*it2)->clone();
				depCrv->calculateCurve();
				pp_curves->dn_dependents(i)[*it2] = depCrv;
			}
			m_futures[j] += pp_val;
		}
		for (unsigned int j = 0; j < m_parRates.size(); ++j)
		{
			m_parRates[j] += pp_val / 100.00;
			partialClear();
			calculateCurve();
			pp_curves->label(i) = "Swap " + (string)m_swapMaturityDates[j];
			pp_curves->up(i++) = this->clone();
			for (auto it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			{
				auto depCrv = (*it2)->clone();
				depCrv->calculateCurve();
				pp_curves->dn_dependents(i)[*it2] = depCrv;
			}
			m_parRates[j] -= pp_val / 100.00;
		}


		// dn
		i = 0;
		for (map<date, double>::iterator it = m_cashParams.begin(); it != m_cashParams.end(); ++it)
		{
			it->second -= pp_val / 100.0;
			partialClear();
			calculateCurve();
			pp_curves->dn(i++) = this->clone();
			for (auto it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			{
				auto depCrv = (*it2)->clone();
				depCrv->calculateCurve();
				pp_curves->dn_dependents(i)[*it2] = depCrv;
			}
			it->second += pp_val / 100.0;
		}
		for (unsigned int j = 0; j < m_futures.size(); ++j)
		{
			m_futures[j] += pp_val;
			partialClear();
			calculateCurve();
			pp_curves->dn(i++) = this->clone();
			for (auto it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			{
				auto depCrv = (*it2)->clone();
				depCrv->calculateCurve();
				pp_curves->dn_dependents(i)[*it2] = depCrv;
			}
			m_futures[j] -= pp_val;
		}
		for (unsigned int j = 0; j < m_parRates.size(); ++j)
		{
			m_parRates[j] -= pp_val / 100.00;
			partialClear();
			calculateCurve();
			pp_curves->dn(i++) = this->clone();
			for (auto it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			{
				auto depCrv = (*it2)->clone();
				depCrv->calculateCurve();
				pp_curves->dn_dependents(i)[*it2] = depCrv;
			}
			m_parRates[j] += pp_val / 100.00;
		}

		if (CalculateGammaCurves)
		{
			//upup
			for (unsigned int j = 0; j < m_futures.size(); ++j)
				m_futures[j] -= pp_val;
			for (auto it = m_cashParams.begin(); it != m_cashParams.end(); ++it)
				it->second += pp_val / 100.0;
			for (unsigned int j = 0; j < m_parRates.size(); ++j)
				m_parRates[j] += pp_val / 100.00;

			i = 0;
			for (auto it = m_cashParams.begin(); it != m_cashParams.end(); ++it)
			{
				it->second += pp_val / 100.0;
				partialClear();
				calculateCurve();
				pp_curves->upup(i++) = this->clone();
				it->second -= pp_val / 100.0;
			}
			for (unsigned int j = 0; j < m_futures.size(); ++j)
			{
				m_futures[j] -= pp_val;
				partialClear();
				calculateCurve();
				pp_curves->upup(i++) = this->clone();
				m_futures[j] += pp_val;
			}
			for (unsigned int j = 0; j < m_parRates.size(); ++j)
			{
				m_parRates[j] += pp_val / 100.00;
				partialClear();
				calculateCurve();
				pp_curves->upup(i++) = this->clone();
				m_parRates[j] -= pp_val / 100.00;
			}

			// updn
			i = 0;
			for (auto it = m_cashParams.begin(); it != m_cashParams.end(); ++it)
			{
				it->second -= pp_val / 100.0;
				partialClear();
				calculateCurve();
				pp_curves->updn(i++) = this->clone();
				it->second += pp_val / 100.0;
			}
			for (unsigned int j = 0; j < m_futures.size(); ++j)
			{
				m_futures[j] += pp_val;
				partialClear();
				calculateCurve();
				pp_curves->updn(i++) = this->clone();
				m_futures[j] -= pp_val;
			}
			for (unsigned int j = 0; j < m_parRates.size(); ++j)
			{
				m_parRates[j] -= pp_val / 100.00;
				partialClear();
				calculateCurve();
				pp_curves->updn(i++) = this->clone();
				m_parRates[j] += pp_val / 100.00;
			}


			//dnup
			for (unsigned int j = 0; j < m_futures.size(); ++j)
				m_futures[j] += 2.0*pp_val;
			for (auto it = m_cashParams.begin(); it != m_cashParams.end(); ++it)
				it->second -= 2.0*pp_val / 100.0;
			for (unsigned int j = 0; j < m_parRates.size(); ++j)
				m_parRates[j] -= 2.0*pp_val / 100.00;

			i = 0;
			for (auto it = m_cashParams.begin(); it != m_cashParams.end(); ++it)
			{
				it->second += pp_val / 100.0;
				partialClear();
				calculateCurve();
				pp_curves->dnup(i++) = this->clone();
				it->second -= pp_val / 100.0;
			}
			for (unsigned int j = 0; j < m_futures.size(); ++j)
			{
				m_futures[j] -= pp_val;
				partialClear();
				calculateCurve();
				pp_curves->dnup(i++) = this->clone();
				m_futures[j] += pp_val;
			}
			for (unsigned int j = 0; j < m_parRates.size(); ++j)
			{
				m_parRates[j] += pp_val / 100.00;
				partialClear();
				calculateCurve();
				pp_curves->dnup(i++) = this->clone();
				m_parRates[j] -= pp_val / 100.00;
			}

			// dndn
			i = 0;
			for (auto it = m_cashParams.begin(); it != m_cashParams.end(); ++it)
			{
				it->second -= pp_val / 100.0;
				partialClear();
				calculateCurve();
				pp_curves->dndn(i++) = this->clone();
				it->second += pp_val / 100.0;
			}
			for (unsigned int j = 0; j < m_futures.size(); ++j)
			{
				m_futures[j] += pp_val;
				partialClear();
				calculateCurve();
				pp_curves->dndn(i++) = this->clone();
				m_futures[j] -= pp_val;
			}
			for (unsigned int j = 0; j < m_parRates.size(); ++j)
			{
				m_parRates[j] -= pp_val / 100.00;
				partialClear();
				calculateCurve();
				pp_curves->dndn(i++) = this->clone();
				m_parRates[j] += pp_val / 100.00;
			}


			for (unsigned int j = 0; j < m_futures.size(); ++j)
				m_futures[j] -= pp_val;
			for (auto it = m_cashParams.begin(); it != m_cashParams.end(); ++it)
				it->second += pp_val / 100.0;
			for (unsigned int j = 0; j < m_parRates.size(); ++j)
				m_parRates[j] += pp_val / 100.0;
		}

		partialClear();
		calculateCurve();

		//recalculateDependents
		for (auto it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
		{
			((*it2))->calculateCurve();
		}

		return pp_curves;
	}





} // namespace MCPL