#pragma once
#pragma warning ( disable : 4251 4786 ) 

#ifndef MCPLDEAL_H
#define MCPLDEAL_H
#include "MCPL.h"

#include "mcpldefs.h"

#include<string>
#include<vector>

#include "swapData.h"

#include "leg.h"

using namespace std;

namespace MCPL
{


	class Deal
	{
	
	public:
	
		typedef enum { dealtype_swap, dealtype_leg} dealtype;

		virtual dealtype getDealType() = 0;

		// Clone function which creates a deep clone of cashflows
		virtual shared_ptr<Deal> CloneDealCashflows() = 0;


		virtual void setCoupon(double)=0; //Sets the coupon in all the fixed legs
		virtual void setCoupon(const vector<double>& Coupons)=0; //Sets the coupon in all the fixed legs
		virtual void setSpread(double)=0; //Sets the spread in all the float legs
		virtual void setSpread(const vector<double>& Spreads)=0; //Sets the spread in all the float legs

		virtual void setNotional(const vector<double>& notionals)=0;
		virtual void setNotional(double motional)=0;

		virtual Handle<Leg> getLeg(PAYTYPE)=0;
		virtual shared_ptr<Leg> getFirstFixedLeg() = 0;
		virtual Handle<Leg> getLeg(unsigned int i) = 0;

		virtual double Price()=0;
		virtual double Price(double coupon)=0;
		virtual double PriceLeg(PAYTYPE type, date & payDate)=0;

		virtual double Price(date &)=0; // Price to date
		virtual double Price(date & firstDate, date& lastDate)=0; // Price only pp which fall entorely between dates
		virtual double Price(date &, double rate)=0;
		virtual double Price(date & firstDate, date& lastDate, double rate)=0;
		virtual double BPV()=0;
		virtual double numericalBPV()=0;
		virtual double notionalBPV()=0;

		virtual void setCurves(Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr))=0;
		virtual void setCurves(Handle<RatesCurve> discCurve, Handle<RatesCurve> leg1fcastCurve, Handle<RatesCurve> leg2fcastCurve, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr))=0;
		virtual void updatePaymentsFromCurves()=0;

		// Fopr a swap, this is the same as set curves. It makes it possible to treat a swap the same as a leg in certain templated hedging functions
		virtual void updatePaymentsFromCurves(Handle<RatesCurve> discountCurve, Handle<RatesCurve> forecastCurve, shared_ptr<VolatilityGrid> pCMSvols = shared_ptr<VolatilityGrid>(nullptr)) = 0;

		virtual Handle<RatesCurve> getDiscountPtr()=0;
		virtual Handle<RatesCurve> getForecastPtr()=0;
	};




} //namespace MCPL
#endif //MCPLDEAL_H

// End.
