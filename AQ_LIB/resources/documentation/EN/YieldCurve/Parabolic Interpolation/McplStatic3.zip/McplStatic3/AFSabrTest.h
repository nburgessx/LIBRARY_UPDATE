#pragma once
#include "mcpldefs.h"
#include "handle.hpp"
#include <vector>
#include <xtr1common>
#include "McDataClasses/McDataClasses.h"
#include "option.h"
#include "SABR.H"

namespace MCPL
{
	class AFSabrTest
	{
	const static long zAFSABRDefNGridPts  = 500;              // if number of grid points is less than 10 or greater than 2500
	const static long zAFSABRMinNGridPts  = 10;               // then t defaults to 500 grid points for the AF SABR routines
	const static long zAFSABRMaxNGridPts  = 2500;
							 
	const static long zAFSABRDefNTSteps  = 100;
	const static long zAFSABRMinNTSteps  = 3;                 // if number of timesteps is less than 3 or greater than 1000
	const static long zAFSABRMaxNTSteps  = 1000;              // it default to 100 timesteps in the AF SABR routines
							 
	const static long zAFSABRDefNumStdDevs  = 3 ;             // FMax defaults to 3 std deviations above the money for AF SABR
	const static long zAFSABRMaxNumStrikes  = 1000;           // maximum number of strikes allowed in AF SABR routines

	static double qvMAXIMUMBETAVALUE;
	static double qvMINIMUMBETAVALUE;

	//typedef enum
	//{
 //   qvVanOptTypeCall = 0,      // European call (payer, caplet)
 //   qvVanOptTypePut      ,     // European put (reciever, floorlet)
 //   qvVanOptTypeStraddle ,     // European straddle
 //   qvVanOptTypeLast    ,      // Last vanilla option type
	//} qvEnumVanOptType;

	public:

		static void qvzzNATriDiag(vector<double>& U,long j0, long jN, vector<double>& A, vector<double>& B, vector<double>& C, vector<double>& R);

		static void AFSABRSolve(vector<double>& Q, double& QLeft, double& QRight, double FMin, double h, long m, double T0, double dt, long n, bool AbLowBC, bool AbHighBC,
                             double fwd, double alpha, double beta, double rho, double VolVol);

		static void AFSABRGrid(double& h, long& nGrid, double& FMin, double& FMax, double& dt, long& nSteps, double fwd, double yExp);

		static void qvzzOptAFSABRSolve(double& FMin, double& FMax, long& nGrid, vector<double>& Q, 
                            double fwd, double yExp, double alpha, double beta, double rho, double VolVol,
                            bool AbLowBC, bool AbHighBC, long nSteps);

		static void qvzzOptAFSABRTimeValues(long& nStrikes, vector<double>& strikes, vector<double>& Values, double fwd, double yExp,
                                 double alpha, double beta, double rho, double VolVol, bool AbLowBC, bool AbHighBC,
                                 double FMin, double FMax, long nGrid, long nSteps);

		static double OptValueFromDensity(double strike, OptionType opt, vector<double>& Q, double FMin, double h, long m);

		static shared_ptr<Matrix<double>> qvOptAFSABRValues(double fwd, double yExp, vector<double>& strikes, OptionType OptType,
																			double alpha, double beta, double rho, double VolVol, double FMinAct=0.0, double FMaxAct=.1,
																			long nGridPts=500, long nTSteps=100);

		static double  AFSABR_price(double K, double fwd, double yExp, SABRParams & par, double bpv, OptionType type, double FMinAct=0.0, double FMaxAct=.1,
																			long nGridPts=500, long nTSteps=100);

		static shared_ptr<Matrix<double>> qvOptAFSABRValues(double fwd, double yExp, vector<double>& strikes, vector<OptionType>& OptType,
																			double alpha, double beta, double rho, double VolVol, double FMinAct=0.0, double FMaxAct=.1,
																			long nGridPts=500, long nTSteps=100);

		static shared_ptr<vector<double>>  AFSabrTest::AFSABR_price(vector<double>& strikes, double fwd, double yExp, SABRParams & par, double bpv, vector<OptionType>& optTypes, double FMinAct, double FMaxAct,
			long nGridPts, long nTSteps); 
		//static shared_ptr<vector<double>>  AFSABR_price(vector<double>& strikes, double fwd, double yExp, SABRParams & par, double bpv, vector<OptionType>& type, double FMinAct, double FMaxAct,
		//	long nGridPts, long nTSteps)
	};



}
