#pragma once

#ifndef MCPLBLACKMODEL_H
#define MCPLBLACKMODEL_H

#include "mcpldefs.h"
#include "mathmisc.h"
#include "option.h"

using namespace std;

namespace MCPL
{

	class BlackVol
	{
	public:

		double vol;
		double rateShift;

		BlackVol() :
			vol(0),
			rateShift(0)
			{}

		BlackVol(double vol_, double rateSHift_) :
			vol(vol_),
			rateShift(rateSHift_)
			{}

	};

class mixing_model
{
public:

	mixing_model() :
		m_ATM_mixing( .5 ),
		m_t0_mixing_slope( 0 ),
		m_minMixing( -200 ),
		m_maxMixing( 200 )
	{}

	mixing_model(double ATM_mixing,  double t0_mixing_slope, double minMix, double maxMix) :
		m_ATM_mixing( ATM_mixing ),
		m_t0_mixing_slope( t0_mixing_slope ),
		m_minMixing( minMix ),
		m_maxMixing( maxMix )
	{}
	
	/*		mixing_model(double ATM_mixing,  double t0_mixing_slope) :
		m_ATM_mixing( ATM_mixing ),
		m_t0_mixing_slope( t0_mixing_slope )
	{}*/
/*
	mixing_model(double ATM_mixing = .5, double mixing_slope = 0.0, double alpha=1.0) :
		m_ATM_mixing( ATM_mixing ),
		m_mixing_slope( mixing_slope ),
		m_alpha(alpha)
	{}
*/	
	double get_mixing(double strike, double forward, double timetoexp, BlackVol vol) const;
	double mixing_model::get_slope(double timeToExp, BlackVol vol) const;
	double mixing_model::get_mixing_from_slope(double d_strike, double d_forward, double slope) const ;

	void set_mixing(double ATM_mixing, double t0_mixing_slope, double minMix, double maxMix)
	{
		m_ATM_mixing = ATM_mixing;
		m_t0_mixing_slope = t0_mixing_slope;
		m_minMixing = minMix;
		m_maxMixing = maxMix;
	}

	/*void set_mixing(double ATM_mixing, double t0_mixing_slope)
	{
		m_ATM_mixing = ATM_mixing;
		m_t0_mixing_slope = t0_mixing_slope;
	}*/
private:
	double m_ATM_mixing;
	double m_t0_mixing_slope;
	double m_minMixing;
	double m_maxMixing;
};

// picks which type of black pricer to use according to model.
double blackGeneric(double strike, double forward, double T, BlackVol vol, double df, mixing_model mixing, OptionType, OptionModel);

//Calculates a mixing according to black magic rules.
//double blackMixed(double strike, double forward, double T, double vol, double df, OptionType type);

double blackMixed(double strike, double forward, double T, BlackVol vol, double df, mixing_model mixing, OptionType type);
double blackMixedVega(double strike, double forward, double T, BlackVol vol, double df, mixing_model mix, OptionType type);
double blackMixedDelta(double strike, double forward, double T, BlackVol vol, double df, mixing_model mix, OptionType type);
double blackMixedGamma(double strike, double forward, double T, BlackVol vol, double df, mixing_model mix, OptionType type);
BlackVol blackMixedImpVol(double targetPrice, double strike, double forward, double rateShift, double T, double df, mixing_model mixing, OptionType type);

double blackMixedImpMixing(double targetPrice, double strike, double forward, double T, double df, BlackVol vol,
						OptionType type);


double black(double strike, double ulPrice, double T, BlackVol vol, double df, OptionType type);
double blackProbabilityOfExercise(double strike, double ulPrice, double T, BlackVol vol, OptionType type);
//double blackShifted(double strike, double forward, double T, double vol, double shift, double df, OptionType type);
double blackVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
double blackTheta(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
double blackNormalTheta(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
double blackMixedTheta(double strike, double forward, double T, BlackVol vol, double df, mixing_model mix, OptionType type);
BlackVol blackImpVol(double targetPrice, double strike, double forward, double shift, double T, double df, OptionType type);
double blackDelta(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
double blackGamma(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
double blackVegaVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
double blackDelVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type);

double blackNormal(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
double blackNormalVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
BlackVol blackNormalImpVol(double targetPrice, double strike, double forward, double shift, double T, double df, OptionType type);
double blackNormalDelta(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
double blackNormalGamma(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
double blackNormalVegaVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type);
double blackNormalDelVega(double strike, double forward, double T, BlackVol vol, double df, OptionType type);

BlackVol b2nATMvol(double forward, double t, BlackVol vol);
BlackVol n2bATMvol(double forward, double t, BlackVol target_nvol);

/*

// abstract base class for black models
class BlackModel
{
public:

	void setType( OptionType type ) { m_type = type; }
	void setVolatility( double vol ) { m_volatility = vol; }
	void setStrike( double s ) { m_strike = s; }
	void setTimeToExpiry( double t ) { m_timeToExpiry = t; }
	void setDiscountFactor( double df ) { m_discountFactor = df; }
	void setForward( double f ) { m_forward = f; }

	OptionType getType() { return m_type; } const
	double getVolatility() { return m_volatility; } const
	double getStrike() { return m_strike; } const
	double getTimeToExpiry() { return m_timeToExpiry; } const
	double getDiscountFactor() { return m_discountFactor; } const
	double getForward() { return m_forward; } const

	virtual double price() const = 0; // pure virtual pricer!

private:
	OptionType m_type;
	double m_volatility;
	double m_strike;
	double m_timeToExpiry;
	double m_discountFactor;
	double m_forward;
};


class Black : public BlackModel
{
public:
	double price() 
	{ 
		return black(getStrike(), getForward() , getTimeToExpiry(), getVolatility(), getDiscountFactor(), getType() ); 
	}
};

class BlackNormal : public BlackModel
{
public:
	double price() 
	{ 
		return blackNormal(getStrike(), getForward() , getTimeToExpiry(), getVolatility(), 
						getDiscountFactor(), getType() ); 
	}
};

class BlackMixed : public BlackModel
{
public:
	void setMixing(double m) { m_mixing = m; }
	double getMixing() { return m_mixing; } const

	double price() 
	{ 
		return blackMixed(getStrike(), getForward() , getTimeToExpiry(), getVolatility(), getDiscountFactor(), 
						getMixing() , getType() ); 
	}

private:
	double m_mixing;
};

//typedef marketData Black76ModelData;

/*
*************************************************************************************
* A sample model implementation. 
* Works in conjunction with the template class PricingModel and a model data type.
*************************************************************************************
*/
/*

/*
class Black76 
{
private:
//	Black76ModelData m_modelData;

public:
	
//	void setData(marketData & modelData) { m_modelData = modelData;}

	/*
	************************************************************
	* The Price() method prices an arbitary templated option.
	************************************************************
	*/
/*	template <typename T_Option> 	
		double Price(T_Option& opt, date priceTo)
	{
		T_Option::TYPE type;
		T_Option::LPUNDERLYING pUnderlying;
		T_Option::UNDERLYING::LPDATA pUnderlyingData;
		
		type = opt.getType();
		pUnderlying = opt.getUnderlying();
		pUnderlyingData = pUnderlying->getDataPtr();
		pUnderlying->setCoupon( opt.getVariable("STRIKE") );

		date expiry		= opt.getExerciseDate();
		double K		= opt.getBSStrike(expiry);
		double S		= opt.getBSUnderlying(expiry);
		double	DCC		= m_modelData.getVariable("DAYCOUNTCONVENTION");
		double T		= double(expiry - priceTo) / DCC;
		double sigma	= opt.getVariable("LOGVOL");

		
		double df		= pUnderlyingData->getDiscountFactor(expiry);

		df /= pUnderlyingData->getDiscountFactor(priceTo);

		return black(K,S,T,sigma,type, df);

	}
	
};

typedef PricingModel<Black76>	Black76Pricer;
*/

} // namespace MCPL

#endif // MCPLBLACKMODEL_H