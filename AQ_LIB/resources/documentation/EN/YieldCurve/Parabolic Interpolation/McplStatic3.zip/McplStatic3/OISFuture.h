#pragma once

#ifndef MCPLOISFUTURE_H
#define MCPLOISFUTURE_H
#pragma warning ( disable : 4251 4786 ) 

#include "mcpldefs.h"
#include "mathmisc.h"
#include "option.h"
#include "Swap.h"
#include "OISLeg.h"
#include "mcDateClass/dates.h"

using namespace std;
#include<string>
#include<vector>


namespace MCPL
{

	class Future 
	{	
	private:

		CURRENCY p_ccy;
		MCPL::Month p_month;
		int p_year;

	public :

		double TargetPrice;
		double ConvexityAdjustment;

		typedef enum { FUTURE, FFFUTURE } FutureType;

		//constructors
		Future() 
		{
			ConvexityAdjustment = 0;
		}


		//OIS future no curves
		//For now just works as Fed Funds futures for USD
		Future(MCPL::Month month, int year, CURRENCY ccy )
		{
			ConvexityAdjustment = 0;
			p_ccy = ccy;
			p_month = month;
			p_year = year;
		}

		Future(Future & that)
		{
			ConvexityAdjustment = that.ConvexityAdjustment;
			TargetPrice = that.TargetPrice;
			p_ccy = that.p_ccy;
			p_month = that.p_month;
			p_year = that.p_year;
		}

		// Find the rate of the future.
		virtual double Rate() 
		{ mcpl_error("should not be calling Future::Rate()"); return 0.0; } // Need to override this in an inherited class

		virtual double Price() { return 100 - (Rate() + ConvexityAdjustment)*100; }

		double getTargetRate() { return (100.0 - TargetPrice)/100.0 - ConvexityAdjustment; }

		void setTargetRate(double rate) { TargetPrice = 100-(rate + ConvexityAdjustment)*100; }

		virtual void setCurves (Handle<RatesCurve> discountCurve , Handle<RatesCurve> forecastCurve) 
		{mcpl_error("should not be calling Future::setCurves()"); }

		virtual date getStartDate()
		{ mcpl_error("should not be calling Future::getStartDate()"); return date(0); } // Need to override this in an inherited class

		virtual date getLastDate()
		{ mcpl_error("should not be calling Future::getLastDate()"); return date(0); } // Need to override this in an inherited class

		virtual double getDCF()
		{ mcpl_error("should not be calling Future::getDCF()"); return date(0); } // Need to override this in an inherited class

		CURRENCY getCurrency() { return p_ccy; }

		MCPL::Month getMonth() { return p_month; }

		int getYear() { return p_year; }

		virtual FutureType getType() { return FUTURE; }
	};

	class IMM3mFuture : public Future
	{	
	private:

		Handle<RatesCurve> _forecastCurve;
		date _startDate;
		date _endDate;
		CURRENCY _ccy;
		double _dcf;

	public :


		//constructors
		IMM3mFuture()
			: Future()
		{}


		//OIS future no curves
		//For now just works as Fed Funds futures for USD
		IMM3mFuture(MCPL::Month month, int year, CURRENCY ccy )
		{
			_ccy = ccy;
			_startDate = immDate(date(year, month, 1));
			_endDate = addBusinessMonths(_startDate, 3, liborHolidays(_ccy), true);
			_dcf = dayCountFrac(getLiborBasis(ccy), _startDate, _endDate);
		}

		IMM3mFuture(IMM3mFuture & that)
			: Future((Future)that)
		{
			_forecastCurve = that._forecastCurve;
			_startDate = that._startDate;
			_endDate = that._endDate;
			_ccy = that._ccy;
			_dcf = that._dcf;
		}

		// Find the rate of the future.
		 double Rate()
		{
			return _forecastCurve->getZero(_startDate, _endDate);
		}

		 void setCurves (Handle<RatesCurve> discountCurve , Handle<RatesCurve> forecastCurve)
		{
			_forecastCurve = forecastCurve;
		}

		 date getStartDate()
		{
			return _startDate;
		}

		 date getLastDate()
		{
			return _endDate;
		}

		 double getDCF()
		{
			return _dcf;
		}

	};


	class OISFuture : public Future
	{	
	private:

		OISLeg f_Leg;
		double _dcf;

	public :


		//constructors
		OISFuture()
			: Future()
		{}


		//OIS future no curves
		//For now just works as Fed Funds futures for USD
		OISFuture(MCPL::Month month, int year, CURRENCY ccy );

		OISFuture(OISFuture & that)
			: Future((Future)that)
		{
			f_Leg = that.f_Leg;
			_dcf = that._dcf;
		}

		// Find the rate of the future.
		virtual double Rate();

		virtual void setCurves (Handle<RatesCurve> discountCurve , Handle<RatesCurve> forecastCurve);

		virtual date getStartDate()
		{
			return f_Leg.getStartDate();
		}

		virtual date getLastDate()
		{
			return f_Leg.getLastDate();
		}

		virtual double getDCF()
		{
			return _dcf;
		}

		FutureType getType() { return FFFUTURE; }

	};

}

#endif // MCPLOISFUTURE_H
