#include"MCSDiscountCurve.h"

#include "numrec/dnrutil.h"
#include "amoeba.h"

namespace MCPL
{
	bool MCSDiscountCurve::instrumentsChanged(const vector<Handle<CurveRateHelper>> &Instruments)
	{
		if (Instruments.size() != _instruments.size())
			return true;

		for (unsigned int i = 0; i < _instruments.size(); i++)
		{
			//Just check that we are refering to same object
			if (_instruments[i] != Instruments[i])
				return true;
		}

		return false;
	}

	void MCSDiscountCurve::set_currency_defaults(CURRENCY ccy)
	{
		m_ccy = ccy;

		switch (ccy)
		{
		case USD: case EUR: case CHF: case JPY:
			m_basis = act_360;
			break;
		case GBP:
			m_basis = act_365f;
			break;
		default:
			mcpl_error(std::string("This currency does not have a money basis defined in parabolicCurve."));
		}

	}

	//========================================================================================================================

	double MCSDiscountCurve::forecastFixing(date & reset)
	{
		date spotdate = spot(reset, m_ccy);
		return getZero(spotdate, addBusinessMonths(spotdate, m_period_months, m_hols, false), m_basis);
	}

	//========================================================================================================================

	void MCSDiscountCurve::create(const vector<Handle<CurveRateHelper>> &Instruments,
		date & today,
		CURRENCY ccy,
		double tension_,
		Handle<RatesCurve> discountCurve_)
	{

		vector<Handle<CurveRateHelper>> sortedInsts(Instruments);
		sort(sortedInsts.begin(), sortedInsts.end(), [](Handle<CurveRateHelper>& h1, Handle<CurveRateHelper>& h2) -> bool
		{
			if (h1->getType() == h2->getType() && h1->getType() == CurveRateHelper::CASH)
				return h1->getAdjMaturityDate() < h2->getAdjMaturityDate();
			if (h1->getType() == CurveRateHelper::CASH)
				return true;
			if (h2->getType() == CurveRateHelper::CASH)
				return false;

			return h1->getAdjMaturityDate() < h2->getAdjMaturityDate();
		});

		_tension = tension_;

		if (discountCurve_)
		{
			_isSelfDiscounting = false;
			_discountCurve = discountCurve_;
		}
		else
		{
			_isSelfDiscounting = true;
			_discountCurve = shared_ptr<RatesCurve>(this, null_deleter());
		}

		clear();

		if ((_today != today)
			|| (ccy != m_ccy)
			|| instrumentsChanged(sortedInsts))
		{

			_instruments = sortedInsts;

			set_currency_defaults(ccy);

			_today = today;
			_spot = spot(today, ccy);

			calculateDates();
			calculateCurve();
		}
		else
		{
			_instruments = sortedInsts;
			calculateCurve();
		}
	}

	void MCSDiscountCurve::addDependent(Handle<RatesCurve> dependentCurve)
	{
		_dependentCurves.push_back(dependentCurve);
	}

	void MCSDiscountCurve::calculateDates()
	{
		auto it = find_if(_instruments.begin(), _instruments.end(), [](Handle<CurveRateHelper>& h) { return h->getType() == CurveRateHelper::CASH && (h->getMaturityDate() - h->getStartDate() < 7); });
		_ONCash = (it != _instruments.end()) ? *it : Handle<CurveRateHelper>(nullptr);


		it = find_if(_instruments.begin(), _instruments.end(), [](Handle<CurveRateHelper>& h) { return h->getType() == CurveRateHelper::CASH && (h->getMaturityDate() - h->getStartDate() >= 7); });
		_Cash = (it != _instruments.end()) ? *it : _ONCash;

		if (!_ONCash && !_Cash)
			mcpl_error("You must supply at least one cash instrument to MCSDiscountCurve");

		//Find all the futures.
		_futures.clear();
		_swaps.clear();
		_firstNonCashIndex = 0;
		for (auto it = _instruments.begin(); it != _instruments.end(); it++)
		{
			if ((*it)->getType() != CurveRateHelper::CASH && (*it)->UseInCurve && _firstNonCashIndex == 0)
				_firstNonCashIndex = it - _instruments.begin();

			if (((*it)->getType() == CurveRateHelper::FUTURE) && ((*it)->UseInCurve))
			{
				_futures.push_back(*it);
			}

			if (((*it)->getType() == CurveRateHelper::SWAP) && ((*it)->UseInCurve))
			{
				_swaps.push_back(*it);
			}

			if ((*it)->getType() == CurveRateHelper::BUNDLE)
			{
				Handle<BundleRateHelper> bundle = dynamic_pointer_cast<BundleRateHelper>((*it));
				for (auto& f : *(bundle->getFutures()))
					_futures.push_back(f);
			}
		}
	}


	//Set the basis spread at effDate s.t. the calculated forward rate from effDate -> matDate using basis = rate
	//Set the forward extrapolation of this as flat.
	void MCSDiscountCurve::setFwdRate(const date& effDate_, const date& matDate_, double rate_, DayBasis dayBasis_)
	{
		double x1 = rate_ - 1e-3;
		double x2 = rate_ + 1e-3;

		//double funcmin = quadraticFitter([&](double x) { _curve->setIRate(matDate_, x); return rate_ - _curve->getRate(effDate_, matDate_, dayBasis_); }, x1, x2 , 1e-7 /*1/1000th of bp*/, 5);
		double funcmin = quadraticFitter([&](double x) { return rateFitter(x, rate_, effDate_, matDate_, dayBasis_); }, x1, x2, 1e-7 /*1/1000th of bp*/, 5);

		_curve->setIRate(matDate_, funcmin);
	}

	double MCSDiscountCurve::rateFitter(double testIrate_, double targetRate_, const date& effDate_, const date& matDate_, DayBasis dayBasis_)
	{
		_curve->setIRate(matDate_, testIrate_);
		double rate = _curve->getRate(effDate_, matDate_, dayBasis_);
		return targetRate_ - rate;
	}
	
	
	/*void MCSDiscountCurve::calculateCurveOld()
	{
		date nextFitDate;

		clear();
		
		_curve->setIRate(_today, _ONCash->getTargetRate());
		setFwdRate(_today, _ONCash->getMaturityDate(), _ONCash->getTargetRate(), dynamic_pointer_cast<CashRateHelper>(_ONCash)->getBasis());
		nextFitDate = _ONCash->getMaturityDate();

		if (_Cash->getMaturityDate() > _ONCash->getMaturityDate())
		{
			setFwdRate(_Cash->getStartDate(), _Cash->getMaturityDate(), _Cash->getTargetRate(), dynamic_pointer_cast<CashRateHelper>(_Cash)->getBasis());
			nextFitDate = _Cash->getMaturityDate();
		}

		//Fit the futures
		for (auto &fut : _futures)
		{
			setFwdRate(fut->getStartDate(), fut->getAdjMaturityDate(), fut->getTargetRate(), m_basis);
			nextFitDate = fut->getAdjMaturityDate();
		}

		
		//Fit the Swaps
		unsigned int firstUsedSwapIndex = find_if(_swaps.begin(), _swaps.end(), [&](const shared_ptr<CurveRateHelper> &s){ return s->getLastDate() > nextFitDate; }) - _swaps.begin();
		for (unsigned int i = firstUsedSwapIndex; i < _swaps.size(); i++)
		{
			auto &swap = _swaps[i];
			if (i == 0)
				_curve->setIRate(swap->getLastDate(), swap->getTargetRate());
			else
			{
				double dcf1 = _swaps[i - 1]->getLastDate() - _today;
				double dcf2 = swap->getLastDate() - _today;
				double y1 = _curve->getIRate(_swaps[i - 1]->getLastDate());
				double S1 = _swaps[i - 1]->getTargetRate();
				double S2 = swap->getTargetRate();

				double y2 = 2.0*(dcf2*S2 - dcf1*S1) / (dcf2 - dcf1) - y1;
				_curve->setIRate(swap->getLastDate(), y2);

			}
			nextFitDate = swap->getMaturityDate();
		}

		unsigned int ndims = 3;
		Amoeba am(1e-2);
		vector<double> p(ndims);

		for (unsigned int i = firstUsedSwapIndex; i <= _swaps.size() - ndims; i++)
		{
			int j = i - firstUsedSwapIndex;
			if (j % (ndims - 1) == 0 || (i == _swaps.size() - ndims))
			{
				for (unsigned int j = 0; j < ndims; j++)
					p[j] = _curve->getIRate(_swaps[i + j]->getLastDate());

				vector<double> min = am.minimize(p, 1e-3, [&](const vector<double> &x){ return swapsFitter2D(x, i); });

				for (unsigned int j = 0; j < ndims; j++)
					_curve->setIRate(_swaps[i + j]->getLastDate(), min[j]);
			}
		}

	}*/

	void MCSDiscountCurve::calculateCurve()
	{
		date nextFitDate;

		clear();

		_curve->setIRate(_today, _ONCash->getTargetRate());
		setFwdRate(_today, _ONCash->getMaturityDate(), _ONCash->getTargetRate(), dynamic_pointer_cast<CashRateHelper>(_ONCash)->getBasis());
		nextFitDate = _ONCash->getMaturityDate();

		if (_Cash->getMaturityDate() > _ONCash->getMaturityDate())
		{
			setFwdRate(_Cash->getStartDate(), _Cash->getMaturityDate(), _Cash->getTargetRate(), dynamic_pointer_cast<CashRateHelper>(_Cash)->getBasis());
			nextFitDate = _Cash->getMaturityDate();
		}

		_amoebaInsts.clear();
		//Fit the futures
		for (auto &fut : _futures)
		{
			_amoebaInsts.push_back(fut);
			//setFwdRate(fut->getStartDate(), fut->getAdjMaturityDate(), fut->getTargetRate(), m_basis);
			nextFitDate = fut->getAdjMaturityDate();
		}


		//Fit the Swaps
		unsigned int firstUsedSwapIndex = find_if(_swaps.begin(), _swaps.end(), [&](const shared_ptr<CurveRateHelper> &s){ return s->getLastDate() > nextFitDate; }) - _swaps.begin();
		unsigned int lastFutIndex = _amoebaInsts.size();
		vector<double> swapIRateGuess;
		for (unsigned int i = firstUsedSwapIndex; i < _swaps.size(); i++)
		{
			_amoebaInsts.push_back(_swaps[i]);
			auto &swap = _swaps[i];
			if (swapIRateGuess.size() == 0)
			{
				swapIRateGuess.push_back((swap->getTargetRate() - _ONCash->getTargetRate()) / 2.0);
			}
			else
			{
				double dcf1 = _swaps[i - 1]->getLastDate() - _today;
				double dcf2 = swap->getLastDate() - _today;
				double y1 = *(swapIRateGuess.rbegin());
				double S1 = _swaps[i - 1]->getTargetRate();
				double S2 = swap->getTargetRate();

				double y2 = 2.0*(dcf2*S2 - dcf1*S1) / (dcf2 - dcf1) - y1;
				swapIRateGuess.push_back(y2);

			}
		}

		unsigned int ndims = 3;
		Amoeba am(1e-2);
		vector<double> p(ndims);

		//Check we have enough instruments to run amoeba.
		if (_amoebaInsts.size() < ndims)
		{
			mcpl_error("Need more instruments to create an MCSDiscountCurve. Insts = " + stringify(_amoebaInsts.size()) + " ndims = " + stringify(ndims));
		}

		for (unsigned int i = 0; i <= _amoebaInsts.size() - ndims; i++)
		{
			if (i % (ndims - 1) == 0 || (i == _amoebaInsts.size() - ndims))
			{
				for (unsigned int j = 0; j < ndims; j++)
				{
					if (_amoebaInsts[i + j]->getLastDate() <= _curve->lastDate()) //Already have a fit for this t, so use that as a first guess at next fit
						p[j] = _curve->getIRate(_amoebaInsts[i + j]->getLastDate()); 
					else // Have to guess a first guess.
					{
						if (_amoebaInsts[i + j]->getType() == CurveRateHelper::FUTURE)
							p[j] = _amoebaInsts[i + j]->getTargetRate();
						else
						{
							p[j] = swapIRateGuess[i + j - lastFutIndex];
						}
					}
				}

				vector<double> min = am.minimize(p, 1e-3, [&](const vector<double> &x){ return swapsFitter2D(x, i); });

				for (unsigned int j = 0; j < ndims; j++)
					_curve->setIRate(_amoebaInsts[i + j]->getLastDate(), min[j]);
			}
		}

	}

	double MCSDiscountCurve::swapsFitter(double testIate_, Handle<CurveRateHelper> swap)
	{
		_curve->setIRate(swap->getLastDate(), testIate_);
		swap->SetCurves(_discountCurve, Handle<MCSDiscountCurve>(this, null_deleter()));

		double swapRate = swap->getRate();
		double targetRate = swap->getTargetRate();

		return  (swapRate - targetRate);
	}

	double MCSDiscountCurve::swapsFitter2D(const vector<double> testIrates_, int firstFitIndex_)
	{
		unsigned int nDims = testIrates_.size();
		for (unsigned int i = 0; i < nDims; i++)
		{
			unsigned int fitIndex = i + firstFitIndex_;
			_curve->setIRate(_amoebaInsts[fitIndex]->getLastDate(), testIrates_[i]);
		}

		//const double tol = .005;
		const double r = 2.0;

		double sum = 0;
		for (unsigned int i = 0; i < nDims; i++)
		{
			unsigned int fitIndex = i + firstFitIndex_;
			
			_amoebaInsts[fitIndex]->SetCurves(_discountCurve, Handle<MCSDiscountCurve>(this, null_deleter()));
			
			double error = _amoebaInsts[fitIndex]->getTargetRate() - _amoebaInsts[fitIndex]->getRate();
			double absError = fabs(error);

			double tol = _amoebaInsts[fitIndex]->RateFitTolerance;

			if (error > tol)
				error -= tol / r;
			else if (error < -tol)
				error += tol / r;
			else
				error = error / r;

			//if (fabs(error) < tol)
			//	error = 0;
			
			sum += error*error;
		}

		return sqrt(sum) + _curve->curveLength(_amoebaInsts[max(firstFitIndex_ - 2, 0)]->getLastDate(), _amoebaInsts[firstFitIndex_ + nDims - 1]->getLastDate()) * _tension;

	}

} // namespace MCPL