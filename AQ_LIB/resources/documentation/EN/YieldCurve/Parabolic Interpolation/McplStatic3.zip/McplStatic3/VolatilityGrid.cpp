#include "VolatilityGrid.h"

namespace MCPL
{




#define STRIKE_MULTIPLE 100000
#define TENOR_MULTIPLE  100000


  // Make << work in printing
  std::ostream& operator<< (std::ostream& o, const strike &d_strike)
  {
    return o << d_strike.m_strike;
  }
  // Make << work in printing
  std::ostream& operator<< (std::ostream& o, const expiry &d_expiry)
  {
    return o << d_expiry.m_expiry;
  }


  // Make << work in printing
  std::ostream& operator<< (std::ostream& o, const tenor &d_tenor)
  {
    return o << d_tenor.m_tenor;
  }

  void VolatilityGridBase::redim_cube()
  {
    unsigned long e,t,s;
    e = m_days_to_expiry.size();
    t = m_tenor_months.size();
    s =  m_strikes.size();

    m_data.redim( __max(e,1) , __max(t,1) , __max(s , 1) );
    m_cube_reset = true;
  }


  // Get volatility associated with a date
  double VolatilityGridBase::get_nocheck1(expiry days_to_exp, unsigned  col, unsigned  plane) const
  {

    if ( size() == 1 ) return m_data(0,0,0); // flat vol

    t_expiry_map::const_iterator it_exp;

    it_exp = m_days_to_expiry.find((long) days_to_exp );


    if ( it_exp != m_days_to_expiry.end() )  // We have the vol as a grid element, so return it
    {
      return(m_data(it_exp->second, col, plane));
    } 
    else 
    {
      it_exp = m_days_to_expiry.lower_bound((long)days_to_exp); // earliest element in map for which the key < label
      if ( it_exp == m_days_to_expiry.end() ) // are we off the end of the grid?
      {
        if ( m_permit_extrapolation )
        {
          --it_exp;
          return (m_data(it_exp->second, col, plane));
        }
        else
          mcpl_error(string("VolatilityGridBase error: days_to_exp off end of grid ") + stringify(days_to_exp));
      }
      else if ( it_exp == m_days_to_expiry.begin() ) // are we off the start of the grid?
      {
        if ( m_permit_extrapolation )
          return (m_data(it_exp->second, col, plane));
        else
          mcpl_error(string("VolatilityGridBase error: days_to_exp before start of grid ") + stringify(days_to_exp));
      }

      // Ok, so we are in the grid somewhere, and can interpolate!

      double  y1, y2;
      long x1, x2;

      x1 = it_exp->first;
      y1 = m_data(it_exp->second,col,plane);

      --it_exp;

      x2 = it_exp->first;
      y2 = m_data(it_exp->second,col,plane);

      return( h_expiry_interpolator->interpolate_basic(x1,y1,x2,y2, days_to_exp) );
    }
  }


  BlackVol VolatilityGridBase::get(expiry days_to_exp) const // Get volatility associated with a date
  {
	  if (size() == 1) return BlackVol(m_data(0, 0, 0),_shift); // flat vol

    data_cube::tri data_size;
    size( data_size );

    if ( (data_size.second != 1) || (data_size.third != 1) )
      mcpl_error(" attempt to get a 1d vol from a >1d vol grid : ");

	return BlackVol(get_nocheck1((long)days_to_exp, 0, 0),_shift);
  }



  BlackVol VolatilityGridBase::get(date & d_expiry) const // Get volatility associated with a date
  {
	  if (size() == 1) return BlackVol(m_data(0, 0, 0),_shift); // flat vol

    if (! m_today_set ) mcpl_error("today not defined in volatility grid");

    return get( expiry(d_expiry - m_today) );
  }


  /*************************************************************************************************************/

  // Get volatility associated with a date and a tenor in months

  double VolatilityGridBase::get_nocheck2(expiry days_to_exp, tenor d_tenor, unsigned plane) const 
  {
    if ( size() == 1 ) return m_data(0,0,0); // flat vol

    t_tenor_map::const_iterator it_tenor;
    long approx_tenor = long((double) d_tenor * (double) TENOR_MULTIPLE);

    it_tenor = m_tenor_months.find((long) approx_tenor );


    if ( m_tenor_months.size() <= 1 ) 
    {     // We have no (or just one) tenors in this grid
      return(get_nocheck1(days_to_exp, 0, plane) );
    }

    if ( it_tenor != m_tenor_months.end() )  // We have the tenor, so just need to find the expiry
    {
      return(get_nocheck1(days_to_exp, it_tenor->second, plane) );
    } 
    else 
    {
      it_tenor = m_tenor_months.lower_bound((long) approx_tenor); // earliest element in map for which the key < label
      if ( it_tenor == m_tenor_months.end() ) // are we off the end of the grid?
      {
        if ( m_permit_extrapolation )
        {
          --it_tenor;
          return (get_nocheck1(days_to_exp, it_tenor->second, plane));
        }
        else
          mcpl_error(string("VolatilityGridBase error: tenor off end of grid ") + stringify(d_tenor) + string(" months"));
      }
      else if ( it_tenor == m_tenor_months.begin() ) // are we off the start of the grid?
      {
        if ( m_permit_extrapolation )
          return (get_nocheck1(days_to_exp, it_tenor->second, plane));
        else
          mcpl_error(string("VolatilityGridBase error: tenor before start of grid ") + stringify(days_to_exp) + string(" months"));
      }

      // Ok, so we are in the grid somewhere, and can interpolate!

      double  y1, y2;
      double x1, x2;

      x1 = double(it_tenor->first) /  TENOR_MULTIPLE;
      y1 = get_nocheck1(days_to_exp, it_tenor->second, plane);

      --it_tenor;

      x2 = double(it_tenor->first) / TENOR_MULTIPLE;
      y2 = get_nocheck1(days_to_exp, it_tenor->second, plane);

      return( h_tenor_interpolator->interpolate_basic(x1,y1,x2,y2, d_tenor) );
    }
  }

  BlackVol VolatilityGridBase::get(expiry days_to_exp, tenor d_tenor) const // Get volatility associated with a (date, tenor)
  {
	  if (this->size() == 1) return BlackVol(m_data(0, 0, 0),_shift); // flat vol

    data_cube::tri data_size;
    this->size( data_size );

    if ( data_size.third != 1 )
      mcpl_error(" attempt to get a 2d vol from a >2d vol grid.");

	return BlackVol(get_nocheck2(days_to_exp, d_tenor, 0),_shift);
  }

  BlackVol VolatilityGridBase::get(date & exp, tenor d_tenor) const // Get volatility associated with a date
  {
	  if (size() == 1) return BlackVol(m_data(0, 0, 0),_shift); // flat vol

    if (! m_today_set ) mcpl_error("today not defined in volatility grid");

    return get((expiry)(exp - m_today), d_tenor);
  }

  /*************************************************************************************************************/
  // Get volatility associated with a date and a strike in months
  double VolatilityGridBase::get_nocheck3(expiry days_to_exp, unsigned col, strike d_strike) const  //test
  {
    if ( size() == 1 ) return m_data(0,0,0); // flat vol

    data_cube::tri data_size;
    size( data_size );

    //	if ( (data_size.second == 1) || (data_size.third == 1) )
    //		mcpl_error(" attempt to get a 3d vol from a <3d vol grid.");

    // Get an aproximate strike
    long approx_strike = (long) ((double)d_strike * (double)STRIKE_MULTIPLE);

    t_strikes_map::const_iterator it_strike;

    it_strike = m_strikes.find( approx_strike );


    if ( it_strike != m_strikes.end() )  // We have the strike, so just a 2d interp
    {
      return(get_nocheck1(days_to_exp, col, it_strike->second) );
    } 
    else 
    {
      it_strike = m_strikes.lower_bound(approx_strike); // earliest element in map for which the key < label
      if ( it_strike == m_strikes.end() ) // are we off the end of the grid?
      {
        if ( m_permit_extrapolation )
        {
          --it_strike;
          return (get_nocheck1(days_to_exp, col, it_strike->second));
        }
        else
          mcpl_error(string("VolatilityGridBase error: strike off end of grid ") + stringify(d_strike));
      }
      else if ( it_strike == m_strikes.begin() ) // are we off the start of the grid?
      {
        if ( m_permit_extrapolation )
          return (get_nocheck1(days_to_exp, col, it_strike->second));
        else
          mcpl_error(string("VolatilityGridBase error: strike before start of grid ") + stringify(d_strike));
      }

      // Ok, so we are in the grid somewhere, and can interpolate!

      double  y1, y2;
      double x1, x2;

      x1 = double(it_strike->first) / STRIKE_MULTIPLE;
      y1 = get_nocheck1(days_to_exp, col, it_strike->second);

      --it_strike;

      x2 = double(it_strike->first) / STRIKE_MULTIPLE;
      y2 = get_nocheck1(days_to_exp, col, it_strike->second);

      while( (x1 == x2) && (--it_strike != m_strikes.begin() ) )
      {
        x2 = double(it_strike->first) / STRIKE_MULTIPLE;
        y2 = get_nocheck1(days_to_exp, col, it_strike->second);
      }

      return( h_strike_interpolator->interpolate_basic(x1,y1,x2,y2, d_strike) );
    }
  }


  BlackVol VolatilityGridBase::get(expiry days_to_exp, strike d_strike) const // Get volatility associated with a date,strike
  {
	  if (this->size() == 1) return BlackVol( m_data(0, 0, 0),_shift); // flat vol

    data_cube::tri data_size;
    this->size( data_size );

    if ( data_size.second != 1 )
      mcpl_error(" attempt to get a (exp,strike) vol from an incompatible grid.");

	return BlackVol(get_nocheck3(days_to_exp, 0, d_strike),_shift);
  }

  BlackVol VolatilityGridBase::get(date & exp, strike d_strike) const
  {
	  if (size() == 1) return BlackVol(m_data(0, 0, 0),_shift); // flat vol

    if (! m_today_set ) mcpl_error("today not defined in volatility grid");

    return get((expiry) (exp - m_today), d_strike);
  }


  /*************************************************************************************************************/

  // Get volatility associated with a date, tenor and strike

  BlackVol VolatilityGridBase::get(expiry days_to_exp, tenor d_tenor, strike d_strike) const
  {
	  if (size() == 1) return BlackVol(m_data(0, 0, 0),_shift); // flat vol

    data_cube::tri data_size;
    size( data_size );

    //	if ( (data_size.second == 1) || (data_size.third == 1) )
    //		mcpl_error(" attempt to get a 3d vol from a <3d vol grid.");

    // Get an aproximate expiry
    long approx_strike = (long) ((double)d_strike * (double)STRIKE_MULTIPLE);

    t_strikes_map::const_iterator it_strike;

    it_strike = m_strikes.find( approx_strike );


    if ( it_strike != m_strikes.end() )  // We have the strike, so just a 2d interp
    {
		return BlackVol(get_nocheck2(days_to_exp, d_tenor, it_strike->second),_shift);
    } 
    else 
    {
      it_strike = m_strikes.lower_bound(approx_strike); // earliest element in map for which the key < label
      if ( it_strike == m_strikes.end() ) // are we off the end of the grid?
      {
        if ( m_permit_extrapolation )
        {
          --it_strike;
		  return BlackVol(get_nocheck2(days_to_exp, d_tenor, it_strike->second),_shift);
        }
        else
          mcpl_error(string("VolatilityGridBase error: strike off end of grid ") + stringify(d_strike));
      }
      else if ( it_strike == m_strikes.begin() ) // are we off the start of the grid?
      {
        if ( m_permit_extrapolation )
			return BlackVol(get_nocheck2(days_to_exp, d_tenor, it_strike->second),_shift);
        else
          mcpl_error(string("VolatilityGridBase error: strike before start of grid ") + stringify(d_strike));
      }

      // Ok, so we are in the grid somewhere, and can interpolate!

      double  y1, y2;
      double x1, x2;

      x1 = double(it_strike->first) / STRIKE_MULTIPLE;
      y1 = get_nocheck2(days_to_exp, d_tenor, it_strike->second);

      --it_strike;

      x2 = double(it_strike->first) / STRIKE_MULTIPLE;
      y2 = get_nocheck2(days_to_exp, d_tenor, it_strike->second);

      while( (x1 == x2) && (--it_strike != m_strikes.begin() ) )
      {
        x2 = double(it_strike->first) / STRIKE_MULTIPLE;
        y2 = get_nocheck2(days_to_exp, d_tenor, it_strike->second);
      }

	  return BlackVol(h_strike_interpolator->interpolate_basic(x1, y1, x2, y2, d_strike),_shift);
    }
  }


  BlackVol VolatilityGridBase::get(date & d_expiry, tenor d_tenor, strike d_strike) const
  {
	  if (size() == 1) return BlackVol(m_data(0, 0, 0),_shift); // flat vol

    if (! m_today_set ) mcpl_error("today not defined in volatility grid");

    return get((d_expiry - m_today), d_tenor, d_strike);
  }			


  /*************************************************************************************************************/

  BlackVol VolatilityGridBase::get(expiry d_expiry, tenor d_tenor, strike d_strike, double forward) const
  {
    if ( m_strikeType == STRIKETYPE_ABSOLUTE )
	    return get(d_expiry, d_tenor, d_strike);
		else if ( m_strikeType == STRIKETYPE_ATM )
			return get(d_expiry, d_tenor, (strike)( (double) d_strike - forward) );
		else
			mcpl_error("Undefined strike type in VolatilityGrid.cpp");

		return BlackVol(0,_shift); //should never het here, but removes compiler warning!
  }			

  BlackVol VolatilityGridBase::get(date & d_expiry, tenor d_tenor, strike d_strike, double forward) const
  {
    return get((d_expiry - m_today), d_tenor, d_strike, forward);
  }			

  /*************************************************************************************************************/

  void VolatilityGridBase::getExpiries(vector<date> & date_vector) const
  {
    date_vector.clear();

    for ( t_expiry_map::const_iterator it = m_days_to_expiry.begin() ; 
      it != m_days_to_expiry.end() ; ++it )
      date_vector.push_back( m_today + int(it->first) );
  }

  /*************************************************************************************************************/

  void VolatilityGridBase::getExpiries(vector<long> & days_to_exp_vector) const
  {
    days_to_exp_vector.clear();

    for ( t_expiry_map::const_iterator it = m_days_to_expiry.begin() ; 
      it != m_days_to_expiry.end() ; ++it )
      days_to_exp_vector.push_back( it->first );
  }

  /*************************************************************************************************************/

  void VolatilityGridBase::getTenors(vector<double> & tenor_vector) const 
  {
    tenor_vector.clear();

    for ( t_tenor_map::const_iterator it = m_tenor_months.begin() ; 
      it != m_tenor_months.end() ; ++it )
      tenor_vector.push_back( (double) it->first / TENOR_MULTIPLE );
  }

  /*************************************************************************************************************/

  void VolatilityGridBase::getStrikes(vector<double> & strikes_vector) const
  {
    strikes_vector.clear();

    for ( t_strikes_map::const_iterator it = m_strikes.begin() ; 
      it != m_strikes.end() ; ++it )
      strikes_vector.push_back( (double)  it->first / STRIKE_MULTIPLE );
  }


  /*************************************************************************************************************/

  void VolatilityGridBase::setStrikes(const vector<double> & strikes_vector)
  {
    m_cube_reset = false;

    m_data.redim(1,1,1);

    unsigned long sz = strikes_vector.size(); 
    long strike, previous_strike;

    m_strikes.clear();
    strike = (long)(strikes_vector[0]*STRIKE_MULTIPLE);
    m_strikes[ strike ] = 0;

    for ( unsigned i=1, j=1; i < sz ; ++i ) 
    {
      previous_strike = strike;
      strike = (long)(strikes_vector[i]*STRIKE_MULTIPLE);
      if ( strike > previous_strike )  // strikes have to be strictly increasing, or they will be ignored.
        m_strikes[ strike ] = j++;
    }


  }


  /*************************************************************************************************************/

  void VolatilityGridBase::setTenors(const vector<double> & tenor_vector)
  {
    m_cube_reset = false;

    m_data.redim(1,1,1);

    unsigned sz = tenor_vector.size(); 
    long tenr, previous_tenor;

    m_tenor_months.clear();
    tenr = (long) (tenor_vector[0] * TENOR_MULTIPLE);
    m_tenor_months[ tenr ] = 0;

    for ( unsigned i=1, j=1; i < sz ; ++i ) 
    {
      previous_tenor = tenr;
      tenr = (long) (tenor_vector[i] * TENOR_MULTIPLE);
      if ( tenr > previous_tenor ) // tenors must be increasing.
        m_tenor_months[ tenr ] = j++;
    }

  }

  /*************************************************************************************************************/

  void VolatilityGridBase::setExpiries(const date & today, const vector<date> & date_vector)
  {
    m_cube_reset = false;

    m_data.redim(1,1,1);

    m_today = today;
    m_today_set = true;

    unsigned sz = date_vector.size(); 
    long expiry, previous_expiry;
    m_days_to_expiry.clear();

    expiry = long (date_vector[0] - m_today);
    m_days_to_expiry[ expiry ] = 0;

    for ( unsigned i=1, j=1; i < sz ; ++i ) 
    {
      previous_expiry = expiry;
      expiry =  long(date_vector[i] - m_today);
      if ( expiry > previous_expiry ) 
        m_days_to_expiry[ expiry ] = j++;
    }

  }

  void VolatilityGridBase::setExpiries(const vector<long> & days_to_exp_vector)
  {
    m_cube_reset = false;

    m_data.redim(1,1,1);

    m_today_set = false;
    m_days_to_expiry.clear();

    unsigned long sz = days_to_exp_vector.size(); 

    for ( unsigned long i=0; i < sz ; ++i ) 
    {
      unsigned long temp = days_to_exp_vector[i];
      m_days_to_expiry[ days_to_exp_vector[i] ] = i;
    }
    //unsigned sz2 = m_days_to_expiry.size();

  }

  /*************************************************************************************************************/


  void VolatilityGridBase::set(expiry days_to_expiry, tenor t, strike s, double vol)
  {
    if (  m_strikes.size() == 0 )
      mcpl_error("A <3d vol grid cannot be set with a 3d vol");


    t_expiry_map::iterator it_exp;
    t_tenor_map::iterator it_tenor;
    t_strikes_map::iterator it_strike;

    it_exp = m_days_to_expiry.find( days_to_expiry.m_expiry );
    if ( it_exp == m_days_to_expiry.end() ) 
      mcpl_error( string("No such expiry in the vol grid : ") + stringify(days_to_expiry.m_expiry) + string(" days to expiry.") );

    it_tenor = m_tenor_months.find( (long)(t.m_tenor*TENOR_MULTIPLE) );
    if ( it_tenor == m_tenor_months.end() ) 
      mcpl_error( string("No such tenor in the vol grid : ") + stringify((double(t.m_tenor)/TENOR_MULTIPLE)) + string(" years.") );

    it_strike = m_strikes.find( long(s.m_strike*STRIKE_MULTIPLE) );
    if ( it_strike == m_strikes.end() ) 
      mcpl_error( string("No such strike in the vol grid : ") + stringify(double(s.m_strike)/STRIKE_MULTIPLE) );


    if ( ! m_cube_reset ) redim_cube();
    m_data(it_exp->second, it_tenor->second, it_strike->second ) = vol;
  }

  void VolatilityGridBase::set(date & exp, tenor t, strike s, double vol)
  {
    if ( !m_today_set ) mcpl_error("today has not been set in vol grid");

    expiry days_to_expiry = (exp - m_today);

    set(days_to_expiry, t, s, vol);
  }


  /*************************************************************************************************************/

  // A skewed cap grid, expiry and strike.

  void VolatilityGridBase::set(expiry days_to_expiry, strike s, double vol)
  {
    if (  m_strikes.size() == 0 )
      mcpl_error("A skewed CFS vol grid cannot be set with a 3d vol");


    t_expiry_map::iterator it_exp;
    t_strikes_map::iterator it_strike;

    it_exp = m_days_to_expiry.find( days_to_expiry.m_expiry );
    if ( it_exp == m_days_to_expiry.end() ) 
      mcpl_error( string("No such expiry in the vol grid : ") + stringify(days_to_expiry.m_expiry) + string(" days to expiry.") );

    it_strike = m_strikes.find( long(s.m_strike*STRIKE_MULTIPLE) );
    if ( it_strike == m_strikes.end() ) 
      mcpl_error( string("No such strike in the vol grid : ") + stringify(double(s.m_strike)/STRIKE_MULTIPLE) );

    if ( ! m_cube_reset ) redim_cube();
    m_data(it_exp->second, 0, it_strike->second ) = vol;
  }

  void VolatilityGridBase::set(date & exp, strike s, double vol)
  {
    if ( !m_today_set ) mcpl_error("today has not been set in vol grid");

    expiry days_to_expiry = (exp - m_today);

    set(days_to_expiry, s, vol);
  }

  /*********************************************/


  void VolatilityGridBase::set(expiry days_to_expiry, tenor t, double vol)
  {
    if (  m_strikes.size() > 1 )
      mcpl_error("A 3d vol grid cannot be set with a 2d vol");

    if (  m_tenor_months.size() == 0 )
      mcpl_error("A 1d vol grid cannot be set with a 2d vol");

    t_expiry_map::iterator it_exp;
    t_tenor_map::iterator it_tenor;

    it_exp = m_days_to_expiry.find( days_to_expiry.m_expiry );
    if ( it_exp == m_days_to_expiry.end() ) 
      mcpl_error( string("No such expiry in the vol grid : ") + stringify(days_to_expiry.m_expiry) + string(" days to expiry.") );

    it_tenor = m_tenor_months.find( (long)(t.m_tenor*TENOR_MULTIPLE) );
    if ( it_tenor == m_tenor_months.end() ) 
      mcpl_error( string("No such tenor in the vol grid : ") + stringify(double(t.m_tenor)/TENOR_MULTIPLE) + string(" years.") );

    if ( ! m_cube_reset ) redim_cube();
    m_data(it_exp->second, it_tenor->second, 0) = vol;
  }

  void VolatilityGridBase::set(date & exp, tenor t, double vol)
  {
    if ( !m_today_set ) mcpl_error("today has not been set in vol grid");

    expiry days_to_expiry = (exp - m_today);

    set(days_to_expiry, t, vol);
  }

  /*********************************************/


  void VolatilityGridBase::set(expiry days_to_expiry, double vol)
  {
    if ( ( m_tenor_months.size() > 1 ) || ( m_strikes.size() > 1 ) )
      mcpl_error("A >1d vol grid cannot be set with a 1d (date only) vol");

    t_expiry_map::iterator it_exp;

    it_exp = m_days_to_expiry.find( days_to_expiry.m_expiry );
    if ( it_exp == m_days_to_expiry.end() ) 
      mcpl_error( string("No such expiry in the vol grid : ") + stringify(days_to_expiry.m_expiry) + string(" days to expiry.") );

    if ( ! m_cube_reset ) redim_cube();
    m_data(it_exp->second,0,0) = vol;
  }

  void VolatilityGridBase::set(date & exp, double vol)
  {
    if ( !m_today_set ) mcpl_error("today has not been set in vol grid");

    expiry days_to_expiry = (exp - m_today);

    set(days_to_expiry, vol);
  }


  /*********************************************/
  // Sets a flat vol

  void VolatilityGridBase::set(BlackVol vol)
  {
    resetAxes();

    m_data.redim(1,1,1);

    m_data(0,0,0) = vol.vol;
	setShift(vol.rateShift);

    m_permit_extrapolation = true;

  }

  void VolatilityGridBase::resetAxes()
  {
    m_tenor_months.clear();
    m_tenor_months[(long)(TENOR_MULTIPLE * .25)] = 0;

    m_strikes.clear();
    m_strikes[(long)(STRIKE_MULTIPLE * .01)] = 0;

    m_days_to_expiry.clear();
    m_days_to_expiry[0] = 0;

  }

  //void VolatilityGridBase::set(date & date, DatePeriod & tenor, double vol) ;
  //void VolatilityGridBase::set(date & date, DatePeriod & tenor, double strike, double vol) ;

  ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////
  SABRParams VolatilityGrid::getSABRParams(date & date) const 
  { 
	  return SABRParams(VolatilityGridBase::get(date).vol, getBeta(date), getNu(date), getRho(date), getShift(), CorrectForFlyArb, FlyStrikeSpacing, MaxFlyCorrectionStrike);
  }

  SABRParams VolatilityGrid::getSABRParams(expiry days_to_expiry) const 
  {
	  return SABRParams(VolatilityGridBase::get(days_to_expiry).vol, getBeta(days_to_expiry), getNu(days_to_expiry), getRho(days_to_expiry), getShift(), CorrectForFlyArb, FlyStrikeSpacing, MaxFlyCorrectionStrike);
  } 

  SABRParams VolatilityGrid::getSABRParams(date & date, tenor t) const 
  {
	  return SABRParams(VolatilityGridBase::get(date, t).vol, getBeta(date, t), getNu(date, t), getRho(date, t), getShift(), CorrectForFlyArb, FlyStrikeSpacing, MaxFlyCorrectionStrike);
  }

  SABRParams VolatilityGrid::getSABRParams(expiry days_to_exp, tenor t) const 
  {
	  return SABRParams(VolatilityGridBase::get(days_to_exp, t).vol, getBeta(days_to_exp, t), getNu(days_to_exp, t),getRho(days_to_exp, t), getShift(), CorrectForFlyArb, FlyStrikeSpacing, MaxFlyCorrectionStrike);
  }

  SABRParams VolatilityGrid::getSABRParams( VolatilityDeal & deal) const
  { 
    date exp = deal.get_expiry();
    tenor T = deal.get_tenor();
	return SABRParams(VolatilityGridBase::get(exp, T).vol, getBeta(exp, T), getNu(exp, T), getRho(exp, T), getShift(), CorrectForFlyArb, FlyStrikeSpacing, MaxFlyCorrectionStrike);
  }


} // namespace MCPL