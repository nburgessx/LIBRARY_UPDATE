#pragma once

#ifndef MCPLASSETSWAP_H
#define MCPLASSETSWAP_H
#pragma warning ( disable : 4251 4786 ) 

#include "mcpldefs.h"
#include "mathmisc.h"
#include "option.h"
#include "Swap.h"
#include "mcDateClass/dates.h"

using namespace std;
#include<string>
#include<vector>


namespace MCPL
{
	/* the asset swap class is a child of the swap class */
	class AssetSwap : public Swap
	{
	public:
		//constructors
		AssetSwap() {}

		/* constructs a PAR-PAR asset swap */
		AssetSwap(date today, date maturity, date datedDate, date firstCouponDate,
			double coupon, double cleanPrice,
			BONDTYPE bondType, Handle<RatesCurve> discountCurve = Handle<RatesCurve>(), Handle<RatesCurve> forecastCurve = Handle<RatesCurve>());

		//~AssetSwap();

		double getAccruedInterest();

		double priceWithRate(double rate_);
		double YieldToMaturity(double dirtyPrice);

		date getEvalDate() { return _EvalDate; }

		static double AssetSwap::BondPrice(date settlement_, date maturity_, double couponRate_, double yield_, double redemption_, int freq_, DayBasis basis_);
		static double AssetSwap::BondYield(date settlement_, date maturity_, double couponRate_, double price_, double redemption_, int freq_, DayBasis basis_);

	private:
		date	m_settlement;
		date	_EvalDate;
		double	m_accruedInterest;
		double  m_cleanPrice;


	};

}

#endif // ASSETSWAP_H
