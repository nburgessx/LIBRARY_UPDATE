#include"oneFactorGenericNormal.h"
#include "mathmisc.h"
#include<math.h>

#include <fstream>
#include "LatticeCurve.h"

//#define DEBUG

namespace MCPL
{
	
	void oneFactorGenericNormal::calcProbabilities()
	{
		for (unsigned int ex = 0; ex < _exDates.size(); ex++)
		{
			double volatility = _fwdVols[ex];
			double tempSum = 0;
			for (int k = 0; k < _nSteps * 2+1; k++)
			{
				int i = k - _nSteps;
				double temp = (i * _dFwd) * (i * _dFwd);
				double prob = exp(-1 * temp / (2 * volatility));
				_Probabilities(ex, k) = prob;
				tempSum += prob;
			}

			//Normalise
			for (int k = 0; k < _nSteps * 2+1; k++)
			{
				_Probabilities(ex, k) = _Probabilities(ex, k) / tempSum;
			}
		}
	}

	void oneFactorGenericNormal::calcInstrinsic()
	{
		double pp = .001;
		auto oldFcrv = _ULdeal->getForecastPtr();
		shared_ptr<LatticeCurve> curve(new LatticeCurve(oldFcrv, _exDates[0], [](double f) {return f; }));
		shared_ptr<LatticeCurve> curve2(new LatticeCurve(oldFcrv, _exDates[0], [&](double f) {return f + pp; }));

		_ULdeal->setCurves(_ULdeal->getDiscountPtr(), curve);

		// Set up a temp swap to use for calculating the ratio between pping the fwds curve, and pping the par rate of the swap
		//auto tempDeal = _ULdeal->CloneDealCashflows();

		for (int iEx = _exDates.size() - 1; iEx >= 0; iEx--)
		{
			//vector<double> test;
			date deltaDate = _exDates[iEx];
			curve->setChangeFwdFromDate(deltaDate);

			double basisRatio;
			if (_ULdeal->getDealType() == Deal::dealtype_swap)
			{
				auto swapdeal = dynamic_pointer_cast<Swap>(_ULdeal);
				// Calculate the ratio between pping the fwds curve and the par rate (which is what the swaption vol represents). This is due to using different basis
				curve2->setChangeFwdFromDate(deltaDate);
				curve2->setFwdDeltaFn([](double f) { return f; });


				swapdeal->setCurves(swapdeal->getDiscountPtr(), curve2);
				double rate1 = swapdeal->SolveRateNumeric(0, deltaDate);
				curve2->setFwdDeltaFn([&](double f) { return f + pp; });
				swapdeal->setCurves(swapdeal->getDiscountPtr(), curve2);
				double rate2 = swapdeal->SolveRateNumeric(0, deltaDate);
				basisRatio = pp / (rate2 - rate1);
			}
			else
			{
				basisRatio = 1;
			}

			for (int k = 0; k < _nSteps+1; k++)
			{
				double dfwd = basisRatio * _dFwd * (k - _nSteps / 2);
				curve->setFwdDeltaFn([&](double f) { return f + dfwd; });
				_ULdeal->updatePaymentsFromCurves(_ULdeal->getDiscountPtr(), curve);
				_intrinsicValues(iEx, k) = (_priceToCancelCashflows ? -1.0 : 1.0) * _ULdeal->Price(deltaDate);
				//test.push_back(_intrinsicValues(iEx, k));
			}
		}

		_ULdeal->setCurves(_ULdeal->getDiscountPtr(), oldFcrv);
	}
	
	//If UL value is linear with fwd rate, then we can use this fast instrinsic value calculator.
	void oneFactorGenericNormal::calcInstrinsicFast()
	{
		auto swapdeal = dynamic_pointer_cast<Swap>(_ULdeal);
		auto oldFcrv = swapdeal->getForecastPtr();
		shared_ptr<LatticeCurve> curve(new LatticeCurve(oldFcrv, _exDates[0], [](double f) {return f; }));

		swapdeal->setCurves(swapdeal->getDiscountPtr(), curve);

		for (int iEx = _exDates.size() - 1; iEx >= 0; iEx--)
		{
			date deltaDate = _exDates[iEx];
			curve->setChangeFwdFromDate(deltaDate);

			double ival1 = (_priceToCancelCashflows ? -1.0 : 1.0) * swapdeal->Price(deltaDate);
			double fwd1 = swapdeal->SolveRateNumeric(0, deltaDate);

			curve->setFwdDeltaFn([&](double f) { return f + _dFwd; });
			swapdeal->updatePaymentsFromCurves(swapdeal->getDiscountPtr(), curve);

			double ival2 = (_priceToCancelCashflows ? -1.0 : 1.0) * swapdeal->Price(deltaDate);
			double fwd2 = swapdeal->SolveRateNumeric(0, deltaDate);

			curve->setFwdDeltaFn([](double f) { return f; });
			swapdeal->updatePaymentsFromCurves(swapdeal->getDiscountPtr(), curve);

			double numeraire = (ival2 - ival1) / (fwd2 - fwd1);

			for (int k = 0; k < _nSteps + 1; k++)
			{
				double dfwd = _dFwd * (k - _nSteps / 2);
				_intrinsicValues(iEx, k) = ival1 + dfwd*numeraire;
			}
		}

		swapdeal->setCurves(swapdeal->getDiscountPtr(), oldFcrv);
	}
}