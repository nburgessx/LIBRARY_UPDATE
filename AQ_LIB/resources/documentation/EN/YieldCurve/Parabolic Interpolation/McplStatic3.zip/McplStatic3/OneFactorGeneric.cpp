#include"oneFactorGeneric.h"
#include "mathmisc.h"
#include<math.h>

#include <fstream>
#include "LatticeCurve.h"

//#define DEBUG

namespace MCPL
{
	
	oneFactorGeneric::oneFactorGeneric(shared_ptr<Deal> ULdeal_, int nSteps_, double dFwd_, shared_ptr<vector<date>> exDates_, shared_ptr<vector<double>> fwdVols_, bool priceToCancelCashflows_, bool useLinearGenerator_)
	{
		_nSteps = nSteps_;
		_dFwd = dFwd_;
		_exDates = vector<date>(*exDates_);
		_intrinsicValues = Matrix<double>(exDates_->size(), _nSteps + 1);
		_Values = Matrix<double>(exDates_->size(), _nSteps + 1);
		_ExerciseProbMatrix = Matrix<double>(exDates_->size(), _nSteps + 1);
		_Probabilities = Matrix<double>(exDates_->size(), _nSteps * 2 + 1);
		_fwdVols = vector<double>(*fwdVols_);
		_ExProbs = vector<double>(*fwdVols_);
		_CumulativeExProbs = vector<double>(*fwdVols_);
		_ForwardPVs = vector<double>(*fwdVols_);
		_priceToCancelCashflows = priceToCancelCashflows_;
		_ULdeal = ULdeal_->CloneDealCashflows();
		_useLinearGenerator = useLinearGenerator_;
	}

	//Calculates the expected value for _values[nT-1,i]
	double oneFactorGeneric::singleBackwardCompute(int nT, int i, std::function<double(int, int)> payoff)
	{
		double value = 0;
		for (int j = 0; j < _nSteps+1; j++)
		{
			//value += _Values(nT, j) * _Probabilities(nT, _nSteps + j - i);
			value += payoff(nT, j) * _Probabilities(nT, _nSteps + j - i);
		}
		return value;
	}

	double oneFactorGeneric::BackwardCompute()
	{
		for (int nT = _exDates.size() - 2; nT >= 0; nT--)
		{
			for (int i = 0; i < _nSteps+1; i++)
			{
				_Values(nT, i) = __max(_intrinsicValues(nT, i), singleBackwardCompute(nT + 1, i, [&](int nt_, int i_){ return _Values(nt_, i_); }) );
			}
		}

		double pv = singleBackwardCompute(0, (_nSteps + 1) / 2, [&](int nt_, int i_){ return _Values(nt_, i_); });
		
		_ForwardPVs.clear();
		_ForwardPVs.push_back(pv);
		for (int nt = 0; nt < _exDates.size() - 1; nt++)
			_ForwardPVs.push_back(_Values(nt, (_nSteps + 1) / 2));

		return pv;
	}

	void oneFactorGeneric::BackwardComputeExProbs()
	{
		for (int nT = _exDates.size() - 2; nT >= 0; nT--)
		{
			for (int i = 0; i < _nSteps + 1; i++)
			{
				_ExerciseProbMatrix(nT, i) = singleBackwardCompute(nT + 1, i, [&](int nT_, int i_)
								{ return _intrinsicValues(nT_ - 1, i_) < _Values(nT_ - 1, i_) ? 0 : 1; }
					);
			}
		}

		// Take middle row from _ExerciseProbMatrix
		_ExProbs.clear();
		_ExProbs.push_back(singleBackwardCompute(0, _nSteps / 2, [&](int nT_, int i_) { return _ExerciseProbMatrix(nT_, i_); }));
		for (int nt = 0; nt < _exDates.size() - 1; nt++)
			_ExProbs.push_back(_ExerciseProbMatrix(nt, (_nSteps + 1) / 2));

		_CumulativeExProbs.clear();
		double sum = 0;
		for (int nt = 0; nt < _exDates.size(); nt++)
		{
			double prob = _ExProbs[nt] * (1 - sum);
			sum += prob;
			_CumulativeExProbs.push_back(prob);
		}

	}

	double oneFactorGeneric::priceStructure()
	{
		int LastEx = _exDates.size() - 1;

		if (_useLinearGenerator)
			calcInstrinsicFast();
		else
			calcInstrinsic();

		for (int i = 0; i < _Values.Cols(); i++)
		{
			double val = __max(0, _intrinsicValues(LastEx, i));
			_ExerciseProbMatrix(LastEx, i) = val > 0 ? 1 : 0;
		}

		vector<double> test;
		for (unsigned int i = 0; i < _Values.Cols(); i++)
		{
			_Values(LastEx, i) = __max(0, _intrinsicValues(LastEx, i));
			test.push_back(_intrinsicValues(LastEx, i));
		}

		calcProbabilities();
		double pv = BackwardCompute();
		BackwardComputeExProbs();

		return pv;
	}
}