#pragma once
#ifndef MCPLLATTICECURVE_H
#define MCPLLATTICECURVE_H
#include "MCPL.h"

#include<string>
#include<vector>
#include <functional>

#include "mcpldefs.h"
#include "RatesCurve.h"

using namespace std;

namespace MCPL
{
	class LatticeCurve : public RatesCurve
	{
	public:

		LatticeCurve(shared_ptr<RatesCurve> baseCurve_, const date & changeFwdFromDate_, function<double(double)> perturbFunc_)
		{
			_baseCurve = baseCurve_;
			_changeFwdFromDate = changeFwdFromDate_;
			_perturbFunc = perturbFunc_;
		}

		void setFwdDeltaFn(function<double(double)> func_) { _perturbFunc = func_; }

		date getChangeFwdFromDate() { return _changeFwdFromDate; }
		void setChangeFwdFromDate(const date& changeFwdFromDate_) { _changeFwdFromDate = changeFwdFromDate_; }

		virtual double getZero(const date & d1, const date & d2, DayBasis basis) 
		{
			if (d1 > _changeFwdFromDate)
				return _perturbFunc(_baseCurve->getZero(d1, d2, basis));
			else
				return _baseCurve->getZero(d1, d2, basis);
		}

		virtual double getZero(const date & d1, const date & d2) // forward rate from d1 to d2
		{
			if (d1 > _changeFwdFromDate)
				return _perturbFunc(_baseCurve->getZero(d1, d2));
			else
				return _baseCurve->getZero(d1, d2);
		}

		// Get continuously compounded rate
		virtual double getCCRate(date & d1, date & d2, DayBasis basis) 
		{
			if (d1 > _changeFwdFromDate)
				return _perturbFunc(_baseCurve->getCCRate(d1, d2, basis));
			else
				return _baseCurve->getCCRate(d1, d2, basis);
		}

		virtual void partialClear() { mcpl_error("partialClear not implemented in LatticeCurve"); }  // clear curves, not stored cashflows

		virtual Handle<RatesCurve> clone() { mcpl_error("clone not implemented in LatticeCurve"); return nullptr; }

		virtual void clear() { mcpl_error("clear not implemented in LatticeCurve"); }

		virtual double forecastFixing(date & reset_date)  { return _baseCurve->forecastFixing(reset_date); }

		virtual double getDiscountFactor(const date & d)  { return _baseCurve->getDiscountFactor(d); }
		double getRatesDiscountFactor(const date & d) { return _baseCurve->getRatesDiscountFactor(d); }
		virtual DayBasis getDayBasis()  { return _baseCurve->getDayBasis(); }
		virtual CURRENCY getCurrency()  { return _baseCurve->getCurrency(); }

		virtual void setDiscountFactor(date & d, double value)  { mcpl_error("setDiscountFactor not implemented in LatticeCurve"); }
		virtual void setDayBasis(DayBasis basis)  { mcpl_error("setDayBasis not implemented in LatticeCurve"); }
		virtual void setCurrency(CURRENCY ccy)  { mcpl_error("setCurrency not implemented in LatticeCurve"); }

		virtual void setDefaults(CURRENCY ccy, unsigned periodMonths)  { mcpl_error("setDefaults not implemented in LatticeCurve"); }

		virtual date firstDate()  { return _baseCurve->firstDate(); }
		virtual date lastDate()  { return _baseCurve->lastDate(); }
		virtual void shiftCurve(double dR, DayBasis basis)  { mcpl_error("shiftCurve not implemented in LatticeCurve"); }
		virtual shared_ptr<vector<long>> getLabels()  { mcpl_error("getLabels not implemented in LatticeCurve"); return nullptr; }

		virtual void calculateCurve()  { mcpl_error("calculateCurve not implemented in LatticeCurve"); }

		virtual void addDependent(Handle<RatesCurve> dependentCurve_) { mcpl_error("addDependent not implemented in LatticeCurve"); }

	private:

		shared_ptr<RatesCurve> _baseCurve;
		date _changeFwdFromDate;

		function<double(double)> _perturbFunc;
	};

}

#endif //MCPLLATTICECURVE_H