#pragma once
#ifndef _MCPL_interpolators_h
#define _MCPL_interpolators_h

#pragma warning ( disable : 4251 4786 ) 
#include "MCPL.h"
#include "mcpldefs.h"
#include "handle.hpp"

using namespace std;

namespace MCPL
{

/*********************************************************************************************
Base Interpolator:
	Pure virtual interpolator base class.
*********************************************************************************************/
class Interpolator
{
public:
	virtual ~Interpolator() {};

	template < typename T_Label , typename iterator>
	double interpolate(const T_Label & x, iterator & it)
	{
		double y1, y2;
		T_Label x1, x2;

		x1 = (*it).first;
		y1 = (*it).second;
		--it;
		x2 = (*it).first;
		y2 = (*it).second;
		
		return interpolate_basic(x1,y1, x2,y2, x);
	}

	virtual double interpolate_basic(double x1, double y1, double x2, double y2, double x) =0;

};



/*************************************************************************************************
More interesting interpolators
*************************************************************************************************/

class forwardFlatInterpolator : public Interpolator
{
public:

	double interpolate_basic(double x1, double y1, double x2, double y2, double x)
	{
		return y1;
	}
};

class backwardFlatInterpolator : public Interpolator
{
public:

	double interpolate_basic(double x1, double y1, double x2, double y2, double x)
	{
		return y2;
	}
};

class linearInterpolator : public Interpolator
{
public:

	double interpolate_basic(double x1, double y1, double x2, double y2, double x)
	{
		double y;
		if ( x1 == x2 ) 
			mcpl_error("Error in linear interp: x1 = x2");

		else
		{
//			cout << "WARNING: using a linear interp for date " << x << endl;
//			cout << "  x1 = " << x1 << " : y1 = " << y1 << endl;
//			cout << "  x2 = " << x2 << " : y2 = " << y2 << endl;

			y = ( (double(x2) - double(x)) * y1  +  (double(x) - double(x1)) * y2 ) / double(x2 - x1);

//			cout << "  y = " << y << endl;
		}
		return y;
	}
};

class logLinearInterpolator : public Interpolator
{
public:
	double interpolate_basic(double x1, double y1, double x2, double y2, double x)
	{
		double y;

		if ( x1 == x2 ) {
		
			MCPL_ERROR err("Error in linear interp: x1 = x2 = ");
			err +=  char(x2);
			throw err;
		}

		else
		{
//			cout << "WARNING: using a linear interp for date " << x << endl;
//			cout << "  x1 = " << x1 << " : y1 = " << y1 << endl;
//			cout << "  x2 = " << x2 << " : y2 = " << y2 << endl;

			y = ( (double(x2) - double(x)) * log(y1)  +  (double(x) - double(x1)) * log(y2) ) / double(x2 - x1);
			y = exp(y);

//			cout << "  y = " << y << endl;
		}
		return y;
	}

};

class varianceInterpolator : public Interpolator
{
public:

	double interpolate_basic(double x1, double y1, double x2, double y2, double x)
	{
		double y;
		if ( x1 == x2 ) {
			MCPL_ERROR err("Error in linear interp: x1 = x2 = ");
//			err +=  x2;
			throw err;
		}

		else
		{
//			cout << "WARNING: using a linear interp for date " << x << endl;
//			cout << "  x1 = " << x1 << " : y1 = " << y1 << endl;
//			cout << "  x2 = " << x2 << " : y2 = " << y2 << endl;
			
			y1 = y1*y1*x1; // sigma^2t
			y2 = y2*y2*x2;
			y = ( (x2 - x) * y1  +  (x - x1) * y2 ) / (x2 - x1);
			
			y = sqrt(y/x);

//			cout << "  y = " << y << endl;
		}
		return y;
	}
};




class SmoothDFInterpolatorData
{
    double df; //discount factor at the beginning of the segment
    double a, b, c; // parabola coefficients in y = a*x^2 + b*x + c
    DayBasis dcc;
    double getIntergralY(double x) { return a*x*x*x/3.0 + b*x*x/2.0 + c*x; } // integral of y(x) from 0 to x
public:
	SmoothDFInterpolatorData() : a(0.0), b(0.0), c(0.0), df(1.0), dcc(act_365f) {}
	SmoothDFInterpolatorData(double DF) : a(0.0), b(0.0), c(0.0), df(DF), dcc(act_365f) {}
	SmoothDFInterpolatorData(double DF, double A, double B, double C, const DayBasis DCC = act_365f) : df(DF), a(A), b(B), c(C), dcc(act_365f) {}
    double InterpolatedDF(date start, date x)
    { 
        return df*exp(-getIntergralY(dayCountFrac(dcc, start, x))); 
    } // returns discount factor corresponding to date x, to the right of date start where we assume discount factor to be DF.
    operator double() {return df;} // for flatVol in interpolatingStore
    double getDF() {return df;}
    void setFlat(double C) {a=0.0; b=0.0; c=C;}
    double getFirst() { return c; }
    void setB(double B) {b=B;}
    void setA(double A) {a=A;}
    void setDF(double DF) {df=DF;}
    double getY(double x) { return a*x*x + b*x + c; }
    double getA() {return a;}
    double getB() {return b;}
};


//-----------------------------------------------
// parabolic instantaneous forwards interp.
class SmoothDFInterpolator : public Interpolator
{
public:

    // first element of iterator must be T_Label type. second is SmoothInterpolatorData that has parabola coefficients
	template < typename T_Label , typename iterator>
	double interpolate(const T_Label & x, iterator & it)
	{
        it--; // the point is actually in the previous segment
		T_Label x1 = (*it).first;
		SmoothDFInterpolatorData y1 = (*it).second;
		return y1.InterpolatedDF(x1,x);
	}

	virtual double interpolate_basic(double x1, double y1, double x2, double y2, double x)
    {
		MCPL_ERROR err("Error in smooth interpolator: interpolate_basic should never be called ");
		throw err;
        return 0.0;
    }

};

class SmoothFwdInterpolatorData
{
	double a, b, c; // parabola coefficients in y = a*x^2 + b*x + c
	DayBasis dcc;
	double getIntergralY(double x) { return a*x*x*x / 3.0 + b*x*x / 2.0 + c*x; } // integral of y(x) from 0 to x
public:
	SmoothFwdInterpolatorData() : a(0.0), b(0.0), c(0.0), dcc(act_365f) {}
	SmoothFwdInterpolatorData(double C) : a(0.0), b(0.0), c(C) {}
	SmoothFwdInterpolatorData(double A, double B, double C, const DayBasis DCC = act_365f) : a(A), b(B), c(C), dcc(act_365f) {}

	operator double() { return c; } // for flatVol in interpolatingStore

	double getY(double x) { return a*x*x + b*x + c; }

	void setFlat(double C) { a = 0.0; b = 0.0; c = C; }
	
	void setB(double B) { b = B; }
	void setA(double A) { a = A; }
	void setC(double C) { c = C; }
	double getA() { return a; }
	double getB() { return b; }
	double getC() { return c; }
};


//-----------------------------------------------
// parabolic instantaneous forwards interp.
class SmoothFwdInterpolator : public Interpolator
{
public:

	// first element of iterator must be T_Label type. second is SmoothInterpolatorData that has parabola coefficients
	template < typename T_Label, typename iterator>
	double interpolate(const T_Label & x, iterator & it)
	{
		//it--; // the point is actually in the previous segment
		SmoothFwdInterpolatorData y1 = it->second;
		T_Label x1 = it->first;
		return y1.getY(x-x1);
	}

	virtual double interpolate_basic(double x1, double y1, double x2, double y2, double x)
	{
		MCPL_ERROR err("Error in smooth interpolator: interpolate_basic should never be called ");
		throw err;
		return 0.0;
	}

};


Handle<Interpolator> str2interpolator(char *strInterpolator);



} //namespace MCPL

#endif // MCPL_interpolators_h

