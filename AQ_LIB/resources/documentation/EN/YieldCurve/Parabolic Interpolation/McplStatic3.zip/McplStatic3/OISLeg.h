#pragma once

#ifndef MCPLOISLEG_H
#define MCPLOISLEG_H
#pragma warning ( disable : 4251 4786 ) 

#include "mcpldefs.h"
#include "mathmisc.h"
#include "option.h"
#include "Leg.h"
#include "mcDateClass/dates.h"

using namespace std;
#include<string>
#include<vector>


namespace MCPL
{

	class OISLeg : public Leg
	{	
	public :
		//constructors
		OISLeg() : Leg() {}


		// OIS leg.
		OISLeg(DIRECTIONTYPE dir, const date & start, const date & target, double notional, double spread,
			const int rollDay, ROLLTYPE rolltype, long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, CURRENCY ccy, int payDateOffsetDays_,
			MCPL::ACCRUAL_TYPE accrualType = ACCRUAL_FLAT_COMPOUNDING);

		// Clone function which creates a deep clone of cashflows
		virtual shared_ptr<Leg> CloneCashflows();

		double averageRate();

	private:

		void GenerateOISLeg ( DIRECTIONTYPE dir, const date & start, const date & target, double notional, double spread,
			const int rollDay, ROLLTYPE rolltype, long int pmtPerYear, DayBasis basis, HOLIDAYCAL hol, CURRENCY ccy, int payDateOffsetDays_, MCPL::ACCRUAL_TYPE accrualType);

	};

}

#endif // MCPLOISLEG_H
