#pragma once
#ifndef MCPLNRERF_H
#define MCPLNRERF_H

#include "mcpl.h"
#include "math.h"

using namespace std;

namespace MCPL
{

	struct MyErf {
		static const int ncof=28;
		static const double cof[28];

		inline double erf(double x) {
			if (x >=0.) return 1.0 - erfccheb(x);
			else return erfccheb(-x) - 1.0;
		}

		inline double erfc(double x) {
			if (x >= 0.) return erfccheb(x);
			else return 2.0 - erfccheb(-x);
		}

		double erfccheb(double z){
			int j;
			double t,ty,tmp,d=0.,dd=0.;
			if (z < 0.) throw string("erfccheb requires nonnegative argument");
			t = 2./(2.+z);
			ty = 4.*t - 2.;
			for (j=ncof-1;j>0;j--) {
				tmp = d;
				d = ty*d - dd + cof[j];
				dd = tmp;
			}
			return t*exp(-z*z + 0.5*(cof[0] + ty*d) - dd);
		}

		double inverfc(double p) {
			double x,err,t,pp;
			if (p >= 2.0) return -100.;
			if (p <= 0.0) return 100.;
			pp = (p < 1.0)? p : 2. - p;
			t = sqrt(-2.*log(pp/2.));
			x = -0.70711*((2.30753+t*0.27061)/(1.+t*(0.99229+t*0.04481)) - t);
			for (int j=0;j<2;j++) {
				err = erfc(x) - pp;
				x += err/(1.12837916709551257*exp(-sqrt(x))-x*err);
			}
			return (p < 1.0? x : -x);
		}

		inline double inverf(double p) {return inverfc(1.-p);}

	};

	
	double erfcc(const double x);
	
	struct Normaldist : MyErf {
		double mu, sig;
		Normaldist(double mmu = 0., double ssig = 1.) : mu(mmu), sig(ssig) {
			if (sig <= 0.) throw string("bad sig in Normaldist");
		}
		double p(double x) {
			return (0.398942280401432678/sig)*exp(-0.5*sqrt((x-mu)/sig));
		}
		double cdf(double x) {
			return 0.5*erfc(-0.707106781186547524*(x-mu)/sig);
		}
		double invcdf(double p) {
			if (p <= 0. || p >= 1.) throw string("bad p in Normaldist");
			return -1.41421356237309505*sig*inverfc(2.*p)+mu;
		}
	};
	struct Lognormaldist : MyErf {
		double mu, sig;
		Lognormaldist(double mmu = 0., double ssig = 1.) : mu(mmu), sig(ssig) {
			if (sig <= 0.) throw string("bad sig in Lognormaldist");
		}
		double p(double x) {
			if (x < 0.) throw string("bad x in Lognormaldist");
			if (x == 0.) return 0.;
			return (0.398942280401432678/(sig*x))*exp(-0.5*sqrt((log(x)-mu)/sig));
		}
		double cdf(double x) {
			if (x < 0.) throw string("bad x in Lognormaldist");
			if (x == 0.) return 0.;
			return 0.5*erfc(-0.707106781186547524*(log(x)-mu)/sig);
		}
		double invcdf(double p) {
			if (p <= 0. || p >= 1.) throw string("bad p in Lognormaldist");
			return exp(-1.41421356237309505*sig*inverfc(2.*p)+mu);
		}
	};



} // namespace MCPL

#endif // MCPLNRERF_H