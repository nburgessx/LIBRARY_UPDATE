#include"CMSSwap.h"

#include "numrec/dnr.h"

#include "numrec3/nr3.h"
#include "LinearCurvesHelpers.h"

namespace MCPL
{


	////FedFunds Basis swap no curves
	//CMSSwap::CMSSwap(DIRECTIONTYPE dir, date & start, date & mature, double notional, double FedFundsSpread,
	//	const int rollDay, ROLLTYPE rolltype, long int FFPmtsPerYear, long int FloatPmtsPerYear, DayBasis FFBasis, DayBasis FloatBasis,
	//	HOLIDAYCAL hol, CURRENCY ccy)
	//	: Swap()
	//{
	//	DIRECTIONTYPE dir2;

	//	m_notional = notional;
	//	m_coupon = 0;
	//	m_spread = FedFundsSpread;
	//	m_direction = dir;

	//	p_Leg2ForecastCurve = p_DiscountCurve = p_ForecastCurve = NULL;
	//	p_CMSvols = NULL;

	//	dir2 = dir == PAY ? RECEIVE : PAY;

	//	int pmtDateOffsetDays = 2;
	//	if (ccy == EUR)
	//		pmtDateOffsetDays = 1;
	//	else if (ccy == GBP)
	//		pmtDateOffsetDays = 0;

	//	addLeg(Handle<OISLeg>(new OISLeg(dir, start, mature, notional, FedFundsSpread, rollDay, rolltype, FFPmtsPerYear, FFBasis, hol, ccy, pmtDateOffsetDays, MCPL::ACCRUAL_AVERAGE)));
	//	addLeg(Handle<Leg>(new Leg(dir2, MC_FLOAT, start, mature, notional, 0, FloatPmtsPerYear, FloatBasis, hol, MCPL::ROLL_BACKWARD, ccy, MCPL::ModelNone, mixing_model(), date(0), false, pmtDateOffsetDays)));

	//}

	// As above (i.e. lets you specify the two leg types ) and also alows for index tenors 
	// which differ from 12/pmtsperyear
	// i.e. for CMS swaps.
	CMSSwap::CMSSwap(PAYTYPE sideOneType, PAYTYPE sideTwoType, date & start, date & mature,
		double notional, double spread1, double spread2,
		long int leg1PmtsPerYear, long int leg2PmtsPerYear, long int leg1TenorMnths,
		long int leg2TenorMnths, SwapType CMStype1, SwapType CMStype2,
		DayBasis leg1Basis, DayBasis leg2Basis, HOLIDAYCAL hol, ROLLTYPE rolltype, CURRENCY ccy,
		OptionModel CMSmodel)
	{

		m_notional = notional;
		m_coupon = spread1;
		m_spread = spread2;
		m_direction = PAY;
		m_hols = hol;
		m_effectiveDate = start;
		m_matureDate = mature;
		m_adjMatureDate = m_matureDate;
		m_adjMatureDate.rollFwd(hol, true);
		m_roll = mature.day();
		m_longCoupon = false;


		addLeg(Handle<Leg>(new Leg(PAY, sideOneType, start, mature, notional, spread1, leg1PmtsPerYear, leg1TenorMnths,
			CMStype1, leg1Basis, hol, rolltype, ccy, CMSmodel)));
		addLeg(Handle<Leg>(new Leg(RECEIVE, sideTwoType, start, mature, notional, spread2, leg2PmtsPerYear, leg2TenorMnths,
			CMStype2, leg2Basis, hol, rolltype, ccy, CMSmodel)));

		/*p_DiscountCurve = discountCurve;
		p_ForecastCurve = leg1ForecastCurve;
		p_Leg2ForecastCurve = leg2ForecastCurve;
		p_CMSvols = pCMSvols;
		this->setCurves();*/
	}

	// Solve for spread. legToSolveFor has to be either 0 or 1.
	/*double CMSSwap::Solve(double dPresentValue)
	{

		double dSwapBpv = 0.0;
		double dTarget = 0.0;

		Handle<Leg> leg = getLeg(1);
		double  dSwapValue = Price();
		dSwapBpv = leg->BasisPointValue() * leg->getNotional();
		dTarget = (dPresentValue - dSwapValue) / dSwapBpv + leg->getSpread();

		return dTarget;
	}*/


	double CMSSwap::SolveForSpread(double dPresentValue)
	{
		double x1 = -.003; //30bp
		double x2 = .003;
		double spreadSoln;

		shared_ptr<Swap> fitswap =  CloneCashflows();
		auto fn = [&](double spread){ 
			fitswap->getLeg(1)->setSpread(spread);  
			return fitswap->Price() - dPresentValue; 
		};

		if (NUMREC::zbrac(fn, &x1, &x2) != 0)
			spreadSoln = linearFitter(fn, x1, x2, 1e-8); // Upper and lower brackets for alpha (0% , 100%)!
		else
			mcpl_error("Cannot find a solution for spread");

		return spreadSoln;
	}
} //end namespace MCPL