#include"PPCurves.h"



namespace MCPL
{

  void PPCurves::clear()
  {
	m_labels.clear();

    m_base->clear();

    m_up.clear();
    m_dn.clear();
    m_up_dependents.clear();
    m_dn_dependents.clear();
    m_upup.clear();
    m_updn.clear();
    m_dnup.clear();
    m_dndn.clear();
  }

  void PPCurves::resize(int size)
  {
	m_labels.resize(size);

    m_up.resize(size);
    m_dn.resize(size);
    m_up_dependents.resize(size);
    m_dn_dependents.resize(size);
	if (_usingGammaCurves)
	{
		m_upup.resize(size);
		m_updn.resize(size);
		m_dnup.resize(size);
		m_dndn.resize(size);
	}
  }

  void PPCurves::shiftCurve( double dR , DayBasis basis )
  {
    int curves = size();
    base()->shiftCurve(dR, basis);
    for ( int i=0 ; i < curves; ++i )
    {
      up(i)->shiftCurve(dR, basis);
      dn(i)->shiftCurve(dR, basis);
	  if (_usingGammaCurves)
	  {
		  upup(i)->shiftCurve(dR, basis);
		  updn(i)->shiftCurve(dR, basis);
		  dnup(i)->shiftCurve(dR, basis);
		  dndn(i)->shiftCurve(dR, basis);
	  }
    }
  }

  //***********************************************************************************************************
  //***********************************************************************************************************
  /*  Cap Vols */

  // crate PP vols from a cap vol curve
  PPCapVols::PPCapVols( CapVolCurve & curve ) : m_ppsize(0.000001), m_clean(false)
  {
    int n_vols = curve.size();
    m_base = curve;
    //	recreate_ppcurves();
  }

  // crate PP vols from a cap vol curve
  void PPCapVols::recreate_ppcurves()
  {
    int n_vols = m_base.size();

    // resize the vectors
    m_up.clear();
    m_dn.clear();

    shared_ptr<vector<long>> dates = m_base.getLabels();

    for ( int i=0 ; i < n_vols ; ++i )
    {
		double baseVol = m_base.get((*dates)[i]);

      m_up.push_back( m_base );
      m_up.back().set((*dates)[i] , baseVol + m_ppsize );

      m_dn.push_back( m_base );
	  m_dn.back().set((*dates)[i], baseVol - m_ppsize);

    }

    m_clean = true;

  }

  void PPCapVols::clear()
  {
    m_base.clear();
    m_up.clear();
    m_dn.clear();
    m_clean = false;
  }

  void PPCapVols::resize(int size)
  {
    m_up.resize(size);
    m_dn.resize(size);
    m_clean = false;
  }

  //***********************************************************************************************************
  //***********************************************************************************************************
  /*  Vols */

  void PPVols::clear()
  {
    m_base->clear();
    m_up.clear();
    m_dn.clear();
    m_clean = false;
  }

  void PPVols::resize(int size)
  {
    m_up.resize(size);
    m_dn.resize(size);
    m_clean = false;
  }

  // crate PP vols from a cap vol curve
  PPVols::PPVols(shared_ptr<VolatilityGrid> grid, double ppsize) : m_ppsize(ppsize), m_clean(false)
  {
    VolatilityGrid::data_cube::tri size;
    grid->size( size );

    m_nvols = size.first * size.second * size.third;
    m_base = grid;
  }


  // create PP vols from a cap vol curve
  void PPVols::recreate_ppcurves()
  {
    //	int n_vols = m_base.size();

    // resize the vectors
    m_up.clear();
    m_dn.clear();

    //	vector<long> dates = m_base.getLabels();

    for ( unsigned i=0 ; i < m_nvols ; ++i )
    {
      double baseVol = (*m_base)( i );

	  m_up.push_back(shared_ptr<VolatilityGrid>(new VolatilityGrid(*m_base)));
      (*m_up.back())(i) =  baseVol + m_ppsize ;
      //int test = m_up.back()(i) - baseVol;

	  m_dn.push_back(shared_ptr<VolatilityGrid>(new VolatilityGrid(*m_base)));
      (*m_dn.back())(i) = baseVol - m_ppsize;

    }

    m_clean = true;

  }


} // namespace MCPL