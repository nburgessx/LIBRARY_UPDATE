#include"parabolicCurve.h"

#include "numrec/dnrutil.h"


namespace MCPL
{
	double ParabolicCurve::get (const long& dLabel) 
	{
		if (m_appearAsFlat)
			return swapData::get(dLabel);
		else
			return SmoothCurve::get(dLabel);
	}

	bool ParabolicCurve::instrumentsChanged(const vector<Handle<CurveRateHelper>> &Instruments)
	{
		if ( Instruments.size() != _instruments.size() )
			return true;

		for ( unsigned int i=0 ; i < _instruments.size() ; i++ )
		{
			//Just check that we are refering to same object
			if ( _instruments[i] != Instruments[i] )
				return true;
		}

		return false;
	}

	//========================================================================================================================

	void ParabolicCurve::create(	const vector<Handle<CurveRateHelper>> &Instruments , 
		date & today, 
		CURRENCY ccy, 
		Handle<RatesCurve> swapDiscountCurve,
		bool IsOIS)
	{
		m_appearAsFlat = true;
		m_IsOIS = IsOIS;

		vector<Handle<CurveRateHelper>> sortedInsts(Instruments);
		sort(sortedInsts.begin(), sortedInsts.end(), [](Handle<CurveRateHelper>& h1, Handle<CurveRateHelper>& h2) -> bool
			{
				if (h1->getType() == h2->getType() && h1->getType() == CurveRateHelper::CASH)
					return h1->getAdjMaturityDate() < h2->getAdjMaturityDate();
				if (h1->getType() == CurveRateHelper::CASH)
					return true;
				if (h2->getType() == CurveRateHelper::CASH)
					return false;

				return h1->getAdjMaturityDate() < h2->getAdjMaturityDate();
			});

		if ( !swapDiscountCurve )
		{
			m_swapsDiscountCurve = Handle<RatesCurve>(this, null_deleter());
		}
		else
		{
			m_swapsDiscountCurve = swapDiscountCurve;
			m_swapsDiscountCurve->addDependent(Handle<RatesCurve>(this, null_deleter()));
		}
		m_dependentCurves.clear();


		if ( (m_today != today) 
			|| ( ccy != m_ccy )
			|| instrumentsChanged(sortedInsts))
		{

			_instruments = sortedInsts;

			set_currency_defaults(ccy);

			m_today = today;
			m_spot = spot(today, ccy);

			swapData::clear();
			SmoothCurve::clear();
			calculateDates();
			calculateCurve();
		} 
		else 
		{
			_instruments = sortedInsts;
			swapData::clear();
			SmoothCurve::clear();
			calculateCurve();
		}
	}

	void ParabolicCurve::addDependent(Handle<RatesCurve> dependentCurve)
	{
		m_dependentCurves.push_back(dependentCurve);
	}


	void ParabolicCurve::calculateDates()
	{
		auto it = find_if(_instruments.begin(), _instruments.end(), [](Handle<CurveRateHelper>& h) { return h->getType() == CurveRateHelper::CASH && (h->getMaturityDate() - h->getStartDate() < 7); });
		_ONCash = ( it != _instruments.end() ) ? *it : Handle<CurveRateHelper>(nullptr);


		it = find_if(_instruments.begin(), _instruments.end(), [](Handle<CurveRateHelper>& h) { return h->getType() == CurveRateHelper::CASH && (h->getMaturityDate() - h->getStartDate() >= 7); });
		_Cash = ( it != _instruments.end() ) ? *it : _ONCash;

		if (!_ONCash && !_Cash)
			mcpl_error("You must supply at least one cash instrument to ParabolicCurve");

		if ( !_ONCash )
			mcpl_error("You must supply one cash rate out of spot with < 1w tenor to ParabolicCurve (i.e. O/N)");

		//Find all the futures.
		_futures.clear();
		_firstNonCashIndex = 0;
		for ( auto it = _instruments.begin() ; it != _instruments.end() ; it++ )
		{
			if ( (*it)->getType() != CurveRateHelper::CASH && (*it)->UseInCurve && _firstNonCashIndex == 0 )
				_firstNonCashIndex = it - _instruments.begin();
			
			if ( ( (*it)->getType() == CurveRateHelper::FUTURE) && ((*it)->UseInCurve) )
			{
				_futures.push_back(*it);
			}

			if ((*it)->getType() == CurveRateHelper::BUNDLE)
			{
				Handle<BundleRateHelper> bundle = dynamic_pointer_cast<BundleRateHelper>((*it));
				for (auto& f : *(bundle->getFutures()))
					_futures.push_back(f);
			}
		}

	}

	void ParabolicCurve::addSmoothSegment(date start, double df)
	{
		// make the current segment the previous one
		m_prevSmoothDate = m_currSmoothDate;
		m_prevSmoothData = m_currSmoothData;
		// add the new segment
		m_currSmoothDate = start;
		m_currSmoothData = SmoothDFInterpolatorData(df, 0.0, 0.0, 0.0, act_365f);
		SmoothCurve::set(m_currSmoothDate, m_currSmoothData);

		// update prev smooth segment with correct flat rate
		if (fabs(m_prevSmoothData.getB()) < 1e-14 && (m_prevSmoothDate != m_currSmoothDate) )
		{   // only do it if it is flat segment. should be continuous rate
			double smoothSegmentFlatRate = log(m_prevSmoothData.getDF()/m_currSmoothData.getDF()) / dayCountFrac(act_365f, m_prevSmoothDate, m_currSmoothDate);
			m_prevSmoothData.setFlat(smoothSegmentFlatRate);
			SmoothCurve::set(m_prevSmoothDate, m_prevSmoothData );
		}
	}

	// convert simply compounded rate over period DCF to equivalent simply compounded rate over smaller compounding period dcf
	double ParabolicCurve::convertSimpleRate(double f, double DCF, double dcf)
	{
		return (pow(1.0+f*DCF, -DCF/dcf) - 1.0) / dcf;
	}

	void ParabolicCurve::calculateCurve()
	{
		discountCurve cashCurve;

		// bootstrap cash part of the curve
		// initialise curve, DF==1
		cashCurve.set(m_today , 1.0 );  
		swapData::set(m_today , 1.0 );
		m_lastFittedDate = m_today;

		double spotDF = 1.0;

		// add first point to smoothCurve

		m_prevSmoothDate = m_today;
		m_prevSmoothData = SmoothDFInterpolatorData(1.0, 0.0, 0.0, 0.0, act_365f);
		if ( m_spot > m_today)
		{
			double dcf = dayCountFrac(m_basis, m_today, m_spot);
			spotDF = 1.0 / (1.0 + _ONCash->getTargetRate()*dcf );
			double smoothSegmentFlatRate = log(m_prevSmoothData.getDF()/spotDF) / dayCountFrac(act_365f, m_prevSmoothDate, m_spot);
			m_prevSmoothData.setFlat(smoothSegmentFlatRate);
		}
		else
		{
			m_prevSmoothData.setFlat(_Cash->getTargetRate());
		}
		SmoothCurve::set(m_prevSmoothDate, m_prevSmoothData);


		// bootstrap spot date point
		cashCurve.set(m_spot , spotDF); 
		swapData::set(m_spot , spotDF);
		m_lastFittedDate = m_spot;
		// add the same point to smoothCurve
		m_currSmoothDate = m_today;
		m_currSmoothData = m_prevSmoothData;
		addSmoothSegment(m_spot , spotDF);

		date cashDateAfterIMM1(0); // date of the first cash rate after the first futures date
		date cashDateAfterIMM2(0); // non-zero if cash covers second IMM (in case of 6m cash point used for Risk curve)

		double dcf = dayCountFrac( m_basis, m_spot, _Cash->getAdjMaturityDate() );
		double df = spotDF/(1 + _Cash->getTargetRate() * dcf );
		cashCurve.set(_Cash->getAdjMaturityDate(), df );
		swapData::set(_Cash->getAdjMaturityDate(), df );
		m_lastFittedDate = __max( _Cash->getAdjMaturityDate(),m_spot) ;
		if ((long)cashDateAfterIMM1 == 0l)
			if (_futures.size())
			{
				if (_Cash->getAdjMaturityDate() >= _futures[0]->getStartDate())
					cashDateAfterIMM1 = _Cash->getAdjMaturityDate();
			}
			else
				cashDateAfterIMM1 = _Cash->getAdjMaturityDate();
		if ((long)cashDateAfterIMM2 == 0l && (long)cashDateAfterIMM1 > 0l)
			if (_futures.size())
			{
				if (_Cash->getAdjMaturityDate() >= addBusinessMonths(_futures[0]->getStartDate(),3,liborHolidays(m_ccy)) )
					cashDateAfterIMM2 = _Cash->getAdjMaturityDate();
			}
			else
				cashDateAfterIMM2 = _Cash->getAdjMaturityDate();
		// add the same point to smoothCurve
		addSmoothSegment(m_lastFittedDate, df);

		// to cover the case when on IMM date 3M cash falls short of start of next future.
		//        if ((long)cashDateAfterIMM1 == 0l && m_futuresStarts.size())
		//            cashDateAfterIMM1 = m_lastFittedDate;

		// set the stub discount factor by taking the DF at first cash maturity after IMM1 date and 
		//   interpolating back to IMM1 using the flat rate assumption and the first futures rate
		// OR if cash ends before futures, extrapolate last cash rate till first future
		double immDF = 0.0;
		if (_futures.size())
		{
			swapData::clear();
			SmoothCurve::clear();
			swapData::set(m_today , 1.0 );
			swapData::set(m_spot , spotDF );
			// add the first point to SmoothCurve
			m_prevSmoothDate = m_today;
			m_prevSmoothData = SmoothDFInterpolatorData(1.0, 0.0, 0.0, 0.0, act_365f);
			double smoothSegmentFlatRate = log(m_prevSmoothData.getDF()/spotDF) / dayCountFrac(act_365f, m_prevSmoothDate, m_spot);
			m_prevSmoothData.setFlat(smoothSegmentFlatRate);
			SmoothCurve::set(m_prevSmoothDate, m_prevSmoothData);
			// add the same point to smoothCurve
			m_currSmoothDate = m_today;
			m_currSmoothData = m_prevSmoothData;
			addSmoothSegment(m_spot , spotDF);

			// working out stub DF
			if ((long)cashDateAfterIMM2 > 0l && (long)cashDateAfterIMM1 > 0l)
			{   // last cash date after second IMM
				double cashDF = cashCurve.get(cashDateAfterIMM2);
				double ffRate = _futures[0]->getTargetRate(); // first futs rate
				double sfRate = _futures[1]->getTargetRate(); // second futs rate
				discountCurve futCurve;
				futCurve.set(_futures[0]->getStartDate(), 1.0);
				futCurve.set(_futures[0]->getAdjMaturityDate(), 1.0/(1+ffRate*_futures[0]->getFutureHandle()->getDCF()) );
				futCurve.set(_futures[1]->getAdjMaturityDate(), 1.0/(1+ffRate*_futures[0]->getFutureHandle()->getDCF())/(1+sfRate*_futures[1]->getFutureHandle()->getDCF()) );
				immDF = cashDF / futCurve.get(cashDateAfterIMM2);
			}
			else
				if ((long)cashDateAfterIMM1 > 0l)
				{   // last cash date after first IMM
					double cashDF = cashCurve.get(cashDateAfterIMM1);
					double ffRate = _futures[0]->getTargetRate(); // first futs rate
					discountCurve futCurve;
					futCurve.set(_futures[0]->getStartDate(), 1.0);
					futCurve.set(_futures[0]->getAdjMaturityDate(), 1.0/(1+ffRate*_futures[0]->getFutureHandle()->getDCF()) );
					immDF = cashDF / futCurve.get(cashDateAfterIMM1);
				}
				else
				{   // last cash date before first future
					double cashDF = cashCurve.get(m_lastFittedDate);

					double DF1 = cashCurve.get(m_lastFittedDate-1);
					double DF2 = cashCurve.get(m_lastFittedDate);
					double dcf = dayCountFrac(act_365f, m_lastFittedDate-1, m_lastFittedDate);
					double rate = dcf==0 ? 0 : zero(DF2/DF1, dcf);
					immDF = cashDF / (1 + rate*dayCountFrac(act_365f, m_lastFittedDate, _futures[0]->getStartDate()) );
				}

				swapData::set(_futures[0]->getStartDate(), immDF );
				// add the same point to smoothCurve
				addSmoothSegment(_futures[0]->getStartDate(), immDF);
				m_lastFittedDate = _futures[0]->getStartDate();
		}
		else
		{
			// if no futures, just use the cash curve. do nothing as we extended both curves simultaneously up to now.
		}

		// bootstrap futures
		for (unsigned int i=0; i<_futures.size(); i++)
		{
			double ffRate = _futures[i]->getTargetRate();
			immDF /= (1.0 + ffRate * _futures[i]->getFutureHandle()->getDCF()); // the first immDF was set above!
			m_lastFittedDate = _futures[i]->getAdjMaturityDate();
			swapData::set(m_lastFittedDate, immDF);
			// add the same point to smoothCurve
			addSmoothSegment(m_lastFittedDate, immDF);
			// if there is gap till next future start, extrapolate till next IMM
			if (i<(_futures.size() - 1) && _futures[i + 1]->getStartDate() > _futures[i]->getAdjMaturityDate())
			{
				double dcf = dayCountFrac(act_365f, _futures[i]->getStartDate() , _futures[i]->getAdjMaturityDate());
				double r = log(1.0 + ffRate*dcf)/dcf;// continuously compounded rate
				m_lastFittedDate = _futures[i + 1]->getStartDate();
				dcf = dayCountFrac(act_365f, _futures[i]->getAdjMaturityDate(), m_lastFittedDate);
				immDF /= exp(r * dcf);
				swapData::set(m_lastFittedDate, immDF);
				addSmoothSegment(m_lastFittedDate, immDF);
			}
			// if there is overlap, re-calculate immDF for the next future bootstrap
			else if (i<(_futures.size() - 1) && _futures[i + 1]->getStartDate() < _futures[i]->getAdjMaturityDate())
			{
				double dcf = dayCountFrac(act_365f, _futures[i]->getStartDate(), _futures[i]->getAdjMaturityDate());
				double r = log(1.0 + ffRate*dcf)/dcf;// continuously compounded rate
				dcf = dayCountFrac(act_365f, _futures[i + 1]->getStartDate(), _futures[i]->getAdjMaturityDate());
				immDF *= exp(r * dcf);
			}
		}

		
		// bootstrap instruments
		for ( unsigned int i=0 ; i < _instruments.size() ; i++ )
		{
			if ( _instruments[i]->getType() != CurveRateHelper::CASH && _instruments[i]->getLastDate() > (m_lastFittedDate+5) ) // Add 5 to not make fit of instrument dependant on just one day.
			{
				if (!fitParSwap(i) ) // fit instrument number i
					break;
				else
					m_lastFittedDate = _instruments[i]->getLastDate();
			}
		}
		
		

		if (_instruments.size())
		{
			// update smooth discount factor of last segment
			m_currSmoothData.setDF(m_prevSmoothData.InterpolatedDF(m_prevSmoothDate, m_currSmoothDate));
			// final segment is flat to infinity
			m_currSmoothData.setFlat(m_prevSmoothData.getY(dayCountFrac(act_365f, m_prevSmoothDate, m_currSmoothDate)));
			SmoothCurve::set(m_currSmoothDate, m_currSmoothData);
			// extend for 1 extra week. to cover 1 day delay of payment on OIS
			m_currSmoothData.setDF(m_currSmoothData.InterpolatedDF(m_currSmoothDate, m_currSmoothDate+7));
			m_currSmoothData.setFlat(m_currSmoothData.getY(dayCountFrac(act_365f, m_currSmoothDate, m_currSmoothDate+7)));
			SmoothCurve::set(m_currSmoothDate+7, m_currSmoothData);
		}

		

	}


	bool ParabolicCurve::fitParSwap(int index) // index is the swap index we are working on fitting now
	{
		//ParabolicCurveFitFn::index = index;
		shared_ptr<ParabolicCurve> fitcurve = shared_ptr<ParabolicCurve>(this, null_deleter());

		// extend the flat forwards curve using this swap
		double x1= -0.0005;
		double x2=  0.003;
		m_appearAsFlat = true;
		//double flatSegmentRate = linearFitter( ParabolicCurveFitFn::func_linear , x1, x2, max(1e-7 /*1/1000th of bp*/, _instruments[index]->RateFitTolerance) ); // returns continuously compounded flat rate for the segment
		double flatSegmentRate = linearFitter([&](double a){return func_linear2(fitcurve, index, a); }, x1, x2, max(1e-7 /*1/1000th of bp*/, _instruments[index]->RateFitTolerance)); // returns continuously compounded flat rate for the segment

		// extend the smooth forwards curve using this swap
		m_appearAsFlat = false;
		m_nextSmoothDate = _instruments[index]->getLastDate();
		double lastDF = swapData::get(m_nextSmoothDate);
		// now make the dummy new current segment in the curve, but not move curr/prev just yet
		SmoothCurve::set(m_nextSmoothDate, SmoothDFInterpolatorData(lastDF, 0.0, 0.0, 0.0, act_365f));
		// re-fit the previous smooth forwards segment
		double xguess = 0.0;
		double funcmin = 0.0;
		int maxiterations = 5;

		if (index > (int)_firstNonCashIndex) // not the first instrument after cash
		{
			double dcf = dayCountFrac(act_365f, m_prevSmoothDate, m_currSmoothDate);
			x1= -5.0/dcf;// minus 500%
			x2=  5.0/dcf;// plus  500%
			xguess = m_prevSmoothData.getA(); // guessing the previously fit quadratic coefficient
			//			NUMREC::brent(x1, xguess, x2, ParabolicCurveFitFn::func_smoothPrev, max(1e-7 /*1/1000th of bp*/, m_swapTolerances[index]), &funcmin);
			//funcmin = quadraticFitter( ParabolicCurveFitFn::func_smoothPrev, x1, x2, max(1e-7 /*1/1000th of bp*/, _instruments[index]->RateFitTolerance), maxiterations );
			funcmin = quadraticFitter([&](double a){return func_smoothPrev2(fitcurve, index, a); }, x1, x2, max(1e-7 /*1/1000th of bp*/, _instruments[index]->RateFitTolerance), maxiterations);
		}
		else
		{
		}
		// fit the current smooth forwards segment using this swap. guessing the quadratic coefficient a in f(t)=a*t*t+b*t+c
		double dcf = dayCountFrac(act_365f, m_currSmoothDate, m_nextSmoothDate);
		x1= -5.0/dcf;// minus 500%
		x2=  5.0/dcf;// plus  500%
		xguess = 0.0; // guessing the linear segment
		//		NUMREC::brent(x1, xguess, x2, ParabolicCurveFitFn::func_smoothCurr, max(1e-7 /*1/1000th of bp*/, m_swapTolerances[index]), &funcmin);
		//funcmin = quadraticFitter( ParabolicCurveFitFn::func_smoothCurr, x1, x2, max(1e-7 /*1/1000th of bp*/, _instruments[index]->RateFitTolerance), maxiterations );
		funcmin = quadraticFitter([&](double a){return func_smoothCurr2(fitcurve, index, a); }, x1, x2, max(1e-7 /*1/1000th of bp*/, _instruments[index]->RateFitTolerance), maxiterations);
		// now move prev to what used to be curr
		addSmoothSegment( _instruments[index]->getLastDate(), lastDF);

		return true;
	}

	double ParabolicCurve::func_linear2(shared_ptr<ParabolicCurve> fitcurve, unsigned int index, double flatSegmentRate )
	{

		// update the curve
		double dcf = dayCountFrac(act_365f, fitcurve->m_lastFittedDate, fitcurve->_instruments[index]->getLastDate());
		double dfLast = fitcurve->swapData::get(fitcurve->m_lastFittedDate);
		double dfFwd = exp(-flatSegmentRate*dcf); // assume the flatSegmentRate is continuously compounded rate
		fitcurve->swapData::set(fitcurve->_instruments[index]->getLastDate(), dfLast * dfFwd);
		// re-price the swap
		if (fitcurve->m_swapsDiscountCurve) // Discount using suppplied discount curve rather than the curve being built
		{
			fitcurve->_instruments[index]->SetCurves(fitcurve->m_swapsDiscountCurve, fitcurve);
		}
		else
		{
			fitcurve->_instruments[index]->SetCurves(fitcurve, fitcurve);
		}
		// careful. we use swaps with first coupon unfixed when we build the curve. then we hedge swaps with first fixing and see risk in the front end. this is to match apollo
		/*if (fitcurve->m_firstFixRate != 0.0)
		fitcurve->m_swapCashflows[index].fixFirst(fitcurve->m_firstFixRate);*/
		double swapRate = fitcurve->_instruments[index]->getRate();
		double targetRate = fitcurve->_instruments[index]->getTargetRate();

		return  (swapRate - targetRate);
	}

	double ParabolicCurve::func_smoothPrev2(shared_ptr<ParabolicCurve> fitcurve, unsigned int index, double a)
	{//re-fit the previous parabolic segment replacing the condition at the end from zero derivative to mid-rate between flat segments
		double prevStartRate = fitcurve->m_prevSmoothData.getFirst();
		double prevDCF = dayCountFrac(act_365f, fitcurve->m_prevSmoothDate, fitcurve->m_currSmoothDate);
		double currDCF = dayCountFrac(act_365f, fitcurve->m_currSmoothDate, fitcurve->m_nextSmoothDate);
		double prevFlatRate = log(fitcurve->swapData::get(fitcurve->m_prevSmoothDate) / fitcurve->swapData::get(fitcurve->m_currSmoothDate)) / prevDCF;
		double currFlatRate = log(fitcurve->swapData::get(fitcurve->m_currSmoothDate) / fitcurve->swapData::get(fitcurve->m_nextSmoothDate)) / currDCF;
		// TODO should be duration-weighted using discount curve?
		double b = ((prevFlatRate*currDCF + currFlatRate*prevDCF) / (prevDCF + currDCF) - prevStartRate) / prevDCF - a*prevDCF;
		fitcurve->m_prevSmoothData.setA(a);
		fitcurve->m_prevSmoothData.setB(b);
		// keeping C unchanged

		// update the curve, prev segment parabola
		fitcurve->SmoothCurve::set(fitcurve->m_prevSmoothDate, fitcurve->m_prevSmoothData);
		// update the curve, current segment smooth discount factor
		fitcurve->m_currSmoothData.setDF(fitcurve->m_prevSmoothData.InterpolatedDF(fitcurve->m_prevSmoothDate, fitcurve->m_currSmoothDate));
		fitcurve->SmoothCurve::set(fitcurve->m_currSmoothDate, fitcurve->m_currSmoothData);

		// re-price the swap
		if (fitcurve->m_swapsDiscountCurve) // Discount using suppplied discount curve rather than the curve being built
		{
			fitcurve->_instruments[index - 1]->SetCurves(fitcurve->m_swapsDiscountCurve, fitcurve);
		}
		else
		{
			fitcurve->_instruments[index - 1]->SetCurves(fitcurve, fitcurve);
		}
		/*if (fitcurve->m_firstFixRate != 0.0)
		fitcurve->m_swapCashflows[index-1].fixFirst(fitcurve->m_firstFixRate);*/
		double swapRate = fitcurve->_instruments[index - 1]->getRate();
		double targetRate = fitcurve->_instruments[index - 1]->getTargetRate();

		return  (swapRate - targetRate);
	}

	double ParabolicCurve::func_smoothCurr2(shared_ptr<ParabolicCurve> fitcurve, unsigned int index, double a)
	{
		// fit the current segment as if it is the new parabolic segment
		// guessing the first parabolic coefficient a
		double prevEndRate = fitcurve->m_prevSmoothData.getY(dayCountFrac(act_365f, fitcurve->m_prevSmoothDate, fitcurve->m_currSmoothDate));
		double c = prevEndRate;
		double currDCF = dayCountFrac(act_365f, fitcurve->m_currSmoothDate, fitcurve->m_nextSmoothDate);
		if (!index) // first swap after futures
		{
			double prevDCF = dayCountFrac(act_365f, fitcurve->m_prevSmoothDate, fitcurve->m_currSmoothDate);
			double currFlatRate = log(fitcurve->swapData::get(fitcurve->m_currSmoothDate) / fitcurve->swapData::get(fitcurve->m_nextSmoothDate)) / currDCF;
			double prevFlatRate = prevDCF == 0 ? currFlatRate : log(fitcurve->swapData::get(fitcurve->m_prevSmoothDate) / fitcurve->swapData::get(fitcurve->m_currSmoothDate)) / prevDCF;
			c = (currFlatRate * prevDCF + prevFlatRate * currDCF) / (currDCF + prevDCF);
		}
		double b = -2.0*a*currDCF; // D(Y)=0 @ x=currDCF
		// update parabola
		fitcurve->m_currSmoothData.setFlat(c);
		fitcurve->m_currSmoothData.setA(a);
		fitcurve->m_currSmoothData.setB(b);

		// update the curve
		fitcurve->SmoothCurve::set(fitcurve->m_currSmoothDate, fitcurve->m_currSmoothData);

		// Update next DF if we are fitting the last swap.
		if (index == fitcurve->_instruments.size() - 1)
		{
			// update smooth discount factor of last segment
			double lastDF = fitcurve->m_currSmoothData.InterpolatedDF(fitcurve->m_currSmoothDate, fitcurve->m_nextSmoothDate);
			fitcurve->SmoothCurve::set(fitcurve->m_nextSmoothDate, SmoothDFInterpolatorData(lastDF, 0.0, 0.0, 0.0, act_365f));
		}

		// re-price the swap
		if (fitcurve->m_swapsDiscountCurve) // Discount using suppplied discount curve rather than the curve being built
		{
			fitcurve->_instruments[index]->SetCurves(fitcurve->m_swapsDiscountCurve, fitcurve);
		}
		else
		{
			fitcurve->_instruments[index]->SetCurves(fitcurve, fitcurve);
		}
		// careful! we use swaps with first coupon unfixed when we build the curve. then we hedge swaps with first fixing and see risk in the front end. this is to match apollo
		/*if (fitcurve->m_firstFixRate != 0.0)
		fitcurve->m_swapCashflows[index].fixFirst(fitcurve->m_firstFixRate);*/
		double swapRate = fitcurve->_instruments[index]->getRate();
		double targetRate = fitcurve->_instruments[index]->getTargetRate();

		return  (swapRate - targetRate);
	}

	void ParabolicCurve::set_currency_defaults(CURRENCY ccy)
	{
		m_ccy = ccy;

		switch ( ccy )
		{
		case USD: case EUR: case CHF: case JPY:
			m_basis = act_360;
			break;
		case GBP:
			m_basis = act_365f;
			break;
		default:
			mcpl_error(std::string("This currency does not have a money basis defined in parabolicCurve.") );
		}

	}



	// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
	Handle<PPCurves> ParabolicCurve::create_PPCurves( double pp_val, bool CalculateGammaCurves)
	{
		Handle<PPCurves> pp_curves = Handle<PPCurves>(new PPCurves());
		pp_curves->setUsingGamma(CalculateGammaCurves);

		int nHedges =   _instruments.size() ; 

		pp_curves->resize( nHedges ); 
		pp_curves->set_ppsize( pp_val/100.0 ); // set the perturb size in factor (i.e. 1 = 1%)

		pp_curves->base() = Handle<RatesCurve>(new ParabolicCurve(*this));

		//unsigned int i=0;
		// up
		for ( auto it = _instruments.begin() ; it != _instruments.end() ; it++ )
		{
			unsigned int i = it - _instruments.begin();
			(*it)->perturbUp(pp_val / 100.0);
			pp_curves->label(i) = (*it)->getLabel();
			partialClear();
			calculateCurve();
			pp_curves->up(i)= Handle<RatesCurve>(new ParabolicCurve(*this));

			//for (auto it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
			for (auto depCrv : m_dependentCurves)
			{
				/*(*it2)->calculateCurve();
				pp_curves->up_dependents(i)[*it2] = Handle<RatesCurve>(new ParabolicCurve(*dynamic_pointer_cast<ParabolicCurve>(*it2)));*/
				auto depCrvClone = depCrv->clone();
				depCrvClone->calculateCurve();
				pp_curves->up_dependents(i)[depCrv] = depCrvClone;
			}
			(*it)->perturbDown(pp_val / 100.0);
		}

		// dn
		for ( auto it = _instruments.begin(); it != _instruments.end(); it++)
		{
			unsigned int i = it - _instruments.begin();
			(*it)->perturbDown(pp_val / 100.0);
			pp_curves->label(i) = (*it)->getLabel();
			partialClear();
			calculateCurve();
			pp_curves->dn(i)= Handle<RatesCurve>(new ParabolicCurve(*this));

			for (auto depCrv : m_dependentCurves)
			{
				auto depCrvClone = depCrv->clone();
				depCrvClone->calculateCurve();
				pp_curves->dn_dependents(i)[depCrv] = depCrvClone;
			}
			(*it)->perturbUp(pp_val / 100.0);
		}


		if (CalculateGammaCurves)
		{
			//upup
			for ( auto it = _instruments.begin(); it != _instruments.end(); it++)
				(*it)->perturbUp(pp_val / 100.0);

			// up
			for ( auto it = _instruments.begin(); it != _instruments.end(); it++)
			{
				unsigned int i = it - _instruments.begin();
				(*it)->perturbUp(pp_val / 100.0);
				pp_curves->label(i) = (*it)->getLabel();
				partialClear();
				calculateCurve();
				pp_curves->upup(i)= Handle<RatesCurve>(new ParabolicCurve(*this));

				/*for (vector<Handle<ParabolicCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
				{
				(*it2)->calculateCurve();
				pp_curves->up_dependents(i)[*it2] = Handle<ParabolicCurve>(new ParabolicCurve(*(*it2)));
				}*/
				(*it)->perturbDown(pp_val / 100.0);
			}

			// dn
			for (auto it = _instruments.begin(); it != _instruments.end(); it++)
			{
				unsigned int i = it - _instruments.begin();
				(*it)->perturbDown(pp_val/100.0);
				pp_curves->label(i) = (*it)->getLabel();
				partialClear();
				calculateCurve();
				pp_curves->updn(i)= Handle<RatesCurve>(new ParabolicCurve(*this));

				/*for (vector<Handle<ParabolicCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
				{
				(*it2)->calculateCurve();
				pp_curves->dn_dependents(i)[*it2] = Handle<ParabolicCurve>(new ParabolicCurve(*(*it2)));
				}*/
				(*it)->perturbUp(pp_val / 100.0);
			}


			//dnup
			for (auto it = _instruments.begin(); it != _instruments.end(); it++)
				(*it)->perturbDown(2.0*pp_val/100.0);

			// up
			for (auto it = _instruments.begin(); it != _instruments.end(); it++)
			{
				unsigned int i = it - _instruments.begin();
				(*it)->perturbUp(pp_val / 100.0);
				pp_curves->label(i) = (*it)->getLabel();
				partialClear();
				calculateCurve();
				pp_curves->dnup(i)= Handle<RatesCurve>(new ParabolicCurve(*this));
				(*it)->perturbDown(pp_val / 100.0);

				/*for (vector<Handle<ParabolicCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
				{
				(*it2)->calculateCurve();
				pp_curves->up_dependents(i)[*it2] = Handle<ParabolicCurve>(new ParabolicCurve(*(*it2)));
				}
				(*it)->setTargetRate((*it)->getTargetRate() - pp_val/100.0);*/
			}

			// dn
			for (auto it = _instruments.begin(); it != _instruments.end(); it++)
			{
				unsigned int i = it - _instruments.begin();
				(*it)->perturbDown(pp_val/100.0);
				pp_curves->label(i) = (*it)->getLabel();
				partialClear();
				calculateCurve();
				pp_curves->dndn(i)= Handle<RatesCurve>(new ParabolicCurve(*this));
				(*it)->perturbUp(pp_val / 100.0);

				/*for (vector<Handle<ParabolicCurve>>::iterator it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
				{
				(*it2)->calculateCurve();
				pp_curves->dn_dependents(i)[*it2] = Handle<ParabolicCurve>(new ParabolicCurve(*(*it2)));
				}
				(*it)->setTargetRate((*it)->getTargetRate() + pp_val/100.0);*/
			}


			for (auto it = _instruments.begin(); it != _instruments.end(); it++)
				(*it)->perturbUp(pp_val / 100.0);

		}

		partialClear();
		calculateCurve();

		//recalculateDependents
		for (auto it2 = m_dependentCurves.begin(); it2 != m_dependentCurves.end(); it2++)
		{
			((*it2))->calculateCurve();
		}

		return pp_curves;
	}





} // namespace MCPL