#include"LinearFuturesCurve.h"

#include "numrec/dnrutil.h"


namespace MCPL
{

	void LinearFuturesCurve::calculateDates()
	{


		m_nInputFutures = m_futures.size();

		if ( m_nInputFutures <= 1 )
			MCPL_ERROR("LinearFuturesCurve needs at least two input futures");

		// Set up IMM start, end dates and day count fractions.
		m_starts.clear(); m_starts.resize(m_nInputFutures);
		m_ends.clear(); m_ends.resize(m_nInputFutures);
		m_PDCF.clear(); m_PDCF.resize( m_nInputFutures );

		m_starts[0] = nthIMMDate(m_1stFut, 1, 3).roll(m_hols, 0, true);
		m_ends[0] = nthIMMDate(m_1stFut, 2, 3).roll(m_hols, 0, true);
		m_PDCF[0] = dayCountFrac(m_basis, m_starts[0] , m_ends[0] );

		for ( int i = 1 ; i < m_nInputFutures ; ++i ) 
		{
			m_starts[i] = m_ends[i-1];
			m_ends[i] = nthIMMDate(m_1stFut, i+2, 3).roll(m_hols, 0, true);
			m_PDCF[i] = dayCountFrac(m_basis, m_starts[i] , m_ends[i] );
		}

		m_1stFut = m_starts[0];
		date lastInputFutDate = m_ends.back();
		int nDropFuts = min(4,m_nInputFutures);
		m_lastDrop = ( m_futures[m_futures.size()-(nDropFuts)] - m_futures.back() )/nDropFuts; 

		// Now for the swaps
		//
		// We have to set up synthetic futures which span the gap from the last input future to the end of the last swap.
		//

		date nextIMMdate = lastInputFutDate;
		date lastSwapEndDate = m_swapLastDates.back();

		double lastFutPrice = m_futures.back();

		while ( nextIMMdate < lastSwapEndDate )
		{
			m_starts.push_back( nextIMMdate );

			date endIMMdate = nthIMMDate(nextIMMdate, 2, 3).roll(m_hols, 0, true);
			m_ends.push_back(endIMMdate);

			m_PDCF.push_back(dayCountFrac(m_basis, nextIMMdate , endIMMdate ));

			m_futures.push_back( lastFutPrice );
			nextIMMdate = endIMMdate;
		}	

		long n_swaps = m_swapLastDates.size();
		m_firstUsedSwapIndex = 0;

		if ( n_swaps > 0 )
		{
			// Set up swap dates.

			for ( int i=0 ; i < n_swaps ; ++i )
			{
				if ( m_swapLastDates[i] <= lastInputFutDate )
				{
					m_firstUsedSwapIndex = i+1;
				}
				else
				{
					break;
				}
			}

			// Set up all pricing swaps
			m_swapCashflows.clear();
			m_cashflows.clear();
			m_linFutsPriceDrops.clear();
			m_swapAdjustments.clear();

			//long lastSwapTenor = (long) m_swapTenors.back();
			//long firstSwapTenor = (long) m_swapTenors[m_firstUsedSwapIndex];

			for ( unsigned int j = m_firstUsedSwapIndex ; j < m_swapLastDates.size() ; ++j )
			{

				if ( m_fltPmtsPerYear != 4 )
				{
					m_swapCashflows.push_back( Swap(PAY, m_swapType, m_spot, m_swapLastDates[j], m_spot, 1, .05, 0, m_swapHols, m_ccy) );
				}
				else
				{
					Leg leg = Leg( PAY , MC_FIXED, m_spot, m_swapLastDates[j], 1, .05, m_fixedPmtsPerYear, m_fixedBasis, m_swapHols, ROLL_BACKWARD);
					m_cashflows.push_back( leg );
				}
				m_linFutsPriceDrops.push_back(0.0); 
				m_swapAdjustments.push_back(0);
			}
			

			// setup indeces of corresponding futures for the swaps
			m_linFutsSwapIndex.clear(); // Index of first fut with start date > swap[-1]'s mat date
			m_linFutsSwapIndex.resize(m_swapAdjustments.size() + 1);
			m_linFutsSwapIndex[0] = m_nInputFutures;

			int swapIndex = m_firstUsedSwapIndex;
			for ( unsigned int j = m_nInputFutures ; j < m_ends.size() ; j++ )
			{
				if ( m_starts[j] > m_swapLastDates[swapIndex] )
				{
					m_linFutsSwapIndex[swapIndex - m_firstUsedSwapIndex + 1] = j;
					swapIndex++;
				}
			}

			m_linFutsSwapIndex.back() = j;
		}
	}


	void LinearFuturesCurve::calculateCurve()
	{
		double rate, PDF;
		discountCurve cashCurve;

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );
		cashCurve.set(m_today , 1.0 );
		cashCurve.set(m_spot , spotDF );

		map<date,double>::const_iterator it = m_cashParams.begin();
		++it;
		for (  ; it != m_cashParams.end() ; ++it ) 
		{
			dcf = dayCountFrac( m_basis, m_spot, it->first );

			cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
		}


		discountCurve::clear();
		discountCurve::set(m_today , 1.0 );
		discountCurve::set(m_spot , spotDF );

		discountCurve::set(m_1stFut , cashCurve.get(m_1stFut) ); // set first discount from LIBOR

		for ( int i = 0 ; i < m_nInputFutures ; ++i ) 
		{
			date start = m_starts[i];
			date end = m_ends[i];

			rate = (100.0-m_futures[i])/100.0 - m_InputAdjustments.get(m_starts[i])/10000.0;

			PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
			discountCurve::set(end , get(start) * PDF );
		}

		// The swaps

		m_swapAdjustments.clear();
		for (unsigned int i=0 ; i < m_swapLastDates.size(); i++ ) 
		{
			m_swapAdjustments.push_back(0);
		}

		calcFuturesFromSwaps(0);

			/*for ( unsigned int i=0 ; i < m_swapCashflows.size() ; i++ )
			{
			fitSwapAdjs(i);
			}*/
		if ( m_lastUsedSwapIndex > 0 )
		{
			fitNDimSwapAdjs();
		}
	}

	void LinearFuturesCurve::calcFuturesFromSwaps(int index)
	{
		// Set up the linear interp curve of par rates to get the par points between the input points
		for ( unsigned int i=index ; i < m_swapAdjustments.size() ; i++ )
		{
			if ( !fitFuturesDrops(i) )
				break;
			m_lastUsedSwapIndex = (long) i;
		}

	}

	void LinearFuturesCurve::calculateCurveFromFutures()
	{
		double rate, PDF;
		discountCurve cashCurve;

		double dcf = dayCountFrac(m_basis, m_today, m_spot);
		double spotDF = 1.0 / (1.0 + m_cashParams[m_spot]*dcf );
		cashCurve.set(m_today , 1.0 );
		cashCurve.set(m_spot , spotDF );

		map<date,double>::const_iterator it = m_cashParams.begin();
		++it;
		for (  ; it != m_cashParams.end() ; ++it ) 
		{
			dcf = dayCountFrac( m_basis, m_spot, it->first );

			cashCurve.set(it->first, spotDF/(1+it->second*dcf ) );
		}


		discountCurve::clear();
		discountCurve::set(m_today , 1.0 );
		discountCurve::set(m_spot , spotDF );

		discountCurve::set(m_1stFut , cashCurve.get(m_1stFut) ); // set first discount from LIBOR

		int nFutures = m_futures.size();
		for ( int i = 0 ; i < nFutures ; ++i ) 
		{
			date start = m_starts[i];
			date end = m_ends[i];

			rate = (100.0-m_futures[i])/100.0 - m_InputAdjustments.get(m_starts[i])/10000.0;

			PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
			discountCurve::set(end , get(start) * PDF );
		}

	}



	//
	namespace LinearFuturesCurveFitFn
	{
		int index;
		Handle<LinearFuturesCurve> fitcurve;

		double func_linear(double drop)
		{

			Handle<LinearFuturesCurve> curve = fitcurve;

			for ( int i = fitcurve->m_linFutsSwapIndex[index] ; i < fitcurve->m_linFutsSwapIndex[index+1] ; i++ )
			{
				fitcurve->m_futures[i] = fitcurve->m_futures[i-1] - drop;
				date start = fitcurve->m_starts[i];
				date end = fitcurve->m_ends[i];

				double rate = (100.0-fitcurve->m_futures[i])/100.0 
					- fitcurve->m_InputAdjustments.get(fitcurve->m_starts[i])/10000.0;

				double PDF = 1.0 / ( 1.0 + rate * fitcurve->m_PDCF[i] );
				fitcurve->set(end , fitcurve->get(start) * PDF );
			}

			double swapRate;
			if ( curve->m_fltPmtsPerYear != 4 )
			{
				curve->m_swapCashflows[index].setCurves(curve, curve);
				swapRate = (fitcurve->m_swapCashflows[index]).Solve(0, solveFORCOUPON);
			}
			else
			{
				curve->m_cashflows[index].setCurves(curve, curve);
				curve->m_cashflows[index].updatePaymentsFromCurves();
				date lastDate = curve->m_cashflows[index].getLastDate();

				swapRate = ( curve->get( curve->m_spot ) - curve->get( lastDate ) )
									/ (curve->m_cashflows[index]).BasisPointValue();
			}
			double targetRate = fitcurve->m_parRates[index + fitcurve->m_firstUsedSwapIndex];

			return  fitcurve->m_swapAdjustments[index] + (swapRate - targetRate );
		}
	}

	//
	namespace LinearFuturesCurveMinFn
	{
		int index;
		Handle<LinearFuturesCurve> fitcurve;

		double func_minimise(double adjustment)
		{
			Handle<LinearFuturesCurve> curve = fitcurve;
			int tmpIndex = index;

			fitcurve->m_swapAdjustments[index] = adjustment;
			fitcurve->calcFuturesFromSwaps(index);

			double dDropSum2=0;

			for ( int i=index ; i <= fitcurve->m_lastUsedSwapIndex ; i++ )
			{
				double dDrop;
				if ( i == 0 )
				{
					dDrop = fitcurve->m_linFutsPriceDrops[0] - fitcurve->m_lastDrop;
				}
				else
				{
					dDrop = fitcurve->m_linFutsPriceDrops[i] - fitcurve->m_linFutsPriceDrops[i-1];
				}
				dDropSum2 += dDrop*dDrop;
			}

			double stopFactor = fabs(adjustment) > .005 ? 1000000.0 : 1.0;

			return stopFactor * (sqrt(adjustment*adjustment)  +  fitcurve->m_fitfactor * sqrt(dDropSum2));
		}

	}

	namespace LinearFuturesCurveNDimMinFn
	{
		Handle<LinearFuturesCurve> fitcurve;

		double func_minimise(double adjustments[])
		{
			Handle<LinearFuturesCurve> curve = fitcurve;

			int fi = curve->m_firstUsedSwapIndex;

			for ( int i=0 ; i <= curve->m_lastUsedSwapIndex ; i++ )
				curve->m_swapAdjustments[i] = adjustments[i+1];

			curve->calcFuturesFromSwaps(0);

			double dDropSum2 = 0;
			double adjsSum2 = 0;

			for ( int i=0 ; i <= curve->m_lastUsedSwapIndex ; i++ )
			{
				double dDrop;
				if ( i == 0 )
				{
					dDrop = curve->m_linFutsPriceDrops[0] - curve->m_lastDrop;
				}
				else
				{
					dDrop = curve->m_linFutsPriceDrops[i] - curve->m_linFutsPriceDrops[i-1];
				}
				dDropSum2 += dDrop*dDrop;
				double stopFactor = fabs(adjustments[i+1]) > curve->m_swapTolerances[i + fi] ? 1000000.0 : 1.0;
				adjsSum2 += stopFactor * adjustments[i+1]*adjustments[i+1];
			}


			return sqrt(adjsSum2)  +  curve->m_fitfactor * sqrt(dDropSum2);
		}

	}

	//
	bool LinearFuturesCurve::fitFuturesDrops(int index)
	{
		LinearFuturesCurveFitFn::index = index;
		LinearFuturesCurveFitFn::fitcurve = Handle<LinearFuturesCurve>(this, null_deleter());

		double x1=-.1;
		double x2=.1;

		//double drop=0;
		//if ( NUMREC::zbrac(LinearFuturesCurveFitFn::func_linear, &x1, &x2) == 1 )
		//{
		////	drop =  NUMREC::zriddr( LinearFuturesCurveFitFn::func_linear , x1, x2, .001 );
		////	drop =  NUMREC::zbrent( LinearFuturesCurveFitFn::func_linear , x1, x2, .01 );
		//	drop = linearFitter( LinearFuturesCurveFitFn::func_linear , x1, x2, .00001 );
		////	drop = quadraticFitter( LinearFuturesCurveFitFn::func_linear , x1, x2, .00001 );
		//}
		//else
		//{
		//	return false;
		//}


		double drop = linearFitter( LinearFuturesCurveFitFn::func_linear , x1, x2, .00001 );
		//double drop = quadraticFitter( LinearFuturesCurveFitFn::func_linear , x1, x2, .00001 );

		m_linFutsPriceDrops[index] = drop;

		// Now fix the curve after the fitting!
		for ( int i = m_linFutsSwapIndex[index] ; i < m_linFutsSwapIndex[index+1] ; i++ )
		{
			m_futures[i] = m_futures[i-1] - drop;
			date start = m_starts[i];
			date end = m_ends[i];

			double rate = (100.0-m_futures[i])/100.0 - m_InputAdjustments.get(m_starts[i])/10000.0;

			double PDF = 1.0 / ( 1.0 + rate * m_PDCF[i] );
			set(end , get(start) * PDF );
		}

		return true;
	}

	//
	bool LinearFuturesCurve::fitSwapAdjs(int index)
	{
		if ( m_fitfactor == 0 )
		{
			m_swapAdjustments[index] = 0;
			return true;
		}
		else
		{

			LinearFuturesCurveMinFn::index = index;
			LinearFuturesCurveMinFn::fitcurve = Handle<LinearFuturesCurve>(this, null_deleter());

			double x1=-.0005;
			double x2=.0005;
			double x3, f1, f2, f3, xmin;

			NUMREC::mnbrak(&x1, &x2, &x3, &f1, &f2, &f3, LinearFuturesCurveMinFn::func_minimise);

			//NUMREC::golden(x1, x2, x3, LinearFuturesCurveMinFn::func_minimise, .01, &xmin);
			NUMREC::brent(x1, x2, x3, LinearFuturesCurveMinFn::func_minimise, .01, &xmin);

			m_swapAdjustments[index] = xmin;

			// Now fix the curve after the fitting!
			return fitFuturesDrops(index);
		}
	}

	//
	bool LinearFuturesCurve::fitNDimSwapAdjs()
	{
		if ( m_fitfactor == 0 )
		{
			//m_swapAdjustments[index] = 0;
			return true;
		}
		else
		{

			LinearFuturesCurveNDimMinFn::fitcurve = Handle<LinearFuturesCurve>(this, null_deleter());

			double *x, *y, **p;
			int nDims = m_lastUsedSwapIndex+1;

			x = NUMREC::vector(1,nDims);
			y = NUMREC::vector(1,nDims+1);
			p = NUMREC::matrix(1,nDims+1 , 1,nDims);

			for ( int i=1; i <= nDims+1 ; i++ )
			{
				for ( int j=1 ; j <= nDims ; j++ )
				{
					x[j] = p[i][j] = (i == (j+1) ? 0.00001 : 0.0);
				}
				y[i] = LinearFuturesCurveNDimMinFn::func_minimise(x);
			}

			int nfunc;
			NUMREC::amoeba(p, y, nDims, 1.0e-4, LinearFuturesCurveNDimMinFn::func_minimise, &nfunc);

			for ( int j=1 ; j <= nDims ; j++ )
			{
				m_swapAdjustments[j-1] = p[1][j];
			}

			//double fRet;
			//NUMREC::powell(x, p, nDims, 1.0e-4, &nfunc, &fRet, LinearFuturesCurveNDimMinFn::func_minimise);
			//for ( int j=1 ; j <= nDims ; j++ )
			//{
			//	m_swapAdjustments[j-1] = x[j];
			//}

			// Now fix the curve after the fitting!
			return fitFuturesDrops(0);
		}
	}



	void LinearFuturesCurve::set_currency_defaults(CURRENCY ccy)
	{
		m_ccy = ccy;
		this->setCurrency(ccy);

		switch(m_ccy)
		{
		case USD:
			set_currency_defaults(ccy, SB3);
			break;
		case EUR:
			set_currency_defaults(ccy, AB6);
			break;
		case JPY:
			set_currency_defaults(ccy, SB6);
			break;
		case GBP:
			set_currency_defaults(ccy, SB6);
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}

	}

	void LinearFuturesCurve::set_currency_defaults(CURRENCY ccy, SwapType type)
	{

		vanillaSwapParams(ccy, type, m_fixedPmtsPerYear, m_fltPmtsPerYear, m_fixedBasis, m_basis) ;

		m_swapType = type;
		m_ccy = ccy;

		switch(ccy)
		{
		case USD:
			m_swapHols = HOLIDAYCAL(UK | USA);
			m_hols = UK;
			break;
		case EUR:
			m_swapHols = EUTARG;
			m_hols = EUTARG;
			break;
		case JPY:
			m_swapHols = JP;
			m_hols = UK;
			break;
		case GBP:
			m_swapHols = UK;
			m_hols = UK;
			break;
		default:
			mcpl_error("Currency not yet supported in ApolloCurve");
		}
	}


	bool LinearFuturesCurve::cmpvecs( const vector<double> & v1, const vector<double> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}
	//
	bool LinearFuturesCurve::cmpvecs( const vector<date> & v1, const vector<date> & v2)
	{
		int len;
		if ( (len = v1.size()) != v2.size() ) return false;
		else 
		{
			bool test = true;
			for ( int i=0 ; (i < len) && test ; ++i )
				if (v1[i] != v2[i]) 
				{
					test = false;
					break;
				}
				return test;
		}
		return false; // should not get here.
	}
	//
	bool LinearFuturesCurve::cmpmaps( const map<date,double> & v1, map<date,double> & v2)
	{
		if ( v1.size() != v2.size() ) return false;
		else 
		{
			bool test = true;
			map<date,double>::const_iterator it1 = v1.begin();
			map<date,double>::const_iterator it2 = v2.begin();
			while ( test && ( it1 != v1.end() ) && ( it2 != v2.end() ) )
			{
				if ( it1->first != it2->first ) 
					test = false;

				++it1;
				++it2;
			}		
			return test;
		}
		return false; // should not get here.
	}

	//void LinearFuturesCurve::generateSwapVectors()
	//{
	//	m_parRates.clear();
	//	m_swapTenors.clear();
	//	m_swapLastDates.clear();

	//	for ( map<date,double>::const_iterator it = m_swapParams.begin() ; it != m_swapParams.end() ; ++it )
	//	{
	//		double tenor = dayCountFrac(_30_360f,  m_spot, it->first );

	//		m_parRates.push_back( it->second );
	//		m_swapTenors.push_back( tenor );
	//		m_swapLastDates.push_back( it->first );
	//	}
	//}

	//void LinearFuturesCurve::generateSwapRateVector()
	//{

	//	for ( unsigned int i=0 ; i < m_swapLastDates.size() ; ++i )
	//	{
	//		m_parRates[i] = m_swapParams[ m_swapLastDates[i] ];
	//	}
	//}

	void LinearFuturesCurve::create( const vector<double> & futures, const LinearCurve & adjustments, 
		const vector<date> swapDates, const vector<double> & swapRates, const vector<double> & swapTolerances,
		const SwapType sType,
		date & today, date & firstFut, const map<date,double> & cashParams, CURRENCY ccy, double fitfactor)
	{
		m_fitfactor = fitfactor;
		if ( (m_today != today) 
			|| (m_1stFut != firstFut) 
			|| futures.size() != m_futures.size() 
			|| ( ccy != m_ccy )
			|| sType != m_swapType 
			|| !cmpvecs(swapDates, m_swapLastDates) 
			|| !cmpmaps(cashParams, m_cashParams)) 
		{
			set_currency_defaults(ccy, sType);
			m_today = today;
			m_spot = spot(today, ccy);
			m_1stFut = firstFut;
			m_futures = futures;
			m_InputAdjustments = adjustments;
			//m_stub_curve = stub;
			m_swapType = sType;
			m_swapLastDates = swapDates;
			m_parRates = swapRates;
			m_swapTolerances = swapTolerances;
			m_cashParams = cashParams;
			//generateSwapVectors();
			clear();
			calculateDates();
			calculateCurve();
		} 
		else 
		{
			m_futures = futures;
			m_InputAdjustments = adjustments;
			//m_stub_curve = stub;
			//m_swapParams = swaps;
			m_cashParams = cashParams;
			m_parRates = swapRates;
			m_swapTolerances = swapTolerances;
			clear();
			calculateCurve();
		}
	}



	// generate PP curves from the futures curve. pp_val is the amount of perturbation applied.
	Handle<PPCurves> LinearFuturesCurve::create_PPCurves( double pp_val )
	{
		Handle<PPCurves> pp_curves = Handle<PPCurves>(new PPCurves());

		int nHedges =  m_futures.size() + m_cashParams.size(); 
		pp_curves->resize( nHedges ); 
		pp_curves->set_ppsize( pp_val/100.0 ); // set the perturb size in factor (i.e. 1 = 1%)
		
		pp_curves->base() = Handle<swapData>(new LinearFuturesCurve(*this));

		unsigned int i=0;
		// up
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->label(i) = "cash " + (string) it->first;
			pp_curves->up(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] -= pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->label(i) = "Fut " + (string) m_starts[j];
			pp_curves->up(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			m_futures[j] += pp_val;
		}


		// dn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dn(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dn(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			m_futures[j] -= pp_val;
		}


		//upup
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			m_futures[j] -= pp_val;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			it->second += pp_val/100.0;

		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->upup(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] -= pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->upup(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			m_futures[j] += pp_val;
		}

		// updn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->updn(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->updn(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			m_futures[j] -= pp_val;
		}


		//dnup
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			m_futures[j] += 2.0*pp_val;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			it->second -= 2.0*pp_val/100.0;

		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second += pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dnup(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			it->second -= pp_val/100.0;
		}
		for ( unsigned int j=0 ; j < m_futures.size() ; ++j )
		{
			m_futures[j] -= pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dnup(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			m_futures[j] += pp_val;
		}

		// dndn
		i=0;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
		{
			it->second -= pp_val/100.0;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dndn(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			it->second += pp_val/100.0;
		}
		for ( unsigned int j=0  ; j < m_futures.size() ; ++j ) 
		{
			m_futures[j] += pp_val;
			partialClear();
			calculateCurveFromFutures();
			pp_curves->dndn(i++)= Handle<swapData>(new LinearFuturesCurve(*this));
			m_futures[j] -= pp_val;
		}


		for ( unsigned int j=0 ; j < m_futures.size() ; ++j ) 
			m_futures[j] -= pp_val;
		for ( map<date,double>::iterator it = m_cashParams.begin() ; it != m_cashParams.end() ; ++it )
			it->second += pp_val/100.0;

		partialClear();
		calculateCurveFromFutures();

		return pp_curves;

	}





} // namespace MCPL