#include "Globals.h"

namespace MCPL
{


	namespace Globals
	{	

		static bool MatchApollo = true;

		void SetMatchApollo(bool value)
		{
			MatchApollo = value;
		}

		bool GetMatchApollo()
		{
			return MatchApollo;
		}




		static bool AdjustDates = true;

		void SetAdjustDates(bool value)
		{
			AdjustDates = value;
		}

		bool GetAdjustDates()
		{
			return AdjustDates;
		}


	}

}
